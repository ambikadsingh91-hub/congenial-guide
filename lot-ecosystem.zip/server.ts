import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import { WebSocket, WebSocketServer } from 'ws';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  getDocs,
  runTransaction,
  orderBy,
  limit,
} from 'firebase/firestore';
import firebaseConfig from './firebase-applet-config.json';
import multer from 'multer';
import { setupShortsRoutes } from './src/server/shortsRouter';
import { setupBankRoutes } from './src/server/bankRouter';
import { setupJobManagerRoutes } from './src/server/jobManagerRouter';
import { setupAppStoreRoutes } from './src/server/appStoreRouter';
import {
  savePersistentMedia,
  rehydrateMediaFromFirestore,
  streamMediaFile,
} from './src/server/mediaStorage';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase server connection
const firebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// In-memory active session cache backed by token validation & Firestore persistence
interface SessionData {
  userId: string;
  username: string;
  isAdmin: boolean;
  expiresAt: number;
  createdAt?: string;
}
const sessionStore = new Map<string, SessionData>();

async function getSession(token: string): Promise<SessionData | null> {
  if (!token || token === 'undefined' || token === 'null') return null;
  const cached = sessionStore.get(token);
  if (cached) {
    if (cached.expiresAt > Date.now()) {
      return cached;
    } else {
      sessionStore.delete(token);
      await deleteDoc(doc(db, 'sessions', token)).catch(() => {});
      return null;
    }
  }

  // Not in memory cache (e.g. dev server restarted) -> check Firestore sessions collection
  try {
    const snap = await getDoc(doc(db, 'sessions', token));
    if (snap.exists()) {
      const data = snap.data() as SessionData;
      if (data && data.expiresAt > Date.now()) {
        sessionStore.set(token, data);
        return data;
      } else {
        await deleteDoc(doc(db, 'sessions', token)).catch(() => {});
      }
    }
  } catch (e) {
    console.error('Session lookup error:', e);
  }
  return null;
}

async function saveSession(token: string, sessionData: SessionData): Promise<void> {
  sessionStore.set(token, sessionData);
  try {
    await setDoc(doc(db, 'sessions', token), sessionData);
  } catch (e) {
    console.error('Session save error:', e);
  }
}

async function removeSession(token: string): Promise<void> {
  sessionStore.delete(token);
  try {
    await deleteDoc(doc(db, 'sessions', token));
  } catch (e) {
    console.error('Session delete error:', e);
  }
}

// Invalidate all active sessions and WebSockets for all admin accounts across all devices
async function logoutAdminFromAllDevices(): Promise<{ success: boolean; loggedOutSessionsCount: number; adminUids: string[] }> {
  console.log('[Auth] Initiating global logout for admin account across all devices...');
  const adminUids = new Set<string>();

  // 1. Collect all admin UIDs from 'admins' collection
  try {
    const adminDocs = await getDocs(collection(db, 'admins'));
    adminDocs.forEach((d) => adminUids.add(d.id));
  } catch (e) {
    console.warn('[Auth] admins collection lookup warning:', e);
  }

  // 2. Collect all users with isAdmin == true or username in ('virat', 'admin')
  try {
    const usersSnap = await getDocs(collection(db, 'users'));
    usersSnap.forEach((d) => {
      const u = d.data();
      const uname = (u.username || '').toLowerCase();
      if (u.isAdmin || uname === 'virat' || uname === 'admin') {
        adminUids.add(d.id);
      }
    });
  } catch (e) {
    console.warn('[Auth] users lookup warning:', e);
  }

  let loggedOutCount = 0;

  // 3. Clear from in-memory sessionStore
  for (const [token, session] of sessionStore.entries()) {
    const uname = (session.username || '').toLowerCase();
    if (session.isAdmin || adminUids.has(session.userId) || uname === 'virat' || uname === 'admin') {
      sessionStore.delete(token);
      loggedOutCount++;
    }
  }

  // 4. Delete all matching sessions from Firestore 'sessions' collection
  try {
    const sessionsSnap = await getDocs(collection(db, 'sessions'));
    const deletePromises: Promise<any>[] = [];
    sessionsSnap.forEach((docSnap) => {
      const s = docSnap.data();
      const uname = (s.username || '').toLowerCase();
      if (s.isAdmin || adminUids.has(s.userId) || uname === 'virat' || uname === 'admin') {
        deletePromises.push(deleteDoc(docSnap.ref));
        loggedOutCount++;
      }
    });
    await Promise.all(deletePromises);
  } catch (e) {
    console.warn('[Auth] Firestore sessions purge warning:', e);
  }

  // 5. Force disconnect all open WebSockets for any admin user
  for (const uid of adminUids) {
    const set = userSockets.get(uid);
    if (set) {
      for (const ws of set) {
        try {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              event: 'auth:revoked',
              reason: 'admin_logged_out_all_devices',
              message: 'Administrator account has been logged out from all devices.',
            }));
            ws.close(4001, 'Admin logged out from all devices');
          }
        } catch {}
      }
      userSockets.delete(uid);
    }
  }

  console.log(`[Auth] Admin logout complete. Invalidated ${loggedOutCount} session(s) for admin IDs:`, Array.from(adminUids));
  return { success: true, loggedOutSessionsCount: loggedOutCount, adminUids: Array.from(adminUids) };
}

// Realtime WebSockets: Track connected users and handle live events
const userSockets = new Map<string, Set<WebSocket>>();
const socketToUser = new Map<WebSocket, string>();

function registerUserSocket(userId: string, ws: WebSocket) {
  if (!userSockets.has(userId)) {
    userSockets.set(userId, new Set());
  }
  userSockets.get(userId)!.add(ws);
  socketToUser.set(ws, userId);
  broadcastPresence(userId, true);
}

function unregisterUserSocket(ws: WebSocket) {
  const userId = socketToUser.get(ws);
  if (userId) {
    socketToUser.delete(ws);
    const set = userSockets.get(userId);
    if (set) {
      set.delete(ws);
      if (set.size === 0) {
        userSockets.delete(userId);
        broadcastPresence(userId, false);
      }
    }
  }
}

function sendToUser(userId: string, event: string, payload: any) {
  const set = userSockets.get(userId);
  if (set && set.size > 0) {
    const data = JSON.stringify({ event, ...payload });
    for (const ws of set) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    }
    return true;
  }
  return false;
}

function broadcastPresence(userId: string, isOnline: boolean) {
  const data = JSON.stringify({ event: 'presence:update', userId, isOnline });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  }
}

function isUserOnline(userId: string): boolean {
  const set = userSockets.get(userId);
  return !!set && set.size > 0;
}

wss.on('connection', async (ws: WebSocket, req) => {
  try {
    const url = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`);
    const token = url.searchParams.get('token');
    if (token) {
      const session = await getSession(token);
      if (session && session.expiresAt > Date.now()) {
        registerUserSocket(session.userId, ws);
        ws.send(JSON.stringify({ event: 'auth:success', userId: session.userId }));
      }
    }
  } catch {}

  ws.on('message', async (messageRaw: any) => {
    try {
      const data = JSON.parse(messageRaw.toString());
      if (data.type === 'auth') {
        const token = data.token;
        if (token) {
          const session = await getSession(token);
          if (session && session.expiresAt > Date.now()) {
            registerUserSocket(session.userId, ws);
            ws.send(JSON.stringify({ event: 'auth:success', userId: session.userId }));
          }
        }
      } else if (data.type === 'call:signal') {
        const senderId = socketToUser.get(ws);
        if (senderId && data.to) {
          sendToUser(data.to, 'call:signal', { from: senderId, signal: data.signal });
        }
      } else if (data.type === 'typing') {
        const senderId = socketToUser.get(ws);
        if (senderId && data.to) {
          sendToUser(data.to, 'chat:typing', { from: senderId, isTyping: !!data.isTyping });
        }
      }
    } catch {}
  });

  ws.on('close', () => {
    unregisterUserSocket(ws);
  });

  ws.on('error', () => {
    unregisterUserSocket(ws);
  });
});


// Helper to authenticate requests
async function authMiddleware(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    let token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;
    if ((!token || token === 'undefined' || token === 'null') && req.cookies && req.cookies.lot_session) {
      token = req.cookies.lot_session;
    }

    if (!token || token === 'undefined' || token === 'null') {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const session = await getSession(token);
    if (!session || session.expiresAt < Date.now()) {
      if (token) {
        await removeSession(token);
      }
      return res.status(401).json({ error: 'Session expired or invalid' });
    }

    // Refresh user from Firestore to get updated state (ban check, balance, admin status)
    const userDocRef = doc(db, 'users', session.userId);
    const userSnap = await getDoc(userDocRef);
    if (!userSnap.exists()) {
      await removeSession(token);
      return res.status(401).json({ error: 'User does not exist' });
    }

    const userData = userSnap.data();
    if (userData.isBanned) {
      return res.status(403).json({ error: 'Account has been suspended' });
    }

    (req as any).user = {
      id: session.userId,
      username: userData.username,
      usernameLower: userData.usernameLower,
      isAdmin: !!userData.isAdmin,
      lotBalance: userData.lotBalance || 0,
      vipBadge: userData.vipBadge || undefined,
      avatarUrl: userData.avatarUrl || undefined,
      token,
    };

    next();
  } catch (err: any) {
    console.error('Auth middleware error:', err);
    res.status(500).json({ error: 'Internal server error during authentication' });
  }
}

// Admin only middleware
function adminMiddleware(req: Request, res: Response, next: NextFunction) {
  if (!(req as any).user || !(req as any).user.isAdmin) {
    return res.status(403).json({ error: 'Administrator access required' });
  }
  next();
}

// Multer setup for persistent messaging & media attachments (JPG, PNG, WEBP, GIF, MP4)
const mediaUploadsDir = path.join(process.cwd(), 'uploads', 'media');
if (!fs.existsSync(mediaUploadsDir)) {
  fs.mkdirSync(mediaUploadsDir, { recursive: true });
}

const mediaStorageConfig = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, mediaUploadsDir);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.bin';
    const cleanBase = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 30);
    const unique = `${Date.now()}_${crypto.randomBytes(6).toString('hex')}_${cleanBase}${ext}`;
    cb(null, unique);
  },
});

const mediaUpload = multer({
  storage: mediaStorageConfig,
  limits: { fileSize: 25 * 1024 * 1024 }, // 25MB max
  fileFilter: (_req, file, cb) => {
    const allowed = [
      'image/jpeg',
      'image/png',
      'image/webp',
      'image/gif',
      'video/mp4',
      'video/webm',
      'video/quicktime',
    ];
    if (allowed.includes(file.mimetype) || file.mimetype.startsWith('image/') || file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file format. Please upload an image (JPG, PNG, WEBP), GIF, or video.'));
    }
  },
});

// Serve uploaded shorts videos with HTTP 206 Partial Content and Cloud Firestore chunk rehydration
// CRITICAL BUG FIX: Never silently replace creator's video with lot_default_short.mp4 or placeholder audio!
app.get('/uploads/shorts/:filename', async (req: Request, res: Response) => {
  try {
    const filename = req.params.filename;
    const filePath = path.join(process.cwd(), 'uploads', 'shorts', filename);

    if (!fs.existsSync(filePath)) {
      // Rehydrate video from Cloud Firestore binary storage chunks
      const rehydrated = await rehydrateMediaFromFirestore(db, filename, filePath);
      if (!rehydrated) {
        return res.status(404).json({ error: 'Video not found or has been deleted by creator' });
      }
    }

    const ext = path.extname(filename).toLowerCase();
    const mimeType = ext === '.webm' ? 'video/webm' : ext === '.mov' ? 'video/quicktime' : ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg' : ext === '.png' ? 'image/png' : 'video/mp4';
    streamMediaFile(req, res, filePath, mimeType);
  } catch (err) {
    console.error('Error streaming shorts video:', err);
    res.status(500).json({ error: 'Failed to stream video' });
  }
});

// Serve uploaded App Store packages, icons, and screenshots with Cloud Firestore chunk rehydration
app.get('/uploads/apps/:filename', async (req: Request, res: Response) => {
  try {
    const filename = req.params.filename;
    const filePath = path.join(process.cwd(), 'uploads', 'apps', filename);

    if (!fs.existsSync(filePath)) {
      // Rehydrate app package, icon, or screenshot from Cloud Firestore binary chunks
      const rehydrated = await rehydrateMediaFromFirestore(db, filename, filePath);
      if (!rehydrated) {
        return res.status(404).json({ error: 'App asset not found or has been deleted' });
      }
    }

    const ext = path.extname(filename).toLowerCase();
    const mimeType =
      ext === '.apk'
        ? 'application/vnd.android.package-archive'
        : ext === '.aab'
        ? 'application/octet-stream'
        : ext === '.png'
        ? 'image/png'
        : ext === '.webp'
        ? 'image/webp'
        : ext === '.jpg' || ext === '.jpeg'
        ? 'image/jpeg'
        : 'application/octet-stream';

    streamMediaFile(req, res, filePath, mimeType);
  } catch (err) {
    console.error('Error streaming app store asset:', err);
    res.status(500).json({ error: 'Failed to stream app asset' });
  }
});

// Serve media attachments (images, native keyboard GIFs, chat media)
app.get('/api/media/:fileId/:filename', async (req: Request, res: Response) => {
  try {
    const { fileId, filename } = req.params;
    const filePath = path.join(mediaUploadsDir, filename);

    if (!fs.existsSync(filePath)) {
      // Rehydrate from Cloud Firestore binary storage chunks
      const rehydrated = await rehydrateMediaFromFirestore(db, fileId, filePath);
      if (!rehydrated) {
        return res.status(404).json({ error: 'Media attachment not found' });
      }
    }

    const ext = path.extname(filename).toLowerCase();
    const mimeType =
      ext === '.gif'
        ? 'image/gif'
        : ext === '.png'
        ? 'image/png'
        : ext === '.webp'
        ? 'image/webp'
        : ext === '.mp4'
        ? 'video/mp4'
        : 'image/jpeg';
    streamMediaFile(req, res, filePath, mimeType);
  } catch (err) {
    console.error('Error serving media attachment:', err);
    res.status(500).json({ error: 'Failed to stream media attachment' });
  }
});

// POST /api/media/upload - Persistent media upload for messaging and Shorts comments
app.post('/api/media/upload', authMiddleware, mediaUpload.single('file'), async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: 'No media file provided' });
    }

    const fileBuffer = fs.readFileSync(file.path);
    const fileId = 'media_' + crypto.randomUUID();

    // Persist to both disk and Cloud Firestore binary chunks
    const persistent = await savePersistentMedia(db, {
      fileId,
      filename: file.filename,
      mimeType: file.mimetype,
      buffer: fileBuffer,
      subfolder: 'media',
      uploaderId: user.id,
    });

    res.json({
      success: true,
      url: persistent.url,
      fileId: persistent.fileId,
      filename: file.filename,
      originalName: file.originalname,
      mimeType: file.mimetype,
      size: file.size,
    });
  } catch (err: any) {
    console.error('Media upload error:', err);
    res.status(500).json({ error: err.message || 'Failed to upload media attachment' });
  }
});

// Serve static uploads for thumbnails/images
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')), (_req, res) => {
  res.status(404).json({ error: 'Asset not found' });
});

// Initialize LOT Shorts API routes & ecosystem hooks
setupShortsRoutes(app, {
  db,
  authMiddleware,
  adminMiddleware,
  sendToUser,
  sessionStore,
  getSession,
});

// Initialize LOT Bank API routes (Deposit, Withdraw, 7-Day Loan System, Overdue Auto-Deductions)
setupBankRoutes(app, {
  db,
  authMiddleware,
  sendToUser,
});

// Initialize Business & Government Job Manager API routes
setupJobManagerRoutes(app, {
  db,
  authMiddleware,
  sendToUser,
});

// Initialize LOT App Store API routes (Android APK publishing, download stream, permanent LOT purchases)
setupAppStoreRoutes(app, {
  db,
  authMiddleware,
  adminMiddleware,
  sendToUser,
});

// ----------------------------------------------------
// Stock Instruments & Market Simulation Engine
// ----------------------------------------------------
interface StockData {
  id: string;
  symbol: string;
  name: string;
  category: string;
  currentPrice: number;
  previousPrice: number;
  dayHigh: number;
  dayLow: number;
  change24h: number;
  volume24h: number;
  sparkline: number[];
}

const DEFAULT_STOCKS: StockData[] = [
  {
    id: 'LOTX',
    symbol: 'LOTX',
    name: 'LOT Exchange Core',
    category: 'Ecosystem',
    currentPrice: 154.2,
    previousPrice: 148.5,
    dayHigh: 158.0,
    dayLow: 147.2,
    change24h: 3.84,
    volume24h: 124800,
    sparkline: [148.5, 150.1, 149.2, 152.4, 151.8, 155.0, 153.2, 154.2],
  },
  {
    id: 'CYBR',
    symbol: 'CYBR',
    name: 'Cybernetics Neural Labs',
    category: 'Tech & Implants',
    currentPrice: 89.4,
    previousPrice: 92.1,
    dayHigh: 94.0,
    dayLow: 87.5,
    change24h: -2.93,
    volume24h: 84300,
    sparkline: [92.1, 91.0, 93.4, 90.2, 88.9, 87.5, 88.2, 89.4],
  },
  {
    id: 'NEXU',
    symbol: 'NEXU',
    name: 'Nexus Gaming Realms',
    category: 'Metaverse & Gaming',
    currentPrice: 245.8,
    previousPrice: 232.0,
    dayHigh: 252.0,
    dayLow: 230.5,
    change24h: 5.95,
    volume24h: 215400,
    sparkline: [232.0, 235.0, 238.4, 240.1, 244.2, 241.0, 248.5, 245.8],
  },
  {
    id: 'VOID',
    symbol: 'VOID',
    name: 'Void Armory & Foundry',
    category: 'Weapons & Relics',
    currentPrice: 42.6,
    previousPrice: 41.0,
    dayHigh: 45.0,
    dayLow: 40.2,
    change24h: 3.9,
    volume24h: 62000,
    sparkline: [41.0, 41.5, 42.0, 40.8, 43.1, 44.0, 41.8, 42.6],
  },
  {
    id: 'TITN',
    symbol: 'TITN',
    name: 'Titan Quantum Rigging',
    category: 'Hardware & Compute',
    currentPrice: 312.5,
    previousPrice: 318.0,
    dayHigh: 322.0,
    dayLow: 308.0,
    change24h: -1.73,
    volume24h: 178900,
    sparkline: [318.0, 316.5, 319.2, 314.0, 310.5, 311.2, 315.0, 312.5],
  },
];

let liveStocks = [...DEFAULT_STOCKS];

// Simulate small micro-volatility every 8 seconds
setInterval(() => {
  liveStocks = liveStocks.map((stock) => {
    const deltaPercent = (Math.random() - 0.49) * 0.015; // -0.7% to +0.8%
    const newPrice = Math.max(1, +(stock.currentPrice * (1 + deltaPercent)).toFixed(2));
    const newHigh = Math.max(stock.dayHigh, newPrice);
    const newLow = Math.min(stock.dayLow, newPrice);
    const change = +(((newPrice - stock.previousPrice) / stock.previousPrice) * 100).toFixed(2);
    const newSpark = [...stock.sparkline.slice(1), newPrice];

    return {
      ...stock,
      currentPrice: newPrice,
      dayHigh: newHigh,
      dayLow: newLow,
      change24h: change,
      volume24h: stock.volume24h + Math.floor(Math.random() * 50),
      sparkline: newSpark,
    };
  });
}, 8000);

// ----------------------------------------------------
// 1. AUTHENTICATION & SHARED ACCOUNT SYSTEM
// ----------------------------------------------------

// POST /api/auth/register
app.post('/api/auth/register', async (req: Request, res: Response) => {
  try {
    const { username, password, confirmPassword } = req.body;

    if (!username || typeof username !== 'string' || username.trim().length < 3 || username.trim().length > 30) {
      return res.status(400).json({ error: 'Username must be between 3 and 30 characters.' });
    }

    const cleanUsername = username.trim();
    if (!/^[a-zA-Z0-9_]+$/.test(cleanUsername)) {
      return res.status(400).json({ error: 'Username can only contain letters, numbers, and underscores.' });
    }

    if (!password || typeof password !== 'string' || password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }

    const usernameLower = cleanUsername.toLowerCase();

    // Check username uniqueness via transaction
    const usernameDocRef = doc(db, 'usernames', usernameLower);
    const configDocRef = doc(db, 'system_config', 'admin_bootstrap');

    const result = await runTransaction(db, async (tx) => {
      const existingUser = await tx.get(usernameDocRef);
      if (existingUser.exists()) {
        throw new Error('USERNAME_TAKEN');
      }

      // Check Virat Administrator Bootstrap
      let isViratAdmin = false;
      if (usernameLower === 'virat') {
        const bootstrapSnap = await tx.get(configDocRef);
        if (bootstrapSnap.exists() && bootstrapSnap.data().bootstrapped) {
          throw new Error('USERNAME_TAKEN');
        }
        isViratAdmin = true;
      }

      const userId = 'usr_' + crypto.randomUUID();
      const passwordHash = await bcrypt.hash(password, 10);
      const now = new Date().toISOString();
      const initialBalance = 0; // Starter balance set to 0 LOT

      // Reserve username
      tx.set(usernameDocRef, {
        username: cleanUsername,
        uid: userId,
        reservedAt: now,
      });

      // Create User doc
      const userRef = doc(db, 'users', userId);
      tx.set(userRef, {
        id: userId,
        username: cleanUsername,
        usernameLower,
        passwordHash,
        lotBalance: initialBalance,
        isAdmin: isViratAdmin,
        isBanned: false,
        createdAt: now,
        lastLoginAt: now,
      });

      // If Virat, mark admin registry and bootstrap config
      if (isViratAdmin) {
        tx.set(configDocRef, {
          bootstrapped: true,
          adminUid: userId,
          bootstrappedAt: now,
        });
        tx.set(doc(db, 'admins', userId), {
          uid: userId,
          username: cleanUsername,
          grantedAt: now,
        });
      }

      // Initial welcoming transaction in ledger if initialBalance > 0
      if (initialBalance > 0) {
        const txId = 'tx_' + crypto.randomUUID();
        tx.set(doc(db, 'transactions', txId), {
          id: txId,
          userId,
          type: 'admin_adjustment',
          amount: initialBalance,
          balanceAfter: initialBalance,
          referenceId: 'welcome_grant',
          description: 'Welcome to LOT Ecosystem grant',
          createdAt: now,
        });
      }

      // Notification
      const notifId = 'notif_' + crypto.randomUUID();
      tx.set(doc(db, 'notifications', notifId), {
        id: notifId,
        userId,
        title: 'Welcome to LOT Ecosystem!',
        message: 'Your account has been created with 0 LOT starter balance. Earn LOT through minigames, trading, and promo codes!',
        type: 'announcement',
        read: false,
        createdAt: now,
      });

      return {
        id: userId,
        username: cleanUsername,
        lotBalance: initialBalance,
        isAdmin: isViratAdmin,
        createdAt: now,
      };
    });

    // Create session (persisted in Firestore for seamless refresh & browser restarts)
    const token = crypto.randomBytes(32).toString('hex');
    const sessionData: SessionData = {
      userId: result.id,
      username: result.username,
      isAdmin: result.isAdmin,
      expiresAt: Date.now() + 90 * 24 * 60 * 60 * 1000, // 90 days
      createdAt: result.createdAt,
    };
    await saveSession(token, sessionData);

    res.cookie('lot_session', token, {
      httpOnly: true,
      secure: false, // in preview iframe
      sameSite: 'lax',
      maxAge: 90 * 24 * 60 * 60 * 1000,
    });

    res.json({
      success: true,
      token,
      user: { ...result, token },
      message: result.isAdmin ? 'Welcome Virat! Administrator privileges successfully established.' : 'Account registered successfully.',
    });
  } catch (err: any) {
    if (err.message === 'USERNAME_TAKEN') {
      return res.status(409).json({ error: 'This username is already taken. Please choose another.' });
    }
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Registration failed due to a server error.' });
  }
});

// POST /api/auth/login
app.post('/api/auth/login', async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Incorrect username or password.' });
    }

    const usernameLower = username.trim().toLowerCase();
    const usernameDocRef = doc(db, 'usernames', usernameLower);
    const usernameSnap = await getDoc(usernameDocRef);

    if (!usernameSnap.exists()) {
      return res.status(401).json({ error: 'Incorrect username or password.' });
    }

    const { uid } = usernameSnap.data();
    const userDocRef = doc(db, 'users', uid);
    const userSnap = await getDoc(userDocRef);

    if (!userSnap.exists()) {
      return res.status(401).json({ error: 'Incorrect username or password.' });
    }

    const userData = userSnap.data();
    if (userData.isBanned) {
      return res.status(403).json({ error: 'Account has been suspended. Please contact Virat.' });
    }

    const matches = await bcrypt.compare(password, userData.passwordHash);
    if (!matches) {
      return res.status(401).json({ error: 'Incorrect username or password.' });
    }

    // Update lastLoginAt
    await updateDoc(userDocRef, {
      lastLoginAt: new Date().toISOString(),
    });

    const token = crypto.randomBytes(32).toString('hex');
    const sessionData: SessionData = {
      userId: uid,
      username: userData.username,
      isAdmin: !!userData.isAdmin,
      expiresAt: Date.now() + 90 * 24 * 60 * 60 * 1000, // 90 days
      createdAt: new Date().toISOString(),
    };
    await saveSession(token, sessionData);

    res.cookie('lot_session', token, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      maxAge: 90 * 24 * 60 * 60 * 1000,
    });

    res.json({
      success: true,
      token,
      user: {
        id: uid,
        username: userData.username,
        lotBalance: userData.lotBalance || 0,
        isAdmin: !!userData.isAdmin,
        vipBadge: userData.vipBadge,
        avatarUrl: userData.avatarUrl,
        createdAt: userData.createdAt,
        token,
      },
    });
  } catch (err: any) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error during login. Please try again.' });
  }
});

// GET /api/auth/me
app.get('/api/auth/me', authMiddleware, async (req: Request, res: Response) => {
  const user = (req as any).user;
  res.json({
    user: {
      id: user.id,
      username: user.username,
      lotBalance: user.lotBalance,
      isAdmin: user.isAdmin,
      vipBadge: user.vipBadge,
      avatarUrl: user.avatarUrl,
      token: user.token,
    },
  });
});

// POST /api/user/avatar (Update or remove user profile picture)
app.post('/api/user/avatar', authMiddleware, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { avatarUrl } = req.body;

    if (avatarUrl !== undefined && typeof avatarUrl !== 'string') {
      return res.status(400).json({ error: 'Invalid avatar format.' });
    }

    const cleanAvatar = avatarUrl ? avatarUrl.trim() : '';

    const userDocRef = doc(db, 'users', user.id);
    await updateDoc(userDocRef, {
      avatarUrl: cleanAvatar || null,
      updatedAt: new Date().toISOString(),
    });

    res.json({
      success: true,
      avatarUrl: cleanAvatar,
      message: cleanAvatar ? 'Profile picture updated successfully!' : 'Profile picture removed.',
    });
  } catch (err: any) {
    console.error('Update avatar error:', err);
    res.status(500).json({ error: 'Failed to update profile picture.' });
  }
});

// POST /api/auth/logout
app.post('/api/auth/logout', async (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  const bearerToken = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;
  const token = bearerToken || req.cookies?.lot_session;
  if (token) {
    await removeSession(token);
  }
  res.clearCookie('lot_session');
  res.json({ success: true });
});

// POST /api/auth/logout-all-admin - Log out the admin account from all devices
app.post('/api/auth/logout-all-admin', async (req: Request, res: Response) => {
  try {
    const result = await logoutAdminFromAllDevices();
    res.clearCookie('lot_session');
    res.json({ message: 'Admin account has been logged out from all devices.', ...result });
  } catch (err: any) {
    console.error('Logout all admin error:', err);
    res.status(500).json({ error: 'Failed to log out admin from all devices' });
  }
});

// ----------------------------------------------------
// 2. AUTHORITATIVE LOT CURRENCY LEDGER & TRANSACTIONS
// ----------------------------------------------------

// GET /api/transactions
app.get('/api/transactions', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const txQuery = query(collection(db, 'transactions'), where('userId', '==', userId), limit(100));
    const snap = await getDocs(txQuery);
    const txs = snap.docs.map((d) => d.data());
    txs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ transactions: txs });
  } catch (err: any) {
    console.error('Transactions fetch error:', err);
    res.status(500).json({ error: 'Failed to load ledger transactions' });
  }
});

// ----------------------------------------------------
// 3. VPAY PEER-TO-PEER LOT TRANSFERS
// ----------------------------------------------------

// GET /api/vpay/qr-info - Returns verified payment URI & QR payload for the authenticated user
app.get('/api/vpay/qr-info', authMiddleware, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const paymentUri = `vpay://pay?recipientId=${user.id}&username=${encodeURIComponent(user.username)}`;
    const qrPayload = JSON.stringify({
      protocol: 'vpay',
      version: '1.0',
      recipientId: user.id,
      username: user.username,
      network: 'LOT_ECOSYSTEM',
      created: Date.now(),
    });

    res.json({
      success: true,
      userId: user.id,
      username: user.username,
      avatarUrl: user.avatarUrl || '',
      vipBadge: user.vipBadge || null,
      paymentUri,
      qrPayload,
      vpayTag: `lotpay:${user.username.toLowerCase()}`,
    });
  } catch (err: any) {
    console.error('QR info error:', err);
    res.status(500).json({ error: 'Failed to generate QR payment information' });
  }
});

// POST /api/vpay/resolve-qr - Resolves scanned QR code / URI / payload into verified recipient details
app.post('/api/vpay/resolve-qr', authMiddleware, async (req: Request, res: Response) => {
  try {
    const sender = (req as any).user;
    const { qrData } = req.body;

    if (!qrData || typeof qrData !== 'string') {
      return res.status(400).json({ error: 'Invalid QR code data' });
    }

    let recipientId: string | null = null;
    let recipientUsername: string | null = null;

    const trimmed = qrData.trim();

    // 1. Check if JSON payload (e.g. { protocol: 'vpay', recipientId: '...', username: '...' })
    if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
      try {
        const parsed = JSON.parse(trimmed);
        if (parsed.recipientId) recipientId = String(parsed.recipientId);
        if (parsed.username) recipientUsername = String(parsed.username);
      } catch {}
    }

    // 2. Check if vpay:// URI (e.g. vpay://pay?recipientId=...&username=...)
    if (!recipientId && (trimmed.startsWith('vpay://') || trimmed.startsWith('vpay:'))) {
      try {
        const urlStr = trimmed.replace('vpay://', 'http://vpay/').replace('vpay:', 'http://vpay/');
        const u = new URL(urlStr);
        recipientId = u.searchParams.get('recipientId');
        recipientUsername = u.searchParams.get('username');
      } catch {}
    }

    // 3. Check if lotpay: username format (e.g. lotpay:virat)
    if (!recipientId && !recipientUsername && trimmed.toLowerCase().startsWith('lotpay:')) {
      recipientUsername = trimmed.slice(7).trim();
    }

    // 4. Check if standard @username or raw username
    if (!recipientId && !recipientUsername) {
      if (trimmed.startsWith('@')) {
        recipientUsername = trimmed.slice(1).trim();
      } else if (/^[a-zA-Z0-9_-]{2,32}$/.test(trimmed)) {
        recipientUsername = trimmed;
      }
    }

    // Resolve user in database
    let resolvedUser: any = null;
    if (recipientId) {
      const snap = await getDoc(doc(db, 'users', recipientId));
      if (snap.exists()) {
        resolvedUser = { id: snap.id, ...snap.data() };
      }
    }

    if (!resolvedUser && recipientUsername) {
      const cleanLower = recipientUsername.toLowerCase();
      const uSnap = await getDoc(doc(db, 'usernames', cleanLower));
      if (uSnap.exists()) {
        const uid = uSnap.data().uid;
        const uDoc = await getDoc(doc(db, 'users', uid));
        if (uDoc.exists()) {
          resolvedUser = { id: uDoc.id, ...uDoc.data() };
        }
      }
    }

    if (!resolvedUser) {
      return res.status(404).json({ error: 'Recipient account not found in LOT Ecosystem.' });
    }

    if (resolvedUser.id === sender.id) {
      return res.status(400).json({ error: 'You cannot scan your own QR code to pay yourself.' });
    }

    if (resolvedUser.isBanned) {
      return res.status(403).json({ error: 'This player account has been suspended and cannot receive payments.' });
    }

    res.json({
      success: true,
      recipient: {
        id: resolvedUser.id,
        username: resolvedUser.username,
        avatarUrl: resolvedUser.avatarUrl || '',
        vipBadge: resolvedUser.vipBadge || null,
        vpayTag: `lotpay:${resolvedUser.username.toLowerCase()}`,
        isVerified: true,
      },
    });
  } catch (err: any) {
    console.error('Resolve QR error:', err);
    res.status(500).json({ error: 'Failed to resolve QR code' });
  }
});

// POST /api/vpay/transfer - Real-time P2P transfer with idempotency & ledger record
app.post('/api/vpay/transfer', authMiddleware, async (req: Request, res: Response) => {
  try {
    const sender = (req as any).user;
    const { recipientUsername, recipientId: reqRecipientId, amount, note, idempotencyKey } = req.body;

    const numAmount = Number(amount);
    if (!numAmount || isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'Please enter a valid amount of LOT greater than 0.' });
    }

    if (numAmount > sender.lotBalance) {
      return res.status(400).json({ error: 'Insufficient LOT balance.' });
    }

    // Lookup recipient by ID or username
    let recipientUid = reqRecipientId;
    let recipientActualName = recipientUsername;

    if (!recipientUid && recipientUsername) {
      const cleanRecipientLower = recipientUsername.trim().toLowerCase();
      if (cleanRecipientLower === sender.usernameLower) {
        return res.status(400).json({ error: 'You cannot send LOT to yourself.' });
      }
      const recipientUsernameSnap = await getDoc(doc(db, 'usernames', cleanRecipientLower));
      if (!recipientUsernameSnap.exists()) {
        return res.status(404).json({ error: `User "${recipientUsername}" was not found.` });
      }
      recipientUid = recipientUsernameSnap.data().uid;
      recipientActualName = recipientUsernameSnap.data().username;
    } else if (recipientUid) {
      if (recipientUid === sender.id) {
        return res.status(400).json({ error: 'You cannot send LOT to yourself.' });
      }
      const uSnap = await getDoc(doc(db, 'users', recipientUid));
      if (!uSnap.exists()) {
        return res.status(404).json({ error: 'Recipient account not found.' });
      }
      recipientActualName = uSnap.data().username;
    } else {
      return res.status(400).json({ error: 'Recipient is required.' });
    }

    const transferId = idempotencyKey ? `vpay_${idempotencyKey.slice(0, 32)}` : 'vpay_' + crypto.randomUUID();
    const now = new Date().toISOString();

    const transferResult = await runTransaction(db, async (tx) => {
      // Check idempotency if specified
      if (idempotencyKey) {
        const existingTxSnap = await tx.get(doc(db, 'vpay_transfers', transferId));
        if (existingTxSnap.exists()) {
          const data = existingTxSnap.data();
          return {
            senderNewBalance: sender.lotBalance,
            transferId,
            isDuplicate: true,
          };
        }
      }

      const senderRef = doc(db, 'users', sender.id);
      const recipientRef = doc(db, 'users', recipientUid);

      const senderSnap = await tx.get(senderRef);
      const recipientSnap = await tx.get(recipientRef);

      if (!senderSnap.exists() || !recipientSnap.exists()) {
        throw new Error('USER_NOT_FOUND');
      }

      const senderData = senderSnap.data();
      const recipientData = recipientSnap.data();

      if (recipientData.isBanned) {
        throw new Error('RECIPIENT_BANNED');
      }

      if ((senderData.lotBalance || 0) < numAmount) {
        throw new Error('INSUFFICIENT_FUNDS');
      }

      const senderNewBalance = senderData.lotBalance - numAmount;
      const recipientNewBalance = (recipientData.lotBalance || 0) + numAmount;

      tx.update(senderRef, { lotBalance: senderNewBalance });
      tx.update(recipientRef, { lotBalance: recipientNewBalance });

      // Transfer record
      tx.set(doc(db, 'vpay_transfers', transferId), {
        id: transferId,
        senderId: sender.id,
        senderUsername: sender.username,
        recipientId: recipientUid,
        recipientUsername: recipientActualName,
        amount: numAmount,
        note: note ? String(note).slice(0, 200) : '',
        idempotencyKey: idempotencyKey || null,
        status: 'completed',
        createdAt: now,
      });

      // Sender ledger debit
      const txSenderId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txSenderId), {
        id: txSenderId,
        userId: sender.id,
        type: 'vpay_send',
        amount: -numAmount,
        balanceAfter: senderNewBalance,
        referenceId: transferId,
        description: `VPay transfer to @${recipientActualName}${note ? ': ' + note : ''}`,
        createdAt: now,
      });

      // Recipient ledger credit
      const txRecipientId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txRecipientId), {
        id: txRecipientId,
        userId: recipientUid,
        type: 'vpay_receive',
        amount: numAmount,
        balanceAfter: recipientNewBalance,
        referenceId: transferId,
        description: `VPay transfer from @${sender.username}${note ? ': ' + note : ''}`,
        createdAt: now,
      });

      // Notification for recipient
      const notifId = 'notif_' + crypto.randomUUID();
      tx.set(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: recipientUid,
        title: 'VPay Payment Received',
        message: `You received ${numAmount} LOT from @${sender.username}${note ? ' ("' + note + '")' : ''}.`,
        type: 'vpay',
        read: false,
        createdAt: now,
      });

      return {
        senderNewBalance,
        transferId,
        isDuplicate: false,
      };
    });

    res.json({
      success: true,
      transferId: transferResult.transferId,
      newBalance: transferResult.senderNewBalance,
      recipientUsername: recipientActualName,
      amount: numAmount,
      note: note || '',
      createdAt: now,
      message: `Successfully transferred ${numAmount} LOT to @${recipientActualName}`,
    });
  } catch (err: any) {
    if (err.message === 'INSUFFICIENT_FUNDS') {
      return res.status(400).json({ error: 'Insufficient LOT balance.' });
    }
    if (err.message === 'RECIPIENT_BANNED') {
      return res.status(400).json({ error: 'Recipient account is restricted and cannot accept payments.' });
    }
    console.error('VPay transfer error:', err);
    res.status(500).json({ error: 'Transfer failed. Your balance was not charged.' });
  }
});

// GET /api/vpay/history
app.get('/api/vpay/history', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const sentQuery = query(collection(db, 'vpay_transfers'), where('senderId', '==', userId), limit(50));
    const receivedQuery = query(collection(db, 'vpay_transfers'), where('recipientId', '==', userId), limit(50));

    const [sentSnap, receivedSnap] = await Promise.all([getDocs(sentQuery), getDocs(receivedQuery)]);
    const all = [...sentSnap.docs.map((d) => d.data()), ...receivedSnap.docs.map((d) => d.data())];
    all.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({ transfers: all });
  } catch (err: any) {
    console.error('VPay history error:', err);
    res.status(500).json({ error: 'Failed to load transfer history' });
  }
});

// ----------------------------------------------------
// 4. LOT SHOP MARKETPLACE & WEBHOOKS
// ----------------------------------------------------

// GET /api/shop/listings
app.get('/api/shop/listings', async (req: Request, res: Response) => {
  try {
    const { category, search } = req.query;
    const listingsRef = collection(db, 'listings');
    const snap = await getDocs(listingsRef);
    let items = snap.docs.map((d) => d.data());

    // Filter active items unless requested
    items = items.filter((item) => item.status !== 'delisted');

    if (category && category !== 'All') {
      items = items.filter((item) => item.category === category);
    }

    if (search && typeof search === 'string' && search.trim()) {
      const term = search.trim().toLowerCase();
      items = items.filter(
        (item) => item.title.toLowerCase().includes(term) || item.description.toLowerCase().includes(term) || item.sellerUsername.toLowerCase().includes(term)
      );
    }

    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ listings: items });
  } catch (err: any) {
    console.error('Listings error:', err);
    res.status(500).json({ error: 'Failed to load marketplace listings' });
  }
});

// POST /api/shop/listings
app.post('/api/shop/listings', authMiddleware, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { title, description, category, priceLot, stock, images } = req.body;

    if (!title || typeof title !== 'string' || title.trim().length < 2) {
      return res.status(400).json({ error: 'Title must be at least 2 characters.' });
    }

    const validCategories = ['Weapons', 'Collectibles', 'Clothing', 'Other'];
    if (!validCategories.includes(category)) {
      return res.status(400).json({ error: 'Invalid category. Choose Weapons, Collectibles, Clothing, or Other.' });
    }

    const price = Number(priceLot);
    if (!price || price <= 0) {
      return res.status(400).json({ error: 'Price must be greater than 0 LOT.' });
    }

    const stockQty = Math.floor(Number(stock));
    if (!stockQty || stockQty <= 0) {
      return res.status(400).json({ error: 'Stock must be at least 1 unit.' });
    }

    const imageArray = Array.isArray(images) && images.length > 0 ? images.slice(0, 5) : ['https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80'];

    const listingId = 'list_' + crypto.randomUUID();
    const now = new Date().toISOString();

    const listingData = {
      id: listingId,
      title: title.trim(),
      description: (description || '').trim(),
      category,
      priceLot: price,
      stock: stockQty,
      sellerId: user.id,
      sellerUsername: user.username,
      images: imageArray,
      status: 'active',
      createdAt: now,
      updatedAt: now,
    };

    await setDoc(doc(db, 'listings', listingId), listingData);

    res.json({
      success: true,
      listing: listingData,
    });
  } catch (err: any) {
    console.error('Create listing error:', err);
    res.status(500).json({ error: 'Failed to create listing' });
  }
});

// POST /api/shop/buy
app.post('/api/shop/buy', authMiddleware, async (req: Request, res: Response) => {
  try {
    const buyer = (req as any).user;
    const { listingId, quantity } = req.body;

    const qty = Math.max(1, Math.floor(Number(quantity) || 1));
    const now = new Date().toISOString();
    const orderId = 'ord_' + crypto.randomUUID();

    let webhookUrlToSend: string | null = null;
    let webhookPayload: any = null;

    const purchaseResult = await runTransaction(db, async (tx) => {
      const listingRef = doc(db, 'listings', listingId);
      const buyerRef = doc(db, 'users', buyer.id);

      const listingSnap = await tx.get(listingRef);
      const buyerSnap = await tx.get(buyerRef);

      if (!listingSnap.exists()) {
        throw new Error('LISTING_NOT_FOUND');
      }

      if (!buyerSnap.exists()) {
        throw new Error('BUYER_NOT_FOUND');
      }

      const listing = listingSnap.data();
      if (listing.status !== 'active') {
        throw new Error('ITEM_NOT_AVAILABLE');
      }

      if (listing.stock < qty) {
        throw new Error('INSUFFICIENT_STOCK');
      }

      if (listing.sellerId === buyer.id) {
        throw new Error('CANNOT_BUY_OWN_ITEM');
      }

      const totalCost = listing.priceLot * qty;
      const buyerData = buyerSnap.data();

      if ((buyerData.lotBalance || 0) < totalCost) {
        throw new Error('INSUFFICIENT_BALANCE');
      }

      // Fetch seller doc
      const sellerRef = doc(db, 'users', listing.sellerId);
      const sellerSnap = await tx.get(sellerRef);
      if (!sellerSnap.exists()) {
        throw new Error('SELLER_NOT_FOUND');
      }
      const sellerData = sellerSnap.data();

      const buyerNewBalance = buyerData.lotBalance - totalCost;
      const sellerNewBalance = (sellerData.lotBalance || 0) + totalCost;
      const remainingStock = listing.stock - qty;

      // Update balances
      tx.update(buyerRef, { lotBalance: buyerNewBalance });
      tx.update(sellerRef, { lotBalance: sellerNewBalance });

      // Update listing stock
      tx.update(listingRef, {
        stock: remainingStock,
        status: remainingStock <= 0 ? 'sold_out' : 'active',
        updatedAt: now,
      });

      // Create Order
      const orderData = {
        id: orderId,
        listingId,
        listingTitle: listing.title,
        priceLot: listing.priceLot,
        quantity: qty,
        totalLot: totalCost,
        buyerId: buyer.id,
        buyerUsername: buyer.username,
        sellerId: listing.sellerId,
        sellerUsername: listing.sellerUsername,
        status: 'Placed',
        createdAt: now,
        updatedAt: now,
      };
      tx.set(doc(db, 'orders', orderId), orderData);

      // Buyer ledger debit
      const txBuyerId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txBuyerId), {
        id: txBuyerId,
        userId: buyer.id,
        type: 'shop_purchase',
        amount: -totalCost,
        balanceAfter: buyerNewBalance,
        referenceId: orderId,
        description: `Purchased ${qty}x ${listing.title} from @${listing.sellerUsername}`,
        createdAt: now,
      });

      // Seller ledger credit
      const txSellerId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txSellerId), {
        id: txSellerId,
        userId: listing.sellerId,
        type: 'shop_sale',
        amount: totalCost,
        balanceAfter: sellerNewBalance,
        referenceId: orderId,
        description: `Sold ${qty}x ${listing.title} to @${buyer.username}`,
        createdAt: now,
      });

      // Notifications
      const notifBuyerId = 'notif_' + crypto.randomUUID();
      tx.set(doc(db, 'notifications', notifBuyerId), {
        id: notifBuyerId,
        userId: buyer.id,
        title: 'Order Placed Successfully',
        message: `You purchased ${qty}x ${listing.title} for ${totalCost} LOT. Track order in your Orders dashboard.`,
        type: 'order',
        read: false,
        createdAt: now,
      });

      const notifSellerId = 'notif_' + crypto.randomUUID();
      tx.set(doc(db, 'notifications', notifSellerId), {
        id: notifSellerId,
        userId: listing.sellerId,
        title: 'New Sale in LOT Shop!',
        message: `@${buyer.username} purchased ${qty}x ${listing.title} for ${totalCost} LOT. Status: Placed.`,
        type: 'order',
        read: false,
        createdAt: now,
      });

      return {
        order: orderData,
        newBalance: buyerNewBalance,
        sellerId: listing.sellerId,
      };
    });

    // Check Discord webhook asynchronously (never fail completed purchase)
    try {
      const webhookDoc = await getDoc(doc(db, 'seller_webhooks', purchaseResult.sellerId));
      if (webhookDoc.exists() && webhookDoc.data().webhookUrl) {
        webhookUrlToSend = webhookDoc.data().webhookUrl;
        webhookPayload = {
          embeds: [
            {
              title: '🛒 New LOT Shop Sale!',
              description: `**${purchaseResult.order.listingTitle}** was purchased.`,
              color: 0x8b5cf6,
              fields: [
                { name: 'Quantity', value: `${purchaseResult.order.quantity}`, inline: true },
                { name: 'Total LOT', value: `${purchaseResult.order.totalLot} LOT`, inline: true },
                { name: 'Buyer', value: `@${purchaseResult.order.buyerUsername}`, inline: true },
                { name: 'Order ID', value: `\`${purchaseResult.order.id}\``, inline: false },
                { name: 'Status', value: 'Placed ⏳', inline: true },
              ],
              footer: { text: 'LOT Ecosystem • Authoritative Marketplace' },
              timestamp: now,
            },
          ],
        };

        if (webhookUrlToSend) {
          fetch(webhookUrlToSend, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(webhookPayload),
          }).catch((e) => console.warn('Discord webhook dispatch warning:', e));
        }
      }
    } catch (whErr) {
      console.warn('Webhook lookup warning:', whErr);
    }

    res.json({
      success: true,
      order: purchaseResult.order,
      newBalance: purchaseResult.newBalance,
      message: 'Purchase completed successfully!',
    });
  } catch (err: any) {
    if (err.message === 'INSUFFICIENT_BALANCE') {
      return res.status(400).json({ error: 'Insufficient LOT balance to complete this purchase.' });
    }
    if (err.message === 'INSUFFICIENT_STOCK') {
      return res.status(400).json({ error: 'Not enough stock available.' });
    }
    if (err.message === 'CANNOT_BUY_OWN_ITEM') {
      return res.status(400).json({ error: 'You cannot purchase your own listing.' });
    }
    console.error('Purchase error:', err);
    res.status(500).json({ error: 'Purchase could not be completed.' });
  }
});

// GET /api/shop/orders
app.get('/api/shop/orders', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const buyerOrdersQuery = query(collection(db, 'orders'), where('buyerId', '==', userId), limit(50));
    const sellerOrdersQuery = query(collection(db, 'orders'), where('sellerId', '==', userId), limit(50));

    const [buyerSnap, sellerSnap] = await Promise.all([getDocs(buyerOrdersQuery), getDocs(sellerOrdersQuery)]);
    const buyerOrders = buyerSnap.docs.map((d) => d.data());
    const sellerOrders = sellerSnap.docs.map((d) => d.data());

    buyerOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    sellerOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({
      purchases: buyerOrders,
      sales: sellerOrders,
    });
  } catch (err: any) {
    console.error('Orders fetch error:', err);
    res.status(500).json({ error: 'Failed to load orders' });
  }
});

// PATCH /api/shop/orders/:orderId/status
app.patch('/api/shop/orders/:orderId/status', authMiddleware, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { orderId } = req.params;
    const { status } = req.body;

    const validStatuses = ['Placed', 'Processing', 'Delivered'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid order status.' });
    }

    const orderRef = doc(db, 'orders', orderId);
    const orderSnap = await getDoc(orderRef);
    if (!orderSnap.exists()) {
      return res.status(404).json({ error: 'Order not found.' });
    }

    const order = orderSnap.data();
    if (order.sellerId !== user.id && !user.isAdmin) {
      return res.status(403).json({ error: 'Only the seller or an administrator can update this order status.' });
    }

    const now = new Date().toISOString();
    await updateDoc(orderRef, {
      status,
      updatedAt: now,
    });

    // Notify buyer
    const notifId = 'notif_' + crypto.randomUUID();
    await setDoc(doc(db, 'notifications', notifId), {
      id: notifId,
      userId: order.buyerId,
      title: `Order Updated: ${status}`,
      message: `Your order for "${order.listingTitle}" is now marked as ${status}.`,
      type: 'order',
      read: false,
      createdAt: now,
    });

    res.json({ success: true, status });
  } catch (err: any) {
    console.error('Order status update error:', err);
    res.status(500).json({ error: 'Failed to update order status' });
  }
});

// GET /api/shop/seller/webhook
app.get('/api/shop/seller/webhook', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const snap = await getDoc(doc(db, 'seller_webhooks', userId));
    res.json({ webhookUrl: snap.exists() ? snap.data().webhookUrl : '' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch webhook' });
  }
});

// POST /api/shop/seller/webhook
app.post('/api/shop/seller/webhook', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const { webhookUrl } = req.body;

    if (webhookUrl && !webhookUrl.startsWith('https://discord.com/api/webhooks/')) {
      return res.status(400).json({ error: 'Must be a valid Discord webhook URL (https://discord.com/api/webhooks/...)' });
    }

    await setDoc(doc(db, 'seller_webhooks', userId), {
      sellerId: userId,
      webhookUrl: webhookUrl || '',
      updatedAt: new Date().toISOString(),
    });

    res.json({ success: true, message: 'Discord webhook saved securely.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save webhook' });
  }
});

// ----------------------------------------------------
// 5. VSTOCKS TRADING & PORTFOLIO ENGINE
// ----------------------------------------------------

// GET /api/stocks/market
app.get('/api/stocks/market', (req: Request, res: Response) => {
  res.json({
    stocks: liveStocks,
    marketStatus: 'Simulated Market Active (24/7)',
    timestamp: new Date().toISOString(),
  });
});

// GET /api/stocks/portfolio
app.get('/api/stocks/portfolio', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const portfolioQuery = query(collection(db, 'portfolios'), where('userId', '==', userId));
    const snap = await getDocs(portfolioQuery);
    const holdings = snap.docs.map((d) => d.data());

    // Compute live values and unrealized P&L
    let totalPortfolioValue = 0;
    let totalInvested = 0;

    const enrichedHoldings = holdings.map((h) => {
      const stock = liveStocks.find((s) => s.symbol === h.symbol);
      const currentPrice = stock ? stock.currentPrice : h.averageBuyPrice;
      const currentValue = +(h.quantity * currentPrice).toFixed(2);
      const invested = +(h.quantity * h.averageBuyPrice).toFixed(2);
      const pnl = +(currentValue - invested).toFixed(2);
      const pnlPercent = invested > 0 ? +((pnl / invested) * 100).toFixed(2) : 0;

      totalPortfolioValue += currentValue;
      totalInvested += invested;

      return {
        ...h,
        currentPrice,
        currentValue,
        pnl,
        pnlPercent,
      };
    });

    const totalPnl = +(totalPortfolioValue - totalInvested).toFixed(2);
    const totalPnlPercent = totalInvested > 0 ? +((totalPnl / totalInvested) * 100).toFixed(2) : 0;

    res.json({
      holdings: enrichedHoldings,
      totalPortfolioValue: +totalPortfolioValue.toFixed(2),
      totalInvested: +totalInvested.toFixed(2),
      totalPnl,
      totalPnlPercent,
    });
  } catch (err: any) {
    console.error('Portfolio error:', err);
    res.status(500).json({ error: 'Failed to load portfolio' });
  }
});

// POST /api/stocks/trade
app.post('/api/stocks/trade', authMiddleware, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { symbol, type, quantity } = req.body;

    const qty = Math.floor(Number(quantity));
    if (!qty || qty <= 0) {
      return res.status(400).json({ error: 'Please enter a valid share quantity of 1 or more.' });
    }

    if (type !== 'BUY' && type !== 'SELL') {
      return res.status(400).json({ error: 'Trade type must be BUY or SELL.' });
    }

    const stock = liveStocks.find((s) => s.symbol === symbol);
    if (!stock) {
      return res.status(404).json({ error: `Stock symbol "${symbol}" not recognized.` });
    }

    const currentPrice = stock.currentPrice;
    const totalLot = +(qty * currentPrice).toFixed(2);
    const now = new Date().toISOString();
    const tradeId = 'trd_' + crypto.randomUUID();
    const portfolioDocId = `${user.id}_${symbol}`;

    const tradeResult = await runTransaction(db, async (tx) => {
      const userRef = doc(db, 'users', user.id);
      const userSnap = await tx.get(userRef);
      if (!userSnap.exists()) throw new Error('USER_NOT_FOUND');

      const userData = userSnap.data();
      const currentBalance = userData.lotBalance || 0;

      const portfolioRef = doc(db, 'portfolios', portfolioDocId);
      const portfolioSnap = await tx.get(portfolioRef);

      let newBalance = currentBalance;
      let newQty = 0;
      let newAvgPrice = 0;
      let newTotalInvested = 0;

      if (type === 'BUY') {
        if (currentBalance < totalLot) {
          throw new Error('INSUFFICIENT_FUNDS');
        }

        newBalance = +(currentBalance - totalLot).toFixed(2);

        if (portfolioSnap.exists()) {
          const pData = portfolioSnap.data();
          const existingQty = pData.quantity || 0;
          const existingTotal = (pData.averageBuyPrice || 0) * existingQty;
          newQty = existingQty + qty;
          newTotalInvested = +(existingTotal + totalLot).toFixed(2);
          newAvgPrice = +(newTotalInvested / newQty).toFixed(2);

          tx.update(portfolioRef, {
            quantity: newQty,
            averageBuyPrice: newAvgPrice,
            totalInvested: newTotalInvested,
            updatedAt: now,
          });
        } else {
          newQty = qty;
          newAvgPrice = currentPrice;
          newTotalInvested = totalLot;

          tx.set(portfolioRef, {
            id: portfolioDocId,
            userId: user.id,
            symbol,
            quantity: newQty,
            averageBuyPrice: newAvgPrice,
            totalInvested: newTotalInvested,
            updatedAt: now,
          });
        }

        // Ledger debit
        const txId = 'tx_' + crypto.randomUUID();
        tx.set(doc(db, 'transactions', txId), {
          id: txId,
          userId: user.id,
          type: 'stock_buy',
          amount: -totalLot,
          balanceAfter: newBalance,
          referenceId: tradeId,
          description: `VStocks: Bought ${qty} shares of ${symbol} @ ${currentPrice} LOT`,
          createdAt: now,
        });
      } else {
        // SELL
        if (!portfolioSnap.exists() || (portfolioSnap.data().quantity || 0) < qty) {
          throw new Error('INSUFFICIENT_SHARES');
        }

        const pData = portfolioSnap.data();
        const existingQty = pData.quantity;
        newBalance = +(currentBalance + totalLot).toFixed(2);
        newQty = existingQty - qty;

        if (newQty <= 0) {
          tx.delete(portfolioRef);
        } else {
          newAvgPrice = pData.averageBuyPrice;
          newTotalInvested = +(newQty * newAvgPrice).toFixed(2);
          tx.update(portfolioRef, {
            quantity: newQty,
            totalInvested: newTotalInvested,
            updatedAt: now,
          });
        }

        // Ledger credit
        const txId = 'tx_' + crypto.randomUUID();
        tx.set(doc(db, 'transactions', txId), {
          id: txId,
          userId: user.id,
          type: 'stock_sell',
          amount: totalLot,
          balanceAfter: newBalance,
          referenceId: tradeId,
          description: `VStocks: Sold ${qty} shares of ${symbol} @ ${currentPrice} LOT`,
          createdAt: now,
        });
      }

      // Update user wallet
      tx.update(userRef, { lotBalance: newBalance });

      // Record trade
      const tradeDoc = {
        id: tradeId,
        userId: user.id,
        symbol,
        type,
        quantity: qty,
        pricePerUnit: currentPrice,
        totalLot,
        createdAt: now,
      };
      tx.set(doc(db, 'trades', tradeId), tradeDoc);

      return {
        trade: tradeDoc,
        newBalance,
        newQty,
      };
    });

    res.json({
      success: true,
      trade: tradeResult.trade,
      newBalance: tradeResult.newBalance,
      remainingShares: tradeResult.newQty,
      message: `Successfully executed ${type} order for ${qty}x ${symbol} at ${currentPrice} LOT`,
    });
  } catch (err: any) {
    if (err.message === 'INSUFFICIENT_FUNDS') {
      return res.status(400).json({ error: 'Insufficient LOT balance to buy these shares.' });
    }
    if (err.message === 'INSUFFICIENT_SHARES') {
      return res.status(400).json({ error: 'You do not own enough shares to execute this sell.' });
    }
    console.error('Trade error:', err);
    res.status(500).json({ error: 'Stock trade execution failed.' });
  }
});

// GET /api/stocks/trades
app.get('/api/stocks/trades', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const tradesQuery = query(collection(db, 'trades'), where('userId', '==', userId), limit(50));
    const snap = await getDocs(tradesQuery);
    const trades = snap.docs.map((d) => d.data());
    trades.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ trades });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch trade history' });
  }
});

// ----------------------------------------------------
// 6. REDEMPTION CODES & PROMOTIONS
// ----------------------------------------------------

// POST /api/redemption/redeem
app.post('/api/redemption/redeem', authMiddleware, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { code } = req.body;

    if (!code || typeof code !== 'string') {
      return res.status(400).json({ error: 'Please enter a redemption code.' });
    }

    const cleanCode = code.trim().toUpperCase();
    const codeDocRef = doc(db, 'redemption_codes', cleanCode);
    const claimDocId = `${user.id}_${cleanCode}`;
    const claimDocRef = doc(db, 'redemption_claims', claimDocId);
    const now = new Date().toISOString();

    const redemptionResult = await runTransaction(db, async (tx) => {
      const codeSnap = await tx.get(codeDocRef);
      if (!codeSnap.exists()) {
        throw new Error('CODE_NOT_FOUND');
      }

      const codeData = codeSnap.data();
      if (!codeData.isActive) {
        throw new Error('CODE_INACTIVE');
      }

      if (codeData.expiresAt && new Date(codeData.expiresAt).getTime() < Date.now()) {
        throw new Error('CODE_EXPIRED');
      }

      if (codeData.claimsCount >= codeData.maxClaims) {
        throw new Error('MAX_CLAIMS_REACHED');
      }

      const claimSnap = await tx.get(claimDocRef);
      if (claimSnap.exists()) {
        throw new Error('ALREADY_CLAIMED');
      }

      const userRef = doc(db, 'users', user.id);
      const userSnap = await tx.get(userRef);
      if (!userSnap.exists()) throw new Error('USER_NOT_FOUND');

      const currentBalance = userSnap.data().lotBalance || 0;
      const newBalance = currentBalance + codeData.rewardLot;

      // Update code claimsCount
      tx.update(codeDocRef, {
        claimsCount: codeData.claimsCount + 1,
      });

      // Update user wallet
      tx.update(userRef, { lotBalance: newBalance });

      // Record claim
      tx.set(claimDocRef, {
        id: claimDocId,
        codeId: cleanCode,
        code: cleanCode,
        userId: user.id,
        username: user.username,
        rewardLot: codeData.rewardLot,
        claimedAt: now,
      });

      // Write ledger transaction
      const txId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txId), {
        id: txId,
        userId: user.id,
        type: 'redemption',
        amount: codeData.rewardLot,
        balanceAfter: newBalance,
        referenceId: cleanCode,
        description: `Redeemed promo code "${cleanCode}" for ${codeData.rewardLot} LOT`,
        createdAt: now,
      });

      // Notification
      const notifId = 'notif_' + crypto.randomUUID();
      tx.set(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: user.id,
        title: 'Redemption Successful! 🎉',
        message: `You claimed code "${cleanCode}" and received ${codeData.rewardLot} LOT!`,
        type: 'redemption',
        read: false,
        createdAt: now,
      });

      return {
        rewardLot: codeData.rewardLot,
        newBalance,
      };
    });

    res.json({
      success: true,
      rewardLot: redemptionResult.rewardLot,
      newBalance: redemptionResult.newBalance,
      message: `Congratulations! Code applied. +${redemptionResult.rewardLot} LOT added to your balance.`,
    });
  } catch (err: any) {
    if (err.message === 'CODE_NOT_FOUND') {
      return res.status(404).json({ error: 'Invalid redemption code.' });
    }
    if (err.message === 'CODE_INACTIVE') {
      return res.status(400).json({ error: 'This redemption code has been disabled.' });
    }
    if (err.message === 'CODE_EXPIRED') {
      return res.status(400).json({ error: 'This redemption code has expired.' });
    }
    if (err.message === 'MAX_CLAIMS_REACHED') {
      return res.status(400).json({ error: 'This redemption code has reached its maximum claim limit.' });
    }
    if (err.message === 'ALREADY_CLAIMED') {
      return res.status(400).json({ error: 'You have already redeemed this code.' });
    }
    console.error('Redemption error:', err);
    res.status(500).json({ error: 'Redemption failed. Please try again.' });
  }
});

// GET /api/redemption/my-claims
app.get('/api/redemption/my-claims', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const snap = await getDocs(query(collection(db, 'redemption_claims'), where('userId', '==', userId)));
    const claims = snap.docs.map((d) => d.data());
    claims.sort((a, b) => new Date(b.claimedAt).getTime() - new Date(a.claimedAt).getTime());
    res.json({ claims });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch redemption claims' });
  }
});

// ----------------------------------------------------
// 7. MINIGAMES & SERVER-VALIDATED REWARDS (1 - 100 LOT)
// ----------------------------------------------------

const userGameCooldowns = new Map<string, number>();

// POST /api/games/reward
app.post('/api/games/reward', authMiddleware, async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { gameType, score, clientNonce } = req.body;

    const validGames = ['guess', 'memory', 'reaction', 'daily'];
    if (!validGames.includes(gameType)) {
      return res.status(400).json({ error: 'Unknown minigame type.' });
    }

    // Cooldown check: prevent automated rapid-fire replay exploits (minimum 15s between game rewards)
    const cooldownKey = `${user.id}_${gameType}`;
    const lastPlayed = userGameCooldowns.get(cooldownKey) || 0;
    const nowMs = Date.now();
    const cooldownDuration = gameType === 'daily' ? 20 * 60 * 60 * 1000 : 12 * 1000;

    if (nowMs - lastPlayed < cooldownDuration) {
      const waitSec = Math.ceil((cooldownDuration - (nowMs - lastPlayed)) / 1000);
      return res.status(429).json({ error: `Game cooldown active. Please wait ${waitSec}s before claiming again.` });
    }

    // Authoritative reward calculation strictly 1 - 100 LOT
    let rewardLot = 10;
    if (gameType === 'guess') {
      // attempts: 1-3 => 50, 4-6 => 30, 7+ => 15
      const attempts = Number(score) || 6;
      rewardLot = attempts <= 3 ? 50 : attempts <= 6 ? 30 : 15;
    } else if (gameType === 'memory') {
      // time in sec: <20s => 60, <35s => 40, >=35s => 20
      const seconds = Number(score) || 30;
      rewardLot = seconds < 20 ? 60 : seconds < 35 ? 40 : 20;
    } else if (gameType === 'reaction') {
      // reaction ms: <200ms => 75, <280ms => 45, else => 20
      const ms = Number(score) || 300;
      rewardLot = ms < 200 ? 75 : ms < 280 ? 45 : 20;
    } else if (gameType === 'daily') {
      // Daily challenge completion: guaranteed 100 LOT
      rewardLot = 100;
    }

    rewardLot = Math.min(100, Math.max(1, rewardLot));
    userGameCooldowns.set(cooldownKey, nowMs);

    const now = new Date().toISOString();
    const gameRewardId = 'gm_' + crypto.randomUUID();

    const gameResult = await runTransaction(db, async (tx) => {
      const userRef = doc(db, 'users', user.id);
      const userSnap = await tx.get(userRef);
      if (!userSnap.exists()) throw new Error('USER_NOT_FOUND');

      const currentBalance = userSnap.data().lotBalance || 0;
      const newBalance = currentBalance + rewardLot;

      tx.update(userRef, { lotBalance: newBalance });

      // Ledger transaction
      const txId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txId), {
        id: txId,
        userId: user.id,
        type: 'minigame_reward',
        amount: rewardLot,
        balanceAfter: newBalance,
        referenceId: gameRewardId,
        description: `Minigame prize: ${gameType.toUpperCase()} challenge (+${rewardLot} LOT)`,
        createdAt: now,
      });

      // Notification
      const notifId = 'notif_' + crypto.randomUUID();
      tx.set(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: user.id,
        title: 'Minigame Reward Won! 🎮',
        message: `You completed the ${gameType.toUpperCase()} challenge and won ${rewardLot} LOT!`,
        type: 'game',
        read: false,
        createdAt: now,
      });

      return { newBalance, rewardLot };
    });

    res.json({
      success: true,
      rewardLot: gameResult.rewardLot,
      newBalance: gameResult.newBalance,
      message: `Victory! Earned ${gameResult.rewardLot} LOT!`,
    });
  } catch (err: any) {
    console.error('Game reward error:', err);
    res.status(500).json({ error: 'Failed to process minigame reward' });
  }
});

// ----------------------------------------------------
// 8. NOTIFICATIONS & ANNOUNCEMENTS
// ----------------------------------------------------

// GET /api/notifications
app.get('/api/notifications', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const snap = await getDocs(query(collection(db, 'notifications'), where('userId', '==', userId), limit(30)));
    const notifs = snap.docs.map((d) => d.data());
    notifs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ notifications: notifs });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch notifications' });
  }
});

// POST /api/notifications/mark-read
app.post('/api/notifications/mark-read', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const { notificationId } = req.body;

    if (notificationId) {
      await updateDoc(doc(db, 'notifications', notificationId), { read: true });
    } else {
      const snap = await getDocs(query(collection(db, 'notifications'), where('userId', '==', userId), where('read', '==', false)));
      const promises = snap.docs.map((d) => updateDoc(d.ref, { read: true }));
      await Promise.all(promises);
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update notifications' });
  }
});

// GET /api/announcements
app.get('/api/announcements', async (req: Request, res: Response) => {
  try {
    const snap = await getDocs(collection(db, 'announcements'));
    const items = snap.docs.map((d) => d.data());
    items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ announcements: items.slice(0, 10) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch announcements' });
  }
});

// ----------------------------------------------------
// 9. VIRAT ADMINISTRATOR DASHBOARD & AUDIT LOGS
// ----------------------------------------------------

// GET /api/admin/users
app.get('/api/admin/users', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const snap = await getDocs(collection(db, 'users'));
    const users = snap.docs.map((d) => {
      const data = d.data();
      return {
        id: data.id,
        username: data.username,
        lotBalance: data.lotBalance || 0,
        isAdmin: !!data.isAdmin,
        isBanned: !!data.isBanned,
        createdAt: data.createdAt,
        lastLoginAt: data.lastLoginAt,
      };
    });
    res.json({ users });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// POST /api/admin/users/:userId/balance
app.post('/api/admin/users/:userId/balance', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { userId } = req.params;
    const { amountDelta, reason } = req.body;

    const delta = Number(amountDelta);
    if (!delta || isNaN(delta)) {
      return res.status(400).json({ error: 'Please specify a valid numeric adjustment amount.' });
    }

    if (!reason || typeof reason !== 'string' || reason.trim().length < 3) {
      return res.status(400).json({ error: 'A mandatory administrative reason is required.' });
    }

    const now = new Date().toISOString();
    const logId = 'log_' + crypto.randomUUID();

    const result = await runTransaction(db, async (tx) => {
      const targetUserRef = doc(db, 'users', userId);
      const targetSnap = await tx.get(targetUserRef);
      if (!targetSnap.exists()) throw new Error('USER_NOT_FOUND');

      const targetData = targetSnap.data();
      const currentBalance = targetData.lotBalance || 0;
      const newBalance = currentBalance + delta;

      if (newBalance < 0) {
        throw new Error('NEGATIVE_BALANCE');
      }

      tx.update(targetUserRef, { lotBalance: newBalance });

      // Ledger transaction
      const txId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txId), {
        id: txId,
        userId,
        type: 'admin_adjustment',
        amount: delta,
        balanceAfter: newBalance,
        referenceId: logId,
        description: `Admin balance adjustment by @${admin.username}: ${reason.trim()}`,
        createdAt: now,
      });

      // Admin Audit Log
      tx.set(doc(db, 'admin_audit_logs', logId), {
        id: logId,
        adminId: admin.id,
        adminUsername: admin.username,
        action: 'BALANCE_ADJUSTMENT',
        targetUserId: userId,
        details: `Adjusted user @${targetData.username} by ${delta > 0 ? '+' : ''}${delta} LOT. Reason: ${reason.trim()}`,
        createdAt: now,
      });

      // User notification
      const notifId = 'notif_' + crypto.randomUUID();
      tx.set(doc(db, 'notifications', notifId), {
        id: notifId,
        userId,
        title: 'Administrative Balance Adjustment',
        message: `Your balance was adjusted by ${delta > 0 ? '+' : ''}${delta} LOT. Memo: ${reason.trim()}`,
        type: 'admin',
        read: false,
        createdAt: now,
      });

      return { newBalance, username: targetData.username };
    });

    res.json({
      success: true,
      message: `Adjusted @${result.username}'s balance. New balance: ${result.newBalance} LOT`,
    });
  } catch (err: any) {
    if (err.message === 'NEGATIVE_BALANCE') {
      return res.status(400).json({ error: 'Adjustment would result in negative user balance.' });
    }
    console.error('Balance adjustment error:', err);
    res.status(500).json({ error: 'Failed to adjust balance' });
  }
});

// POST /api/admin/users/:userId/ban
app.post('/api/admin/users/:userId/ban', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { userId } = req.params;
    const { isBanned, reason } = req.body;

    if (userId === admin.id) {
      return res.status(400).json({ error: 'You cannot ban your own administrator account.' });
    }

    const targetUserRef = doc(db, 'users', userId);
    const snap = await getDoc(targetUserRef);
    if (!snap.exists()) {
      return res.status(404).json({ error: 'User not found.' });
    }

    const now = new Date().toISOString();
    await updateDoc(targetUserRef, { isBanned: !!isBanned });

    // Record audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: isBanned ? 'BAN_USER' : 'UNBAN_USER',
      targetUserId: userId,
      details: `${isBanned ? 'Banned' : 'Unbanned'} user @${snap.data().username}. Reason: ${reason || 'Administrative action'}`,
      createdAt: now,
    });

    res.json({ success: true, isBanned: !!isBanned });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update ban status' });
  }
});

// POST /api/admin/users/:userId/reset-password
app.post('/api/admin/users/:userId/reset-password', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { userId } = req.params;
    const { newPassword } = req.body;

    if (!newPassword || typeof newPassword !== 'string' || newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters.' });
    }

    const targetUserRef = doc(db, 'users', userId);
    const snap = await getDoc(targetUserRef);
    if (!snap.exists()) {
      return res.status(404).json({ error: 'User not found.' });
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    await updateDoc(targetUserRef, { passwordHash });

    // Invalidate sessions for this user
    for (const [token, sess] of sessionStore.entries()) {
      if (sess.userId === userId) {
        sessionStore.delete(token);
      }
    }

    // Audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: 'PASSWORD_RESET',
      targetUserId: userId,
      details: `Password reset by admin @${admin.username} for user @${snap.data().username}`,
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, message: `Password reset for @${snap.data().username}` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to reset password' });
  }
});

// DELETE /api/admin/users/:userId
app.delete('/api/admin/users/:userId', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { userId } = req.params;

    if (userId === admin.id) {
      return res.status(400).json({ error: 'Safeguard triggered: Cannot delete your own administrator account.' });
    }

    const userRef = doc(db, 'users', userId);
    const snap = await getDoc(userRef);
    if (!snap.exists()) {
      return res.status(404).json({ error: 'User not found' });
    }

    const usernameLower = snap.data().usernameLower;
    await deleteDoc(userRef);
    await deleteDoc(doc(db, 'usernames', usernameLower));

    // Audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: 'DELETE_ACCOUNT',
      targetUserId: userId,
      details: `Deleted account for user @${snap.data().username}`,
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, message: 'Account deleted safely.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// ----------------------------------------------------
// NEW ADMIN FEATURE 1: SET LOT BALANCE BY USERNAME
// ----------------------------------------------------
app.post('/api/admin/set-lot-by-username', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { username, mode = 'set', amount, reason } = req.body;

    if (!username || typeof username !== 'string') {
      return res.status(400).json({ error: 'Target username is required.' });
    }

    const cleanUsername = username.replace(/^@/, '').trim();
    const usernameLower = cleanUsername.toLowerCase();

    const amt = Number(amount);
    if (isNaN(amt) || amt < 0) {
      return res.status(400).json({ error: 'Please provide a valid non-negative LOT amount.' });
    }

    if (!reason || typeof reason !== 'string' || reason.trim().length < 3) {
      return res.status(400).json({ error: 'A mandatory administrative audit reason (minimum 3 characters) is required.' });
    }

    // Lookup user by username mapping
    const usernameRef = doc(db, 'usernames', usernameLower);
    const usernameSnap = await getDoc(usernameRef);
    if (!usernameSnap.exists()) {
      return res.status(404).json({ error: `User "@${cleanUsername}" was not found in the ecosystem.` });
    }

    const targetUid = usernameSnap.data().uid;
    const now = new Date().toISOString();
    const logId = 'log_' + crypto.randomUUID();

    const result = await runTransaction(db, async (tx) => {
      const targetUserRef = doc(db, 'users', targetUid);
      const userSnap = await tx.get(targetUserRef);
      if (!userSnap.exists()) {
        throw new Error('USER_NOT_FOUND');
      }

      const currentBalance = userSnap.data().lotBalance || 0;
      let newBalance = currentBalance;
      let delta = 0;

      if (mode === 'set') {
        newBalance = Math.floor(amt);
        delta = newBalance - currentBalance;
      } else if (mode === 'add') {
        delta = Math.floor(amt);
        newBalance = currentBalance + delta;
      } else if (mode === 'deduct') {
        delta = -Math.floor(amt);
        newBalance = currentBalance + delta;
      } else {
        throw new Error('INVALID_MODE');
      }

      if (newBalance < 0) {
        throw new Error('NEGATIVE_BALANCE');
      }

      tx.update(targetUserRef, { lotBalance: newBalance });

      // Record in immutable transactions ledger
      const txId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txId), {
        id: txId,
        userId: targetUid,
        type: 'admin_adjustment',
        amount: delta,
        balanceAfter: newBalance,
        referenceId: logId,
        description: `Admin balance adjustment by @${admin.username} (Mode: ${mode.toUpperCase()}): ${reason.trim()}`,
        createdAt: now,
      });

      // Record in admin audit logs
      tx.set(doc(db, 'admin_audit_logs', logId), {
        id: logId,
        adminId: admin.id,
        adminUsername: admin.username,
        action: 'SET_LOT_BY_USERNAME',
        targetUserId: targetUid,
        details: `Set LOT for @${userSnap.data().username}: previous ${currentBalance} -> new ${newBalance} LOT (${delta >= 0 ? '+' : ''}${delta}). Reason: ${reason.trim()}`,
        createdAt: now,
      });

      // User notification
      const notifId = 'notif_' + crypto.randomUUID();
      tx.set(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: targetUid,
        title: 'LOT Balance Adjusted by Admin ⚙️',
        message: `Your LOT balance has been updated to ${newBalance.toLocaleString()} LOT (${delta >= 0 ? '+' : ''}${delta.toLocaleString()} LOT). Memo: ${reason.trim()}`,
        type: 'admin',
        read: false,
        createdAt: now,
      });

      return {
        username: userSnap.data().username,
        previousBalance: currentBalance,
        newBalance,
        delta,
      };
    });

    res.json({
      success: true,
      message: `Successfully updated @${result.username}'s LOT balance to ${result.newBalance.toLocaleString()} LOT (${result.delta >= 0 ? '+' : ''}${result.delta.toLocaleString()} LOT).`,
      result,
    });
  } catch (err: any) {
    if (err.message === 'NEGATIVE_BALANCE') {
      return res.status(400).json({ error: 'Adjustment would result in negative user balance.' });
    }
    console.error('Set lot by username error:', err);
    res.status(500).json({ error: 'Failed to set LOT balance by username.' });
  }
});

// NEW ADMIN FEATURE 2: USER DOSSIER LOOKUP BY USERNAME
app.get('/api/admin/lookup-user/:username', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const { username } = req.params;
    const cleanUsername = username.replace(/^@/, '').trim().toLowerCase();

    const usernameRef = doc(db, 'usernames', cleanUsername);
    const usernameSnap = await getDoc(usernameRef);
    if (!usernameSnap.exists()) {
      return res.status(404).json({ error: `User "@${username}" not found.` });
    }

    const uid = usernameSnap.data().uid;
    const userSnap = await getDoc(doc(db, 'users', uid));
    if (!userSnap.exists()) {
      return res.status(404).json({ error: 'User data not found.' });
    }

    const uData = userSnap.data();

    // Fetch related count summaries for dossier
    const [txSnap, tradesSnap, ordersSnap] = await Promise.all([
      getDocs(query(collection(db, 'transactions'), where('userId', '==', uid), limit(5))),
      getDocs(query(collection(db, 'trades'), where('userId', '==', uid), limit(5))),
      getDocs(query(collection(db, 'orders'), where('buyerId', '==', uid), limit(5))),
    ]);

    res.json({
      user: {
        id: uData.id,
        username: uData.username,
        lotBalance: uData.lotBalance || 0,
        isAdmin: !!uData.isAdmin,
        isBanned: !!uData.isBanned,
        vipBadge: uData.vipBadge || null,
        avatarUrl: uData.avatarUrl || null,
        createdAt: uData.createdAt,
        lastLoginAt: uData.lastLoginAt,
        recentTxCount: txSnap.size,
        recentTradesCount: tradesSnap.size,
        recentOrdersCount: ordersSnap.size,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to lookup user dossier' });
  }
});

// NEW ADMIN FEATURE 3: VIP TIER & PRESTIGE BADGE ASSIGNMENT
app.post('/api/admin/users/:userId/vip', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { userId } = req.params;
    const { vipBadge } = req.body;

    const userRef = doc(db, 'users', userId);
    const snap = await getDoc(userRef);
    if (!snap.exists()) {
      return res.status(404).json({ error: 'User not found' });
    }

    const badgeVal = vipBadge && typeof vipBadge === 'string' ? vipBadge.trim() : null;
    await updateDoc(userRef, { vipBadge: badgeVal });

    // Audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: 'UPDATE_VIP_BADGE',
      targetUserId: userId,
      details: `${badgeVal ? `Awarded badge "${badgeVal}" to` : 'Removed VIP badge from'} @${snap.data().username}`,
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, vipBadge: badgeVal });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update VIP badge' });
  }
});

// NEW ADMIN FEATURE 4: GLOBAL TRANSACTIONS & LEDGER SEARCH
app.get('/api/admin/transactions/search', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const { search = '', type = '' } = req.query as { search?: string; type?: string };
    const snap = await getDocs(collection(db, 'transactions'));
    let txs = snap.docs.map((d) => d.data());

    // In-memory filter for flexible search across multiple fields
    if (type) {
      txs = txs.filter((t) => t.type === type);
    }
    if (search) {
      const qLower = search.toLowerCase();
      txs = txs.filter(
        (t) =>
          (t.id && t.id.toLowerCase().includes(qLower)) ||
          (t.description && t.description.toLowerCase().includes(qLower)) ||
          (t.userId && t.userId.toLowerCase().includes(qLower))
      );
    }

    txs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ transactions: txs.slice(0, 150) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to search transactions' });
  }
});

// NEW ADMIN FEATURE 5: VPAY P2P TRANSFERS AUDIT & REVERSE
app.get('/api/admin/vpay/transfers', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const { search = '' } = req.query as { search?: string };
    const snap = await getDocs(collection(db, 'vpay_transfers'));
    let transfers = snap.docs.map((d) => d.data());

    if (search) {
      const qLower = search.toLowerCase();
      transfers = transfers.filter(
        (t) =>
          (t.senderUsername && t.senderUsername.toLowerCase().includes(qLower)) ||
          (t.recipientUsername && t.recipientUsername.toLowerCase().includes(qLower)) ||
          (t.note && t.note.toLowerCase().includes(qLower)) ||
          (t.id && t.id.toLowerCase().includes(qLower))
      );
    }

    transfers.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ transfers: transfers.slice(0, 100) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch VPay transfers' });
  }
});

// Emergency VPay Transfer Reversal
app.post('/api/admin/vpay/reverse/:transferId', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { transferId } = req.params;
    const { reason = 'Administrative refund of disputed transfer' } = req.body;

    const transferRef = doc(db, 'vpay_transfers', transferId);
    const transferSnap = await getDoc(transferRef);
    if (!transferSnap.exists()) {
      return res.status(404).json({ error: 'Transfer not found.' });
    }

    const tData = transferSnap.data();
    if (tData.reversed) {
      return res.status(400).json({ error: 'This transfer has already been reversed.' });
    }

    const now = new Date().toISOString();
    const logId = 'log_' + crypto.randomUUID();

    await runTransaction(db, async (tx) => {
      const senderRef = doc(db, 'users', tData.senderId);
      const recipientRef = doc(db, 'users', tData.recipientId);

      const senderSnap = await tx.get(senderRef);
      const recipientSnap = await tx.get(recipientRef);

      if (!senderSnap.exists() || !recipientSnap.exists()) {
        throw new Error('USERS_NOT_FOUND');
      }

      const senderBal = senderSnap.data().lotBalance || 0;
      const recipientBal = recipientSnap.data().lotBalance || 0;

      // Credit sender back
      tx.update(senderRef, { lotBalance: senderBal + tData.amount });
      // Debit recipient
      tx.update(recipientRef, { lotBalance: Math.max(0, recipientBal - tData.amount) });

      // Mark transfer as reversed
      tx.update(transferRef, { reversed: true, reversedAt: now, reversedBy: admin.username });

      // Ledger for sender
      const tx1 = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', tx1), {
        id: tx1,
        userId: tData.senderId,
        type: 'admin_adjustment',
        amount: tData.amount,
        balanceAfter: senderBal + tData.amount,
        referenceId: transferId,
        description: `Reversal of VPay transfer to @${tData.recipientUsername} (+${tData.amount} LOT)`,
        createdAt: now,
      });

      // Audit log
      tx.set(doc(db, 'admin_audit_logs', logId), {
        id: logId,
        adminId: admin.id,
        adminUsername: admin.username,
        action: 'REVERSE_VPAY_TRANSFER',
        targetUserId: tData.recipientId,
        details: `Reversed transfer ${transferId} (${tData.amount} LOT from @${tData.recipientUsername} back to @${tData.senderUsername}). Reason: ${reason}`,
        createdAt: now,
      });
    });

    res.json({ success: true, message: `Reversed transfer of ${tData.amount} LOT back to @${tData.senderUsername}` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to reverse transfer' });
  }
});

// NEW ADMIN FEATURE 6: VSTOCKS PORTFOLIOS SEARCH & FORCE LIQUIDATION
app.get('/api/admin/vstocks/portfolios', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const { search = '', symbol = '' } = req.query as { search?: string; symbol?: string };
    const snap = await getDocs(collection(db, 'portfolios'));
    let portfolios = snap.docs.map((d) => d.data());

    if (symbol) {
      portfolios = portfolios.filter((p) => p.symbol === symbol.toUpperCase());
    }
    if (search) {
      const qLower = search.toLowerCase();
      portfolios = portfolios.filter((p) => p.userId && p.userId.toLowerCase().includes(qLower));
    }

    res.json({ portfolios });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch portfolios' });
  }
});

// Force Liquidate Stock Position
app.post('/api/admin/vstocks/liquidate/:portfolioId', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { portfolioId } = req.params;
    const { reason = 'Administrative liquidation' } = req.body;

    const portRef = doc(db, 'portfolios', portfolioId);
    const portSnap = await getDoc(portRef);
    if (!portSnap.exists()) {
      return res.status(404).json({ error: 'Portfolio entry not found' });
    }

    const portData = portSnap.data();
    const stock = liveStocks.find((s) => s.symbol === portData.symbol);
    const unitPrice = stock ? stock.currentPrice : portData.averageBuyPrice;
    const totalPayout = +(portData.quantity * unitPrice).toFixed(2);
    const now = new Date().toISOString();
    const logId = 'log_' + crypto.randomUUID();

    await runTransaction(db, async (tx) => {
      const userRef = doc(db, 'users', portData.userId);
      const userSnap = await tx.get(userRef);
      if (!userSnap.exists()) throw new Error('USER_NOT_FOUND');

      const newBal = (userSnap.data().lotBalance || 0) + totalPayout;
      tx.update(userRef, { lotBalance: newBal });
      tx.delete(portRef);

      const txId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txId), {
        id: txId,
        userId: portData.userId,
        type: 'admin_adjustment',
        amount: totalPayout,
        balanceAfter: newBal,
        referenceId: portfolioId,
        description: `Admin forced liquidation of ${portData.quantity} shares of ${portData.symbol} (+${totalPayout} LOT)`,
        createdAt: now,
      });

      tx.set(doc(db, 'admin_audit_logs', logId), {
        id: logId,
        adminId: admin.id,
        adminUsername: admin.username,
        action: 'LIQUIDATE_STOCK',
        targetUserId: portData.userId,
        details: `Forced liquidated ${portData.quantity} ${portData.symbol} for ${totalPayout} LOT. Reason: ${reason}`,
        createdAt: now,
      });
    });

    res.json({ success: true, message: `Liquidated position for ${totalPayout} LOT payout.` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to liquidate stock position' });
  }
});

// NEW ADMIN FEATURE 7: VSTOCKS MARKET CONTROLLER (SET PRICE & MARKET EVENTS)
app.post('/api/admin/vstocks/override-price', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { symbol, newPrice, reason } = req.body;

    const priceNum = Number(newPrice);
    if (!symbol || isNaN(priceNum) || priceNum <= 0) {
      return res.status(400).json({ error: 'Valid stock symbol and positive price are required.' });
    }

    const idx = liveStocks.findIndex((s) => s.symbol === symbol.toUpperCase());
    if (idx === -1) {
      return res.status(404).json({ error: 'Stock instrument not found.' });
    }

    const prev = liveStocks[idx].currentPrice;
    const change = +(((priceNum - prev) / prev) * 100).toFixed(2);
    liveStocks[idx].currentPrice = priceNum;
    liveStocks[idx].change24h = change;
    liveStocks[idx].sparkline = [...liveStocks[idx].sparkline.slice(1), priceNum];

    // Audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: 'STOCK_PRICE_OVERRIDE',
      details: `Admin price override for ${symbol.toUpperCase()}: ${prev} -> ${priceNum} LOT (${change}%). Reason: ${reason || 'Admin intervention'}`,
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, stock: liveStocks[idx] });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to override stock price' });
  }
});

// Market events: Bull surge or Bear correction
app.post('/api/admin/vstocks/trigger-event', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { eventType, percentage = 15 } = req.body;

    const mult = eventType === 'surge' ? 1 + percentage / 100 : 1 - percentage / 100;

    liveStocks = liveStocks.map((stock) => {
      const newPrice = Math.max(1, +(stock.currentPrice * mult).toFixed(2));
      const change = +(((newPrice - stock.previousPrice) / stock.previousPrice) * 100).toFixed(2);
      return {
        ...stock,
        currentPrice: newPrice,
        change24h: change,
        sparkline: [...stock.sparkline.slice(1), newPrice],
      };
    });

    // Audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: 'MARKET_EVENT',
      details: `Admin triggered ${eventType.toUpperCase()} event (${percentage}%) across all market instruments`,
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, message: `Market event ${eventType} executed.`, liveStocks });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to trigger market event' });
  }
});

// NEW ADMIN FEATURE 8: SHOP CATALOG SEARCH & EDIT LISTING
app.get('/api/admin/shop/listings', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const { search = '', category = '' } = req.query as { search?: string; category?: string };
    const snap = await getDocs(collection(db, 'listings'));
    let listings = snap.docs.map((d) => d.data());

    if (category) {
      listings = listings.filter((l) => l.category === category);
    }
    if (search) {
      const qLower = search.toLowerCase();
      listings = listings.filter(
        (l) =>
          (l.title && l.title.toLowerCase().includes(qLower)) ||
          (l.sellerUsername && l.sellerUsername.toLowerCase().includes(qLower)) ||
          (l.id && l.id.toLowerCase().includes(qLower))
      );
    }

    res.json({ listings });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch shop listings' });
  }
});

app.patch('/api/admin/shop/listings/:listingId', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { listingId } = req.params;
    const { priceLot, stock, status, isFeatured } = req.body;

    const listRef = doc(db, 'listings', listingId);
    const snap = await getDoc(listRef);
    if (!snap.exists()) {
      return res.status(404).json({ error: 'Listing not found' });
    }

    const updates: any = {};
    if (priceLot !== undefined) updates.priceLot = Math.max(1, Number(priceLot));
    if (stock !== undefined) updates.stock = Math.max(0, Number(stock));
    if (status !== undefined) updates.status = status;
    if (isFeatured !== undefined) updates.isFeatured = !!isFeatured;

    await updateDoc(listRef, updates);

    // Audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: 'UPDATE_SHOP_LISTING',
      details: `Admin modified listing "${snap.data().title}" (${listingId}): ${JSON.stringify(updates)}`,
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, updates });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update shop listing' });
  }
});

// NEW ADMIN FEATURE 9: ORDER FORCE REFUND DISPUTE RESOLVER
app.post('/api/admin/orders/:orderId/refund', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { orderId } = req.params;
    const { reason = 'Order dispute resolution' } = req.body;

    const orderRef = doc(db, 'orders', orderId);
    const orderSnap = await getDoc(orderRef);
    if (!orderSnap.exists()) {
      return res.status(404).json({ error: 'Order not found' });
    }

    const oData = orderSnap.data();
    if (oData.status === 'Refunded') {
      return res.status(400).json({ error: 'Order already refunded.' });
    }

    const now = new Date().toISOString();
    const logId = 'log_' + crypto.randomUUID();

    await runTransaction(db, async (tx) => {
      const buyerRef = doc(db, 'users', oData.buyerId);
      const buyerSnap = await tx.get(buyerRef);
      if (!buyerSnap.exists()) throw new Error('BUYER_NOT_FOUND');

      const newBuyerBal = (buyerSnap.data().lotBalance || 0) + oData.totalLot;
      tx.update(buyerRef, { lotBalance: newBuyerBal });
      tx.update(orderRef, { status: 'Refunded', refundedAt: now, refundedBy: admin.username });

      // Ledger entry
      const txId = 'tx_' + crypto.randomUUID();
      tx.set(doc(db, 'transactions', txId), {
        id: txId,
        userId: oData.buyerId,
        type: 'admin_adjustment',
        amount: oData.totalLot,
        balanceAfter: newBuyerBal,
        referenceId: orderId,
        description: `Admin refund for order #${orderId} (${oData.listingTitle}): +${oData.totalLot} LOT`,
        createdAt: now,
      });

      // Audit log
      tx.set(doc(db, 'admin_audit_logs', logId), {
        id: logId,
        adminId: admin.id,
        adminUsername: admin.username,
        action: 'ORDER_REFUND',
        targetUserId: oData.buyerId,
        details: `Force refunded order ${orderId} (${oData.totalLot} LOT) to @${oData.buyerUsername}. Reason: ${reason}`,
        createdAt: now,
      });

      // Notification
      const notifId = 'notif_' + crypto.randomUUID();
      tx.set(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: oData.buyerId,
        title: 'Order Refund Processed 💰',
        message: `Admin @${admin.username} has refunded ${oData.totalLot} LOT for order "${oData.listingTitle}".`,
        type: 'admin',
        read: false,
        createdAt: now,
      });
    });

    res.json({ success: true, message: `Refunded ${oData.totalLot} LOT to buyer @${oData.buyerUsername}.` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to refund order' });
  }
});

// NEW ADMIN FEATURE 10: MASS BATCH LOT AIRDROP
app.post('/api/admin/batch-airdrop', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { targetType = 'all', usernames = [], amount, memo } = req.body;

    const amt = Number(amount);
    if (!amt || amt <= 0) {
      return res.status(400).json({ error: 'Valid positive airdrop amount required.' });
    }

    const note = memo && memo.trim() ? memo.trim() : 'Ecosystem community grant';
    const now = new Date().toISOString();
    let targetUsers: { id: string; username: string }[] = [];

    if (targetType === 'all') {
      const snap = await getDocs(collection(db, 'users'));
      targetUsers = snap.docs
        .map((d) => ({ id: d.id, username: d.data().username, isBanned: d.data().isBanned }))
        .filter((u: any) => !u.isBanned);
    } else {
      for (const uname of usernames) {
        const uLower = uname.replace(/^@/, '').trim().toLowerCase();
        const unSnap = await getDoc(doc(db, 'usernames', uLower));
        if (unSnap.exists()) {
          targetUsers.push({ id: unSnap.data().uid, username: unSnap.data().username });
        }
      }
    }

    if (targetUsers.length === 0) {
      return res.status(400).json({ error: 'No valid recipient users found for airdrop.' });
    }

    // Process airdrops
    for (const u of targetUsers) {
      try {
        await runTransaction(db, async (tx) => {
          const uRef = doc(db, 'users', u.id);
          const uSnap = await tx.get(uRef);
          if (!uSnap.exists()) return;

          const newBal = (uSnap.data().lotBalance || 0) + amt;
          tx.update(uRef, { lotBalance: newBal });

          const txId = 'tx_' + crypto.randomUUID();
          tx.set(doc(db, 'transactions', txId), {
            id: txId,
            userId: u.id,
            type: 'admin_adjustment',
            amount: amt,
            balanceAfter: newBal,
            referenceId: 'airdrop_' + now,
            description: `Community Airdrop (+${amt} LOT): ${note}`,
            createdAt: now,
          });

          const notifId = 'notif_' + crypto.randomUUID();
          tx.set(doc(db, 'notifications', notifId), {
            id: notifId,
            userId: u.id,
            title: 'Community LOT Airdrop Received! 🎁',
            message: `You received ${amt.toLocaleString()} LOT from the ecosystem treasury! Note: ${note}`,
            type: 'admin',
            read: false,
            createdAt: now,
          });
        });
      } catch {
        // continue
      }
    }

    // Audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: 'BATCH_AIRDROP',
      details: `Airdropped ${amt} LOT each to ${targetUsers.length} accounts. Note: ${note}`,
      createdAt: now,
    });

    res.json({
      success: true,
      message: `Airdropped ${amt.toLocaleString()} LOT to ${targetUsers.length} users successfully!`,
      recipientCount: targetUsers.length,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to process batch airdrop' });
  }
});

// NEW ADMIN FEATURE 11: TARGETED DIRECT ADMIN NOTIFICATION
app.post('/api/admin/direct-message', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { username, title, message } = req.body;

    if (!username || !title || !message) {
      return res.status(400).json({ error: 'Username, title, and message are required.' });
    }

    const uLower = username.replace(/^@/, '').trim().toLowerCase();
    const unSnap = await getDoc(doc(db, 'usernames', uLower));
    if (!unSnap.exists()) {
      return res.status(404).json({ error: `User "@${username}" not found.` });
    }

    const targetUid = unSnap.data().uid;
    const notifId = 'notif_' + crypto.randomUUID();
    const now = new Date().toISOString();

    await setDoc(doc(db, 'notifications', notifId), {
      id: notifId,
      userId: targetUid,
      title: `[ADMIN ALERT] ${title.trim()}`,
      message: message.trim(),
      type: 'admin',
      read: false,
      createdAt: now,
    });

    res.json({ success: true, message: `Direct admin alert sent to @${username}.` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to send direct message' });
  }
});

// NEW ADMIN FEATURE 12: ANTI-CHEAT & WEALTH RADAR
app.get('/api/admin/anti-cheat/radar', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const [usersSnap, transfersSnap] = await Promise.all([
      getDocs(collection(db, 'users')),
      getDocs(collection(db, 'vpay_transfers')),
    ]);

    const users = usersSnap.docs.map((d) => d.data());
    const transfers = transfersSnap.docs.map((d) => d.data());

    // Top 10 Wealthiest Accounts
    const topWallets = [...users]
      .sort((a, b) => (b.lotBalance || 0) - (a.lotBalance || 0))
      .slice(0, 10)
      .map((u) => ({
        username: u.username,
        lotBalance: u.lotBalance || 0,
        isAdmin: !!u.isAdmin,
        isBanned: !!u.isBanned,
        createdAt: u.createdAt,
      }));

    // Detect High-Value Transfers (> 5,000 LOT)
    const largeTransfers = transfers
      .filter((t) => t.amount >= 5000)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 15);

    // Banned accounts
    const bannedUsers = users.filter((u) => u.isBanned).map((u) => ({ username: u.username, id: u.id, lotBalance: u.lotBalance }));

    res.json({
      topWallets,
      largeTransfers,
      bannedUsers,
      totalRegistered: users.length,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to compute anti-cheat radar' });
  }
});

// NEW ADMIN FEATURE 13: MINIGAME CONTROLLER & COOLDOWN RESET
app.post('/api/admin/minigames/reset-cooldown', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const { username } = req.body;
    if (!username) {
      // Clear all cooldowns
      userGameCooldowns.clear();
      return res.json({ success: true, message: 'All minigame cooldowns cleared globally.' });
    }

    const uLower = username.replace(/^@/, '').trim().toLowerCase();
    const unSnap = await getDoc(doc(db, 'usernames', uLower));
    if (!unSnap.exists()) {
      return res.status(404).json({ error: 'User not found' });
    }

    const uid = unSnap.data().uid;
    for (const key of userGameCooldowns.keys()) {
      if (key.startsWith(uid)) {
        userGameCooldowns.delete(key);
      }
    }

    res.json({ success: true, message: `Cleared minigame cooldowns for @${username}.` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to reset cooldown' });
  }
});

// Admin Redemption Codes: POST /api/admin/redemption/create
app.post('/api/admin/redemption/create', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { code, rewardLot, maxClaims, expiresAt } = req.body;

    if (!code || typeof code !== 'string' || code.trim().length < 3) {
      return res.status(400).json({ error: 'Code must be at least 3 characters.' });
    }

    const cleanCode = code.trim().toUpperCase();
    const reward = Number(rewardLot);
    const max = Number(maxClaims);

    if (!reward || reward <= 0) {
      return res.status(400).json({ error: 'Reward must be greater than 0 LOT.' });
    }

    if (!max || max <= 0) {
      return res.status(400).json({ error: 'Max claims must be at least 1.' });
    }

    const codeRef = doc(db, 'redemption_codes', cleanCode);
    const existing = await getDoc(codeRef);
    if (existing.exists()) {
      return res.status(409).json({ error: 'A redemption code with this name already exists.' });
    }

    const codeData = {
      id: cleanCode,
      code: cleanCode,
      rewardLot: reward,
      maxClaims: max,
      claimsCount: 0,
      isActive: true,
      expiresAt: expiresAt || null,
      createdBy: admin.username,
      createdAt: new Date().toISOString(),
    };

    await setDoc(codeRef, codeData);

    res.json({ success: true, code: codeData });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to create redemption code' });
  }
});

// Admin Redemption Codes: POST /api/admin/redemption/batch-create
app.post('/api/admin/redemption/batch-create', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { prefix = 'LOT', count = 5, rewardLot = 500, maxClaims = 1, expiresAt } = req.body;

    const countNum = Math.min(50, Math.max(1, Number(count) || 5));
    const reward = Math.max(1, Number(rewardLot) || 500);
    const max = Math.max(1, Number(maxClaims) || 1);
    const cleanPrefix = (prefix || 'LOT').trim().toUpperCase().replace(/[^A-Z0-9]/g, '') || 'LOT';

    const generatedCodes: any[] = [];
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const now = new Date().toISOString();

    for (let i = 0; i < countNum; i++) {
      let rand = '';
      for (let j = 0; j < 6; j++) {
        rand += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      const codeStr = `${cleanPrefix}-${rand}`;
      const codeRef = doc(db, 'redemption_codes', codeStr);
      const codeData = {
        id: codeStr,
        code: codeStr,
        rewardLot: reward,
        maxClaims: max,
        claimsCount: 0,
        isActive: true,
        expiresAt: expiresAt || null,
        createdBy: admin.username,
        createdAt: now,
      };
      await setDoc(codeRef, codeData);
      generatedCodes.push(codeData);
    }

    // Audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: 'BATCH_CREATE_CODES',
      details: `Generated ${generatedCodes.length} redemption codes with prefix "${cleanPrefix}", reward ${reward} LOT each.`,
      createdAt: now,
    });

    res.json({ success: true, count: generatedCodes.length, codes: generatedCodes });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to batch generate codes' });
  }
});

// GET /api/admin/redemption/list
app.get('/api/admin/redemption/list', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const snap = await getDocs(collection(db, 'redemption_codes'));
    const codes = snap.docs.map((d) => d.data());
    codes.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    // Also get all claims to show claimants
    const claimsSnap = await getDocs(collection(db, 'redemption_claims'));
    const claims = claimsSnap.docs.map((d) => d.data());

    res.json({ codes, claims });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch redemption codes' });
  }
});

// PATCH /api/admin/redemption/:code/toggle
app.patch('/api/admin/redemption/:code/toggle', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const { code } = req.params;
    const { isActive } = req.body;
    await updateDoc(doc(db, 'redemption_codes', code.toUpperCase()), {
      isActive: !!isActive,
    });
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update code status' });
  }
});

// DELETE /api/admin/redemption/:code
app.delete('/api/admin/redemption/:code', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { code } = req.params;
    const cleanCode = code.toUpperCase();

    const codeRef = doc(db, 'redemption_codes', cleanCode);
    const snap = await getDoc(codeRef);
    if (!snap.exists()) {
      return res.status(404).json({ error: 'Redemption code not found.' });
    }

    await deleteDoc(codeRef);

    // Audit log
    const logId = 'log_' + crypto.randomUUID();
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      id: logId,
      adminId: admin.id,
      adminUsername: admin.username,
      action: 'DELETE_REDEMPTION_CODE',
      details: `Deleted redemption code ${cleanCode}`,
      createdAt: new Date().toISOString(),
    });

    res.json({ success: true, message: `Redemption code ${cleanCode} deleted.` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete redemption code' });
  }
});

// POST /api/admin/announcements
app.post('/api/admin/announcements', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const admin = (req as any).user;
    const { title, content } = req.body;

    if (!title || !content) {
      return res.status(400).json({ error: 'Title and content are required.' });
    }

    const announcementId = 'ann_' + crypto.randomUUID();
    const now = new Date().toISOString();

    const data = {
      id: announcementId,
      title: title.trim(),
      content: content.trim(),
      author: admin.username,
      createdAt: now,
    };

    await setDoc(doc(db, 'announcements', announcementId), data);

    res.json({ success: true, announcement: data });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to publish announcement' });
  }
});

// DELETE /api/admin/announcements/:id
app.delete('/api/admin/announcements/:id', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    await deleteDoc(doc(db, 'announcements', id));
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete announcement' });
  }
});

// GET /api/admin/audit-logs
app.get('/api/admin/audit-logs', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const snap = await getDocs(collection(db, 'admin_audit_logs'));
    const logs = snap.docs.map((d) => d.data());
    logs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ logs: logs.slice(0, 100) });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch audit logs' });
  }
});

// GET /api/admin/stats
app.get('/api/admin/stats', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const [usersSnap, listingsSnap, ordersSnap, tradesSnap, transfersSnap] = await Promise.all([
      getDocs(collection(db, 'users')),
      getDocs(collection(db, 'listings')),
      getDocs(collection(db, 'orders')),
      getDocs(collection(db, 'trades')),
      getDocs(collection(db, 'vpay_transfers')),
    ]);

    let circulatingLot = 0;
    usersSnap.forEach((doc) => {
      circulatingLot += doc.data().lotBalance || 0;
    });

    res.json({
      totalUsers: usersSnap.size,
      circulatingLot: +circulatingLot.toFixed(2),
      activeListings: listingsSnap.size,
      completedOrders: ordersSnap.size,
      totalTrades: tradesSnap.size,
      totalTransfers: transfersSnap.size,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch platform stats' });
  }
});

// GET /api/admin/all-orders
app.get('/api/admin/all-orders', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
  try {
    const snap = await getDocs(collection(db, 'orders'));
    const orders = snap.docs.map((d) => d.data());
    orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ orders });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// ----------------------------------------------------
// 12. PLAYER SOCIAL, MESSAGING & CALLING API
// ----------------------------------------------------

// Helper: Check if userA has blocked userB
async function isBlockedBetween(userAId: string, userBId: string): Promise<{ aBlockedB: boolean; bBlockedA: boolean }> {
  try {
    const [snapA, snapB] = await Promise.all([
      getDoc(doc(db, 'blocks', `block_${userAId}_${userBId}`)),
      getDoc(doc(db, 'blocks', `block_${userBId}_${userAId}`)),
    ]);
    return {
      aBlockedB: snapA.exists(),
      bBlockedA: snapB.exists(),
    };
  } catch {
    return { aBlockedB: false, bBlockedA: false };
  }
}

// GET /api/players/search?q=username
app.get('/api/players/search', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const qStr = String(req.query.q || '').trim().toLowerCase();

    const usersSnap = await getDocs(collection(db, 'users'));
    let matched = usersSnap.docs.map((d) => d.data());

    // Exclude current user and filter by query
    matched = matched.filter((u) => u.id !== current.id);
    if (qStr) {
      matched = matched.filter((u) => (u.usernameLower || u.username.toLowerCase()).includes(qStr));
    }

    matched = matched.slice(0, 20);

    // Enrich with friend & block status
    const enriched = await Promise.all(
      matched.map(async (u) => {
        const [friendSnap, blockSnap, blockedMeSnap] = await Promise.all([
          getDoc(doc(db, 'friends', `friend_${current.id}_${u.id}`)),
          getDoc(doc(db, 'blocks', `block_${current.id}_${u.id}`)),
          getDoc(doc(db, 'blocks', `block_${u.id}_${current.id}`)),
        ]);

        return {
          id: u.id,
          username: u.username,
          avatarUrl: u.avatarUrl || '',
          lotBalance: u.lotBalance || 0,
          vipBadge: u.vipBadge,
          isAdmin: !!u.isAdmin,
          isFriend: friendSnap.exists(),
          isBlocked: blockSnap.exists(),
          hasBlockedMe: blockedMeSnap.exists(),
          isOnline: isUserOnline(u.id),
        };
      })
    );

    res.json({ players: enriched });
  } catch (err: any) {
    console.error('Player search error:', err);
    res.status(500).json({ error: 'Failed to search players' });
  }
});

// GET /api/players/lookup/:username
app.get('/api/players/lookup/:username', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const targetUsername = String(req.params.username || '').trim().toLowerCase();

    if (!targetUsername) {
      return res.status(400).json({ error: 'Username required' });
    }

    const usernameSnap = await getDoc(doc(db, 'usernames', targetUsername));
    if (!usernameSnap.exists()) {
      return res.status(404).json({ error: `Player "@${targetUsername}" not found` });
    }

    const targetUid = usernameSnap.data().uid;
    const userSnap = await getDoc(doc(db, 'users', targetUid));
    if (!userSnap.exists()) {
      return res.status(404).json({ error: 'Player profile not found' });
    }

    const u = userSnap.data();
    const [friendSnap, blockSnap, blockedMeSnap] = await Promise.all([
      getDoc(doc(db, 'friends', `friend_${current.id}_${u.id}`)),
      getDoc(doc(db, 'blocks', `block_${current.id}_${u.id}`)),
      getDoc(doc(db, 'blocks', `block_${u.id}_${current.id}`)),
    ]);

    res.json({
      player: {
        id: u.id,
        username: u.username,
        avatarUrl: u.avatarUrl || '',
        lotBalance: u.lotBalance || 0,
        vipBadge: u.vipBadge,
        isAdmin: !!u.isAdmin,
        isFriend: friendSnap.exists(),
        isBlocked: blockSnap.exists(),
        hasBlockedMe: blockedMeSnap.exists(),
        isOnline: isUserOnline(u.id),
        createdAt: u.createdAt,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to lookup player' });
  }
});

// GET /api/chat/conversations
app.get('/api/chat/conversations', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;

    // Fetch messages where user is sender or recipient
    const [sentSnap, recvSnap] = await Promise.all([
      getDocs(query(collection(db, 'direct_messages'), where('senderId', '==', current.id))),
      getDocs(query(collection(db, 'direct_messages'), where('recipientId', '==', current.id))),
    ]);

    const allMsgs = [...sentSnap.docs.map((d) => d.data()), ...recvSnap.docs.map((d) => d.data())];

    // Group by partnerId
    const groups = new Map<string, any[]>();
    for (const msg of allMsgs) {
      const partnerId = msg.senderId === current.id ? msg.recipientId : msg.senderId;
      if (!groups.has(partnerId)) {
        groups.set(partnerId, []);
      }
      groups.get(partnerId)!.push(msg);
    }

    const convList = await Promise.all(
      Array.from(groups.entries()).map(async ([partnerId, msgs]) => {
        msgs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        const latest = msgs[0];
        const unreadCount = msgs.filter((m) => m.recipientId === current.id && !m.read).length;

        // Fetch partner details
        let partnerUsername = latest.senderId === partnerId ? latest.senderUsername : latest.recipientUsername;
        let partnerAvatar = latest.senderId === partnerId ? latest.senderAvatarUrl : latest.recipientAvatarUrl;
        let partnerBalance = 0;
        let partnerVipBadge: string | undefined = undefined;

        try {
          const userSnap = await getDoc(doc(db, 'users', partnerId));
          if (userSnap.exists()) {
            const ud = userSnap.data();
            partnerUsername = ud.username || partnerUsername;
            partnerAvatar = ud.avatarUrl || partnerAvatar || '';
            partnerBalance = ud.lotBalance || 0;
            partnerVipBadge = ud.vipBadge;
          }
        } catch {}

        const blockInfo = await isBlockedBetween(current.id, partnerId);
        const friendSnap = await getDoc(doc(db, 'friends', `friend_${current.id}_${partnerId}`));

        return {
          id: [current.id, partnerId].sort().join('_'),
          partnerId,
          partnerUsername: partnerUsername || 'Player',
          partnerAvatarUrl: partnerAvatar || '',
          partnerBalance,
          partnerVipBadge,
          lastMessage: latest.content,
          lastMessageTime: latest.createdAt,
          lastSenderId: latest.senderId,
          unreadCount,
          isFriend: friendSnap.exists(),
          isBlocked: blockInfo.aBlockedB,
          hasBlockedMe: blockInfo.bBlockedA,
          isOnline: isUserOnline(partnerId),
        };
      })
    );

    convList.sort((a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime());

    res.json({ conversations: convList });
  } catch (err: any) {
    console.error('Conversations error:', err);
    res.status(500).json({ error: 'Failed to fetch conversations' });
  }
});

// GET /api/chat/messages/:partnerId
app.get('/api/chat/messages/:partnerId', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const partnerId = String(req.params.partnerId);

    const [sentSnap, recvSnap] = await Promise.all([
      getDocs(query(collection(db, 'direct_messages'), where('senderId', '==', current.id), where('recipientId', '==', partnerId))),
      getDocs(query(collection(db, 'direct_messages'), where('senderId', '==', partnerId), where('recipientId', '==', current.id))),
    ]);

    const messages = [...sentSnap.docs.map((d) => d.data()), ...recvSnap.docs.map((d) => d.data())];
    messages.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    // Mark unread messages from partner as read
    const unreadDocs = recvSnap.docs.filter((d) => !d.data().read);
    if (unreadDocs.length > 0) {
      Promise.all(unreadDocs.map((d) => updateDoc(doc(db, 'direct_messages', d.id), { read: true }))).catch(() => {});
      sendToUser(partnerId, 'chat:read', { readerId: current.id });
    }

    res.json({ messages });
  } catch (err: any) {
    console.error('Messages error:', err);
    res.status(500).json({ error: 'Failed to load messages' });
  }
});

// POST /api/chat/messages
app.post('/api/chat/messages', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const {
      recipientId: reqRecipientId,
      recipientUsername,
      content,
      attachmentUrl,
      mediaType,
      fileName,
      fileSize,
      type = 'text',
    } = req.body;

    const trimmedContent = typeof content === 'string' ? content.trim() : '';

    if (!trimmedContent && !attachmentUrl) {
      return res.status(400).json({ error: 'Message or attachment is required' });
    }

    if (trimmedContent.length > 3000) {
      return res.status(400).json({ error: 'Message exceeds 3000 character limit' });
    }

    let targetUid = reqRecipientId;
    let targetUsername = recipientUsername;
    let targetAvatar = '';

    if (!targetUid && recipientUsername) {
      const uSnap = await getDoc(doc(db, 'usernames', recipientUsername.trim().toLowerCase()));
      if (!uSnap.exists()) {
        return res.status(404).json({ error: `Player "@${recipientUsername}" not found` });
      }
      targetUid = uSnap.data().uid;
      targetUsername = uSnap.data().username;
    }

    if (!targetUid) {
      return res.status(400).json({ error: 'Recipient is required' });
    }

    if (targetUid === current.id) {
      return res.status(400).json({ error: 'You cannot message yourself' });
    }

    // Fetch target user profile
    const targetUserSnap = await getDoc(doc(db, 'users', targetUid));
    if (!targetUserSnap.exists()) {
      return res.status(404).json({ error: 'Recipient account does not exist' });
    }
    const targetUserData = targetUserSnap.data();
    targetUsername = targetUserData.username || targetUsername;
    targetAvatar = targetUserData.avatarUrl || '';

    // Check block status
    const blockInfo = await isBlockedBetween(current.id, targetUid);
    if (blockInfo.aBlockedB) {
      return res.status(400).json({ error: 'You have blocked this player. Unblock them first to send messages.' });
    }
    if (blockInfo.bBlockedA) {
      return res.status(403).json({ error: 'You cannot message this player because they have blocked you.' });
    }

    // Get current user avatar
    const senderSnap = await getDoc(doc(db, 'users', current.id));
    const senderAvatar = senderSnap.exists() ? senderSnap.data().avatarUrl || '' : '';

    const msgId = 'msg_' + crypto.randomUUID();
    const conversationId = [current.id, targetUid].sort().join('_');
    const now = new Date().toISOString();

    const resolvedType = attachmentUrl
      ? mediaType === 'gif'
        ? 'gif'
        : 'image'
      : type || 'text';

    const messageData = {
      id: msgId,
      conversationId,
      senderId: current.id,
      senderUsername: current.username,
      senderAvatarUrl: senderAvatar,
      recipientId: targetUid,
      recipientUsername: targetUsername,
      recipientAvatarUrl: targetAvatar,
      content: trimmedContent,
      type: resolvedType,
      attachmentUrl: attachmentUrl || null,
      mediaType: mediaType || null,
      fileName: fileName || null,
      fileSize: fileSize || null,
      read: false,
      createdAt: now,
    };

    await setDoc(doc(db, 'direct_messages', msgId), messageData);

    // Send real-time event to recipient via WebSocket
    sendToUser(targetUid, 'chat:message', { message: messageData });

    // Send notification to recipient
    const notifMessage = trimmedContent
      ? trimmedContent.slice(0, 100)
      : mediaType === 'gif'
      ? 'Sent an animated GIF'
      : 'Sent a photo attachment';

    const notifId = 'notif_' + crypto.randomUUID();
    setDoc(doc(db, 'notifications', notifId), {
      id: notifId,
      userId: targetUid,
      title: `Message from @${current.username}`,
      message: notifMessage,
      type: 'message',
      read: false,
      createdAt: now,
    }).catch(() => {});

    res.json({ success: true, message: messageData });
  } catch (err: any) {
    console.error('Send message error:', err);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

// POST /api/chat/read/:partnerId
app.post('/api/chat/read/:partnerId', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const partnerId = String(req.params.partnerId);

    const recvSnap = await getDocs(
      query(collection(db, 'direct_messages'), where('senderId', '==', partnerId), where('recipientId', '==', current.id), where('read', '==', false))
    );

    await Promise.all(recvSnap.docs.map((d) => updateDoc(doc(db, 'direct_messages', d.id), { read: true })));
    sendToUser(partnerId, 'chat:read', { readerId: current.id });

    res.json({ success: true, markedCount: recvSnap.docs.length });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to mark messages read' });
  }
});

// POST /api/chat/clear/:partnerId
app.post('/api/chat/clear/:partnerId', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const partnerId = String(req.params.partnerId);

    const [sentSnap, recvSnap] = await Promise.all([
      getDocs(query(collection(db, 'direct_messages'), where('senderId', '==', current.id), where('recipientId', '==', partnerId))),
      getDocs(query(collection(db, 'direct_messages'), where('senderId', '==', partnerId), where('recipientId', '==', current.id))),
    ]);

    const allDocs = [...sentSnap.docs, ...recvSnap.docs];
    await Promise.all(allDocs.map((d) => deleteDoc(doc(db, 'direct_messages', d.id))));

    res.json({ success: true, clearedCount: allDocs.length });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to clear chat' });
  }
});

// GET /api/friends
app.get('/api/friends', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const snap = await getDocs(query(collection(db, 'friends'), where('userId', '==', current.id)));

    const friendsList = await Promise.all(
      snap.docs.map(async (d) => {
        const item = d.data();
        let friendUsername = item.friendUsername;
        let friendAvatar = item.friendAvatarUrl || '';
        let friendBalance = item.friendBalance || 0;

        try {
          const uSnap = await getDoc(doc(db, 'users', item.friendId));
          if (uSnap.exists()) {
            const ud = uSnap.data();
            friendUsername = ud.username || friendUsername;
            friendAvatar = ud.avatarUrl || friendAvatar;
            friendBalance = ud.lotBalance || 0;
          }
        } catch {}

        return {
          id: d.id,
          userId: current.id,
          friendId: item.friendId,
          friendUsername,
          friendAvatarUrl: friendAvatar,
          friendBalance,
          isOnline: isUserOnline(item.friendId),
          createdAt: item.createdAt,
        };
      })
    );

    friendsList.sort((a, b) => (b.isOnline ? 1 : 0) - (a.isOnline ? 1 : 0) || a.friendUsername.localeCompare(b.friendUsername));
    res.json({ friends: friendsList });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch friends' });
  }
});

// POST /api/friends/toggle
app.post('/api/friends/toggle', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const { targetUserId } = req.body;

    if (!targetUserId || targetUserId === current.id) {
      return res.status(400).json({ error: 'Invalid target player' });
    }

    const docId = `friend_${current.id}_${targetUserId}`;
    const friendRef = doc(db, 'friends', docId);
    const snap = await getDoc(friendRef);

    if (snap.exists()) {
      await deleteDoc(friendRef);
      sendToUser(targetUserId, 'friend:update', { userId: current.id, isFriend: false });
      return res.json({ success: true, isFriend: false, message: 'Unfriended player' });
    }

    // Add friend
    const targetSnap = await getDoc(doc(db, 'users', targetUserId));
    if (!targetSnap.exists()) {
      return res.status(404).json({ error: 'Target player not found' });
    }
    const targetData = targetSnap.data();

    const newRecord = {
      id: docId,
      userId: current.id,
      friendId: targetUserId,
      friendUsername: targetData.username,
      friendAvatarUrl: targetData.avatarUrl || '',
      createdAt: new Date().toISOString(),
    };

    await setDoc(friendRef, newRecord);
    sendToUser(targetUserId, 'friend:update', { userId: current.id, isFriend: true });

    res.json({ success: true, isFriend: true, message: `Added @${targetData.username} as friend` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update friend status' });
  }
});

// GET /api/blocks
app.get('/api/blocks', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const snap = await getDocs(query(collection(db, 'blocks'), where('userId', '==', current.id)));

    const blocksList = await Promise.all(
      snap.docs.map(async (d) => {
        const item = d.data();
        let targetUsername = item.blockedUsername;
        let targetAvatar = item.blockedAvatarUrl || '';

        try {
          const uSnap = await getDoc(doc(db, 'users', item.blockedUserId));
          if (uSnap.exists()) {
            const ud = uSnap.data();
            targetUsername = ud.username || targetUsername;
            targetAvatar = ud.avatarUrl || targetAvatar;
          }
        } catch {}

        return {
          id: d.id,
          userId: current.id,
          blockedUserId: item.blockedUserId,
          blockedUsername: targetUsername,
          blockedAvatarUrl: targetAvatar,
          createdAt: item.createdAt,
        };
      })
    );

    res.json({ blocks: blocksList });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch blocked users' });
  }
});

// POST /api/blocks/toggle
app.post('/api/blocks/toggle', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const { targetUserId } = req.body;

    if (!targetUserId || targetUserId === current.id) {
      return res.status(400).json({ error: 'Invalid target player' });
    }

    const docId = `block_${current.id}_${targetUserId}`;
    const blockRef = doc(db, 'blocks', docId);
    const snap = await getDoc(blockRef);

    if (snap.exists()) {
      await deleteDoc(blockRef);
      sendToUser(targetUserId, 'block:update', { userId: current.id, isBlocked: false });
      return res.json({ success: true, isBlocked: false, message: 'Unblocked player' });
    }

    // Block player
    const targetSnap = await getDoc(doc(db, 'users', targetUserId));
    if (!targetSnap.exists()) {
      return res.status(404).json({ error: 'Target player not found' });
    }
    const targetData = targetSnap.data();

    // If they were friends, automatically unfriend
    const friendRef = doc(db, 'friends', `friend_${current.id}_${targetUserId}`);
    deleteDoc(friendRef).catch(() => {});

    const newRecord = {
      id: docId,
      userId: current.id,
      blockedUserId: targetUserId,
      blockedUsername: targetData.username,
      blockedAvatarUrl: targetData.avatarUrl || '',
      createdAt: new Date().toISOString(),
    };

    await setDoc(blockRef, newRecord);
    sendToUser(targetUserId, 'block:update', { userId: current.id, isBlocked: true });

    res.json({ success: true, isBlocked: true, message: `Blocked @${targetData.username}` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update block status' });
  }
});

// POST /api/call/initiate
app.post('/api/call/initiate', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const { recipientId: reqRecipientId, recipientUsername, type = 'audio' } = req.body;

    let targetUid = reqRecipientId;
    let targetUsername = recipientUsername;
    let targetAvatar = '';

    if (!targetUid && recipientUsername) {
      const uSnap = await getDoc(doc(db, 'usernames', recipientUsername.trim().toLowerCase()));
      if (!uSnap.exists()) {
        return res.status(404).json({ error: `Player "@${recipientUsername}" not found` });
      }
      targetUid = uSnap.data().uid;
    }

    if (!targetUid) {
      return res.status(400).json({ error: 'Recipient is required' });
    }

    if (targetUid === current.id) {
      return res.status(400).json({ error: 'You cannot call yourself' });
    }

    const targetUserSnap = await getDoc(doc(db, 'users', targetUid));
    if (!targetUserSnap.exists()) {
      return res.status(404).json({ error: 'Recipient account does not exist' });
    }
    const targetData = targetUserSnap.data();
    targetUsername = targetData.username || targetUsername;
    targetAvatar = targetData.avatarUrl || '';

    // Check block
    const blockInfo = await isBlockedBetween(current.id, targetUid);
    if (blockInfo.aBlockedB || blockInfo.bBlockedA) {
      return res.status(403).json({ error: 'Cannot place call due to block restrictions.' });
    }

    // Check if recipient is already in an active call session
    const [busyRecipient1, busyRecipient2] = await Promise.all([
      getDocs(query(collection(db, 'calls'), where('recipientId', '==', targetUid), where('status', 'in', ['ringing', 'connected']))),
      getDocs(query(collection(db, 'calls'), where('callerId', '==', targetUid), where('status', 'in', ['ringing', 'connected']))),
    ]);
    if (!busyRecipient1.empty || !busyRecipient2.empty) {
      return res.status(486).json({ error: `@${targetUsername} is currently in another call.` });
    }

    const callerSnap = await getDoc(doc(db, 'users', current.id));
    const callerAvatar = callerSnap.exists() ? callerSnap.data().avatarUrl || '' : '';

    const callId = 'call_' + crypto.randomUUID();
    const now = new Date().toISOString();

    const callData = {
      id: callId,
      callerId: current.id,
      callerUsername: current.username,
      callerAvatarUrl: callerAvatar,
      recipientId: targetUid,
      recipientUsername: targetUsername,
      recipientAvatarUrl: targetAvatar,
      type: type === 'video' ? 'video' : 'audio',
      status: 'ringing',
      startedAt: now,
    };

    await setDoc(doc(db, 'calls', callId), callData);

    // Also record a real-time call event inside direct_messages so both players see it in chat
    const msgId = 'msg_call_' + callId;
    const conversationId = [current.id, targetUid].sort().join('_');
    const callMessage = {
      id: msgId,
      conversationId,
      senderId: current.id,
      senderUsername: current.username,
      senderAvatarUrl: callerAvatar,
      recipientId: targetUid,
      recipientUsername: targetUsername,
      recipientAvatarUrl: targetAvatar,
      content: `📞 Started a ${type === 'video' ? 'video' : 'audio'} call`,
      type: 'call',
      callId,
      callType: type === 'video' ? 'video' : 'audio',
      callStatus: 'ringing',
      read: false,
      createdAt: now,
    };
    await setDoc(doc(db, 'direct_messages', msgId), callMessage);

    // Notify recipient and caller over WebSocket
    const reached = sendToUser(targetUid, 'call:incoming', { call: callData });
    sendToUser(targetUid, 'chat:message', { message: callMessage });
    sendToUser(current.id, 'chat:message', { message: callMessage });

    res.json({ success: true, call: callData, isRecipientOnline: reached });
  } catch (err: any) {
    console.error('Call initiate error:', err);
    res.status(500).json({ error: 'Failed to initiate call' });
  }
});

// POST /api/call/respond
app.post('/api/call/respond', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const { callId, action } = req.body; // action: 'accept' | 'decline'

    if (!callId || !action) {
      return res.status(400).json({ error: 'callId and action required' });
    }

    const callRef = doc(db, 'calls', callId);
    const snap = await getDoc(callRef);
    if (!snap.exists()) {
      return res.status(404).json({ error: 'Call session not found' });
    }

    const callData = snap.data();
    if (callData.recipientId !== current.id && callData.callerId !== current.id) {
      return res.status(403).json({ error: 'Unauthorized to respond to this call' });
    }

    const now = new Date().toISOString();
    const newStatus = action === 'accept' ? 'connected' : 'declined';

    await updateDoc(callRef, {
      status: newStatus,
      ...(action === 'accept' ? { connectedAt: now } : { endedAt: now }),
    });

    // Update in-chat call message status
    const callMsgRef = doc(db, 'direct_messages', 'msg_call_' + callId);
    getDoc(callMsgRef).then((msgSnap) => {
      if (msgSnap.exists()) {
        const updateData = {
          callStatus: newStatus,
          content: action === 'accept' ? '📞 Call connected' : '📞 Call declined',
        };
        updateDoc(callMsgRef, updateData).catch(() => {});
        sendToUser(callData.callerId, 'chat:call_status_update', { callId, status: newStatus });
        sendToUser(callData.recipientId, 'chat:call_status_update', { callId, status: newStatus });
      }
    }).catch(() => {});

    const updatedCall = { ...callData, status: newStatus };
    const otherParticipantId = callData.callerId === current.id ? callData.recipientId : callData.callerId;
    sendToUser(otherParticipantId, 'call:response', { callId, action, call: updatedCall });

    res.json({ success: true, call: updatedCall });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to respond to call' });
  }
});

// POST /api/call/end
app.post('/api/call/end', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const { callId } = req.body;

    if (!callId) {
      return res.status(400).json({ error: 'callId required' });
    }

    const callRef = doc(db, 'calls', callId);
    const snap = await getDoc(callRef);
    if (snap.exists()) {
      const callData = snap.data();
      const now = new Date().toISOString();
      await updateDoc(callRef, { status: 'ended', endedAt: now });

      // Update in-chat call message status
      const callMsgRef = doc(db, 'direct_messages', 'msg_call_' + callId);
      getDoc(callMsgRef).then((msgSnap) => {
        if (msgSnap.exists()) {
          updateDoc(callMsgRef, { callStatus: 'ended', content: '📞 Call ended' }).catch(() => {});
          sendToUser(callData.callerId, 'chat:call_status_update', { callId, status: 'ended' });
          sendToUser(callData.recipientId, 'chat:call_status_update', { callId, status: 'ended' });
        }
      }).catch(() => {});

      const partnerId = callData.callerId === current.id ? callData.recipientId : callData.callerId;
      sendToUser(partnerId, 'call:ended', { callId });
    }

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to end call' });
  }
});

// POST /api/call/timeout - Unanswered call timeout (35s)
app.post('/api/call/timeout', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const { callId } = req.body;

    if (!callId) {
      return res.status(400).json({ error: 'callId required' });
    }

    const callRef = doc(db, 'calls', callId);
    const snap = await getDoc(callRef);
    if (!snap.exists()) {
      return res.status(404).json({ error: 'Call not found' });
    }

    const callData = snap.data();
    if (callData.status === 'ringing') {
      const now = new Date().toISOString();
      await updateDoc(callRef, { status: 'missed', endedAt: now });

      // Update in-chat call message status
      const callMsgRef = doc(db, 'direct_messages', 'msg_call_' + callId);
      updateDoc(callMsgRef, {
        callStatus: 'missed',
        content: `📞 Missed ${callData.type} call`,
      }).catch(() => {});

      sendToUser(callData.callerId, 'call:ended', { callId, reason: 'timeout' });
      sendToUser(callData.recipientId, 'call:ended', { callId, reason: 'timeout' });
    }

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to record call timeout' });
  }
});

// GET /api/call/with/:partnerId - Check active/ringing call with a specific partner
app.get('/api/call/with/:partnerId', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;
    const { partnerId } = req.params;

    const callsRef = collection(db, 'calls');
    const [cSnap, rSnap] = await Promise.all([
      getDocs(query(callsRef, where('callerId', '==', current.id), where('recipientId', '==', partnerId))),
      getDocs(query(callsRef, where('callerId', '==', partnerId), where('recipientId', '==', current.id))),
    ]);

    const allCalls = [...cSnap.docs.map((d) => d.data()), ...rSnap.docs.map((d) => d.data())];
    const activeCall = allCalls
      .filter((c) => c.status === 'ringing' || c.status === 'connected')
      .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())[0] || null;

    res.json({ activeCall });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch call status' });
  }
});

// GET /api/call/active
app.get('/api/call/active', authMiddleware, async (req: Request, res: Response) => {
  try {
    const current = (req as any).user;

    const [callingSnap, receivingSnap] = await Promise.all([
      getDocs(query(collection(db, 'calls'), where('callerId', '==', current.id), where('status', 'in', ['ringing', 'connected']))),
      getDocs(query(collection(db, 'calls'), where('recipientId', '==', current.id), where('status', 'in', ['ringing', 'connected']))),
    ]);

    const activeList = [...callingSnap.docs.map((d) => d.data()), ...receivingSnap.docs.map((d) => d.data())];
    activeList.sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime());

    res.json({ call: activeList[0] || null });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch active call' });
  }
});

// ----------------------------------------------------
// Mount Vite Development Server or Serve Production Static
// ----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', async () => {
    console.log(`LOT Ecosystem full-stack server running on http://0.0.0.0:${PORT}`);
    // Immediately log out admin account from all devices as requested
    try {
      await logoutAdminFromAllDevices();
    } catch (e) {
      console.warn('[Startup] Admin logout error:', e);
    }
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});

