# Security Specification: LOT Ecosystem

## 1. Data Invariants
1. **Authoritative LOT Currency Ledger**: Users can NEVER directly write, increment, decrement, or patch their `lotBalance` in `/users/{userId}` or `/transactions/{transactionId}` from client Firestore. All currency mutations MUST occur through trusted backend server endpoints with atomic transactions.
2. **Identity Integrity**: No user may impersonate another user ID, modify `isAdmin` or `isBanned` flags, or claim administrator identity without backend bootstrap verification.
3. **Marketplace Listings**: Only the seller of a listing (or verified admin) can update their listing, and stock/prices cannot be arbitrarily manipulated during active order execution.
4. **Order State Machine**: Orders transition strictly through `Placed` -> `Processing` -> `Delivered`.
5. **Private Data Isolation**: Notifications, portfolios, trades, and personal transactions are strictly readable only by the respective owner or admin.
6. **Redemption Codes**: Redemption codes cannot be created, modified, or enabled by regular users. Claims must be recorded by backend logic to prevent duplicate or over-quota redemptions.

## 2. The Dirty Dozen Payloads
1. **Self-Balance Escalation**: An authenticated user attempts `db.collection('users').doc(myUid).update({ lotBalance: 9999999 })` -> MUST FAIL.
2. **Admin Flag Hijack**: A standard user sends `update({ isAdmin: true })` -> MUST FAIL.
3. **Ghost Field Injection**: Adding an unmodeled field like `{ backdoor: true }` to user profile -> MUST FAIL.
4. **Impersonated P2P Transfer**: A user attempts to write a transaction document debiting another user's account -> MUST FAIL.
5. **Listing Price Tampering**: A buyer tries to update a seller's listing price to 0 LOT right before purchase -> MUST FAIL.
6. **Fake Stock Holdings**: A user attempts to write directly to `/portfolios/{myUid}_LOTX` with `{ quantity: 1000 }` -> MUST FAIL.
7. **Unauthorized Order Completion**: A non-seller/non-admin attempting to set order status to `Delivered` -> MUST FAIL.
8. **Malicious Admin Audit Log Deletion**: Attacker attempts to delete `/admin_audit_logs/{logId}` -> MUST FAIL.
9. **Private Notification Snooping**: User B querying `where('userId', '==', userA)` to read User A's notifications -> MUST FAIL.
10. **Redemption Code Minting**: Regular user attempting to write a new code into `/redemption_codes/FREE1000` -> MUST FAIL.
11. **Negative Balance Exploitation**: Attempting a transfer or trade when balance < amount -> MUST FAIL on server transaction.
12. **Banned User Access**: Banned account attempting to execute trades or listings -> MUST FAIL.

## 3. Test Runner
All operations are validated through server-side verification and Firestore client rules.
