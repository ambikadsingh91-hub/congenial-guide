/**
 * Compact Number Formatting utility for LOT Ecosystem.
 * Formats numbers into standard compact notation:
 * - 1,000 -> 1K
 * - 10,000 -> 10K
 * - 100,000 -> 100K
 * - 1,000,000 -> 1M
 * - 1,000,000,000 -> 1B
 * - 1,000,000,000,000 -> 1T
 *
 * Handles negative numbers, decimals, null/undefined, and edge cases.
 */

export function formatCompactNumber(
  value: number | string | null | undefined,
  maxDecimals: number = 2
): string {
  if (value === null || value === undefined || value === '') return '0';
  const num = typeof value === 'number' ? value : Number(value);
  if (isNaN(num)) return '0';

  const abs = Math.abs(num);
  const sign = num < 0 ? '-' : '';

  if (abs < 1000) {
    if (Number.isInteger(num)) {
      return num.toString();
    }
    return parseFloat(num.toFixed(maxDecimals)).toString();
  }

  const units = [
    { threshold: 1e12, suffix: 'T' },
    { threshold: 1e9, suffix: 'B' },
    { threshold: 1e6, suffix: 'M' },
    { threshold: 1e3, suffix: 'K' },
  ];

  for (const { threshold, suffix } of units) {
    if (abs >= threshold) {
      const divided = abs / threshold;
      // Round to maxDecimals without trailing zeroes (e.g. 1000 -> 1K, 1500 -> 1.5K, 1250 -> 1.25K)
      const formatted = parseFloat(divided.toFixed(maxDecimals));
      return `${sign}${formatted}${suffix}`;
    }
  }

  return num.toString();
}

/**
 * Convenience helper to format LOT balance, prices, earnings, or stats.
 * When compact is true (default), returns e.g. "10K", "1.5M".
 * If compact is false, returns standard comma-separated string e.g. "10,000".
 */
export function formatLOT(
  value: number | string | null | undefined,
  compact: boolean = true,
  maxDecimals: number = 2
): string {
  if (compact) {
    return formatCompactNumber(value, maxDecimals);
  }
  if (value === null || value === undefined || value === '') return '0';
  const num = typeof value === 'number' ? value : Number(value);
  if (isNaN(num)) return '0';
  return num.toLocaleString();
}
