/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { LotShop } from './components/shop/LotShop';
import { LotShorts } from './components/shorts/LotShorts';
import { LotVideos } from './components/videos/LotVideos';
import { LotAppStore } from './components/appstore/LotAppStore';
import { JobManager } from './components/jobs/JobManager';
import { VPay } from './components/vpay/VPay';
import { VStocks } from './components/vstocks/VStocks';
import { Minigames } from './components/minigames/Minigames';
import { Redemption } from './components/redemption/Redemption';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { UserDashboard } from './components/account/UserDashboard';
import { PlayerSocialHub } from './components/chat/PlayerSocialHub';
import { LotBank } from './components/bank/LotBank';
import { CallOverlayModal } from './components/chat/CallOverlayModal';
import { SocialProvider } from './context/SocialContext';
import { testConnection } from './lib/firebase';
import { sounds } from './lib/sounds';
import { Megaphone, X } from 'lucide-react';

const MainLayout: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<string>('shop');
  const { announcements } = useAuth();
  const [dismissedAnnouncements, setDismissedAnnouncements] = useState<string[]>([]);

  useEffect(() => {
    // Validate Firestore connection on boot per Firebase skill directive
    testConnection();
    // Initialize satisfying interactive sound effects engine
    sounds.initGlobalListeners();
  }, []);

  const activeAnnouncements = announcements.filter((a) => !dismissedAnnouncements.includes(a.id));

  return (
    <SocialProvider onNavigateToChat={() => setCurrentTab('messages')}>
      <div className="min-h-screen flex flex-col bg-[#0B0B14] text-[#F5F3FF]">
        {/* Global Broadcast Announcement Banner if any */}
        {activeAnnouncements.length > 0 && (
          <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-purple-900 border-b border-purple-500/30 px-3 sm:px-4 py-2 text-xs text-white max-w-full overflow-x-hidden">
            <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4 min-w-0">
              <div className="flex items-center gap-2 overflow-hidden min-w-0">
                <Megaphone className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#C4B5FD] shrink-0 animate-bounce" />
                <div className="truncate text-[11px] sm:text-xs">
                  <span className="font-bold text-[#C4B5FD] mr-1.5">{activeAnnouncements[0].title}:</span>
                  <span className="text-purple-100">{activeAnnouncements[0].content}</span>
                </div>
              </div>
              <button
                onClick={() => setDismissedAnnouncements((prev) => [...prev, activeAnnouncements[0].id])}
                className="text-purple-300 hover:text-white p-1 rounded hover:bg-white/10 shrink-0 cursor-pointer"
                aria-label="Dismiss announcement"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Shared Ecosystem Header */}
        <Navbar currentTab={currentTab} setCurrentTab={setCurrentTab} />

        {/* Main Content Area */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
          {currentTab === 'shop' && <LotShop />}
          {currentTab === 'videos' && <LotVideos />}
          {currentTab === 'shorts' && <LotShorts />}
          {currentTab === 'appstore' && <LotAppStore />}
          {currentTab === 'jobs' && <JobManager />}
          {currentTab === 'bank' && <LotBank />}
          {currentTab === 'vpay' && <VPay />}
          {currentTab === 'vstocks' && <VStocks />}
          {currentTab === 'games' && <Minigames />}
          {currentTab === 'redeem' && <Redemption />}
          {currentTab === 'admin' && <AdminDashboard />}
          {currentTab === 'account' && <UserDashboard />}
          {currentTab === 'messages' && <PlayerSocialHub />}
        </main>

        {/* Shared Ecosystem Footer */}
        <Footer setCurrentTab={setCurrentTab} />

        {/* Global Audio/Video Calling Screen & Incoming Call Popup */}
        <CallOverlayModal />

        {/* Login & Registration Modal */}
        <AuthModal />
      </div>
    </SocialProvider>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
}
