import React, { useState, useEffect } from 'react';
import {
  X,
  DollarSign,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Calendar,
  Landmark,
  BadgePercent,
  FileCheck,
  Coins,
} from 'lucide-react';
import {
  Employee,
  SalaryPayment,
  SalaryAdjustment,
  PaymentStatus,
  PaymentMethod,
} from '../../types/jobManager';

interface PaySalaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  employees: Employee[];
  selectedEmployeeId?: string | null;
  onPaymentRecorded: (payment: SalaryPayment) => void;
  authToken?: string;
}

const PAYMENT_METHODS: PaymentMethod[] = [
  'LOT Ecosystem Transfer',
  'Bank Transfer / Direct Deposit',
  'Cash',
  'Cheque',
  'Digital Wallet',
];

export const PaySalaryModal: React.FC<PaySalaryModalProps> = ({
  isOpen,
  onClose,
  employees,
  selectedEmployeeId,
  onPaymentRecorded,
  authToken,
}) => {
  if (!isOpen) return null;

  if (employees.length === 0) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
        <div className="w-full max-w-md bg-[#19192B] border border-[#302D46] rounded-3xl p-6 text-center space-y-4 shadow-2xl">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-white text-base">No Employees Enrolled Yet</h3>
          <p className="text-xs text-[#A5A3B8]">
            To calculate and record salary disbursements, you first need to enroll at least one employee in your organization.
          </p>
          <div className="pt-2 flex items-center justify-center gap-3">
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold cursor-pointer"
            >
              Understood
            </button>
          </div>
        </div>
      </div>
    );
  }

  const [employeeId, setEmployeeId] = useState<string>(
    selectedEmployeeId || (employees.length > 0 ? employees[0].id : '')
  );

  const selectedEmployee = employees.find((e) => e.id === employeeId) || employees[0];

  // Payment form states
  const [salaryPeriod, setSalaryPeriod] = useState(() => {
    const d = new Date();
    return d.toLocaleString('default', { month: 'long', year: 'numeric' });
  });

  const [hoursWorked, setHoursWorked] = useState<number | string>(160);
  const [daysWorked, setDaysWorked] = useState<number | string>(22);
  const [adjustments, setAdjustments] = useState<SalaryAdjustment[]>([]);

  // Adjustment builder
  const [adjType, setAdjType] = useState<SalaryAdjustment['type']>('bonus');
  const [adjLabel, setAdjLabel] = useState('Performance Bonus');
  const [adjAmount, setAdjAmount] = useState<number | string>(500);
  const [adjReason, setAdjReason] = useState('Excellent quarterly results');

  // Payment details
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('paid');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('LOT Ecosystem Transfer');
  const [paidAmount, setPaidAmount] = useState<number | string>(0);
  const [transactionReference, setTransactionReference] = useState(
    () => `TX-${Date.now().toString(36).toUpperCase()}`
  );
  const [nextExpectedDate, setNextExpectedDate] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    return d.toISOString().split('T')[0];
  });
  const [notes, setNotes] = useState('');

  // Calculations
  const [calculatedBase, setCalculatedBase] = useState(0);
  const [totalBonus, setTotalBonus] = useState(0);
  const [totalDeductions, setTotalDeductions] = useState(0);
  const [netPayable, setNetPayable] = useState(0);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Recalculate salary breakdown
  useEffect(() => {
    if (!selectedEmployee) return;

    let base = selectedEmployee.baseSalary;
    if (selectedEmployee.salaryFrequency === 'Hourly') {
      const rate = selectedEmployee.hourlyRate || selectedEmployee.baseSalary;
      base = Number(hoursWorked) * rate;
    } else if (selectedEmployee.salaryFrequency === 'Daily') {
      const rate = selectedEmployee.dailyRate || selectedEmployee.baseSalary;
      base = Number(daysWorked) * rate;
    }
    setCalculatedBase(base);

    let bonus = 0;
    let deduct = 0;
    adjustments.forEach((a) => {
      if (['bonus', 'commission', 'overtime', 'reward'].includes(a.type)) {
        bonus += Math.abs(Number(a.amount) || 0);
      } else {
        deduct += Math.abs(Number(a.amount) || 0);
      }
    });

    setTotalBonus(bonus);
    setTotalDeductions(deduct);
    const finalNet = Math.max(0, base + bonus - deduct);
    setNetPayable(finalNet);

    // Default paid amount to net payable if paid
    if (paymentStatus === 'paid') {
      setPaidAmount(finalNet);
    } else if (paymentStatus === 'pending') {
      setPaidAmount(0);
    }
  }, [selectedEmployee, hoursWorked, daysWorked, adjustments, paymentStatus]);

  // Add adjustment line
  const handleAddAdjustment = () => {
    if (!adjAmount || Number(adjAmount) <= 0) return;
    if (!adjReason.trim()) {
      setError('Please provide a reason for the adjustment/deduction.');
      return;
    }

    setError(null);
    const newAdj: SalaryAdjustment = {
      id: 'adj_' + crypto.randomUUID(),
      type: adjType,
      label: adjLabel.trim() || adjType.toUpperCase(),
      amount: Number(adjAmount),
      reason: adjReason.trim(),
      createdAt: new Date().toISOString(),
    };

    setAdjustments([...adjustments, newAdj]);
    setAdjLabel('');
    setAdjAmount(0);
    setAdjReason('');
  };

  const handleRemoveAdjustment = (id: string) => {
    setAdjustments(adjustments.filter((a) => a.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmployee) {
      setError('Please select an employee.');
      return;
    }
    if (!salaryPeriod.trim()) {
      setError('Salary period is required.');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const payload = {
        employeeId: selectedEmployee.id,
        salaryPeriod: salaryPeriod.trim(),
        baseAmount: calculatedBase,
        hoursWorked: selectedEmployee.salaryFrequency === 'Hourly' ? Number(hoursWorked) || 0 : 0,
        daysWorked: selectedEmployee.salaryFrequency === 'Daily' ? Number(daysWorked) || 0 : 0,
        adjustments,
        totalBonus,
        totalDeductions,
        netPayableAmount: netPayable,
        paidAmount: Number(paidAmount) || 0,
        paymentStatus,
        paymentMethod,
        transactionReference: transactionReference.trim(),
        nextExpectedSalaryDate: nextExpectedDate,
        notes: notes.trim(),
      };

      const effectiveToken =
        authToken ||
        (typeof window !== 'undefined'
          ? localStorage.getItem('lot_session_token') || localStorage.getItem('lot_auth_token')
          : '') ||
        '';

      const res = await fetch('/api/jobs/payments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${effectiveToken}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to process salary payment');
      }

      onPaymentRecorded(data.payment);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Error recording payment');
    } finally {
      setSubmitting(false);
    }
  };

  if (!selectedEmployee) return null;

  const curr = selectedEmployee.currency;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 sm:p-8 text-[#F5F3FF] overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#302D46]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Process & Record Salary</h3>
              <p className="text-xs text-[#A5A3B8]">{selectedEmployee.fullName} • {selectedEmployee.employeeIdNumber}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#121222] border border-[#302D46] hover:bg-[#202039] text-[#A5A3B8] hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs flex items-center gap-2 animate-fadeIn">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-5">
          {/* Employee Selector & Period */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Select Employee</label>
              <select
                value={selectedEmployee.id}
                onChange={(e) => setEmployeeId(e.target.value)}
                className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500 cursor-pointer"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.fullName} ({emp.employeeIdNumber}) - {emp.jobTitle}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Salary Period Label</label>
              <input
                type="text"
                required
                placeholder="e.g. November 2026 / Week 44"
                value={salaryPeriod}
                onChange={(e) => setSalaryPeriod(e.target.value)}
                className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Conditional Hourly / Daily Inputs */}
          {selectedEmployee.salaryFrequency === 'Hourly' && (
            <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold text-white block">Hourly Employee Calculation</span>
                <span className="text-[10px] text-[#8F8CA8]">
                  Rate: {selectedEmployee.hourlyRate || selectedEmployee.baseSalary} {curr}/hr
                </span>
              </div>
              <div className="flex items-center gap-2">
                <label className="text-xs text-[#A5A3B8]">Hours Worked:</label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={hoursWorked}
                  onChange={(e) => setHoursWorked(e.target.value)}
                  className="w-24 px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs font-mono text-center outline-none focus:border-purple-500"
                />
              </div>
            </div>
          )}

          {selectedEmployee.salaryFrequency === 'Daily' && (
            <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold text-white block">Daily Employee Calculation</span>
                <span className="text-[10px] text-[#8F8CA8]">
                  Rate: {selectedEmployee.dailyRate || selectedEmployee.baseSalary} {curr}/day
                </span>
              </div>
              <div className="flex items-center gap-2">
                <label className="text-xs text-[#A5A3B8]">Payable Days:</label>
                <input
                  type="number"
                  min="0"
                  value={daysWorked}
                  onChange={(e) => setDaysWorked(e.target.value)}
                  className="w-24 px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs font-mono text-center outline-none focus:border-purple-500"
                />
              </div>
            </div>
          )}

          {/* Section 2: Bonuses, Incentives & Deductions */}
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <BadgePercent className="w-4 h-4 text-purple-400" />
                Bonuses, Overtime & Deductions
              </span>
              <span className="text-[10px] text-[#A5A3B8]">
                +{totalBonus} {curr} / -{totalDeductions} {curr}
              </span>
            </div>

            {/* List of added adjustments */}
            {adjustments.length > 0 && (
              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {adjustments.map((adj) => {
                  const isBonus = ['bonus', 'commission', 'overtime', 'reward'].includes(adj.type);
                  return (
                    <div
                      key={adj.id}
                      className={`p-2 rounded-xl border flex items-center justify-between text-xs ${
                        isBonus
                          ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                          : 'bg-red-950/30 border-red-500/30 text-red-300'
                      }`}
                    >
                      <div>
                        <span className="font-bold">{adj.label}:</span>{' '}
                        <span className="font-mono">{isBonus ? '+' : '-'}{adj.amount} {curr}</span>
                        <span className="text-[10px] text-[#8F8CA8] ml-2">({adj.reason})</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveAdjustment(adj.id)}
                        className="text-[#8F8CA8] hover:text-red-400 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Add Adjustment sub-form */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-2 border-t border-[#26243A]">
              <div>
                <select
                  value={adjType}
                  onChange={(e) => {
                    const val = e.target.value as any;
                    setAdjType(val);
                    if (val === 'overtime') setAdjLabel('Overtime Pay');
                    else if (val === 'deduction') setAdjLabel('Advance Deduction');
                    else if (val === 'commission') setAdjLabel('Sales Commission');
                    else setAdjLabel('Performance Bonus');
                  }}
                  className="w-full px-2.5 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none cursor-pointer"
                >
                  <option value="bonus">+ Bonus</option>
                  <option value="commission">+ Commission</option>
                  <option value="overtime">+ Overtime</option>
                  <option value="reward">+ Reward</option>
                  <option value="deduction">- Deduction</option>
                  <option value="advance">- Advance Repay</option>
                  <option value="unpaid_leave_penalty">- Unpaid Leave Penalty</option>
                </select>
              </div>

              <div>
                <input
                  type="number"
                  min="0"
                  placeholder="Amount"
                  value={adjAmount}
                  onChange={(e) => setAdjAmount(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs font-mono outline-none"
                />
              </div>

              <div>
                <input
                  type="text"
                  placeholder="Reason / Note *"
                  value={adjReason}
                  onChange={(e) => setAdjReason(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none"
                />
              </div>

              <div>
                <button
                  type="button"
                  onClick={handleAddAdjustment}
                  className="w-full py-1.5 rounded-xl bg-purple-600/30 border border-purple-500/50 hover:bg-purple-600 text-white font-bold text-xs flex items-center justify-center gap-1 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Line</span>
                </button>
              </div>
            </div>
          </div>

          {/* Section 3: Summary Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 to-indigo-950/60 border border-purple-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] text-purple-300 uppercase font-bold tracking-wider">
                Net Payable Calculation
              </span>
              <p className="text-xs text-[#A5A3B8]">
                Base: {calculatedBase.toLocaleString()} {curr} | Bonus: +{totalBonus.toLocaleString()} {curr} | Deductions: -{totalDeductions.toLocaleString()} {curr}
              </p>
            </div>

            <div className="text-right">
              <span className="text-2xl font-black text-emerald-400 font-mono">
                {netPayable.toLocaleString()} {curr}
              </span>
            </div>
          </div>

          {/* Section 4: Payment Execution Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Payment Status</label>
              <select
                value={paymentStatus}
                onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)}
                className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none cursor-pointer"
              >
                <option value="paid">Paid (Completed)</option>
                <option value="pending">Pending Approval</option>
                <option value="partially_paid">Partially Paid</option>
                <option value="overdue">Overdue Payment</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Paid Amount ({curr})</label>
              <input
                type="number"
                min="0"
                step="any"
                value={paidAmount}
                onChange={(e) => setPaidAmount(e.target.value)}
                className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs font-mono outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none cursor-pointer"
              >
                {PAYMENT_METHODS.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Transaction Ref #</label>
              <input
                type="text"
                value={transactionReference}
                onChange={(e) => setTransactionReference(e.target.value)}
                className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs font-mono outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Next Expected Salary Date</label>
              <input
                type="date"
                value={nextExpectedDate}
                onChange={(e) => setNextExpectedDate(e.target.value)}
                className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Notes / Memo</label>
              <input
                type="text"
                placeholder="Optional payroll memo"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#302D46]">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-5 py-2.5 rounded-xl bg-[#121222] border border-[#302D46] text-[#A5A3B8] hover:text-white text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 text-white text-xs font-bold shadow-lg shadow-emerald-500/20 hover:opacity-95 transition-all cursor-pointer flex items-center gap-2 disabled:opacity-50"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Recording Salary...</span>
                </>
              ) : (
                <>
                  <FileCheck className="w-4 h-4" />
                  <span>Record & Generate Payslip</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
