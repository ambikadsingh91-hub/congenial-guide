import React from 'react';
import { SalaryPayment } from '../../types/jobManager';
import { X, Printer, Download, Landmark, CheckCircle2, AlertCircle, FileText, ShieldCheck } from 'lucide-react';
import { formatCompactNumber } from '../../lib/formatNumber';

interface SalarySlipModalProps {
  payment: SalaryPayment | null;
  onClose: () => void;
}

export const SalarySlipModal: React.FC<SalarySlipModalProps> = ({ payment, onClose }) => {
  if (!payment) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadText = () => {
    const slipText = `
============================================================
              LOT ECOSYSTEM SALARY PAYSLIP
============================================================
Organization: ${payment.organizationName}
Slip Reference: ${payment.transactionReference || payment.id}
Generated On: ${new Date().toLocaleString()}
------------------------------------------------------------
EMPLOYEE DETAILS:
Name: ${payment.employeeName}
Employee ID: ${payment.employeeIdNumber}
Position: ${payment.jobTitle}
Department: ${payment.department}
Payment Frequency: ${payment.salaryFrequency}
Salary Period: ${payment.salaryPeriod}

------------------------------------------------------------
EARNINGS & BASE SALARY:
Base Amount: ${payment.baseAmount.toLocaleString()} ${payment.currency}
${payment.totalHoursWorked ? `Hours Worked: ${payment.totalHoursWorked} hrs\n` : ''}${payment.totalDaysWorked ? `Days Worked: ${payment.totalDaysWorked} days\n` : ''}Bonuses & Incentives: +${payment.totalBonus.toLocaleString()} ${payment.currency}
Deductions & Adjustments: -${payment.totalDeductions.toLocaleString()} ${payment.currency}
------------------------------------------------------------
NET PAYABLE AMOUNT: ${payment.netPayableAmount.toLocaleString()} ${payment.currency}
PAID AMOUNT: ${payment.paidAmount.toLocaleString()} ${payment.currency}
STATUS: ${payment.paymentStatus.toUpperCase()}
PAYMENT METHOD: ${payment.paymentMethod}
PAYMENT DATE: ${payment.paymentDate || 'Pending'}
------------------------------------------------------------
Authorized By: @${payment.recordedByUsername}
Audit Stamp: Verified LOT Ecosystem Digital Payroll Record
============================================================
    `.trim();

    const blob = new Blob([slipText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Payslip_${payment.employeeIdNumber}_${payment.salaryPeriod.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const currencySymbol = payment.currency === 'LOT' ? 'LOT' : payment.currency === 'GBP' ? '£' : payment.currency === 'EUR' ? '€' : '$';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 sm:p-8 text-[#F5F3FF] overflow-hidden my-6">
        {/* Header Actions */}
        <div className="flex items-center justify-between pb-4 border-b border-[#302D46]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center">
              <FileText className="w-5 h-5 text-purple-300" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Official Salary Slip</h3>
              <p className="text-xs text-[#A5A3B8]">Period: {payment.salaryPeriod}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2 rounded-xl bg-[#121222] border border-[#302D46] hover:border-purple-500 text-[#A5A3B8] hover:text-white transition-colors cursor-pointer"
              title="Print Salary Slip"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={handleDownloadText}
              className="p-2 rounded-xl bg-[#121222] border border-[#302D46] hover:border-purple-500 text-[#A5A3B8] hover:text-white transition-colors cursor-pointer"
              title="Download Slip File"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-[#121222] border border-[#302D46] hover:bg-[#202039] text-[#A5A3B8] hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Payslip Card */}
        <div id="salary-slip-printable" className="mt-5 p-6 rounded-2xl bg-[#121222] border border-[#302D46] space-y-6">
          {/* Organization Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#26243A] pb-4">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-purple-400">Employer Organization</span>
              <h2 className="text-lg font-black text-white">{payment.organizationName}</h2>
              <p className="text-xs text-[#8F8CA8]">Ref: {payment.transactionReference || payment.id}</p>
            </div>

            <div className="text-left sm:text-right">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                payment.paymentStatus === 'paid'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : payment.paymentStatus === 'overdue'
                  ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              }`}>
                {payment.paymentStatus === 'paid' && <CheckCircle2 className="w-3.5 h-3.5" />}
                {payment.paymentStatus.toUpperCase()}
              </span>
              <p className="text-[11px] text-[#8F8CA8] mt-1">Paid on: {payment.paymentDate || 'Pending'}</p>
            </div>
          </div>

          {/* Employee Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-[#19192B] border border-[#26243A]">
              <span className="text-[10px] text-[#8F8CA8] block">Employee Name</span>
              <span className="font-bold text-white mt-0.5 block truncate">{payment.employeeName}</span>
            </div>
            <div className="p-3 rounded-xl bg-[#19192B] border border-[#26243A]">
              <span className="text-[10px] text-[#8F8CA8] block">Employee ID</span>
              <span className="font-bold text-purple-300 mt-0.5 block font-mono">{payment.employeeIdNumber}</span>
            </div>
            <div className="p-3 rounded-xl bg-[#19192B] border border-[#26243A]">
              <span className="text-[10px] text-[#8F8CA8] block">Designation</span>
              <span className="font-bold text-white mt-0.5 block truncate">{payment.jobTitle}</span>
            </div>
            <div className="p-3 rounded-xl bg-[#19192B] border border-[#26243A]">
              <span className="text-[10px] text-[#8F8CA8] block">Department</span>
              <span className="font-bold text-white mt-0.5 block truncate">{payment.department}</span>
            </div>
          </div>

          {/* Salary Breakdown Table */}
          <div className="border border-[#26243A] rounded-xl overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-[#19192B] text-[#A5A3B8] font-bold border-b border-[#26243A]">
                <tr>
                  <th className="py-2.5 px-3 text-left">Salary Description</th>
                  <th className="py-2.5 px-3 text-left">Calculation Basis</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#26243A]">
                <tr>
                  <td className="py-2.5 px-3 text-white font-medium">Base Salary ({payment.salaryFrequency})</td>
                  <td className="py-2.5 px-3 text-[#8F8CA8]">
                    {payment.totalHoursWorked ? `${payment.totalHoursWorked} hrs logged` : payment.totalDaysWorked ? `${payment.totalDaysWorked} days logged` : 'Standard period rate'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-white font-bold">
                    {payment.baseAmount.toLocaleString()} {currencySymbol}
                  </td>
                </tr>

                {/* Adjustments: Bonuses */}
                {(payment.adjustments || [])
                  .filter((a) => ['bonus', 'commission', 'overtime', 'reward'].includes(a.type))
                  .map((adj) => (
                    <tr key={adj.id} className="bg-emerald-950/20">
                      <td className="py-2.5 px-3 text-emerald-300 font-medium">
                        + {adj.label} <span className="text-[10px] text-[#8F8CA8]">({adj.reason})</span>
                      </td>
                      <td className="py-2.5 px-3 text-emerald-400/80">Incentive / Bonus</td>
                      <td className="py-2.5 px-3 text-right font-mono text-emerald-400 font-bold">
                        +{Math.abs(adj.amount).toLocaleString()} {currencySymbol}
                      </td>
                    </tr>
                  ))}

                {/* Adjustments: Deductions */}
                {(payment.adjustments || [])
                  .filter((a) => !['bonus', 'commission', 'overtime', 'reward'].includes(a.type))
                  .map((adj) => (
                    <tr key={adj.id} className="bg-red-950/20">
                      <td className="py-2.5 px-3 text-red-300 font-medium">
                        - {adj.label} <span className="text-[10px] text-[#8F8CA8]">({adj.reason})</span>
                      </td>
                      <td className="py-2.5 px-3 text-red-400/80">Authorized Deduction</td>
                      <td className="py-2.5 px-3 text-right font-mono text-red-400 font-bold">
                        -{Math.abs(adj.amount).toLocaleString()} {currencySymbol}
                      </td>
                    </tr>
                  ))}
              </tbody>
              <tfoot className="bg-[#19192B] border-t-2 border-purple-500/40">
                <tr>
                  <td className="py-3 px-3 text-sm font-black text-white" colSpan={2}>
                    Net Payable Salary
                  </td>
                  <td className="py-3 px-3 text-right text-base font-black text-emerald-400 font-mono">
                    {payment.netPayableAmount.toLocaleString()} {currencySymbol}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Payment Method & Audit Footer */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 text-[11px] text-[#8F8CA8]">
            <div className="flex items-center gap-1.5">
              <Landmark className="w-3.5 h-3.5 text-purple-400" />
              <span>Channel: <strong className="text-white">{payment.paymentMethod}</strong></span>
              {payment.transactionReference && (
                <span className="font-mono text-purple-300">({payment.transactionReference})</span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Authorized by @{payment.recordedByUsername}</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="mt-5 pt-4 border-t border-[#302D46] flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-[#121222] border border-[#302D46] hover:bg-[#202039] text-white text-xs font-bold transition-colors cursor-pointer"
          >
            Close
          </button>
          <button
            onClick={handleDownloadText}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:opacity-95 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-purple-500/25 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Slip</span>
          </button>
        </div>
      </div>
    </div>
  );
};
