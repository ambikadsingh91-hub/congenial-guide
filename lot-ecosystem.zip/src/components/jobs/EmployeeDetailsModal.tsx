import React, { useState } from 'react';
import {
  X,
  User,
  Briefcase,
  Calendar,
  DollarSign,
  Award,
  TrendingUp,
  FileText,
  Clock,
  Shield,
  Star,
  Plus,
  Upload,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Edit3,
} from 'lucide-react';
import {
  Employee,
  SalaryPayment,
  EmployeeStatus,
} from '../../types/jobManager';

interface EmployeeDetailsModalProps {
  employee: Employee | null;
  onClose: () => void;
  onUpdateEmployee: (updated: Employee) => void;
  onViewSalarySlip: (payment: SalaryPayment) => void;
  payments: SalaryPayment[];
  isManager: boolean;
  authToken?: string;
}

export const EmployeeDetailsModal: React.FC<EmployeeDetailsModalProps> = ({
  employee,
  onClose,
  onUpdateEmployee,
  onViewSalarySlip,
  payments,
  isManager,
  authToken,
}) => {
  if (!employee) return null;

  const [activeTab, setActiveTab] = useState<'overview' | 'performance' | 'promotions' | 'documents' | 'payments'>('overview');

  // Performance form
  const [showPerfForm, setShowPerfForm] = useState(false);
  const [perfRating, setPerfRating] = useState(5);
  const [perfTitle, setPerfTitle] = useState('Quarterly Performance Review');
  const [perfNotes, setPerfNotes] = useState('');

  // Promotion form
  const [showPromoForm, setShowPromoForm] = useState(false);
  const [newTitle, setNewTitle] = useState(employee.jobTitle);
  const [newSalary, setNewSalary] = useState<number | string>(employee.baseSalary);
  const [promoNotes, setPromoNotes] = useState('');

  // Document upload form
  const [showDocForm, setShowDocForm] = useState(false);
  const [docTitle, setDocTitle] = useState('Employment Contract');
  const [docType, setDocType] = useState<'contract' | 'appointment_letter' | 'identity_document' | 'other'>('contract');
  const [docUrl, setDocUrl] = useState('');
  const [docFileName, setDocFileName] = useState('');

  // Status Change
  const [status, setStatus] = useState<EmployeeStatus>(employee.status);
  const [statusSaving, setStatusSaving] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const effectiveToken =
    authToken ||
    (typeof window !== 'undefined'
      ? localStorage.getItem('lot_session_token') || localStorage.getItem('lot_auth_token')
      : '') ||
    '';

  const employeePayments = payments.filter((p) => p.employeeId === employee.id);

  // Status update
  const handleStatusChange = async (newStatus: EmployeeStatus) => {
    setStatus(newStatus);
    setStatusSaving(true);
    setActionError(null);

    try {
      const res = await fetch(`/api/jobs/employees/${employee.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${effectiveToken}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update status');

      onUpdateEmployee(data.employee);
    } catch (err: any) {
      setActionError(err.message);
    } finally {
      setStatusSaving(false);
    }
  };

  // Submit Performance
  const handleAddPerformance = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionError(null);

    try {
      const res = await fetch(`/api/jobs/employees/${employee.id}/performance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${effectiveToken}`,
        },
        body: JSON.stringify({
          rating: perfRating,
          reviewTitle: perfTitle,
          notes: perfNotes,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      const updated = {
        ...employee,
        performanceRecords: [...(employee.performanceRecords || []), data.record],
      };
      onUpdateEmployee(updated);
      setShowPerfForm(false);
      setPerfNotes('');
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  // Submit Promotion
  const handleAddPromotion = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionError(null);

    try {
      const res = await fetch(`/api/jobs/employees/${employee.id}/promotion`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${effectiveToken}`,
        },
        body: JSON.stringify({
          newTitle,
          newSalary: Number(newSalary),
          notes: promoNotes,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      const updated = {
        ...employee,
        jobTitle: data.promotion.newTitle,
        baseSalary: data.promotion.newSalary,
        promotionHistory: [...(employee.promotionHistory || []), data.promotion],
      };
      onUpdateEmployee(updated);
      setShowPromoForm(false);
      setPromoNotes('');
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  // Submit Document
  const handleAddDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    const effectiveUrl = docUrl.trim() || `data:application/pdf;base64,LOT_FILE_${Date.now()}`;
    const effectiveFileName = docFileName || (docTitle.replace(/\s+/g, '_') + '.pdf');

    try {
      const res = await fetch(`/api/jobs/employees/${employee.id}/documents`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${effectiveToken}`,
        },
        body: JSON.stringify({
          title: docTitle.trim() || 'Employee Document',
          type: docType,
          fileUrl: effectiveUrl,
          fileName: effectiveFileName,
          fileSize: 1024 * 250,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      const updated = {
        ...employee,
        documents: [...(employee.documents || []), data.document],
      };
      onUpdateEmployee(updated);
      setShowDocForm(false);
      setDocUrl('');
      setDocFileName('');
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 sm:p-8 text-[#F5F3FF] overflow-hidden my-6">
        {/* Header Profile Card */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#302D46]">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-xl font-black text-white shadow-lg overflow-hidden border border-purple-500/40 shrink-0">
              {employee.avatarUrl ? (
                <img src={employee.avatarUrl} alt={employee.fullName} className="w-full h-full object-cover" />
              ) : (
                employee.fullName.charAt(0).toUpperCase()
              )}
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-black text-white">{employee.fullName}</h2>
                <span className="font-mono text-xs px-2 py-0.5 rounded-md bg-[#121222] text-purple-300 border border-[#302D46]">
                  {employee.employeeIdNumber}
                </span>
                {employee.username && (
                  <span className="text-xs text-[#A5A3B8]">(@{employee.username})</span>
                )}
              </div>
              <p className="text-xs text-[#A5A3B8] mt-0.5">
                {employee.jobTitle} • {employee.department} • {employee.employmentType}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Status Dropdown */}
            {isManager ? (
              <select
                value={status}
                disabled={statusSaving}
                onChange={(e) => handleStatusChange(e.target.value as EmployeeStatus)}
                className="px-3 py-1.5 rounded-xl bg-[#121222] border border-[#302D46] text-xs font-bold outline-none cursor-pointer text-white"
              >
                <option value="active">Active</option>
                <option value="on_leave">On Leave</option>
                <option value="suspended">Suspended</option>
                <option value="resigned">Resigned</option>
                <option value="retired">Retired</option>
                <option value="terminated">Terminated</option>
              </select>
            ) : (
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                {employee.status}
              </span>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-[#121222] border border-[#302D46] hover:bg-[#202039] text-[#A5A3B8] hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {actionError && (
          <div className="mt-4 p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{actionError}</span>
          </div>
        )}

        {/* Sub-Navigation Tabs */}
        <div className="flex bg-[#121222] p-1 rounded-xl border border-[#302D46] mt-5 gap-1 overflow-x-auto">
          {[
            { id: 'overview', label: 'Overview & Salary', icon: DollarSign },
            { id: 'performance', label: 'Performance', icon: Award },
            { id: 'promotions', label: 'Promotions', icon: TrendingUp },
            { id: 'documents', label: 'Contracts & Files', icon: FileText },
            { id: 'payments', label: `Payslips (${employeePayments.length})`, icon: FileCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-sm'
                    : 'text-[#A5A3B8] hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab 1: Overview */}
        {activeTab === 'overview' && (
          <div className="mt-5 space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46]">
                <span className="text-[10px] text-[#8F8CA8] block">Base Salary</span>
                <span className="text-base font-black text-emerald-400 font-mono mt-1 block">
                  {employee.baseSalary.toLocaleString()} {employee.currency}
                </span>
                <span className="text-[10px] text-[#A5A3B8]">{employee.salaryFrequency} payout</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46]">
                <span className="text-[10px] text-[#8F8CA8] block">Leave Balance</span>
                <span className="text-base font-black text-purple-300 font-mono mt-1 block">
                  {Math.max(0, employee.totalLeaveAllowance - (employee.leaveUsed || 0))} Days
                </span>
                <span className="text-[10px] text-[#A5A3B8]">{employee.leaveUsed || 0} of {employee.totalLeaveAllowance} used</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46]">
                <span className="text-[10px] text-[#8F8CA8] block">Joined On</span>
                <span className="text-sm font-bold text-white mt-1 block">
                  {new Date(employee.joiningDate).toLocaleDateString()}
                </span>
                <span className="text-[10px] text-[#A5A3B8]">Tenure active</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46]">
                <span className="text-[10px] text-[#8F8CA8] block">Direct Supervisor</span>
                <span className="text-sm font-bold text-white mt-1 block truncate">
                  @{employee.managerUsername}
                </span>
                <span className="text-[10px] text-[#A5A3B8]">{employee.organizationName}</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] space-y-2 text-xs">
              <h4 className="font-bold text-white">Contact & Employment Info</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[#A5A3B8]">
                <p>Email: <strong className="text-white">{employee.email || 'None provided'}</strong></p>
                <p>Phone: <strong className="text-white">{employee.phone || 'None provided'}</strong></p>
                <p>Classification: <strong className="text-purple-300">{employee.employmentType}</strong></p>
                <p>Linked LOT ID: <strong className="text-white">{employee.userId || 'Manual External Employee'}</strong></p>
              </div>
              {employee.notes && (
                <div className="mt-2 pt-2 border-t border-[#26243A]">
                  <span className="text-[10px] text-[#8F8CA8] block">Internal Notes:</span>
                  <p className="text-white text-xs">{employee.notes}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Performance */}
        {activeTab === 'performance' && (
          <div className="mt-5 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-white">Performance Appraisals & Ratings</h4>
              {isManager && (
                <button
                  onClick={() => setShowPerfForm(!showPerfForm)}
                  className="px-3 py-1.5 rounded-xl bg-purple-600/30 border border-purple-500/50 hover:bg-purple-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Review</span>
                </button>
              )}
            </div>

            {showPerfForm && (
              <form onSubmit={handleAddPerformance} className="p-4 rounded-2xl bg-[#121222] border border-purple-500/40 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-[#A5A3B8] mb-1">Review Title</label>
                    <input
                      type="text"
                      required
                      value={perfTitle}
                      onChange={(e) => setPerfTitle(e.target.value)}
                      className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#A5A3B8] mb-1">Rating (1 to 5 Stars)</label>
                    <div className="flex items-center gap-1 pt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setPerfRating(star)}
                          className="cursor-pointer"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              star <= perfRating ? 'text-amber-400 fill-amber-400' : 'text-[#403D58]'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-[#A5A3B8] mb-1">Evaluation Notes</label>
                  <textarea
                    rows={2}
                    required
                    placeholder="Key achievements, goals met, feedback..."
                    value={perfNotes}
                    onChange={(e) => setPerfNotes(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none"
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowPerfForm(false)}
                    className="px-3 py-1.5 rounded-xl bg-[#19192B] text-xs text-[#A5A3B8]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-purple-600 text-xs font-bold text-white shadow"
                  >
                    Save Review
                  </button>
                </div>
              </form>
            )}

            {/* List */}
            <div className="space-y-2.5 max-h-60 overflow-y-auto">
              {(employee.performanceRecords || []).length === 0 ? (
                <p className="text-xs text-[#8F8CA8] py-4 text-center">No performance records added yet.</p>
              ) : (
                (employee.performanceRecords || []).map((p) => (
                  <div key={p.id} className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] space-y-1">
                    <div className="flex items-center justify-between">
                      <h5 className="font-bold text-xs text-white">{p.reviewTitle}</h5>
                      <div className="flex items-center gap-0.5">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star
                            key={s}
                            className={`w-3.5 h-3.5 ${
                              s <= p.rating ? 'text-amber-400 fill-amber-400' : 'text-[#403D58]'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-[#A5A3B8]">{p.notes}</p>
                    <div className="flex items-center justify-between text-[10px] text-[#7E7B9A] pt-1 border-t border-[#26243A]">
                      <span>Reviewed by {p.reviewedBy}</span>
                      <span>{p.date}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Promotions */}
        {activeTab === 'promotions' && (
          <div className="mt-5 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-white">Promotions & Salary Revision History</h4>
              {isManager && (
                <button
                  onClick={() => setShowPromoForm(!showPromoForm)}
                  className="px-3 py-1.5 rounded-xl bg-purple-600/30 border border-purple-500/50 hover:bg-purple-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Record Promotion</span>
                </button>
              )}
            </div>

            {showPromoForm && (
              <form onSubmit={handleAddPromotion} className="p-4 rounded-2xl bg-[#121222] border border-purple-500/40 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-[#A5A3B8] mb-1">New Job Title</label>
                    <input
                      type="text"
                      required
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#A5A3B8] mb-1">New Salary ({employee.currency})</label>
                    <input
                      type="number"
                      required
                      min="0"
                      value={newSalary}
                      onChange={(e) => setNewSalary(e.target.value)}
                      className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs font-mono outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-[#A5A3B8] mb-1">Reason / Promotion Notes</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Promoted to Senior role based on Q3 performance"
                    value={promoNotes}
                    onChange={(e) => setPromoNotes(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none"
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowPromoForm(false)}
                    className="px-3 py-1.5 rounded-xl bg-[#19192B] text-xs text-[#A5A3B8]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-purple-600 text-xs font-bold text-white shadow"
                  >
                    Save Promotion
                  </button>
                </div>
              </form>
            )}

            <div className="space-y-2.5 max-h-60 overflow-y-auto">
              {(employee.promotionHistory || []).length === 0 ? (
                <p className="text-xs text-[#8F8CA8] py-4 text-center">No promotions recorded yet.</p>
              ) : (
                (employee.promotionHistory || []).map((pr) => (
                  <div key={pr.id} className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white">
                        {pr.previousTitle} → <span className="text-purple-300 font-bold">{pr.newTitle}</span>
                      </span>
                      <span className="font-mono text-emerald-400 font-bold">
                        {pr.previousSalary} → {pr.newSalary} {employee.currency}
                      </span>
                    </div>
                    <p className="text-xs text-[#A5A3B8]">{pr.notes}</p>
                    <div className="flex items-center justify-between text-[10px] text-[#7E7B9A] pt-1 border-t border-[#26243A]">
                      <span>Authorized by {pr.authorizedBy}</span>
                      <span>{pr.date}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 4: Documents */}
        {activeTab === 'documents' && (
          <div className="mt-5 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-white">Employment Contracts & ID Files</h4>
              {isManager && (
                <button
                  onClick={() => setShowDocForm(!showDocForm)}
                  className="px-3 py-1.5 rounded-xl bg-purple-600/30 border border-purple-500/50 hover:bg-purple-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Attach Document</span>
                </button>
              )}
            </div>

            {showDocForm && (
              <form onSubmit={handleAddDocument} className="p-4 rounded-2xl bg-[#121222] border border-purple-500/40 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-[#A5A3B8] mb-1">Document Title</label>
                    <input
                      type="text"
                      required
                      value={docTitle}
                      onChange={(e) => setDocTitle(e.target.value)}
                      className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#A5A3B8] mb-1">Category</label>
                    <select
                      value={docType}
                      onChange={(e) => setDocType(e.target.value as any)}
                      className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none cursor-pointer"
                    >
                      <option value="contract">Employment Contract</option>
                      <option value="appointment_letter">Appointment Letter</option>
                      <option value="identity_document">Identity Document</option>
                      <option value="other">Other File</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <div>
                    <label className="block text-[11px] text-[#A5A3B8] mb-1">Select File from Device (Optional)</label>
                    <input
                      type="file"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          const f = e.target.files[0];
                          setDocFileName(f.name);
                          if (!docTitle || docTitle === 'Employment Contract') {
                            setDocTitle(f.name.replace(/\.[^/.]+$/, ''));
                          }
                          const reader = new FileReader();
                          reader.onload = (ev) => {
                            if (ev.target?.result) setDocUrl(ev.target.result as string);
                          };
                          reader.readAsDataURL(f);
                        }
                      }}
                      className="w-full text-xs text-[#A5A3B8] file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-purple-600/30 file:text-purple-300 hover:file:bg-purple-600/50 cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#A5A3B8] mb-1">Or Document URL / Web Link</label>
                    <input
                      type="text"
                      placeholder="https://... or custom link"
                      value={docUrl.startsWith('data:') ? 'Attached from device file (' + docFileName + ')' : docUrl}
                      onChange={(e) => setDocUrl(e.target.value)}
                      className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowDocForm(false)}
                    className="px-3 py-1.5 rounded-xl bg-[#19192B] text-xs text-[#A5A3B8]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-purple-600 text-xs font-bold text-white shadow"
                  >
                    Upload Record
                  </button>
                </div>
              </form>
            )}

            <div className="space-y-2.5 max-h-60 overflow-y-auto">
              {(employee.documents || []).length === 0 ? (
                <p className="text-xs text-[#8F8CA8] py-4 text-center">No documents uploaded yet.</p>
              ) : (
                (employee.documents || []).map((doc) => (
                  <div key={doc.id} className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-purple-600/20 text-purple-300 flex items-center justify-center">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <h5 className="font-bold text-xs text-white">{doc.title}</h5>
                        <p className="text-[10px] text-[#8F8CA8]">
                          {doc.type} • Uploaded by {doc.uploadedBy}
                        </p>
                      </div>
                    </div>
                    <a
                      href={doc.fileUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1 rounded-xl bg-[#19192B] border border-[#302D46] text-purple-300 hover:text-white text-xs font-semibold"
                    >
                      View
                    </a>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Tab 5: Payslips History */}
        {activeTab === 'payments' && (
          <div className="mt-5 space-y-3">
            <h4 className="text-xs font-bold text-white">Payment Records & Payslips</h4>

            <div className="space-y-2 max-h-64 overflow-y-auto">
              {employeePayments.length === 0 ? (
                <p className="text-xs text-[#8F8CA8] py-4 text-center">No payment history recorded for this employee yet.</p>
              ) : (
                employeePayments.map((p) => (
                  <div
                    key={p.id}
                    className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center justify-between gap-3 hover:border-purple-500/50 transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="font-bold text-xs text-white">{p.salaryPeriod}</h5>
                        <span className={`px-2 py-0.2 rounded-full text-[10px] font-bold ${
                          p.paymentStatus === 'paid'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}>
                          {p.paymentStatus.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-[10px] text-[#8F8CA8] mt-0.5">
                        Paid: {p.paidAmount.toLocaleString()} {p.currency} • Channel: {p.paymentMethod}
                      </p>
                    </div>

                    <button
                      onClick={() => onViewSalarySlip(p)}
                      className="px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600 border border-purple-500/50 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <FileCheck className="w-3.5 h-3.5" />
                      <span>Payslip</span>
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-[#302D46] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#121222] border border-[#302D46] text-[#A5A3B8] hover:text-white text-xs font-bold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
