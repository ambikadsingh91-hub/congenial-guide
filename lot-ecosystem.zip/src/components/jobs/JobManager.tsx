import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Briefcase,
  Users,
  DollarSign,
  CalendarCheck,
  Calendar,
  FileText,
  BarChart3,
  ShieldAlert,
  Search,
  Plus,
  Download,
  CheckCircle2,
  AlertCircle,
  Clock,
  Building2,
  TrendingUp,
  UserCheck,
  Layers,
  RefreshCw,
  Check,
  X,
  FileSpreadsheet,
  Zap,
  ShieldCheck,
} from 'lucide-react';
import {
  Employee,
  SalaryPayment,
  AttendanceRecord,
  LeaveRequest,
  JobAuditLog,
  OrganizationProfile,
  EmploymentType,
  PaymentStatus,
  EmployeeStatus,
  LeaveType,
} from '../../types/jobManager';
import { AddEmployeeModal } from './AddEmployeeModal';
import { PaySalaryModal } from './PaySalaryModal';
import { SalarySlipModal } from './SalarySlipModal';
import { EmployeeDetailsModal } from './EmployeeDetailsModal';
import { EmployeeJobPortal } from './EmployeeJobPortal';
import { formatCompactNumber } from '../../lib/formatNumber';

type ActiveJobTab = 'employees' | 'salary' | 'attendance' | 'leaves' | 'reports' | 'audit';

export const JobManager: React.FC = () => {
  const { user, openAuthModal } = useAuth();
  const [activeTab, setActiveTab] = useState<ActiveJobTab>('employees');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Dual View Mode: 'manager' vs 'employee'
  const [viewMode, setViewMode] = useState<'manager' | 'employee'>('manager');
  const [myEmployments, setMyEmployments] = useState<Employee[]>([]);
  const [selectedEmploymentIndex, setSelectedEmploymentIndex] = useState(0);
  const [employeePortalTab, setEmployeePortalTab] = useState<'payslips' | 'attendance' | 'leaves' | 'documents'>('payslips');
  const [isManagerRole, setIsManagerRole] = useState(true);

  // Data state
  const [organization, setOrganization] = useState<OrganizationProfile | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payments, setPayments] = useState<SalaryPayment[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([]);
  const [auditLogs, setAuditLogs] = useState<JobAuditLog[]>([]);

  // Modals state
  const [isAddEmployeeOpen, setIsAddEmployeeOpen] = useState(false);
  const [isPaySalaryOpen, setIsPaySalaryOpen] = useState(false);
  const [selectedEmployeeForPay, setSelectedEmployeeForPay] = useState<string | null>(null);
  const [selectedEmployeeForDetails, setSelectedEmployeeForDetails] = useState<Employee | null>(null);
  const [selectedPaymentForSlip, setSelectedPaymentForSlip] = useState<SalaryPayment | null>(null);

  // Status correction modal for payments
  const [editingPayment, setEditingPayment] = useState<SalaryPayment | null>(null);
  const [editStatus, setEditStatus] = useState<PaymentStatus>('paid');
  const [editNote, setEditNote] = useState('');
  const [submittingEdit, setSubmittingEdit] = useState(false);

  // Attendance marking state
  const [attendanceDate, setAttendanceDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [markingAttendance, setMarkingAttendance] = useState(false);
  const [bulkPresentSuccess, setBulkPresentSuccess] = useState(false);

  // Leave submission state
  const [leaveEmployeeId, setLeaveEmployeeId] = useState('');
  const [leaveType, setLeaveType] = useState<LeaveType>('Casual Leave');
  const [leaveStartDate, setLeaveStartDate] = useState('');
  const [leaveEndDate, setLeaveEndDate] = useState('');
  const [leaveReason, setLeaveReason] = useState('');
  const [submittingLeave, setSubmittingLeave] = useState(false);

  // Filters & Search
  const [empSearch, setEmpSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState('ALL');

  // Auto-Payroll Execution State
  const [runningAutoPayroll, setRunningAutoPayroll] = useState(false);
  const [autoPayMessage, setAutoPayMessage] = useState<string | null>(null);

  const authToken =
    (typeof window !== 'undefined'
      ? localStorage.getItem('lot_session_token') || localStorage.getItem('lot_auth_token')
      : null) || undefined;
  const isManager = Boolean(user?.isAdmin || isManagerRole);

  const handleRunAutoPayroll = async () => {
    setRunningAutoPayroll(true);
    setAutoPayMessage(null);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
      const res = await fetch('/api/jobs/payroll/run-auto', { method: 'POST', headers });
      const data = await res.json();
      if (data.success) {
        if (data.processedCount > 0) {
          setAutoPayMessage(`⚡ Auto-Payroll Disbursed: ${data.processedCount} employee(s) paid, total ${data.totalDisbursed.toLocaleString()} LOT transferred to their wallets.`);
        } else {
          setAutoPayMessage('⚡ Auto-Payroll checked: All active employee schedules are currently up-to-date.');
        }
        await fetchData();
      } else {
        setAutoPayMessage(data.error || 'Failed to execute auto-payroll.');
      }
    } catch (err: any) {
      setAutoPayMessage(err.message || 'Auto-payroll request error.');
    } finally {
      setRunningAutoPayroll(false);
      setTimeout(() => setAutoPayMessage(null), 8000);
    }
  };

  // Fetch initial data
  const fetchData = async () => {
    try {
      setRefreshing(true);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;

      const [orgRes, empRes, payRes, attRes, leaveRes, audRes] = await Promise.all([
        fetch('/api/jobs/organization', { headers }),
        fetch('/api/jobs/employees', { headers }),
        fetch('/api/jobs/payments', { headers }),
        fetch(`/api/jobs/attendance?date=${attendanceDate}`, { headers }),
        fetch('/api/jobs/leaves', { headers }),
        fetch('/api/jobs/audit-logs', { headers }),
      ]);

      let hasEmployments = false;
      let managerPrivilege = true;
      let employeeCount = 0;

      if (orgRes.ok) {
        const orgData = await orgRes.json();
        setOrganization(orgData.organization || orgData);
        if (orgData.myEmployments && Array.isArray(orgData.myEmployments)) {
          setMyEmployments(orgData.myEmployments);
          if (orgData.myEmployments.length > 0) hasEmployments = true;
        }
        managerPrivilege = Boolean(orgData.isManager || user?.isAdmin);
        setIsManagerRole(managerPrivilege);
      }
      if (empRes.ok) {
        const empData = await empRes.json();
        const emps = empData.employees || [];
        setEmployees(emps);
        employeeCount = emps.length;
        if (empData.myEmployments && Array.isArray(empData.myEmployments) && empData.myEmployments.length > 0) {
          setMyEmployments(empData.myEmployments);
          hasEmployments = true;
        }
      }
      if (payRes.ok) {
        const payData = await payRes.json();
        setPayments(payData.payments || []);
      }
      if (attRes.ok) {
        const attData = await attRes.json();
        setAttendanceRecords(attData.records || []);
      }
      if (leaveRes.ok) {
        const leaveData = await leaveRes.json();
        setLeaveRequests(leaveData.leaves || []);
      }
      if (audRes.ok) {
        const audData = await audRes.json();
        setAuditLogs(audData.logs || []);
      }

      // If user is integrated as an employee and has no employees of their own, default to employee view
      if (hasEmployments && (!managerPrivilege || employeeCount === 0)) {
        setViewMode('employee');
      }
    } catch (err) {
      console.error('Error fetching Job Manager data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Submit leave request for employee portal
  const handleEmployeeSubmitLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    const currEmp = myEmployments[selectedEmploymentIndex] || myEmployments[0];
    if (!currEmp) return;
    if (!leaveStartDate || !leaveEndDate) {
      alert('Please select both start and end dates.');
      return;
    }
    setSubmittingLeave(true);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;

      const daysDiff = Math.max(
        1,
        Math.ceil((new Date(leaveEndDate).getTime() - new Date(leaveStartDate).getTime()) / (1000 * 60 * 60 * 24)) + 1
      );

      const res = await fetch('/api/jobs/leaves', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          employeeId: currEmp.id,
          leaveType,
          startDate: leaveStartDate,
          endDate: leaveEndDate,
          daysCount: daysDiff,
          reason: leaveReason.trim(),
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setLeaveRequests((prev) => [data.leave, ...prev]);
        setLeaveReason('');
        setLeaveStartDate('');
        setLeaveEndDate('');
        alert('Your leave request has been submitted to your organization manager!');
        fetchData();
      } else {
        const err = await res.json();
        alert(err.error || 'Failed to submit leave request');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSubmittingLeave(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Re-fetch attendance when attendance date changes
  useEffect(() => {
    if (!attendanceDate) return;
    const fetchAttendance = async () => {
      try {
        const headers: Record<string, string> = {};
        if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
        const res = await fetch(`/api/jobs/attendance?date=${attendanceDate}`, { headers });
        if (res.ok) {
          const d = await res.json();
          setAttendanceRecords(d.records || []);
        }
      } catch (e) {
        console.error(e);
      }
    };
    fetchAttendance();
  }, [attendanceDate]);

  // Filtered employees
  const filteredEmployees = useMemo(() => {
    return employees.filter((emp) => {
      const matchSearch =
        !empSearch ||
        emp.fullName.toLowerCase().includes(empSearch.toLowerCase()) ||
        emp.jobTitle.toLowerCase().includes(empSearch.toLowerCase()) ||
        emp.employeeIdNumber.toLowerCase().includes(empSearch.toLowerCase()) ||
        Boolean(emp.username && emp.username.toLowerCase().includes(empSearch.toLowerCase()));

      const matchDept = deptFilter === 'ALL' || emp.department === deptFilter;
      const matchType = typeFilter === 'ALL' || emp.employmentType === typeFilter;
      const matchStatus = statusFilter === 'ALL' || emp.status === statusFilter;

      return matchSearch && matchDept && matchType && matchStatus;
    });
  }, [employees, empSearch, deptFilter, typeFilter, statusFilter]);

  // Filtered payments
  const filteredPayments = useMemo(() => {
    return payments.filter((pay) => {
      return paymentStatusFilter === 'ALL' || pay.paymentStatus === paymentStatusFilter;
    });
  }, [payments, paymentStatusFilter]);

  // Calculate quick stats
  const stats = useMemo(() => {
    const totalEmployees = employees.length;
    const activeEmployees = employees.filter((e) => e.status === 'active').length;
    const totalExpectedSalary = employees.reduce((sum, e) => sum + (e.baseSalary || 0), 0);
    const totalPaidSalary = payments
      .filter((p) => p.paymentStatus === 'paid')
      .reduce((sum, p) => sum + (p.paidAmount || 0), 0);
    const pendingPaymentsCount = payments.filter((p) => p.paymentStatus === 'pending' || p.paymentStatus === 'overdue').length;

    return {
      totalEmployees,
      activeEmployees,
      totalExpectedSalary,
      totalPaidSalary,
      pendingPaymentsCount,
    };
  }, [employees, payments]);

  // Bulk mark present for active employees today
  const handleMarkAllPresent = async () => {
    try {
      setMarkingAttendance(true);
      const activeEmps = employees.filter((e) => e.status === 'active');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;

      const promises = activeEmps.map((emp) =>
        fetch('/api/jobs/attendance', {
          method: 'POST',
          headers,
          body: JSON.stringify({
            employeeId: emp.id,
            date: attendanceDate,
            status: 'present',
            hoursWorked: 8,
            notes: 'Batch recorded present by manager',
          }),
        })
      );

      await Promise.all(promises);
      setBulkPresentSuccess(true);
      setTimeout(() => setBulkPresentSuccess(false), 3000);
      fetchData();
    } catch (e) {
      console.error(e);
    } finally {
      setMarkingAttendance(false);
    }
  };

  // Mark single attendance
  const handleMarkSingleAttendance = async (
    empId: string,
    status: 'present' | 'absent' | 'half_day' | 'leave',
    hours: number,
    overtime: number
  ) => {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;

      const res = await fetch('/api/jobs/attendance', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          employeeId: empId,
          date: attendanceDate,
          status,
          hoursWorked: hours,
          overtimeHours: overtime,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setAttendanceRecords((prev) => {
          const idx = prev.findIndex((r) => r.employeeId === empId && r.date === attendanceDate);
          if (idx >= 0) {
            const next = [...prev];
            next[idx] = data.record;
            return next;
          }
          return [data.record, ...prev];
        });
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Submit leave request
  const handleSubmitLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leaveEmployeeId || !leaveStartDate || !leaveEndDate) return;

    try {
      setSubmittingLeave(true);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;

      const start = new Date(leaveStartDate);
      const end = new Date(leaveEndDate);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const daysCount = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1);

      const res = await fetch('/api/jobs/leaves', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          employeeId: leaveEmployeeId,
          leaveType,
          startDate: leaveStartDate,
          endDate: leaveEndDate,
          daysCount,
          reason: leaveReason,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setLeaveRequests((prev) => [data.leave, ...prev]);
        setLeaveReason('');
        setLeaveStartDate('');
        setLeaveEndDate('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingLeave(false);
    }
  };

  // Approve / Reject Leave
  const handleUpdateLeaveStatus = async (leaveId: string, status: 'approved' | 'rejected') => {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;

      const res = await fetch(`/api/jobs/leaves/${leaveId}`, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          status,
          rejectionReason: status === 'rejected' ? 'Declined by authorized manager' : undefined,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setLeaveRequests((prev) => prev.map((l) => (l.id === leaveId ? data.leave : l)));
        fetchData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Update Payment Status
  const handleSavePaymentStatus = async () => {
    if (!editingPayment) return;
    try {
      setSubmittingEdit(true);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;

      const res = await fetch(`/api/jobs/payments/${editingPayment.id}`, {
        method: 'PUT',
        headers,
        body: JSON.stringify({
          paymentStatus: editStatus,
          adminAuditNote: editNote,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setPayments((prev) => prev.map((p) => (p.id === editingPayment.id ? data.payment : p)));
        setEditingPayment(null);
        setEditNote('');
        fetchData();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSubmittingEdit(false);
    }
  };

  // CSV Export
  const handleExportCSV = () => {
    if (employees.length === 0) return;

    const headers = [
      'Employee ID',
      'Full Name',
      'Username',
      'Job Title',
      'Department',
      'Employment Type',
      'Salary Frequency',
      'Salary Rate',
      'Currency',
      'Status',
      'Joining Date',
    ];

    const rows = employees.map((emp) => [
      `"${emp.employeeIdNumber}"`,
      `"${emp.fullName}"`,
      `"${emp.username || 'N/A'}"`,
      `"${emp.jobTitle}"`,
      `"${emp.department}"`,
      `"${emp.employmentType}"`,
      `"${emp.salaryFrequency}"`,
      emp.baseSalary,
      `"${emp.currency}"`,
      `"${emp.status}"`,
      `"${emp.joiningDate}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `lot_employee_records_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const defaultCurrency = organization?.defaultCurrency || 'LOT';
  const departmentList = organization?.departmentList || [
    'Executive & Leadership',
    'Operations & Administration',
    'Finance & Payroll',
    'Engineering & IT',
    'Sales & Customer Support',
    'Government & Public Service',
    'Retail & Store Management',
  ];

  return (
    <div className="space-y-6 pb-16 animate-fadeIn">
      {/* Dual Role Selector: Manager vs Employee Portal */}
      {myEmployments.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-3xl bg-gradient-to-r from-[#19192B] via-[#151528] to-[#19192B] border border-emerald-500/30 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">Active LOT Ecosystem Job Profile</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                  Integrated User
                </span>
              </div>
              <p className="text-xs text-[#A5A3B8]">
                Enrolled as <strong className="text-white">{myEmployments[0]?.fullName}</strong> ({myEmployments[0]?.jobTitle} at {myEmployments[0]?.organizationName || organization?.name})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-[#10101F] rounded-2xl border border-[#2B2B48]">
            <button
              onClick={() => setViewMode('employee')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
                viewMode === 'employee'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              <UserCheck className="w-4 h-4" />
              <span>My Job & Payslips ({myEmployments.length})</span>
            </button>
            <button
              onClick={() => setViewMode('manager')}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
                viewMode === 'manager'
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-lg shadow-purple-600/30'
                  : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>Manager Dashboard</span>
            </button>
          </div>
        </div>
      )}

      {viewMode === 'employee' ? (
        <EmployeeJobPortal
          currentEmployment={myEmployments[selectedEmploymentIndex] || myEmployments[0]}
          employments={myEmployments}
          selectedEmploymentIndex={selectedEmploymentIndex}
          onSelectEmployment={setSelectedEmploymentIndex}
          payments={payments.filter(
            (p) =>
              p.employeeId ===
              (myEmployments[selectedEmploymentIndex]?.id || myEmployments[0]?.id)
          )}
          attendanceRecords={attendanceRecords.filter(
            (r) =>
              r.employeeId ===
              (myEmployments[selectedEmploymentIndex]?.id || myEmployments[0]?.id)
          )}
          leaveRequests={leaveRequests.filter(
            (l) =>
              l.employeeId ===
              (myEmployments[selectedEmploymentIndex]?.id || myEmployments[0]?.id)
          )}
          activePortalTab={employeePortalTab}
          onSelectPortalTab={setEmployeePortalTab}
          onViewSalarySlip={(payment) => setSelectedPaymentForSlip(payment)}
          leaveType={leaveType}
          onLeaveTypeChange={setLeaveType}
          leaveStartDate={leaveStartDate}
          onLeaveStartDateChange={setLeaveStartDate}
          leaveEndDate={leaveEndDate}
          onLeaveEndDateChange={setLeaveEndDate}
          leaveReason={leaveReason}
          onLeaveReasonChange={setLeaveReason}
          submittingLeave={submittingLeave}
          onSubmitLeave={handleEmployeeSubmitLeave}
          onRefresh={fetchData}
          refreshing={refreshing}
        />
      ) : (
        <>
          {/* Top Organization Header & Mode Banner */}
          <div className="relative rounded-3xl bg-gradient-to-r from-[#19192B] via-[#121222] to-[#19192B] border border-[#302D46] p-6 shadow-2xl overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-500/20 text-[#C4B5FD] border border-purple-500/30 flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5 text-[#C4B5FD]" />
                Job & Salary Operations
              </span>
              <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#202039] text-[#A5A3B8] border border-[#302D46]">
                {organization?.type || 'Business & Enterprise'}
              </span>
              <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-950/60 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <ShieldAlert className="w-3 h-3 text-emerald-400" />
                Authorized Manager Active
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
              {organization?.name || 'LOT Business & Public Enterprise Org'}
            </h1>
            <p className="text-xs sm:text-sm text-[#A5A3B8] max-w-2xl">
              Complete workforce, employment contracts, attendance tracking, and verified salary record disbursements.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={fetchData}
              disabled={refreshing}
              className="p-2.5 rounded-xl bg-[#202039] hover:bg-[#2c2c4d] border border-[#302D46] text-[#A5A3B8] hover:text-white transition-all cursor-pointer flex items-center gap-2 text-xs font-semibold"
              title="Refresh records"
            >
              <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-[#C4B5FD]' : ''}`} />
              <span className="hidden sm:inline">Refresh</span>
            </button>

            <button
              onClick={handleExportCSV}
              className="px-3.5 py-2.5 rounded-xl bg-[#202039] hover:bg-[#2c2c4d] border border-[#302D46] text-white hover:text-[#C4B5FD] transition-all cursor-pointer flex items-center gap-2 text-xs font-semibold"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={handleRunAutoPayroll}
              disabled={runningAutoPayroll}
              className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-white shadow-lg shadow-amber-500/20 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
              title="Automatically disburse scheduled salaries for all due employees"
            >
              <Zap className={`w-4 h-4 ${runningAutoPayroll ? 'animate-spin' : 'text-amber-200'}`} />
              <span>{runningAutoPayroll ? 'Auto-Paying...' : 'Run Auto-Pay'}</span>
            </button>

            <button
              onClick={() => {
                setSelectedEmployeeForPay(null);
                setIsPaySalaryOpen(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-500/20 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer"
            >
              <DollarSign className="w-4 h-4" />
              <span>Pay / Record Salary</span>
            </button>

            <button
              onClick={() => setIsAddEmployeeOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:from-[#7C3AED] hover:to-[#9333EA] text-white shadow-lg shadow-purple-500/25 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Enroll Employee</span>
            </button>
          </div>
        </div>

        {autoPayMessage && (
          <div className="mt-3 p-3 rounded-xl bg-amber-950/80 border border-amber-500/50 text-amber-200 text-xs flex items-center gap-2 animate-fadeIn">
            <Zap className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="font-medium">{autoPayMessage}</span>
          </div>
        )}

        {/* Government Employment Notice */}
        <div className="mt-4 pt-4 border-t border-[#302D46]/80 flex items-start gap-2.5 text-[11px] text-[#A5A3B8]">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p>
            <strong className="text-amber-300">Government Job Record Management Notice:</strong> This portal manages and
            audits internal enterprise and organizational employment records. Selecting "Government Job Employee" manages
            personnel files and does not verify official state government civil service credentials or process official
            government tax withholdings. Real transfers occur only via configured LOT Ecosystem transaction channels.
          </p>
        </div>
      </div>

      {/* Quick Metrics Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center shrink-0">
            <Users className="w-5 h-5 text-[#C4B5FD]" />
          </div>
          <div>
            <span className="text-[11px] text-[#A5A3B8] font-medium block">Total Workforce</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-white">{stats.totalEmployees}</span>
              <span className="text-[10px] text-emerald-400 font-semibold">{stats.activeEmployees} Active</span>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <span className="text-[11px] text-[#A5A3B8] font-medium block">Expected Budget</span>
            <span className="text-xl font-black text-white">
              {formatCompactNumber(stats.totalExpectedSalary)} <span className="text-xs text-blue-400">{defaultCurrency}</span>
            </span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <span className="text-[11px] text-[#A5A3B8] font-medium block">Disbursed Salaries</span>
            <span className="text-xl font-black text-emerald-300">
              {formatCompactNumber(stats.totalPaidSalary)} <span className="text-xs text-emerald-400">{defaultCurrency}</span>
            </span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <span className="text-[11px] text-[#A5A3B8] font-medium block">Pending / Overdue</span>
            <span className="text-xl font-black text-amber-300">{stats.pendingPaymentsCount}</span>
          </div>
        </div>

        <div className="col-span-2 lg:col-span-1 p-4 rounded-2xl bg-[#121222] border border-[#302D46] shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center shrink-0">
            <Calendar className="w-5 h-5 text-[#C4B5FD]" />
          </div>
          <div>
            <span className="text-[11px] text-[#A5A3B8] font-medium block">Next Pay Cycle</span>
            <span className="text-sm font-bold text-white">
              {new Date(Date.now() + 7 * 86400000).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
            </span>
          </div>
        </div>
      </div>

      {/* Tab Navigation Bar */}
      <div className="flex items-center gap-1.5 sm:gap-2 p-1.5 bg-[#121222] rounded-2xl border border-[#302D46] overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('employees')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activeTab === 'employees'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Employees ({employees.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('salary')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activeTab === 'salary'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Salaries & Payroll ({payments.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('attendance')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activeTab === 'attendance'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <CalendarCheck className="w-4 h-4" />
          <span>Attendance</span>
        </button>

        <button
          onClick={() => setActiveTab('leaves')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activeTab === 'leaves'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Leave Requests ({leaveRequests.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activeTab === 'reports'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Reports & Analytics</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activeTab === 'audit'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Audit Logs ({auditLogs.length})</span>
        </button>
      </div>

      {/* TAB CONTENT 1: EMPLOYEES DIRECTORY */}
      {activeTab === 'employees' && (
        <div className="space-y-4">
          {/* Filters & Search Controls */}
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#A5A3B8]" />
              <input
                type="text"
                value={empSearch}
                onChange={(e) => setEmpSearch(e.target.value)}
                placeholder="Search employees by name, username, title, or ID..."
                className="w-full pl-10 pr-4 py-2.5 bg-[#19192B] border border-[#302D46] rounded-xl text-xs sm:text-sm text-white placeholder-[#A5A3B8] focus:outline-none focus:border-[#8B5CF6]"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              >
                <option value="ALL">All Departments</option>
                {departmentList.map((d: string) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>

              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              >
                <option value="ALL">All Employment Types</option>
                <option value="Private Company Employee">Private Company</option>
                <option value="Business or Shop Employee">Business / Shop</option>
                <option value="Government Job Employee">Government Job Record</option>
                <option value="Self-Employed">Self-Employed</option>
                <option value="Contract Worker">Contract Worker</option>
                <option value="Temporary Employee">Temporary</option>
                <option value="Custom Employment Type">Custom</option>
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              >
                <option value="ALL">All Statuses</option>
                <option value="active">Active</option>
                <option value="on_leave">On Leave</option>
                <option value="suspended">Suspended</option>
                <option value="resigned">Resigned</option>
                <option value="retired">Retired</option>
                <option value="terminated">Terminated</option>
              </select>
            </div>
          </div>

          {/* Employees Grid */}
          {filteredEmployees.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-[#121222] border border-[#302D46] space-y-3">
              <Users className="w-12 h-12 text-[#A5A3B8]/50 mx-auto" />
              <h3 className="text-base font-bold text-white">No employees found</h3>
              <p className="text-xs text-[#A5A3B8] max-w-sm mx-auto">
                {empSearch || deptFilter !== 'ALL' || typeFilter !== 'ALL' || statusFilter !== 'ALL'
                  ? 'No employees match your search criteria. Try resetting the filters.'
                  : 'Get started by enrolling your first team member or public record personnel.'}
              </p>
              <button
                onClick={() => setIsAddEmployeeOpen(true)}
                className="mt-2 inline-flex items-center gap-2 px-4 py-2 bg-[#8B5CF6] text-white rounded-xl text-xs font-semibold cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Enroll First Employee
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredEmployees.map((emp) => {
                const isGov = emp.employmentType === 'Government Job Employee';
                const isActive = emp.status === 'active';

                return (
                  <div
                    key={emp.id}
                    className="p-5 rounded-2xl bg-[#121222] border border-[#302D46] hover:border-[#8B5CF6]/60 transition-all shadow-md flex flex-col justify-between group"
                  >
                    <div>
                      {/* Top row: Avatar & Status Badge */}
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-white font-bold text-base shadow shrink-0 overflow-hidden">
                            {emp.avatarUrl ? (
                              <img src={emp.avatarUrl} alt={emp.fullName} className="w-full h-full object-cover" />
                            ) : (
                              emp.fullName.charAt(0).toUpperCase()
                            )}
                          </div>
                          <div>
                            <h4 className="font-bold text-white text-sm group-hover:text-[#C4B5FD] transition-colors">
                              {emp.fullName}
                            </h4>
                            <div className="flex items-center gap-1.5 text-xs text-[#A5A3B8]">
                              <span>ID: {emp.employeeIdNumber}</span>
                              {emp.username && (
                                <span className="text-[#C4B5FD] font-semibold">@{emp.username}</span>
                              )}
                            </div>
                          </div>
                        </div>

                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                            isActive
                              ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                              : emp.status === 'on_leave'
                              ? 'bg-blue-950/60 text-blue-300 border-blue-500/40'
                              : 'bg-red-950/60 text-red-300 border-red-500/40'
                          }`}
                        >
                          {emp.status.replace('_', ' ')}
                        </span>
                      </div>

                      {/* Position & Department */}
                      <div className="space-y-1.5 mb-4">
                        <p className="text-xs text-white font-semibold flex items-center gap-1.5">
                          <Briefcase className="w-3.5 h-3.5 text-[#C4B5FD]" />
                          {emp.jobTitle}
                        </p>
                        <p className="text-[11px] text-[#A5A3B8] flex items-center gap-1.5">
                          <Building2 className="w-3.5 h-3.5 text-[#A5A3B8]" />
                          {emp.department} • {emp.organizationName}
                        </p>
                        <div className="pt-1 flex flex-wrap gap-1">
                          <span
                            className={`text-[10px] font-medium px-2 py-0.5 rounded-md ${
                              isGov
                                ? 'bg-amber-950/60 text-amber-300 border border-amber-500/30'
                                : 'bg-[#19192B] text-[#C4B5FD] border border-[#302D46]'
                            }`}
                          >
                            {emp.employmentType}
                          </span>
                        </div>
                      </div>

                      {/* Salary and Auto-Pay details */}
                      <div className="p-3 rounded-xl bg-[#19192B] border border-[#302D46] mb-4 space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-[10px] text-[#A5A3B8] block">Configured Salary</span>
                            <span className="text-xs font-black text-white">
                              {emp.baseSalary.toLocaleString()} {emp.currency}{' '}
                              <span className="text-[10px] font-normal text-[#A5A3B8]">/ {emp.salaryFrequency}</span>
                            </span>
                          </div>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950/60 border border-purple-500/30 text-purple-200 font-semibold">
                            {emp.salaryFrequency}
                          </span>
                        </div>

                        {/* Integration status and auto-pay cycle */}
                        <div className="pt-1.5 border-t border-[#302D46]/60 flex flex-wrap items-center justify-between gap-1 text-[10px]">
                          {emp.userId ? (
                            <span className="text-purple-300 flex items-center gap-1 font-semibold">
                              <ShieldCheck className="w-3 h-3 text-purple-400" />
                              LOT Account Linked
                            </span>
                          ) : (
                            <span className="text-[#8F8CA8]">Manual External Employee</span>
                          )}

                          {emp.autoPayEnabled !== false ? (
                            <span className="text-amber-300 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-500/30 flex items-center gap-0.5 font-mono">
                              <Zap className="w-2.5 h-2.5 text-amber-400" />
                              Auto-Pay Active
                            </span>
                          ) : (
                            <span className="text-gray-400">Manual Pay Only</span>
                          )}
                        </div>

                        {emp.nextExpectedSalaryDate && (
                          <div className="text-[10px] text-[#A5A3B8] flex items-center justify-between pt-0.5">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3 text-amber-400/80" />
                              Next Due:
                            </span>
                            <span className="text-white font-medium">
                              {new Date(emp.nextExpectedSalaryDate).toLocaleDateString([], {
                                month: 'short',
                                day: 'numeric',
                              })}{' '}
                              {new Date(emp.nextExpectedSalaryDate).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2 pt-2 border-t border-[#302D46]/80">
                      <button
                        onClick={() => setSelectedEmployeeForDetails(emp)}
                        className="flex-1 py-2 rounded-xl bg-[#202039] hover:bg-[#2a2a4b] text-white text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5 text-[#C4B5FD]" />
                        <span>Profile & History</span>
                      </button>

                      <button
                        onClick={() => {
                          setSelectedEmployeeForPay(emp.id);
                          setIsPaySalaryOpen(true);
                        }}
                        className="px-3 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                        title="Process payment for this employee"
                      >
                        <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Pay</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 2: SALARIES & PAYROLL */}
      {activeTab === 'salary' && (
        <div className="space-y-4">
          {/* Automated Recurring Payroll Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-[#19192B] to-purple-950/40 border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0">
                <Zap className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-white text-xs sm:text-sm">LOT Automated Recurring Payroll Engine</h4>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-950/70 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Active Background Worker
                  </span>
                </div>
                <p className="text-[11px] text-[#A5A3B8] mt-0.5">
                  Automatically calculates and credits LOT salary to linked employees according to their configured schedule (Hourly, Daily, Weekly, or Monthly).
                </p>
              </div>
            </div>

            <button
              onClick={handleRunAutoPayroll}
              disabled={runningAutoPayroll}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-black text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer shrink-0 disabled:opacity-50 transition-all"
            >
              <Zap className={`w-3.5 h-3.5 ${runningAutoPayroll ? 'animate-spin' : ''}`} />
              <span>{runningAutoPayroll ? 'Executing Auto-Pay...' : 'Run Auto-Pay Now'}</span>
            </button>
          </div>

          {/* Filter Bar */}
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-[#A5A3B8] font-medium">Filter by Status:</span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { label: 'ALL', value: 'ALL' },
                  { label: 'Paid', value: 'paid' },
                  { label: 'Pending', value: 'pending' },
                  { label: 'Partially Paid', value: 'partially_paid' },
                  { label: 'Overdue', value: 'overdue' },
                ].map((st) => (
                  <button
                    key={st.value}
                    onClick={() => setPaymentStatusFilter(st.value)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      paymentStatusFilter === st.value
                        ? 'bg-[#8B5CF6] text-white'
                        : 'bg-[#19192B] text-[#A5A3B8] hover:text-white border border-[#302D46]'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                setSelectedEmployeeForPay(null);
                setIsPaySalaryOpen(true);
              }}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Record New Payment</span>
            </button>
          </div>

          {/* Payments Table */}
          {filteredPayments.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-[#121222] border border-[#302D46] space-y-3">
              <DollarSign className="w-12 h-12 text-[#A5A3B8]/50 mx-auto" />
              <h3 className="text-base font-bold text-white">No salary records found</h3>
              <p className="text-xs text-[#A5A3B8] max-w-sm mx-auto">
                No salary disbursements have been recorded matching your current filter.
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-[#121222] border border-[#302D46] overflow-x-auto shadow-xl">
              <table className="w-full text-left text-xs text-[#A5A3B8]">
                <thead className="bg-[#19192B] text-[#C4B5FD] uppercase text-[10px] font-bold tracking-wider border-b border-[#302D46]">
                  <tr>
                    <th className="px-4 py-3">Employee & Role</th>
                    <th className="px-4 py-3">Period</th>
                    <th className="px-4 py-3">Base / Freq</th>
                    <th className="px-4 py-3">Bonus / Ded.</th>
                    <th className="px-4 py-3">Net Payable</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Method</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#302D46]/60">
                  {filteredPayments.map((pay) => {
                    const isPaid = pay.paymentStatus === 'paid';
                    const isPending = pay.paymentStatus === 'pending';
                    const isOverdue = pay.paymentStatus === 'overdue';

                    return (
                      <tr key={pay.id} className="hover:bg-[#19192B]/50 transition-colors">
                        <td className="px-4 py-3.5">
                          <div className="font-bold text-white">{pay.employeeName}</div>
                          <div className="text-[11px] text-[#A5A3B8]">
                            ID: {pay.employeeIdNumber} • {pay.jobTitle}
                          </div>
                        </td>
                        <td className="px-4 py-3.5 font-medium text-white">{pay.salaryPeriod}</td>
                        <td className="px-4 py-3.5">
                          <span className="font-semibold text-white">
                            {pay.baseAmount.toLocaleString()} {pay.currency}
                          </span>
                          <span className="block text-[10px] text-[#A5A3B8]">{pay.salaryFrequency}</span>
                        </td>
                        <td className="px-4 py-3.5">
                          <span className="text-emerald-400 font-medium">+{pay.totalBonus.toLocaleString()}</span>
                          <span className="text-rose-400 font-medium block">-{pay.totalDeductions.toLocaleString()}</span>
                        </td>
                        <td className="px-4 py-3.5">
                          <span className="text-sm font-black text-white">
                            {pay.netPayableAmount.toLocaleString()} {pay.currency}
                          </span>
                          {pay.paidAmount < pay.netPayableAmount && (
                            <span className="block text-[10px] text-amber-400">
                              Paid: {pay.paidAmount.toLocaleString()}
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3.5">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold border uppercase ${
                              isPaid
                                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                                : isOverdue
                                ? 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                                : isPending
                                ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                                : 'bg-blue-950/80 text-blue-300 border-blue-500/40'
                            }`}
                          >
                            {pay.paymentStatus.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 text-[11px] text-white">
                          <div>{pay.paymentMethod}</div>
                          {pay.recordedBy === 'system_autopay' && (
                            <span className="inline-flex items-center gap-1 text-[9px] text-amber-300 font-mono mt-0.5">
                              <Zap className="w-2.5 h-2.5 text-amber-400" />
                              Auto-Disbursed
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3.5 text-right space-x-1.5 whitespace-nowrap">
                          <button
                            onClick={() => setSelectedPaymentForSlip(pay)}
                            className="px-2.5 py-1.5 rounded-lg bg-[#202039] hover:bg-[#2c2c4d] text-[#C4B5FD] hover:text-white font-semibold transition-colors cursor-pointer"
                          >
                            Slip
                          </button>
                          <button
                            onClick={() => {
                              setEditingPayment(pay);
                              setEditStatus(pay.paymentStatus);
                              setEditNote(pay.notes || '');
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 border border-purple-500/30 font-semibold transition-colors cursor-pointer"
                          >
                            Status
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 3: ATTENDANCE & WORKING HOURS */}
      {activeTab === 'attendance' && (
        <div className="space-y-4">
          {/* Top attendance controls */}
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="text-xs text-[#A5A3B8] font-semibold flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-[#8B5CF6]" />
                Select Attendance Date:
              </span>
              <input
                type="date"
                value={attendanceDate}
                onChange={(e) => setAttendanceDate(e.target.value)}
                className="px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              />
            </div>

            <div className="flex items-center gap-2">
              {bulkPresentSuccess && (
                <span className="text-xs text-emerald-400 font-bold flex items-center gap-1 animate-fadeIn">
                  <CheckCircle2 className="w-4 h-4" /> Active marked present!
                </span>
              )}
              <button
                onClick={handleMarkAllPresent}
                disabled={markingAttendance}
                className="px-4 py-2 bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white rounded-xl text-xs font-bold hover:opacity-90 transition-opacity flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <UserCheck className="w-4 h-4" />
                <span>Mark All Active Present</span>
              </button>
            </div>
          </div>

          {/* Attendance Employee List */}
          <div className="rounded-2xl bg-[#121222] border border-[#302D46] overflow-x-auto shadow-xl">
            <table className="w-full text-left text-xs text-[#A5A3B8]">
              <thead className="bg-[#19192B] text-[#C4B5FD] uppercase text-[10px] font-bold tracking-wider border-b border-[#302D46]">
                <tr>
                  <th className="px-4 py-3">Employee</th>
                  <th className="px-4 py-3">Department</th>
                  <th className="px-4 py-3">Current Status</th>
                  <th className="px-4 py-3">Logged Hours</th>
                  <th className="px-4 py-3">Overtime</th>
                  <th className="px-4 py-3 text-right">Quick Mark Attendance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#302D46]/60">
                {employees.map((emp) => {
                  const record = attendanceRecords.find((r) => r.employeeId === emp.id && r.date === attendanceDate);
                  const status = record?.status || 'Unrecorded';
                  const hours = record?.hoursWorked ?? (emp.salaryFrequency === 'Hourly' ? 8 : 8);
                  const overtime = record?.overtimeHours ?? 0;

                  return (
                    <tr key={emp.id} className="hover:bg-[#19192B]/50 transition-colors">
                      <td className="px-4 py-3.5">
                        <div className="font-bold text-white">{emp.fullName}</div>
                        <div className="text-[11px] text-[#A5A3B8]">
                          ID: {emp.employeeIdNumber} • {emp.jobTitle}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 font-medium text-white">{emp.department}</td>
                      <td className="px-4 py-3.5">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            status === 'present'
                              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40'
                              : status === 'absent'
                              ? 'bg-rose-950/80 text-rose-300 border border-rose-500/40'
                              : status === 'half_day'
                              ? 'bg-amber-950/80 text-amber-300 border border-amber-500/40'
                              : status === 'leave'
                              ? 'bg-blue-950/80 text-blue-300 border border-blue-500/40'
                              : 'bg-zinc-800 text-zinc-400'
                          }`}
                        >
                          {status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-white font-semibold">{record ? `${hours} hrs` : '—'}</td>
                      <td className="px-4 py-3.5 text-amber-300">{overtime > 0 ? `+${overtime} hrs` : '0 hrs'}</td>
                      <td className="px-4 py-3.5 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => handleMarkSingleAttendance(emp.id, 'present', 8, 0)}
                            className="px-2 py-1 rounded bg-emerald-950/80 text-emerald-300 hover:bg-emerald-900 border border-emerald-500/40 text-[10px] font-bold cursor-pointer"
                          >
                            Present
                          </button>
                          <button
                            onClick={() => handleMarkSingleAttendance(emp.id, 'half_day', 4, 0)}
                            className="px-2 py-1 rounded bg-amber-950/80 text-amber-300 hover:bg-amber-900 border border-amber-500/40 text-[10px] font-bold cursor-pointer"
                          >
                            Half
                          </button>
                          <button
                            onClick={() => handleMarkSingleAttendance(emp.id, 'absent', 0, 0)}
                            className="px-2 py-1 rounded bg-rose-950/80 text-rose-300 hover:bg-rose-900 border border-rose-500/40 text-[10px] font-bold cursor-pointer"
                          >
                            Absent
                          </button>
                          <button
                            onClick={() => handleMarkSingleAttendance(emp.id, 'present', 8, 2)}
                            className="px-2 py-1 rounded bg-purple-950/80 text-purple-300 hover:bg-purple-900 border border-purple-500/40 text-[10px] font-bold cursor-pointer"
                          >
                            OT (+2h)
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB CONTENT 4: LEAVE REQUESTS */}
      {activeTab === 'leaves' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Submit Leave Form */}
          <div className="p-5 rounded-2xl bg-[#121222] border border-[#302D46] shadow-xl space-y-4">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#8B5CF6]" />
              Submit Leave Request
            </h3>
            <p className="text-xs text-[#A5A3B8]">
              Authorized managers or staff can record scheduled leaves and balance deductions.
            </p>

            <form onSubmit={handleSubmitLeave} className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-[#A5A3B8] block mb-1">Select Employee</label>
                <select
                  value={leaveEmployeeId}
                  onChange={(e) => setLeaveEmployeeId(e.target.value)}
                  required
                  className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                >
                  <option value="">-- Choose employee --</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.fullName} ({emp.employeeIdNumber})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-[#A5A3B8] block mb-1">Leave Type</label>
                <select
                  value={leaveType}
                  onChange={(e: any) => setLeaveType(e.target.value)}
                  className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                >
                  <option value="Casual Leave">Casual Leave</option>
                  <option value="Sick Leave">Sick Leave</option>
                  <option value="Paid Leave">Paid Annual Leave</option>
                  <option value="Unpaid Leave">Unpaid Leave</option>
                  <option value="Emergency Leave">Emergency Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-semibold text-[#A5A3B8] block mb-1">Start Date</label>
                  <input
                    type="date"
                    value={leaveStartDate}
                    onChange={(e) => setLeaveStartDate(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-[#A5A3B8] block mb-1">End Date</label>
                  <input
                    type="date"
                    value={leaveEndDate}
                    onChange={(e) => setLeaveEndDate(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-[#A5A3B8] block mb-1">Reason / Comments</label>
                <textarea
                  rows={2}
                  value={leaveReason}
                  onChange={(e) => setLeaveReason(e.target.value)}
                  placeholder="e.g. Medical appointment, family visit..."
                  className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={submittingLeave}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white text-xs font-bold hover:opacity-90 transition-opacity cursor-pointer disabled:opacity-50"
              >
                {submittingLeave ? 'Submitting...' : 'Submit Request'}
              </button>
            </form>
          </div>

          {/* Leave Requests Stream */}
          <div className="lg:col-span-2 space-y-3">
            <h3 className="font-bold text-sm text-white flex items-center justify-between">
              <span>Leave Application Records</span>
              <span className="text-xs text-[#A5A3B8] font-normal">{leaveRequests.length} recorded</span>
            </h3>

            {leaveRequests.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-[#121222] border border-[#302D46] text-xs text-[#A5A3B8]">
                No leave applications recorded yet.
              </div>
            ) : (
              <div className="space-y-2.5">
                {leaveRequests.map((req) => {
                  const isPending = req.status === 'pending';
                  const isApproved = req.status === 'approved';

                  return (
                    <div
                      key={req.id}
                      className="p-4 rounded-xl bg-[#121222] border border-[#302D46] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-xs">{req.employeeName}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950/60 text-purple-200 border border-purple-500/30">
                            {req.leaveType}
                          </span>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                              isApproved
                                ? 'bg-emerald-950 text-emerald-300'
                                : isPending
                                ? 'bg-amber-950 text-amber-300'
                                : 'bg-rose-950 text-rose-300'
                            }`}
                          >
                            {req.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#A5A3B8]">
                          {req.startDate} to {req.endDate} ({req.daysCount} {req.daysCount === 1 ? 'day' : 'days'})
                        </p>
                        {req.reason && <p className="text-xs text-zinc-300 italic">"{req.reason}"</p>}
                      </div>

                      {isPending && isManager && (
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => handleUpdateLeaveStatus(req.id, 'approved')}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            onClick={() => handleUpdateLeaveStatus(req.id, 'rejected')}
                            className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB CONTENT 5: REPORTS & ANALYTICS */}
      {activeTab === 'reports' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Department Breakdown */}
            <div className="p-5 rounded-2xl bg-[#121222] border border-[#302D46] shadow-xl space-y-4">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#8B5CF6]" />
                Workforce by Department
              </h3>
              <div className="space-y-3">
                {departmentList.map((dept: string) => {
                  const count = employees.filter((e) => e.department === dept).length;
                  const percentage = employees.length > 0 ? Math.round((count / employees.length) * 100) : 0;

                  return (
                    <div key={dept} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-white font-medium">{dept}</span>
                        <span className="text-[#A5A3B8] font-bold">
                          {count} ({percentage}%)
                        </span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-[#19192B] overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] rounded-full"
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Employment Type Distribution */}
            <div className="p-5 rounded-2xl bg-[#121222] border border-[#302D46] shadow-xl space-y-4">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#8B5CF6]" />
                Employment Type Distribution
              </h3>
              <div className="space-y-2.5">
                {[
                  'Private Company Employee',
                  'Business or Shop Employee',
                  'Government Job Employee',
                  'Self-Employed',
                  'Contract Worker',
                  'Temporary Employee',
                ].map((type) => {
                  const count = employees.filter((e) => e.employmentType === type).length;
                  const totalSal = employees
                    .filter((e) => e.employmentType === type)
                    .reduce((sum, e) => sum + (e.baseSalary || 0), 0);

                  return (
                    <div
                      key={type}
                      className="p-3 rounded-xl bg-[#19192B] border border-[#302D46] flex items-center justify-between"
                    >
                      <div>
                        <span className="text-xs font-bold text-white block">{type}</span>
                        <span className="text-[10px] text-[#A5A3B8]">
                          Committed: {totalSal.toLocaleString()} {defaultCurrency}
                        </span>
                      </div>
                      <span className="text-xs font-black px-2.5 py-1 rounded-lg bg-[#202039] text-[#C4B5FD] border border-[#302D46]">
                        {count} staff
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Export Action Card */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-950/40 via-[#121222] to-emerald-950/40 border border-[#302D46] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1">
              <h4 className="font-bold text-white text-base">Comprehensive Audit & Payroll CSV Export</h4>
              <p className="text-xs text-[#A5A3B8] max-w-xl">
                Download verified employment registries, payroll summaries, and attendance logs for accounting,
                management review, and spreadsheet applications.
              </p>
            </div>
            <button
              onClick={handleExportCSV}
              className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Download Full CSV</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB CONTENT 6: AUDIT TRAIL LOGS */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-white">Immutable Salary & HR Audit Trail</h3>
              <p className="text-xs text-[#A5A3B8]">
                Every employee enrollment, salary modification, status adjustment, and payout is logged with timestamp
                and authorized actor.
              </p>
            </div>
          </div>

          {auditLogs.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-[#121222] border border-[#302D46] text-xs text-[#A5A3B8]">
              No audit log entries recorded yet. Operations performed will display here.
            </div>
          ) : (
            <div className="rounded-2xl bg-[#121222] border border-[#302D46] overflow-x-auto shadow-xl">
              <table className="w-full text-left text-xs text-[#A5A3B8]">
                <thead className="bg-[#19192B] text-[#C4B5FD] uppercase text-[10px] font-bold tracking-wider border-b border-[#302D46]">
                  <tr>
                    <th className="px-4 py-3">Timestamp</th>
                    <th className="px-4 py-3">Action</th>
                    <th className="px-4 py-3">Target Employee</th>
                    <th className="px-4 py-3">Authorized Actor</th>
                    <th className="px-4 py-3">Details / Audit Note</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#302D46]/60">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-[#19192B]/50 transition-colors">
                      <td className="px-4 py-3 text-[11px] text-[#A5A3B8] whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-bold text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/30 text-[10px] uppercase">
                          {log.action.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-white font-semibold">{log.targetEmployeeName || '—'}</td>
                      <td className="px-4 py-3 text-[#C4B5FD] font-mono text-[11px]">
                        @{log.performedByUsername || log.performedBy}
                      </td>
                      <td className="px-4 py-3 text-zinc-300 max-w-xs truncate">{log.description || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      </>
    )}

      {/* MODAL 1: ADD EMPLOYEE */}
      <AddEmployeeModal
        isOpen={isAddEmployeeOpen}
        onClose={() => setIsAddEmployeeOpen(false)}
        onEmployeeCreated={(newEmp) => {
          setEmployees((prev) => [newEmp, ...prev]);
          setIsAddEmployeeOpen(false);
          fetchData();
        }}
        organizationName={organization?.name || 'LOT Business & Public Enterprise Org'}
        departmentList={departmentList}
        defaultCurrency={defaultCurrency}
        authToken={authToken}
      />

      {/* MODAL 2: PAY SALARY */}
      <PaySalaryModal
        isOpen={isPaySalaryOpen}
        onClose={() => {
          setIsPaySalaryOpen(false);
          setSelectedEmployeeForPay(null);
        }}
        employees={employees}
        selectedEmployeeId={selectedEmployeeForPay}
        onPaymentRecorded={(payment) => {
          setPayments((prev) => [payment, ...prev]);
          setIsPaySalaryOpen(false);
          fetchData();
        }}
        authToken={authToken}
      />

      {/* MODAL 3: SALARY SLIP (PRINTABLE & DOWNLOADABLE) */}
      <SalarySlipModal payment={selectedPaymentForSlip} onClose={() => setSelectedPaymentForSlip(null)} />

      {/* MODAL 4: EMPLOYEE DETAILS, PERFORMANCE & PROMOTIONS */}
      <EmployeeDetailsModal
        employee={selectedEmployeeForDetails}
        onClose={() => setSelectedEmployeeForDetails(null)}
        onUpdateEmployee={(updated) => {
          setEmployees((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
          setSelectedEmployeeForDetails(updated);
          fetchData();
        }}
        onViewSalarySlip={(payment) => setSelectedPaymentForSlip(payment)}
        payments={payments.filter((p) => p.employeeId === selectedEmployeeForDetails?.id)}
        isManager={isManager}
        authToken={authToken}
      />

      {/* DIALOG: EDIT PAYMENT STATUS & AUDIT CORRECTION */}
      {editingPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-[#19192B] border border-[#302D46] rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#302D46] pb-3">
              <h3 className="font-bold text-white text-sm">Correct Payment Status</h3>
              <button
                onClick={() => setEditingPayment(null)}
                className="text-[#A5A3B8] hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs text-[#A5A3B8]">
              Target: <strong className="text-white">{editingPayment.employeeName}</strong> (Period:{' '}
              {editingPayment.salaryPeriod})
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-[#A5A3B8] block mb-1">New Status</label>
                <select
                  value={editStatus}
                  onChange={(e: any) => setEditStatus(e.target.value)}
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                >
                  <option value="paid">Paid</option>
                  <option value="pending">Pending</option>
                  <option value="partially_paid">Partially Paid</option>
                  <option value="overdue">Overdue</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-[#A5A3B8] block mb-1">
                  Manager Audit Correction Note <span className="text-red-400">*</span>
                </label>
                <textarea
                  rows={2}
                  value={editNote}
                  onChange={(e) => setEditNote(e.target.value)}
                  placeholder="State reason for manual payment status override..."
                  required
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                ></textarea>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#302D46]">
              <button
                onClick={() => setEditingPayment(null)}
                className="px-3.5 py-2 rounded-xl bg-[#202039] text-xs font-semibold text-[#A5A3B8] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSavePaymentStatus}
                disabled={submittingEdit || !editNote.trim()}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white text-xs font-bold hover:opacity-90 disabled:opacity-50 cursor-pointer"
              >
                {submittingEdit ? 'Saving...' : 'Save & Audit'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
