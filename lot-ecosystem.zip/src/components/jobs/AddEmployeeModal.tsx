import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Search,
  Building2,
  Calendar,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Briefcase,
  Layers,
  Sparkles,
  Zap,
  Check,
  ShieldCheck,
  Wallet,
} from 'lucide-react';
import { EmploymentType, SalaryFrequency, Employee } from '../../types/jobManager';

interface AddEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEmployeeCreated: (newEmp: Employee) => void;
  organizationName: string;
  departmentList: string[];
  defaultCurrency: 'LOT' | 'USD' | 'GBP' | 'EUR';
  authToken?: string;
}

const EMPLOYMENT_TYPES: EmploymentType[] = [
  'Private Company Employee',
  'Business or Shop Employee',
  'Government Job Employee',
  'Self-Employed',
  'Contract Worker',
  'Temporary Employee',
  'Custom Employment Type',
];

const SALARY_FREQUENCIES: SalaryFrequency[] = ['Monthly', 'Weekly', 'Daily', 'Hourly'];

export const AddEmployeeModal: React.FC<AddEmployeeModalProps> = ({
  isOpen,
  onClose,
  onEmployeeCreated,
  organizationName,
  departmentList,
  defaultCurrency,
  authToken,
}) => {
  if (!isOpen) return null;

  // Search & Link LOT User state
  const [usernameInput, setUsernameInput] = useState('');
  const [searching, setSearching] = useState(false);
  const [allSystemUsers, setAllSystemUsers] = useState<any[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<any | null>(null);

  // Form Fields
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [employeeIdNumber, setEmployeeIdNumber] = useState(
    () => `EMP-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`
  );
  const [department, setDepartment] = useState(departmentList[0] || 'General Staff');
  const [jobTitle, setJobTitle] = useState('Staff Specialist');
  const [employmentType, setEmploymentType] = useState<EmploymentType>('Private Company Employee');
  const [customEmploymentType, setCustomEmploymentType] = useState('');
  const [joiningDate, setJoiningDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [salaryFrequency, setSalaryFrequency] = useState<SalaryFrequency>('Monthly');
  const [baseSalary, setBaseSalary] = useState<number | string>(5000);
  const [currency, setCurrency] = useState<'LOT' | 'USD' | 'GBP' | 'EUR'>(defaultCurrency || 'LOT');
  const [hourlyRate, setHourlyRate] = useState<number | string>(25);
  const [dailyRate, setDailyRate] = useState<number | string>(200);
  const [totalLeaveAllowance, setTotalLeaveAllowance] = useState<number | string>(18);
  const [autoPayEnabled, setAutoPayEnabled] = useState(true);
  const [notes, setNotes] = useState('');

  // Submit & Error state
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const effectiveToken =
    authToken ||
    (typeof window !== 'undefined'
      ? localStorage.getItem('lot_session_token') || localStorage.getItem('lot_auth_token')
      : '') ||
    '';

  // Load all system users on open for instant 1-click integration
  useEffect(() => {
    let isMounted = true;
    async function loadUsers() {
      try {
        const headers: Record<string, string> = {};
        if (effectiveToken) headers['Authorization'] = `Bearer ${effectiveToken}`;
        const res = await fetch('/api/jobs/users/search', { headers });
        if (res.ok) {
          const data = await res.json();
          if (isMounted) {
            setAllSystemUsers(data.users || []);
            setFilteredUsers(data.users || []);
          }
        }
      } catch (err) {
        console.warn('Failed to load users:', err);
      }
    }
    loadUsers();
    return () => {
      isMounted = false;
    };
  }, [effectiveToken]);

  // Live filter when typing in username input
  useEffect(() => {
    const clean = usernameInput.trim().toLowerCase().replace(/^@/, '');
    if (!clean) {
      setFilteredUsers(allSystemUsers);
      return;
    }
    const filtered = allSystemUsers.filter(
      (u) =>
        (u.username || '').toLowerCase().includes(clean) ||
        (u.fullName || '').toLowerCase().includes(clean)
    );
    setFilteredUsers(filtered);

    // If an exact match exists, resolve it automatically
    const exact = allSystemUsers.find(
      (u) => (u.username || '').toLowerCase() === clean
    );
    if (exact && !selectedUser) {
      setSelectedUser(exact);
      if (!fullName) setFullName(exact.fullName || exact.username);
    }
  }, [usernameInput, allSystemUsers]);

  const handleSelectUser = (u: any) => {
    setSelectedUser(u);
    setUsernameInput(u.username);
    if (!fullName || fullName === 'Employee') {
      setFullName(u.fullName || u.username);
    }
  };

  const handleClearSelectedUser = () => {
    setSelectedUser(null);
    setUsernameInput('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalFullName = fullName.trim() || (selectedUser ? selectedUser.username : usernameInput.trim());
    if (!finalFullName) {
      setError('Please enter the employee full name or LOT username.');
      return;
    }
    if (!employeeIdNumber.trim()) {
      setError('Please provide a unique Employee ID.');
      return;
    }

    setError(null);
    setSubmitting(true);

    try {
      const payload = {
        userId: selectedUser ? selectedUser.id : null,
        username: selectedUser ? selectedUser.username : usernameInput.trim().replace(/^@/, '') || null,
        avatarUrl: selectedUser ? selectedUser.avatarUrl : null,
        fullName: finalFullName,
        email: email.trim(),
        phone: phone.trim(),
        employeeIdNumber: employeeIdNumber.trim().toUpperCase(),
        department,
        jobTitle: jobTitle.trim(),
        employmentType,
        customEmploymentType: employmentType === 'Custom Employment Type' ? customEmploymentType.trim() : '',
        joiningDate,
        salaryFrequency,
        baseSalary: Number(baseSalary) >= 0 ? Number(baseSalary) : 0,
        currency,
        hourlyRate: salaryFrequency === 'Hourly' ? Number(hourlyRate) || 0 : 0,
        dailyRate: salaryFrequency === 'Daily' ? Number(dailyRate) || 0 : 0,
        totalLeaveAllowance: Number(totalLeaveAllowance) || 18,
        autoPayEnabled,
        notes: notes.trim(),
      };

      const res = await fetch('/api/jobs/employees', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${effectiveToken}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to create employee record');
      }

      onEmployeeCreated(data.employee);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Error creating employee');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 sm:p-8 text-[#F5F3FF] overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#302D46]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-purple-300" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Enroll & Integrate Employee</h3>
              <p className="text-xs text-[#A5A3B8]">{organizationName}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-[#121222] border border-[#302D46] hover:bg-[#202039] text-[#A5A3B8] hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs flex items-center gap-2 animate-fadeIn">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-5">
          {/* Section 1: Link LOT Ecosystem User Account */}
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                Step 1: Select or Search LOT Ecosystem Person
              </span>
              <span className="text-[10px] text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/30">
                Direct Integration
              </span>
            </div>

            {selectedUser ? (
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-purple-950/40 to-[#19192B] border border-purple-500/50 flex items-center justify-between shadow-md">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] border border-purple-400/50 flex items-center justify-center font-bold text-white overflow-hidden text-sm shadow">
                    {selectedUser.avatarUrl ? (
                      <img src={selectedUser.avatarUrl} alt={selectedUser.username} className="w-full h-full object-cover" />
                    ) : (
                      selectedUser.username.charAt(0).toUpperCase()
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-black text-white">@{selectedUser.username}</p>
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-950/70 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-400" />
                        Integrated Person
                      </span>
                    </div>
                    <p className="text-[11px] text-[#A5A3B8] flex items-center gap-1.5 mt-0.5">
                      <Wallet className="w-3 h-3 text-purple-400" />
                      Wallet: <strong className="text-white font-mono">{selectedUser.lotBalance?.toLocaleString() || 0} LOT</strong>
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleClearSelectedUser}
                  className="px-3 py-1.5 rounded-lg bg-[#202039] text-purple-300 text-xs font-bold border border-[#302D46] hover:bg-red-950/60 hover:text-red-300 transition-colors cursor-pointer"
                >
                  Change Person
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="relative">
                  <Search className="w-4 h-4 text-[#8F8CA8] absolute left-3.5 top-3" />
                  <input
                    type="text"
                    placeholder="Enter username (e.g. virat, alice, bob) or search name..."
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500"
                  />
                </div>

                {/* Quick-Pick Registered Users Chips */}
                {filteredUsers.length > 0 && (
                  <div className="pt-1">
                    <p className="text-[10px] text-[#8F8CA8] mb-1.5 font-medium">Quick Pick Registered Account:</p>
                    <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-1 bg-[#161628] rounded-xl border border-[#302D46]/60">
                      {filteredUsers.map((u) => (
                        <button
                          key={u.id}
                          type="button"
                          onClick={() => handleSelectUser(u)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#19192B] hover:bg-purple-900/40 border border-[#302D46] hover:border-purple-500/50 text-left text-xs flex items-center gap-2 transition-all cursor-pointer group"
                        >
                          <div className="w-5 h-5 rounded-md bg-purple-600/30 flex items-center justify-center text-[10px] font-bold text-white overflow-hidden shrink-0">
                            {u.avatarUrl ? (
                              <img src={u.avatarUrl} alt={u.username} className="w-full h-full object-cover" />
                            ) : (
                              u.username.charAt(0).toUpperCase()
                            )}
                          </div>
                          <span className="text-white group-hover:text-purple-300 font-semibold text-[11px]">@{u.username}</span>
                          <span className="text-[10px] text-[#8F8CA8]">({u.lotBalance?.toLocaleString() || 0} LOT)</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Section 2: Personal & Identity Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Full Legal Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Alex Morgan"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Employee ID Number *</label>
              <input
                type="text"
                required
                placeholder="EMP-2026-001"
                value={employeeIdNumber}
                onChange={(e) => setEmployeeIdNumber(e.target.value)}
                className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs font-mono outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Work Email</label>
              <input
                type="email"
                placeholder="alex@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Phone Number</label>
              <input
                type="tel"
                placeholder="+1 555-0199"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Section 3: Job Role & Employment Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Job Title / Designation *</label>
              <input
                type="text"
                required
                placeholder="e.g. Lead Developer / Store Manager"
                value={jobTitle}
                onChange={(e) => setJobTitle(e.target.value)}
                className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Department *</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500 cursor-pointer"
              >
                {departmentList.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-[#A5A3B8] mb-1">Employment Type *</label>
              <select
                value={employmentType}
                onChange={(e) => setEmploymentType(e.target.value as EmploymentType)}
                className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500 cursor-pointer"
              >
                {EMPLOYMENT_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>

              {employmentType === 'Custom Employment Type' && (
                <input
                  type="text"
                  placeholder="Specify custom employment classification..."
                  value={customEmploymentType}
                  onChange={(e) => setCustomEmploymentType(e.target.value)}
                  className="w-full mt-2 px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500"
                />
              )}

              {employmentType === 'Government Job Employee' && (
                <p className="text-[10px] text-amber-400/90 mt-1.5 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 shrink-0" />
                  <span>Notice: This manages internal employment records and does not verify official government status.</span>
                </p>
              )}
            </div>
          </div>

          {/* Section 4: Salary & Automated Payroll Configuration */}
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] space-y-3.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                Salary & Payroll Schedule
              </span>
              <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                Automated Payout Engine
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-[#A5A3B8] mb-1 font-semibold">Payment Frequency *</label>
                <select
                  value={salaryFrequency}
                  onChange={(e) => setSalaryFrequency(e.target.value as SalaryFrequency)}
                  className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500 cursor-pointer"
                >
                  {SALARY_FREQUENCIES.map((f) => (
                    <option key={f} value={f}>
                      {f}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-[#A5A3B8] mb-1 font-semibold">Base Salary Amount *</label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={baseSalary}
                  onChange={(e) => setBaseSalary(e.target.value)}
                  className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs font-mono outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#A5A3B8] mb-1 font-semibold">Currency Mode</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as any)}
                  className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500 cursor-pointer"
                >
                  <option value="LOT">LOT Currency (Ecosystem)</option>
                  <option value="USD">USD ($)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="EUR">EUR (€)</option>
                </select>
              </div>
            </div>

            {salaryFrequency === 'Hourly' && (
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-[10px] text-[#A5A3B8]">Hourly Rate ({currency})</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={hourlyRate}
                    onChange={(e) => setHourlyRate(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs font-mono outline-none"
                  />
                </div>
                <div>
                  <p className="text-[10px] text-[#7E7B9A] mt-4">Automated recurring payouts will disburse this hourly amount every hour.</p>
                </div>
              </div>
            )}

            {salaryFrequency === 'Daily' && (
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-[10px] text-[#A5A3B8]">Daily Rate ({currency})</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={dailyRate}
                    onChange={(e) => setDailyRate(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs font-mono outline-none"
                  />
                </div>
                <div>
                  <p className="text-[10px] text-[#7E7B9A] mt-4">Automated recurring payouts will disburse daily rate every 24 hours.</p>
                </div>
              </div>
            )}

            {/* Auto-Payroll Option Toggle */}
            <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/30 flex items-start gap-3">
              <input
                type="checkbox"
                id="autoPayCheckbox"
                checked={autoPayEnabled}
                onChange={(e) => setAutoPayEnabled(e.target.checked)}
                className="mt-0.5 w-4 h-4 rounded text-purple-600 focus:ring-purple-500 border-gray-600 cursor-pointer"
              />
              <label htmlFor="autoPayCheckbox" className="text-xs text-white cursor-pointer select-none">
                <span className="font-bold text-purple-200 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  Enable Automated Recurring Salary Payouts
                </span>
                <span className="block text-[11px] text-[#A5A3B8] mt-0.5">
                  When enabled, the LOT Recurring Payroll Engine will automatically transfer{' '}
                  <strong className="text-white font-mono">
                    {Number(salaryFrequency === 'Hourly' ? hourlyRate : salaryFrequency === 'Daily' ? dailyRate : baseSalary).toLocaleString()} {currency}
                  </strong>{' '}
                  directly into the employee's wallet based on their selected <strong>{salaryFrequency}</strong> frequency.
                </span>
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-[11px] text-[#A5A3B8] mb-1">Joining Date</label>
                <input
                  type="date"
                  value={joiningDate}
                  onChange={(e) => setJoiningDate(e.target.value)}
                  className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-[#A5A3B8] mb-1">Annual Leave Days Quota</label>
                <input
                  type="number"
                  min="0"
                  value={totalLeaveAllowance}
                  onChange={(e) => setTotalLeaveAllowance(e.target.value)}
                  className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs font-mono outline-none focus:border-purple-500"
                />
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#302D46]">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-5 py-2.5 rounded-xl bg-[#121222] border border-[#302D46] text-[#A5A3B8] hover:text-white text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white text-xs font-bold shadow-lg shadow-purple-500/25 hover:opacity-95 transition-all cursor-pointer flex items-center gap-2 disabled:opacity-50"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Enrolling & Integrating...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Enroll Employee</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
