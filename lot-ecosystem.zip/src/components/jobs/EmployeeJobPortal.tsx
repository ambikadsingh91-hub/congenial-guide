import React from 'react';
import {
  Briefcase,
  Building2,
  DollarSign,
  CalendarCheck,
  Calendar,
  FileText,
  Clock,
  CheckCircle2,
  AlertCircle,
  Download,
  Send,
  Loader2,
  Printer,
  ChevronRight,
  ShieldCheck,
  User,
  Layers,
  Sparkles,
  Zap,
} from 'lucide-react';
import {
  Employee,
  SalaryPayment,
  AttendanceRecord,
  LeaveRequest,
  LeaveType,
} from '../../types/jobManager';
import { formatCompactNumber } from '../../lib/formatNumber';

interface EmployeeJobPortalProps {
  currentEmployment?: Employee;
  employments: Employee[];
  selectedEmploymentIndex: number;
  onSelectEmployment: (index: number) => void;
  payments: SalaryPayment[];
  attendanceRecords: AttendanceRecord[];
  leaveRequests: LeaveRequest[];
  activePortalTab: 'payslips' | 'attendance' | 'leaves' | 'documents';
  onSelectPortalTab: (tab: 'payslips' | 'attendance' | 'leaves' | 'documents') => void;
  onViewSalarySlip: (payment: SalaryPayment) => void;
  leaveType: LeaveType;
  onLeaveTypeChange: (type: LeaveType) => void;
  leaveStartDate: string;
  onLeaveStartDateChange: (date: string) => void;
  leaveEndDate: string;
  onLeaveEndDateChange: (date: string) => void;
  leaveReason: string;
  onLeaveReasonChange: (reason: string) => void;
  submittingLeave: boolean;
  onSubmitLeave: (e: React.FormEvent) => void;
  onRefresh: () => void;
  refreshing: boolean;
}

export const EmployeeJobPortal: React.FC<EmployeeJobPortalProps> = ({
  currentEmployment,
  employments,
  selectedEmploymentIndex,
  onSelectEmployment,
  payments,
  attendanceRecords,
  leaveRequests,
  activePortalTab,
  onSelectPortalTab,
  onViewSalarySlip,
  leaveType,
  onLeaveTypeChange,
  leaveStartDate,
  onLeaveStartDateChange,
  leaveEndDate,
  onLeaveEndDateChange,
  leaveReason,
  onLeaveReasonChange,
  submittingLeave,
  onSubmitLeave,
  onRefresh,
  refreshing,
}) => {
  if (!currentEmployment) {
    return (
      <div className="p-8 rounded-3xl bg-[#121222] border border-[#302D46] text-center space-y-3">
        <Briefcase className="w-12 h-12 text-[#8B5CF6] mx-auto animate-pulse" />
        <h3 className="text-base font-bold text-white">No Integrated Employment Records Found</h3>
        <p className="text-xs text-[#A5A3B8] max-w-md mx-auto">
          You are currently logged in, but your LOT Ecosystem account has not been linked to an active employee record yet. Ask your employer or organization manager to add you using your username.
        </p>
      </div>
    );
  }

  // Calculate Employee Metrics
  const totalPaid = payments
    .filter((p) => p.paymentStatus === 'paid')
    .reduce((sum, p) => sum + (p.paidAmount || p.netPayableAmount || 0), 0);

  const pendingCount = payments.filter(
    (p) => p.paymentStatus === 'pending' || p.paymentStatus === 'overdue'
  ).length;

  const totalPresentDays = attendanceRecords.filter((r) => r.status === 'present').length;
  const totalHoursWorked = attendanceRecords.reduce((sum, r) => sum + (r.hoursWorked || 0), 0);
  const totalOvertimeHours = attendanceRecords.reduce((sum, r) => sum + (r.overtimeHours || 0), 0);

  const approvedLeaveDays = leaveRequests
    .filter((r) => r.status === 'approved')
    .reduce((sum, r) => sum + (r.daysCount || 1), 0);
  const remainingLeaveDays = Math.max(0, (currentEmployment.totalLeaveAllowance ?? 20) - approvedLeaveDays);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Multiple Employments Selector (if user has more than 1 job) */}
      {employments.length > 1 && (
        <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-[#A5A3B8]">
            <Layers className="w-4 h-4 text-[#8B5CF6]" />
            <span>Select Active Job Record:</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {employments.map((emp, idx) => (
              <button
                key={emp.id}
                onClick={() => onSelectEmployment(idx)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  selectedEmploymentIndex === idx
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-[#19192B] text-[#A5A3B8] hover:text-white border border-[#302D46]'
                }`}
              >
                {emp.jobTitle} - {emp.organizationName}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Official Employment Profile Card */}
      <div className="relative rounded-3xl bg-gradient-to-r from-[#19192B] via-[#151528] to-[#19192B] border border-emerald-500/30 p-6 sm:p-7 shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-600 to-emerald-600 p-0.5 shadow-xl shrink-0">
              {currentEmployment.avatarUrl ? (
                <img
                  src={currentEmployment.avatarUrl}
                  alt={currentEmployment.fullName}
                  className="w-full h-full object-cover rounded-2xl"
                />
              ) : (
                <div className="w-full h-full rounded-2xl bg-[#121222] flex items-center justify-center text-white font-black text-xl">
                  {currentEmployment.fullName.slice(0, 2).toUpperCase()}
                </div>
              )}
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/40 uppercase tracking-wider flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  Active Employee Profile
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-[#202039] text-[#C4B5FD] border border-[#302D46]">
                  ID: {currentEmployment.employeeIdNumber}
                </span>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold capitalize ${
                  currentEmployment.status === 'active'
                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                    : 'bg-amber-950/80 text-amber-300 border border-amber-500/30'
                }`}>
                  ● {currentEmployment.status.replace('_', ' ')}
                </span>
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {currentEmployment.fullName}
              </h2>

              <p className="text-xs text-[#A5A3B8] flex flex-wrap items-center gap-2">
                <span className="font-semibold text-white">{currentEmployment.jobTitle}</span>
                <span>•</span>
                <span className="text-[#C4B5FD]">{currentEmployment.department}</span>
                <span>•</span>
                <span className="text-purple-300 font-medium flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5" />
                  {currentEmployment.organizationName}
                </span>
              </p>
            </div>
          </div>

          {/* Salary Rate Badge */}
          <div className="p-4 rounded-2xl bg-[#121222]/90 border border-[#302D46] space-y-1.5 min-w-[220px]">
            <span className="text-[11px] text-[#A5A3B8] uppercase tracking-wider font-semibold block">
              Configured Compensation
            </span>
            <div className="text-2xl font-black text-emerald-400">
              {currentEmployment.currency === 'LOT' ? '£' : '$'}
              {currentEmployment.baseSalary.toLocaleString()}{' '}
              <span className="text-xs font-bold text-white">/ {currentEmployment.salaryFrequency}</span>
            </div>

            {currentEmployment.autoPayEnabled !== false && (
              <div className="text-[10px] text-amber-300 font-semibold flex items-center gap-1 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-500/30">
                <Zap className="w-3 h-3 text-amber-400 shrink-0" />
                <span>Auto-Deposited to LOT Wallet</span>
              </div>
            )}

            {currentEmployment.nextExpectedSalaryDate && (
              <div className="text-[10px] text-[#A5A3B8]">
                Next Due:{' '}
                <span className="text-white font-medium">
                  {new Date(currentEmployment.nextExpectedSalaryDate).toLocaleDateString([], {
                    month: 'short',
                    day: 'numeric',
                  })}{' '}
                  {new Date(currentEmployment.nextExpectedSalaryDate).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
            )}

            <div className="text-[10px] text-[#8F8CA8]">
              Joined: <span className="text-white font-medium">{currentEmployment.joiningDate}</span>
            </div>
          </div>
        </div>

        {/* Government Record Note if Applicable */}
        {currentEmployment.employmentType === 'Government Job Employee' && (
          <div className="mt-4 pt-4 border-t border-[#302D46]/80 flex items-start gap-2.5 text-[11px] text-[#A5A3B8]">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p>
              <strong className="text-amber-300">Government Job Record Note:</strong> This employment record is tracked under enterprise governance and job manager records. It represents internal personnel administration and does not confer official state civil credentials.
            </p>
          </div>
        )}
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
            <DollarSign className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <span className="text-[11px] text-[#A5A3B8] font-medium block">Total Paid Out</span>
            <span className="text-lg font-black text-emerald-300">
              {currentEmployment.currency === 'LOT' ? '£' : '$'}
              {formatCompactNumber(totalPaid)}
            </span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center shrink-0">
            <CalendarCheck className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <span className="text-[11px] text-[#A5A3B8] font-medium block">Attendance Logged</span>
            <span className="text-lg font-black text-white">
              {totalPresentDays} <span className="text-xs text-[#A5A3B8]">Days ({totalHoursWorked}h)</span>
            </span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center shrink-0">
            <Calendar className="w-5 h-5 text-[#C4B5FD]" />
          </div>
          <div>
            <span className="text-[11px] text-[#A5A3B8] font-medium block">Leave Balance</span>
            <span className="text-lg font-black text-purple-300">
              {remainingLeaveDays} <span className="text-xs text-[#A5A3B8]">Days Left</span>
            </span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <span className="text-[11px] text-[#A5A3B8] font-medium block">Pending Payments</span>
            <span className="text-lg font-black text-amber-300">{pendingCount}</span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-[#121222] rounded-2xl border border-[#302D46] overflow-x-auto scrollbar-none">
        <button
          onClick={() => onSelectPortalTab('payslips')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activePortalTab === 'payslips'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>My Payslips & Salary History ({payments.length})</span>
        </button>

        <button
          onClick={() => onSelectPortalTab('attendance')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activePortalTab === 'attendance'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <CalendarCheck className="w-4 h-4" />
          <span>My Attendance Log ({attendanceRecords.length})</span>
        </button>

        <button
          onClick={() => onSelectPortalTab('leaves')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activePortalTab === 'leaves'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>My Leave Requests ({leaveRequests.length})</span>
        </button>

        <button
          onClick={() => onSelectPortalTab('documents')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 cursor-pointer ${
            activePortalTab === 'documents'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span>Contracts & Documents ({currentEmployment.documents?.length || 0})</span>
        </button>
      </div>

      {/* SUBTAB 1: PAYSLIPS & SALARY HISTORY */}
      {activePortalTab === 'payslips' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center justify-between">
            <div>
              <h3 className="font-bold text-white text-sm">Official Salary Disbursement Records</h3>
              <p className="text-xs text-[#A5A3B8]">
                Every salary payment recorded by your employer is certified with a transaction audit reference.
              </p>
            </div>
            <button
              onClick={onRefresh}
              disabled={refreshing}
              className="p-2 rounded-xl bg-[#19192B] border border-[#302D46] text-[#A5A3B8] hover:text-white transition cursor-pointer"
            >
              <Loader2 className={`w-4 h-4 ${refreshing ? 'animate-spin text-[#8B5CF6]' : ''}`} />
            </button>
          </div>

          {payments.length === 0 ? (
            <div className="p-12 rounded-3xl bg-[#121222] border border-[#302D46] text-center space-y-2">
              <FileText className="w-10 h-10 text-[#6C6A84] mx-auto" />
              <h4 className="text-sm font-bold text-white">No Salary Records Yet</h4>
              <p className="text-xs text-[#A5A3B8] max-w-sm mx-auto">
                Your employer has not recorded any salary disbursements yet. Once processed, you will see your printable payslips here!
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {payments.map((pay) => (
                <div
                  key={pay.id}
                  className="p-4 sm:p-5 rounded-2xl bg-[#121222] border border-[#302D46] hover:border-emerald-500/40 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-bold text-white">{pay.salaryPeriod}</span>
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          pay.paymentStatus === 'paid'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                            : pay.paymentStatus === 'overdue'
                            ? 'bg-red-950 text-red-400 border border-red-500/30'
                            : 'bg-amber-950 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        ● {pay.paymentStatus}
                      </span>
                      <span className="text-[11px] text-[#A5A3B8]">
                        Ref: <code className="text-purple-300">{pay.transactionReference}</code>
                      </span>
                    </div>

                    <div className="text-xs text-[#A5A3B8] flex flex-wrap items-center gap-3">
                      <span>Method: <strong className="text-white">{pay.paymentMethod}</strong></span>
                      <span>•</span>
                      <span>Paid Date: <strong className="text-white">{pay.paymentDate || 'Pending'}</strong></span>
                      <span>•</span>
                      <span>Authorized By: <strong className="text-purple-300">@{pay.recordedByUsername}</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between md:justify-end gap-4 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-[#202035]">
                    <div className="text-right">
                      <div className="text-lg font-black text-emerald-400">
                        {pay.currency === 'LOT' ? '£' : '$'}
                        {pay.netPayableAmount.toLocaleString()}
                      </div>
                      <span className="text-[10px] text-[#A5A3B8]">Net Payable Amount</span>
                    </div>

                    <button
                      onClick={() => onViewSalarySlip(pay)}
                      className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-md shadow-emerald-600/20"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>View Payslip</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 2: ATTENDANCE LOG */}
      {activePortalTab === 'attendance' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46]">
            <h3 className="font-bold text-white text-sm">Attendance & Working Hours Log</h3>
            <p className="text-xs text-[#A5A3B8]">
              Your daily attendance entries logged by your employer or operations team.
            </p>
          </div>

          {attendanceRecords.length === 0 ? (
            <div className="p-12 rounded-3xl bg-[#121222] border border-[#302D46] text-center space-y-2">
              <CalendarCheck className="w-10 h-10 text-[#6C6A84] mx-auto" />
              <h4 className="text-sm font-bold text-white">No Attendance Records</h4>
              <p className="text-xs text-[#A5A3B8]">
                Attendance has not been logged for your profile yet.
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-[#121222] border border-[#302D46] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#19192B] text-[#A5A3B8] font-bold uppercase tracking-wider text-[10px] border-b border-[#302D46]">
                    <tr>
                      <th className="p-3.5">Date</th>
                      <th className="p-3.5">Status</th>
                      <th className="p-3.5">Check In / Out</th>
                      <th className="p-3.5">Hours</th>
                      <th className="p-3.5">Overtime</th>
                      <th className="p-3.5">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#202035] text-white">
                    {attendanceRecords.map((rec) => (
                      <tr key={rec.id} className="hover:bg-[#16162A] transition">
                        <td className="p-3.5 font-semibold text-white">{rec.date}</td>
                        <td className="p-3.5">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold capitalize ${
                              rec.status === 'present'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                                : rec.status === 'absent'
                                ? 'bg-red-950 text-red-400 border border-red-500/30'
                                : 'bg-amber-950 text-amber-400 border border-amber-500/30'
                            }`}
                          >
                            ● {rec.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-[#A5A3B8]">
                          {rec.checkInTime} - {rec.checkOutTime}
                        </td>
                        <td className="p-3.5 font-bold text-emerald-400">{rec.hoursWorked}h</td>
                        <td className="p-3.5 text-[#A5A3B8]">
                          {rec.overtimeHours ? `+${rec.overtimeHours}h` : '—'}
                        </td>
                        <td className="p-3.5 text-[#A5A3B8] max-w-[200px] truncate">
                          {rec.notes || '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 3: LEAVES & REQUEST FORM */}
      {activePortalTab === 'leaves' && (
        <div className="space-y-6">
          {/* Submit Leave Application */}
          <div className="p-5 sm:p-6 rounded-3xl bg-[#121222] border border-[#302D46] space-y-4">
            <div className="flex items-center justify-between border-b border-[#252540] pb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-white text-sm sm:text-base">Apply for Leave</h3>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-950 text-purple-300 border border-purple-500/30">
                {remainingLeaveDays} Days Available
              </span>
            </div>

            <form onSubmit={onSubmitLeave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-[#A5A3B8] uppercase tracking-wider block mb-1">
                    Leave Type
                  </label>
                  <select
                    value={leaveType}
                    onChange={(e: any) => onLeaveTypeChange(e.target.value)}
                    className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Casual Leave">Casual Leave</option>
                    <option value="Sick Leave">Sick Leave</option>
                    <option value="Annual Leave">Annual Leave</option>
                    <option value="Maternity/Paternity Leave">Maternity/Paternity Leave</option>
                    <option value="Emergency Leave">Emergency Leave</option>
                    <option value="Unpaid Leave">Unpaid Leave</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-[#A5A3B8] uppercase tracking-wider block mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={leaveStartDate}
                    onChange={(e) => onLeaveStartDateChange(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-[#A5A3B8] uppercase tracking-wider block mb-1">
                    End Date
                  </label>
                  <input
                    type="date"
                    value={leaveEndDate}
                    onChange={(e) => onLeaveEndDateChange(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#A5A3B8] uppercase tracking-wider block mb-1">
                  Reason for Leave Request <span className="text-red-400">*</span>
                </label>
                <textarea
                  rows={2}
                  value={leaveReason}
                  onChange={(e) => onLeaveReasonChange(e.target.value)}
                  placeholder="State reason for absence..."
                  required
                  className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  disabled={submittingLeave || !leaveStartDate || !leaveEndDate}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-2 transition cursor-pointer shadow-lg shadow-emerald-600/25"
                >
                  {submittingLeave ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  <span>Submit Leave Request</span>
                </button>
              </div>
            </form>
          </div>

          {/* List of Submitted Leave Requests */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-[#A5A3B8] uppercase tracking-wider">
              Leave Requests History ({leaveRequests.length})
            </h4>

            {leaveRequests.length === 0 ? (
              <div className="p-8 rounded-2xl bg-[#121222] border border-[#302D46] text-center text-xs text-[#A5A3B8]">
                No leave requests submitted yet.
              </div>
            ) : (
              <div className="space-y-2.5">
                {leaveRequests.map((req) => (
                  <div
                    key={req.id}
                    className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-bold text-white text-xs sm:text-sm">{req.leaveType}</span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            req.status === 'approved'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                              : req.status === 'rejected'
                              ? 'bg-red-950 text-red-400 border border-red-500/30'
                              : 'bg-amber-950 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          ● {req.status}
                        </span>
                        <span className="text-[11px] text-[#A5A3B8]">({req.daysCount} days)</span>
                      </div>
                      <p className="text-xs text-[#C4B5FD]">
                        {req.startDate} to {req.endDate}
                      </p>
                      <p className="text-xs text-[#A5A3B8]">Reason: "{req.reason}"</p>
                      {req.reviewNotes && (
                        <p className="text-[11px] text-amber-300 bg-amber-950/40 p-1.5 rounded-lg border border-amber-500/20">
                          Manager Feedback: {req.reviewNotes} (Reviewed by {req.reviewedBy})
                        </p>
                      )}
                    </div>

                    <div className="text-right text-[11px] text-[#A5A3B8]">
                      Submitted: {new Date(req.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 4: CONTRACTS & DOCUMENTS */}
      {activePortalTab === 'documents' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46]">
            <h3 className="font-bold text-white text-sm">Official Employment Contracts & Documents</h3>
            <p className="text-xs text-[#A5A3B8]">
              Authorized files and appointment letters uploaded for your employment profile.
            </p>
          </div>

          {!currentEmployment.documents || currentEmployment.documents.length === 0 ? (
            <div className="p-12 rounded-3xl bg-[#121222] border border-[#302D46] text-center space-y-2">
              <Briefcase className="w-10 h-10 text-[#6C6A84] mx-auto" />
              <h4 className="text-sm font-bold text-white">No Documents Attached Yet</h4>
              <p className="text-xs text-[#A5A3B8]">
                Your organization manager can upload employment contracts and letters directly to your profile.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {currentEmployment.documents.map((docItem) => (
                <div
                  key={docItem.id}
                  className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center justify-between gap-3"
                >
                  <div className="space-y-1 truncate">
                    <h5 className="text-xs font-bold text-white truncate">{docItem.title}</h5>
                    <p className="text-[11px] text-[#A5A3B8] capitalize">
                      {docItem.type.replace('_', ' ')} • {docItem.fileSize ? `${(docItem.fileSize / 1024).toFixed(1)} KB` : 'Attached File'}
                    </p>
                    <p className="text-[10px] text-purple-300">Uploaded by {docItem.uploadedBy}</p>
                  </div>

                  <a
                    href={docItem.fileUrl}
                    download={docItem.fileName || 'document.pdf'}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-xl bg-[#19192B] hover:bg-[#22223B] border border-[#302D46] text-white hover:text-emerald-400 transition cursor-pointer shrink-0"
                    title="Download Document"
                  >
                    <Download className="w-4 h-4" />
                  </a>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
