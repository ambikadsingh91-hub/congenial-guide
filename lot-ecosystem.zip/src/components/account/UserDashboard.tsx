import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Transaction, TransactionType } from '../../types';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../../lib/firebase';
import {
  User as UserIcon,
  Coins,
  Clock,
  Send,
  ShoppingBag,
  TrendingUp,
  Gift,
  Gamepad2,
  Shield,
  ArrowUpRight,
  ArrowDownLeft,
  Calendar,
  Filter,
  RefreshCw,
  PackageCheck,
  CheckCircle2,
  Sparkles,
  Camera,
  Upload,
  Link,
  Trash2,
  Image as ImageIcon,
  Check,
  X,
  AlertCircle,
} from 'lucide-react';
import { formatCompactNumber } from '../../lib/formatNumber';

const PRESET_AVATARS = [
  { name: 'Cyber Ronin', url: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400&auto=format&fit=crop&q=80' },
  { name: 'Neon Hacker', url: 'https://images.unsplash.com/photo-1563089145-599997674d42?w=400&auto=format&fit=crop&q=80' },
  { name: 'Quantum Core', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=80' },
  { name: 'Gold Sovereign', url: 'https://images.unsplash.com/photo-1618042164219-62c820f10723?w=400&auto=format&fit=crop&q=80' },
  { name: 'Cyber Samurai', url: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=400&auto=format&fit=crop&q=80' },
  { name: 'Void Sorceress', url: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&auto=format&fit=crop&q=80' },
  { name: 'Apex Pilot', url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80' },
  { name: 'Solar Phoenix', url: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=400&auto=format&fit=crop&q=80' },
];

interface RecentTransactionItem {
  id: string;
  category: 'vpay' | 'shop';
  type: 'vpay_send' | 'vpay_receive' | 'shop_purchase';
  title: string;
  counterparty?: string;
  note?: string;
  amount: number;
  balanceAfter?: number;
  status?: string;
  referenceId?: string;
  createdAt: string;
}

export const UserDashboard: React.FC = () => {
  const { user, updateAvatar } = useAuth();
  
  // Profile picture customization state
  const [showAvatarModal, setShowAvatarModal] = useState(false);
  const [avatarTab, setAvatarTab] = useState<'upload' | 'url' | 'presets'>('upload');
  const [avatarInputUrl, setAvatarInputUrl] = useState('');
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [avatarSaving, setAvatarSaving] = useState(false);
  const [avatarError, setAvatarError] = useState<string | null>(null);
  const [avatarSuccessMsg, setAvatarSuccessMsg] = useState<string | null>(null);

  // Full ledger state
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [typeFilter, setTypeFilter] = useState<string>('ALL');

  // Dedicated "Recent Transactions" from Firestore state
  const [recentItems, setRecentItems] = useState<RecentTransactionItem[]>([]);
  const [recentLoading, setRecentLoading] = useState(false);
  const [recentFilter, setRecentFilter] = useState<'ALL' | 'vpay' | 'shop'>('ALL');
  const [lastSynced, setLastSynced] = useState<Date | null>(null);

  // Handle file upload & canvas compression for avatar
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setAvatarError('Please select a valid image file (PNG, JPG, WEBP, etc.)');
      return;
    }

    setAvatarError(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxSize = 384;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxSize) {
            height = Math.round((height * maxSize) / width);
            width = maxSize;
          }
        } else {
          if (height > maxSize) {
            width = Math.round((width * maxSize) / height);
            height = maxSize;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.88);
          setAvatarPreview(dataUrl);
          setAvatarInputUrl('');
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleSaveAvatar = async () => {
    setAvatarSaving(true);
    setAvatarError(null);
    setAvatarSuccessMsg(null);

    const finalUrl = avatarPreview || avatarInputUrl.trim();
    const res = await updateAvatar(finalUrl);

    if (res.success) {
      setAvatarSuccessMsg('Profile picture updated successfully!');
      setTimeout(() => {
        setShowAvatarModal(false);
        setAvatarSuccessMsg(null);
      }, 1000);
    } else {
      setAvatarError(res.error || 'Failed to update profile picture');
    }
    setAvatarSaving(false);
  };

  const handleRemoveAvatar = async () => {
    setAvatarSaving(true);
    setAvatarError(null);
    const res = await updateAvatar('');
    if (res.success) {
      setAvatarPreview(null);
      setAvatarInputUrl('');
      setAvatarSuccessMsg('Profile picture removed.');
      setTimeout(() => {
        setShowAvatarModal(false);
        setAvatarSuccessMsg(null);
      }, 1000);
    } else {
      setAvatarError(res.error || 'Failed to remove picture');
    }
    setAvatarSaving(false);
  };

  // Fetch full ledger from server
  const fetchLedger = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const res = await fetch('/api/transactions');
      if (res.ok) {
        const data = await res.json();
        setTransactions(data.transactions || []);
      }
    } catch {
      // non-critical
    } finally {
      setLoading(false);
    }
  };

  // Pull Recent VPay Transfers and LOT Shop Purchases directly from Firestore
  const fetchRecentFromFirestore = async () => {
    if (!user) return;
    try {
      setRecentLoading(true);
      const items: RecentTransactionItem[] = [];

      // 1. Query Firestore 'transactions' collection for this user
      try {
        const txCollectionRef = collection(db, 'transactions');
        const q = query(txCollectionRef, where('userId', '==', user.id));
        const txSnap = await getDocs(q);

        txSnap.forEach((docSnap) => {
          const d = docSnap.data();
          if (d.type === 'vpay_send' || d.type === 'vpay_receive' || d.type === 'shop_purchase') {
            const isSend = d.type === 'vpay_send';
            const isRecv = d.type === 'vpay_receive';
            const isShop = d.type === 'shop_purchase';

            items.push({
              id: docSnap.id,
              category: isShop ? 'shop' : 'vpay',
              type: d.type,
              title: isShop
                ? 'LOT Shop Purchase'
                : isSend
                ? 'VPay Transfer Sent'
                : 'VPay Transfer Received',
              note: d.description || '',
              amount: d.amount,
              balanceAfter: d.balanceAfter,
              referenceId: d.referenceId,
              createdAt: d.createdAt,
            });
          }
        });
      } catch (firestoreErr) {
        console.warn('Firestore transactions query notice:', firestoreErr);
      }

      // 2. Also query dedicated 'vpay_transfers' and 'orders' collections in Firestore to enrich data
      try {
        const [sentSnap, recvSnap, ordersSnap] = await Promise.all([
          getDocs(query(collection(db, 'vpay_transfers'), where('senderId', '==', user.id))),
          getDocs(query(collection(db, 'vpay_transfers'), where('recipientId', '==', user.id))),
          getDocs(query(collection(db, 'orders'), where('buyerId', '==', user.id))),
        ]);

        // Merge VPay Sent transfers from Firestore if not already captured
        sentSnap.forEach((docSnap) => {
          const d = docSnap.data();
          const existing = items.find((it) => it.referenceId === docSnap.id || it.id === docSnap.id);
          if (!existing) {
            items.push({
              id: docSnap.id,
              category: 'vpay',
              type: 'vpay_send',
              title: `VPay to @${d.recipientUsername}`,
              counterparty: `@${d.recipientUsername}`,
              note: d.note || 'P2P Transfer',
              amount: -Math.abs(d.amount),
              status: d.reversed ? 'Reversed' : 'Completed',
              referenceId: docSnap.id,
              createdAt: d.createdAt,
            });
          } else if (d.recipientUsername) {
            existing.counterparty = `@${d.recipientUsername}`;
            if (d.note) existing.note = d.note;
          }
        });

        // Merge VPay Received transfers from Firestore
        recvSnap.forEach((docSnap) => {
          const d = docSnap.data();
          const existing = items.find((it) => it.referenceId === docSnap.id || it.id === docSnap.id);
          if (!existing) {
            items.push({
              id: docSnap.id,
              category: 'vpay',
              type: 'vpay_receive',
              title: `VPay from @${d.senderUsername}`,
              counterparty: `@${d.senderUsername}`,
              note: d.note || 'P2P Transfer',
              amount: Math.abs(d.amount),
              status: d.reversed ? 'Reversed' : 'Completed',
              referenceId: docSnap.id,
              createdAt: d.createdAt,
            });
          } else if (d.senderUsername) {
            existing.counterparty = `@${d.senderUsername}`;
            if (d.note) existing.note = d.note;
          }
        });

        // Merge LOT Shop purchases from Firestore
        ordersSnap.forEach((docSnap) => {
          const d = docSnap.data();
          const existing = items.find((it) => it.referenceId === docSnap.id || it.id === docSnap.id);
          if (!existing) {
            items.push({
              id: docSnap.id,
              category: 'shop',
              type: 'shop_purchase',
              title: d.listingTitle || 'Shop Order',
              counterparty: d.sellerUsername ? `Seller: @${d.sellerUsername}` : undefined,
              note: `${d.quantity || 1} unit(s) • Status: ${d.status || 'Placed'}`,
              amount: -Math.abs(d.totalLot || d.priceLot || 0),
              status: d.status,
              referenceId: docSnap.id,
              createdAt: d.createdAt,
            });
          } else {
            if (d.listingTitle) existing.title = d.listingTitle;
            if (d.status) existing.status = d.status;
          }
        });
      } catch (enrichErr) {
        // Non-critical enrichment failure handled gracefully
      }

      // If client Firestore was offline, unavailable, or yielded no items, seamlessly fallback to server endpoints
      if (items.length === 0) {
        try {
          const [txRes, vpayRes, ordersRes] = await Promise.allSettled([
            fetch('/api/transactions'),
            fetch('/api/vpay/history'),
            fetch('/api/shop/orders'),
          ]);

          if (txRes.status === 'fulfilled' && txRes.value.ok) {
            const data = await txRes.value.json();
            (data.transactions || []).forEach((t: any) => {
              if (t.type === 'vpay_send' || t.type === 'vpay_receive' || t.type === 'shop_purchase') {
                const isSend = t.type === 'vpay_send';
                const isShop = t.type === 'shop_purchase';
                items.push({
                  id: t.id,
                  category: isShop ? 'shop' : 'vpay',
                  type: t.type,
                  title: isShop ? 'LOT Shop Purchase' : isSend ? 'VPay Transfer Sent' : 'VPay Transfer Received',
                  note: t.description || '',
                  amount: t.amount,
                  balanceAfter: t.balanceAfter,
                  referenceId: t.referenceId,
                  createdAt: t.createdAt,
                });
              }
            });
          }

          if (vpayRes.status === 'fulfilled' && vpayRes.value.ok) {
            const data = await vpayRes.value.json();
            (data.transfers || []).forEach((tr: any) => {
              const isSender = tr.senderId === user.id;
              const existing = items.find((it) => it.referenceId === tr.id || it.id === tr.id);
              if (!existing) {
                items.push({
                  id: tr.id,
                  category: 'vpay',
                  type: isSender ? 'vpay_send' : 'vpay_receive',
                  title: isSender ? `VPay to @${tr.recipientUsername}` : `VPay from @${tr.senderUsername}`,
                  counterparty: `@${isSender ? tr.recipientUsername : tr.senderUsername}`,
                  note: tr.note || 'P2P Transfer',
                  amount: isSender ? -Math.abs(tr.amount) : Math.abs(tr.amount),
                  status: tr.reversed ? 'Reversed' : 'Completed',
                  referenceId: tr.id,
                  createdAt: tr.createdAt,
                });
              }
            });
          }

          if (ordersRes.status === 'fulfilled' && ordersRes.value.ok) {
            const data = await ordersRes.value.json();
            (data.orders || []).forEach((ord: any) => {
              const existing = items.find((it) => it.referenceId === ord.id || it.id === ord.id);
              if (!existing) {
                items.push({
                  id: ord.id,
                  category: 'shop',
                  type: 'shop_purchase',
                  title: ord.listingTitle || 'Shop Order',
                  counterparty: ord.sellerUsername ? `Seller: @${ord.sellerUsername}` : undefined,
                  note: `${ord.quantity || 1} unit(s) • Status: ${ord.status || 'Placed'}`,
                  amount: -Math.abs(ord.totalLot || ord.priceLot || 0),
                  status: ord.status,
                  referenceId: ord.id,
                  createdAt: ord.createdAt,
                });
              }
            });
          }
        } catch {
          // Fallback failed quietly
        }
      }

      // Sort descending by timestamp
      items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setRecentItems(items);
      setLastSynced(new Date());
    } catch {
      // Suppress unhandled errors during network switches
    } finally {
      setRecentLoading(false);
    }
  };

  useEffect(() => {
    fetchLedger();
    fetchRecentFromFirestore();
  }, [user?.id]);

  // Calculations for summary pills
  const totalVpaySent = recentItems
    .filter((it) => it.type === 'vpay_send')
    .reduce((acc, it) => acc + Math.abs(it.amount), 0);

  const totalVpayReceived = recentItems
    .filter((it) => it.type === 'vpay_receive')
    .reduce((acc, it) => acc + Math.abs(it.amount), 0);

  const totalShopSpent = recentItems
    .filter((it) => it.type === 'shop_purchase')
    .reduce((acc, it) => acc + Math.abs(it.amount), 0);

  // Filter recent transactions
  const filteredRecent = recentItems.filter((item) => {
    if (recentFilter === 'ALL') return true;
    return item.category === recentFilter;
  });

  // Filter full ledger
  const filteredTransactions = transactions.filter((t) => {
    if (typeFilter === 'ALL') return true;
    return t.type === typeFilter;
  });

  const getTransactionBadge = (type: TransactionType) => {
    switch (type) {
      case 'vpay_send':
        return <span className="text-red-400 font-bold">VPay Sent</span>;
      case 'vpay_receive':
        return <span className="text-emerald-400 font-bold">VPay Received</span>;
      case 'shop_purchase':
        return <span className="text-purple-300 font-bold">Shop Purchase</span>;
      case 'shop_sale':
        return <span className="text-emerald-300 font-bold">Shop Sale</span>;
      case 'stock_buy':
        return <span className="text-amber-300 font-bold">VStocks Buy</span>;
      case 'stock_sell':
        return <span className="text-emerald-400 font-bold">VStocks Sell</span>;
      case 'redemption':
        return <span className="text-indigo-300 font-bold">Promo Redeemed</span>;
      case 'minigame_reward':
        return <span className="text-pink-300 font-bold">Minigame Prize</span>;
      case 'admin_adjustment':
        return <span className="text-cyan-300 font-bold">Admin Adjustment</span>;
      default:
        return <span className="text-white font-bold">{type}</span>;
    }
  };

  if (!user) {
    return (
      <div className="py-20 text-center bg-[#19192B] border border-[#302D46] rounded-3xl p-8 max-w-md mx-auto">
        <UserIcon className="w-12 h-12 text-[#A5A3B8] mx-auto mb-3" />
        <h2 className="text-lg font-bold text-white">Sign In Required</h2>
        <p className="text-xs text-[#A5A3B8] mt-1">Please log in to view your authoritative LOT ledger and account history.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* Account Overview Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#121222] via-[#19192B] to-[#202039] border border-[#302D46] p-6 sm:p-10 shadow-2xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            {/* Interactive Profile Avatar with Camera Overlay */}
            <div
              onClick={() => {
                setAvatarPreview(user.avatarUrl || null);
                setAvatarInputUrl(user.avatarUrl || '');
                setAvatarError(null);
                setAvatarSuccessMsg(null);
                setShowAvatarModal(true);
              }}
              className="relative group w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] via-[#A855F7] to-[#C4B5FD] flex items-center justify-center text-xl sm:text-2xl font-black text-white shadow-xl shadow-purple-500/20 shrink-0 overflow-hidden cursor-pointer border-2 border-transparent hover:border-purple-400 transition-all"
              title="Click to change your profile picture"
            >
              {user.avatarUrl ? (
                <img src={user.avatarUrl} alt={user.username} className="w-full h-full object-cover" />
              ) : (
                user.username.charAt(0).toUpperCase()
              )}
              {/* Camera Hover Badge */}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center transition-opacity text-white text-[10px] font-bold">
                <Camera className="w-5 h-5 mb-0.5 text-purple-300" />
                <span>Change</span>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-black text-white">@{user.username}</h1>
                {user.isAdmin && (
                  <span className="px-2 py-0.5 rounded-md bg-red-950 text-red-300 border border-red-800 text-[10px] font-bold">
                    ADMIN
                  </span>
                )}
                {user.vipBadge && (
                  <span className="px-2 py-0.5 rounded-md bg-purple-950 text-purple-200 border border-purple-800 text-[10px] font-bold">
                    {user.vipBadge}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3 mt-2 flex-wrap">
                <p className="text-xs text-[#A5A3B8] flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  Member since {new Date(user.createdAt).toLocaleDateString()}
                </p>

                {/* Prominent Change Profile Picture Button */}
                <button
                  type="button"
                  onClick={() => {
                    setAvatarPreview(user.avatarUrl || null);
                    setAvatarInputUrl(user.avatarUrl || '');
                    setAvatarError(null);
                    setAvatarSuccessMsg(null);
                    setShowAvatarModal(true);
                  }}
                  className="px-2.5 py-1 rounded-xl bg-[#202039] hover:bg-[#302D46] border border-[#302D46] hover:border-purple-500 text-purple-200 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                >
                  <Camera className="w-3.5 h-3.5 text-purple-400" />
                  <span>Change Profile Picture</span>
                </button>
              </div>
            </div>
          </div>

          <div className={`p-4 rounded-2xl min-w-[200px] border ${
            user.lotBalance < 0
              ? 'bg-red-950/60 border-red-500/50'
              : 'bg-[#121222]/80 border-[#8B5CF6]/40'
          }`}>
            <span className={`text-[11px] block font-semibold ${user.lotBalance < 0 ? 'text-red-300' : 'text-[#A5A3B8]'}`}>
              {user.lotBalance < 0 ? '⚠️ Overdrawn (Negative Debt)' : 'Authoritative Ledger Balance'}
            </span>
            <div className="text-2xl font-black flex items-center gap-2 mt-1">
              <Coins className={`w-5 h-5 ${user.lotBalance < 0 ? 'text-red-400' : 'text-[#8B5CF6]'}`} />
              <span className={user.lotBalance < 0 ? 'text-red-400' : 'text-white'} title={`${user.lotBalance.toLocaleString()} LOT`}>
                {formatCompactNumber(user.lotBalance)}
              </span>
              <span className={`text-xs font-semibold ${user.lotBalance < 0 ? 'text-red-300' : 'text-[#C4B5FD]'}`}>LOT</span>
            </div>
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------------ */}
      {/* PROFILE PICTURE CUSTOMIZATION MODAL */}
      {/* ------------------------------------------------------------------ */}
      {showAvatarModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-lg bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 sm:p-8 text-[#F5F3FF] overflow-hidden max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-[#302D46] shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center">
                  <Camera className="w-5 h-5 text-[#C4B5FD]" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Customize Profile Picture</h3>
                  <p className="text-xs text-[#A5A3B8]">Upload any picture from your device, paste a URL, or choose a preset.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAvatarModal(false)}
                className="p-1 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-[#202039] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Error or Success Notice */}
            {avatarError && (
              <div className="mt-4 p-3 rounded-xl bg-red-950/80 border border-red-500/40 text-red-200 text-xs flex items-center gap-2 shrink-0 animate-fadeIn">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{avatarError}</span>
              </div>
            )}
            {avatarSuccessMsg && (
              <div className="mt-4 p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 shrink-0 animate-fadeIn">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{avatarSuccessMsg}</span>
              </div>
            )}

            {/* Modal Body */}
            <div className="mt-4 space-y-5 overflow-y-auto pr-1 flex-1">
              {/* Method Tabs */}
              <div className="flex bg-[#121222] p-1 rounded-xl border border-[#302D46]">
                <button
                  type="button"
                  onClick={() => setAvatarTab('upload')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    avatarTab === 'upload'
                      ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow'
                      : 'text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload Picture</span>
                </button>
                <button
                  type="button"
                  onClick={() => setAvatarTab('url')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    avatarTab === 'url'
                      ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow'
                      : 'text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  <Link className="w-3.5 h-3.5" />
                  <span>Image Link URL</span>
                </button>
                <button
                  type="button"
                  onClick={() => setAvatarTab('presets')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    avatarTab === 'presets'
                      ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow'
                      : 'text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Presets Gallery</span>
                </button>
              </div>

              {/* Tab 1: Upload Any Picture from Device */}
              {avatarTab === 'upload' && (
                <div className="space-y-3">
                  <label className="block p-6 rounded-2xl bg-[#121222] border-2 border-dashed border-[#302D46] hover:border-purple-500/60 transition-colors text-center cursor-pointer group">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <div className="w-12 h-12 rounded-2xl bg-purple-500/10 text-purple-400 group-hover:scale-110 flex items-center justify-center mx-auto mb-3 transition-transform">
                      <Upload className="w-6 h-6" />
                    </div>
                    <span className="block text-sm font-bold text-white mb-1">Click to browse or drop any image file</span>
                    <span className="block text-xs text-[#A5A3B8]">Supports JPG, PNG, GIF, WEBP, SVG (auto-optimized)</span>
                  </label>
                </div>
              )}

              {/* Tab 2: Custom Image URL */}
              {avatarTab === 'url' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Paste Any Web Image URL</label>
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={avatarInputUrl}
                        onChange={(e) => {
                          setAvatarInputUrl(e.target.value);
                          setAvatarPreview(e.target.value.trim() || null);
                        }}
                        placeholder="https://images.unsplash.com/... or https://..."
                        className="flex-1 px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                      />
                    </div>
                    <p className="text-[11px] text-[#A5A3B8] mt-1.5">
                      You can paste direct image links from Unsplash, Imgur, Discord, Google, or any photo hosting site.
                    </p>
                  </div>
                </div>
              )}

              {/* Tab 3: Preset Avatars */}
              {avatarTab === 'presets' && (
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-[#A5A3B8] block">Choose a curated avatar identity:</span>
                  <div className="grid grid-cols-4 gap-2.5">
                    {PRESET_AVATARS.map((preset) => {
                      const isSelected = avatarPreview === preset.url;
                      return (
                        <button
                          key={preset.name}
                          type="button"
                          onClick={() => {
                            setAvatarPreview(preset.url);
                            setAvatarInputUrl(preset.url);
                          }}
                          className={`relative rounded-xl overflow-hidden aspect-square border-2 transition-all cursor-pointer group ${
                            isSelected ? 'border-purple-400 shadow-lg scale-105' : 'border-[#302D46] hover:border-purple-500/50'
                          }`}
                        >
                          <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                          <div className="absolute inset-x-0 bottom-0 bg-black/70 p-1 text-[9px] text-center font-bold text-white truncate">
                            {preset.name}
                          </div>
                          {isSelected && (
                            <div className="absolute top-1 right-1 w-4 h-4 rounded-full bg-purple-600 text-white flex items-center justify-center">
                              <Check className="w-2.5 h-2.5" />
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Live Preview Display Card */}
              <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46]">
                <span className="text-[11px] font-bold text-[#A5A3B8] uppercase tracking-wider block mb-3">
                  Live Avatar Preview
                </span>
                <div className="flex items-center gap-4">
                  {/* Circular preview */}
                  <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#8B5CF6] via-[#A855F7] to-[#C4B5FD] flex items-center justify-center text-xl font-black text-white shadow-lg overflow-hidden shrink-0 border-2 border-purple-500/40">
                    {avatarPreview ? (
                      <img
                        src={avatarPreview}
                        alt="Preview"
                        className="w-full h-full object-cover"
                        onError={() => setAvatarError('Could not load image from provided source.')}
                      />
                    ) : (
                      user.username.charAt(0).toUpperCase()
                    )}
                  </div>

                  {/* Rounded square preview */}
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] via-[#A855F7] to-[#C4B5FD] flex items-center justify-center text-lg font-black text-white shadow-lg overflow-hidden shrink-0 border border-purple-500/30">
                    {avatarPreview ? (
                      <img src={avatarPreview} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      user.username.charAt(0).toUpperCase()
                    )}
                  </div>

                  <div className="text-xs">
                    <p className="font-bold text-white">@{user.username}</p>
                    <p className="text-[11px] text-[#A5A3B8] mt-0.5">
                      {avatarPreview ? 'Custom photo selected' : 'Default initial avatar'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="mt-5 pt-4 border-t border-[#302D46] flex items-center justify-between gap-3 shrink-0">
              {user.avatarUrl ? (
                <button
                  type="button"
                  disabled={avatarSaving}
                  onClick={handleRemoveAvatar}
                  className="px-3.5 py-2 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-800 text-red-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove Photo</span>
                </button>
              ) : (
                <div />
              )}

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={avatarSaving}
                  onClick={() => setShowAvatarModal(false)}
                  className="px-4 py-2 rounded-xl bg-[#202039] hover:bg-[#302D46] border border-[#302D46] text-white text-xs font-semibold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={avatarSaving || !avatarPreview}
                  onClick={handleSaveAvatar}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 via-[#8B5CF6] to-[#A855F7] text-white text-xs font-bold shadow-lg hover:opacity-95 transition-all cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Check className="w-4 h-4" />
                  <span>{avatarSaving ? 'Saving Picture...' : 'Save Profile Picture'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* FEATURED SECTION: RECENT TRANSACTIONS (PULLS FROM FIRESTORE) */}
      {/* ------------------------------------------------------------------ */}
      <div className="bg-[#19192B] border border-purple-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#302D46] pb-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-purple-950/80 border border-purple-500/40 text-purple-200 text-[11px] font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-[#C4B5FD]" />
              Live Firestore Synchronized Activity
            </div>
            <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-2">
              Recent Transactions
            </h2>
            <p className="text-xs text-[#A5A3B8] mt-0.5">
              Live Firestore feed of your peer-to-peer VPay transfers and LOT Shop purchases.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Filter Tabs */}
            <div className="flex bg-[#121222] border border-[#302D46] rounded-xl p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setRecentFilter('ALL')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                  recentFilter === 'ALL'
                    ? 'bg-[#8B5CF6] text-white shadow'
                    : 'text-[#A5A3B8] hover:text-white'
                }`}
              >
                All Recent ({recentItems.length})
              </button>
              <button
                type="button"
                onClick={() => setRecentFilter('vpay')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                  recentFilter === 'vpay'
                    ? 'bg-[#8B5CF6] text-white shadow'
                    : 'text-[#A5A3B8] hover:text-white'
                }`}
              >
                <Send className="w-3 h-3" />
                <span>VPay ({recentItems.filter((i) => i.category === 'vpay').length})</span>
              </button>
              <button
                type="button"
                onClick={() => setRecentFilter('shop')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                  recentFilter === 'shop'
                    ? 'bg-[#8B5CF6] text-white shadow'
                    : 'text-[#A5A3B8] hover:text-white'
                }`}
              >
                <ShoppingBag className="w-3 h-3" />
                <span>LOT Shop ({recentItems.filter((i) => i.category === 'shop').length})</span>
              </button>
            </div>

            {/* Live Firestore Refresh button */}
            <button
              onClick={fetchRecentFromFirestore}
              disabled={recentLoading}
              title="Pull fresh data from Firestore database"
              className="p-2 bg-[#202039] hover:bg-[#302D46] border border-[#302D46] hover:border-[#8B5CF6] rounded-xl text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${recentLoading ? 'animate-spin text-[#C4B5FD]' : ''}`} />
              <span className="hidden sm:inline">Sync</span>
            </button>
          </div>
        </div>

        {/* Quick Snapshot Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-950/60 border border-red-500/30 flex items-center justify-center shrink-0">
              <ArrowUpRight className="w-4 h-4 text-red-400" />
            </div>
            <div>
              <span className="text-[10px] text-[#A5A3B8] uppercase tracking-wider block font-medium">VPay Sent</span>
              <span className="text-sm font-bold text-white" title={`${totalVpaySent.toLocaleString()} LOT`}>
                {formatCompactNumber(totalVpaySent)} <span className="text-[10px] text-[#8B5CF6]">LOT</span>
              </span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <ArrowDownLeft className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <span className="text-[10px] text-[#A5A3B8] uppercase tracking-wider block font-medium">VPay Received</span>
              <span className="text-sm font-bold text-white" title={`${totalVpayReceived.toLocaleString()} LOT`}>
                {formatCompactNumber(totalVpayReceived)} <span className="text-[10px] text-[#8B5CF6]">LOT</span>
              </span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-950/60 border border-purple-500/30 flex items-center justify-center shrink-0">
              <ShoppingBag className="w-4 h-4 text-purple-400" />
            </div>
            <div>
              <span className="text-[10px] text-[#A5A3B8] uppercase tracking-wider block font-medium">LOT Shop Spent</span>
              <span className="text-sm font-bold text-white" title={`${totalShopSpent.toLocaleString()} LOT`}>
                {formatCompactNumber(totalShopSpent)} <span className="text-[10px] text-[#8B5CF6]">LOT</span>
              </span>
            </div>
          </div>
        </div>

        {/* Recent Transactions List */}
        {recentLoading && recentItems.length === 0 ? (
          <div className="py-12 text-center text-xs text-[#A5A3B8] flex items-center justify-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin text-[#8B5CF6]" />
            <span>Pulling recent transactions directly from Firestore...</span>
          </div>
        ) : filteredRecent.length === 0 ? (
          <div className="py-12 px-4 text-center bg-[#121222] border border-dashed border-[#302D46] rounded-2xl space-y-2">
            <div className="w-10 h-10 rounded-xl bg-[#19192B] border border-[#302D46] mx-auto flex items-center justify-center text-[#A5A3B8]">
              {recentFilter === 'shop' ? (
                <ShoppingBag className="w-5 h-5" />
              ) : recentFilter === 'vpay' ? (
                <Send className="w-5 h-5" />
              ) : (
                <Clock className="w-5 h-5" />
              )}
            </div>
            <h4 className="text-sm font-bold text-white">No Recent {recentFilter === 'shop' ? 'Shop Purchases' : recentFilter === 'vpay' ? 'VPay Transfers' : 'Activity'} Found</h4>
            <p className="text-xs text-[#A5A3B8] max-w-sm mx-auto">
              {recentFilter === 'shop'
                ? 'You have not purchased any items from the LOT Shop yet.'
                : recentFilter === 'vpay'
                ? 'You have not made or received any VPay transfers yet.'
                : 'No recent VPay transfers or LOT Shop purchases recorded for this account.'}
            </p>
          </div>
        ) : (
          <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
            {filteredRecent.map((item) => {
              const isDebit = item.amount < 0;
              const isVpay = item.category === 'vpay';
              const isShop = item.category === 'shop';

              return (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl bg-[#121222] border border-[#302D46] hover:border-[#8B5CF6]/50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-start sm:items-center gap-3 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        isShop
                          ? 'bg-purple-950/70 border border-purple-500/40 text-[#C4B5FD]'
                          : isDebit
                          ? 'bg-red-950/60 border border-red-500/30 text-red-400'
                          : 'bg-emerald-950/60 border border-emerald-500/30 text-emerald-400'
                      }`}
                    >
                      {isShop ? (
                        <ShoppingBag className="w-5 h-5" />
                      ) : isDebit ? (
                        <ArrowUpRight className="w-5 h-5" />
                      ) : (
                        <ArrowDownLeft className="w-5 h-5" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-white text-sm truncate">{item.title}</span>
                        <span
                          className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                            isShop
                              ? 'bg-purple-950 text-purple-300 border border-purple-800'
                              : isDebit
                              ? 'bg-red-950 text-red-300 border border-red-800'
                              : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          }`}
                        >
                          {isShop ? 'LOT Shop Purchase' : isDebit ? 'VPay Sent' : 'VPay Received'}
                        </span>
                        {item.status && (
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-medium bg-[#202039] text-[#A5A3B8] border border-[#302D46]">
                            {item.status}
                          </span>
                        )}
                      </div>

                      {item.note && (
                        <p className="text-[#A5A3B8] text-xs mt-0.5 truncate max-w-md">{item.note}</p>
                      )}

                      <div className="flex items-center gap-3 text-[11px] text-[#A5A3B8] mt-1">
                        <span>{new Date(item.createdAt).toLocaleString()}</span>
                        {item.referenceId && (
                          <span className="font-mono text-[10px] text-[#8B5CF6]">
                            Ref: {item.referenceId.slice(0, 14)}...
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-left sm:text-right shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#302D46]/60 flex sm:block items-center justify-between">
                    <span className="text-[11px] text-[#A5A3B8] sm:hidden">Amount:</span>
                    <div>
                      <div
                        className={`text-base font-black font-mono ${
                          isDebit ? 'text-red-400' : 'text-emerald-400'
                        }`}
                        title={`${isDebit ? '' : '+'}${item.amount.toLocaleString()} LOT`}
                      >
                        {isDebit ? '' : '+'}{formatCompactNumber(item.amount)}{' '}
                        <span className="text-xs text-[#8B5CF6]">LOT</span>
                      </div>
                      {item.balanceAfter !== undefined && (
                        <span
                          className="text-[10px] text-[#A5A3B8] block font-mono"
                          title={`Balance: ${item.balanceAfter.toLocaleString()} LOT`}
                        >
                          Balance: {formatCompactNumber(item.balanceAfter)} LOT
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {lastSynced && (
          <div className="text-right text-[10px] text-[#A5A3B8] pt-1">
            Last pulled from Firestore at {lastSynced.toLocaleTimeString()}
          </div>
        )}
      </div>

      {/* ------------------------------------------------------------------ */}
      {/* COMPLETE AUTHORITATIVE LEDGER HISTORY */}
      {/* ------------------------------------------------------------------ */}
      <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#8B5CF6]" />
              <h2 className="text-lg font-bold text-white">All Authoritative Ledger Records</h2>
            </div>
            <p className="text-xs text-[#A5A3B8] mt-0.5">
              Comprehensive chronological ledger including minigames, stocks, and administrative adjustments.
            </p>
          </div>

          {/* Filter Dropdown */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-[#A5A3B8]" />
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
            >
              <option value="ALL">All Ledger Events</option>
              <option value="vpay_send">VPay Sent</option>
              <option value="vpay_receive">VPay Received</option>
              <option value="shop_purchase">Shop Purchases</option>
              <option value="shop_sale">Shop Sales</option>
              <option value="stock_buy">VStocks Buys</option>
              <option value="stock_sell">VStocks Sells</option>
              <option value="redemption">Promo Redemptions</option>
              <option value="minigame_reward">Minigame Rewards</option>
              <option value="admin_adjustment">Admin Adjustments</option>
            </select>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12 text-xs text-[#A5A3B8]">Loading ledger entries...</div>
        ) : filteredTransactions.length === 0 ? (
          <div className="text-center py-12 text-xs text-[#A5A3B8]">
            No transactions found matching this filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#302D46] text-[#A5A3B8]">
                  <th className="pb-3">Type</th>
                  <th className="pb-3">Description / Memo</th>
                  <th className="pb-3">Amount</th>
                  <th className="pb-3">Balance After</th>
                  <th className="pb-3 text-right">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#302D46]/60">
                {filteredTransactions.map((tx) => {
                  const isDebit = tx.amount < 0;
                  return (
                    <tr key={tx.id} className="hover:bg-[#121222]/40 transition-colors">
                      <td className="py-3.5">
                        <div className="flex items-center gap-1.5">
                          {isDebit ? (
                            <ArrowUpRight className="w-3.5 h-3.5 text-red-400 shrink-0" />
                          ) : (
                            <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          )}
                          {getTransactionBadge(tx.type)}
                        </div>
                      </td>
                      <td className="py-3.5 text-white max-w-md truncate">{tx.description}</td>
                      <td className="py-3.5 font-bold">
                        <span
                          className={isDebit ? 'text-red-400' : 'text-emerald-400'}
                          title={`${isDebit ? '' : '+'}${tx.amount.toLocaleString()} LOT`}
                        >
                          {isDebit ? '' : '+'}{formatCompactNumber(tx.amount)} LOT
                        </span>
                      </td>
                      <td
                        className="py-3.5 text-[#C4B5FD] font-mono font-medium"
                        title={tx.balanceAfter !== undefined ? `${tx.balanceAfter.toLocaleString()} LOT` : undefined}
                      >
                        {tx.balanceAfter !== undefined ? `${formatCompactNumber(tx.balanceAfter)} LOT` : '-'}
                      </td>
                      <td className="py-3.5 text-right text-[#A5A3B8] whitespace-nowrap">
                        {new Date(tx.createdAt).toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
