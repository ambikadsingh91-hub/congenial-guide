import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Upload,
  Trash2,
  Star,
  Search,
  CheckCircle2,
  AlertCircle,
  Download,
  Coins,
  ShieldCheck,
  RefreshCw,
  Plus,
  Ban,
  FileCode,
  Image as ImageIcon,
  ExternalLink,
  Layers,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';
import { AppRecord } from '../appstore/types';

const CATEGORIES = [
  'Games',
  'Productivity',
  'Finance',
  'Tools',
  'Social',
  'Entertainment',
  'Utilities',
  'Education',
  'Lifestyle',
];

export const AdminAppStorePanel: React.FC = () => {
  const { user } = useAuth();
  const [apps, setApps] = useState<AppRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'suspended' | 'deleted'>('all');

  // Sub-tab: list or upload
  const [viewMode, setViewMode] = useState<'list' | 'upload'>('list');

  // Admin Upload Form State
  const [name, setName] = useState('');
  const [developerName, setDeveloperName] = useState('LOT Foundation');
  const [version, setVersion] = useState('1.0.0');
  const [category, setCategory] = useState('Tools');
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');
  const [isPaid, setIsPaid] = useState(false);
  const [priceLot, setPriceLot] = useState('10');
  const [isFeatured, setIsFeatured] = useState(true);
  const [packageFile, setPackageFile] = useState<File | null>(null);
  const [iconFile, setIconFile] = useState<File | null>(null);
  const [iconPreview, setIconPreview] = useState<string | null>(null);
  const [screenshotFiles, setScreenshotFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);

  // Status feedback
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Deletion modal
  const [deletingApp, setDeletingApp] = useState<AppRecord | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [permanentDelete, setPermanentDelete] = useState(true);

  const fetchAdminApps = async () => {
    try {
      setLoading(true);
      setErrorMsg(null);
      const res = await fetch('/api/admin/apps', {
        headers: {
          Authorization: `Bearer ${user?.token}`,
        },
      });
      if (res.ok) {
        const data = await res.json();
        setApps(data.apps || []);
      } else {
        setErrorMsg('Failed to load applications for admin moderation.');
      }
    } catch (e: any) {
      setErrorMsg(e.message || 'Error fetching admin apps');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminApps();
  }, []);

  const handleToggleFeature = async (app: AppRecord) => {
    try {
      const res = await fetch(`/api/admin/apps/${app.id}/toggle-feature`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${user?.token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setApps((prev) =>
          prev.map((a) => (a.id === app.id ? { ...a, isFeatured: data.isFeatured } : a))
        );
        setFeedbackMsg(`Featured status toggled for "${app.name}".`);
      }
    } catch (e) {
      setErrorMsg('Failed to toggle featured status.');
    }
  };

  const handleToggleStatus = async (app: AppRecord) => {
    const nextStatus = app.status === 'suspended' ? 'active' : 'suspended';
    try {
      const res = await fetch(`/api/admin/apps/${app.id}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user?.token}`,
        },
        body: JSON.stringify({ status: nextStatus }),
      });
      if (res.ok) {
        setApps((prev) =>
          prev.map((a) => (a.id === app.id ? { ...a, status: nextStatus } : a))
        );
        setFeedbackMsg(`Application "${app.name}" status set to ${nextStatus}.`);
      }
    } catch (e) {
      setErrorMsg('Failed to update app status.');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deletingApp) return;
    setIsDeleting(true);
    try {
      const res = await fetch(
        `/api/admin/apps/${deletingApp.id}?permanent=${permanentDelete}`,
        {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${user?.token}` },
        }
      );
      if (res.ok) {
        if (permanentDelete) {
          setApps((prev) => prev.filter((a) => a.id !== deletingApp.id));
        } else {
          setApps((prev) =>
            prev.map((a) => (a.id === deletingApp.id ? { ...a, status: 'deleted' } : a))
          );
        }
        setFeedbackMsg(`"${deletingApp.name}" has been deleted from LOT App Store.`);
        setDeletingApp(null);
      } else {
        setErrorMsg('Failed to delete application.');
      }
    } catch (e: any) {
      setErrorMsg(e.message || 'Delete error');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleAdminUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !packageFile || !description.trim()) {
      setErrorMsg('App name, package file (APK/AAB), and description are required.');
      return;
    }

    setUploading(true);
    setErrorMsg(null);

    try {
      const formData = new FormData();
      formData.append('name', name.trim());
      formData.append('developerName', developerName.trim());
      formData.append('version', version.trim());
      formData.append('category', category);
      formData.append('shortDescription', shortDescription.trim());
      formData.append('description', description.trim());
      formData.append('isPaid', String(isPaid));
      formData.append('priceLot', isPaid ? priceLot : '0');
      formData.append('isFeatured', String(isFeatured));
      formData.append('package', packageFile);
      if (iconFile) formData.append('icon', iconFile);
      screenshotFiles.forEach((file) => formData.append('screenshots', file));

      const res = await fetch('/api/admin/apps/upload', {
        method: 'POST',
        headers: { Authorization: `Bearer ${user?.token}` },
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to publish application.');
      }

      setFeedbackMsg(`Application "${name}" published successfully to LOT App Store!`);
      // Reset form
      setName('');
      setShortDescription('');
      setDescription('');
      setPackageFile(null);
      setIconFile(null);
      setIconPreview(null);
      setScreenshotFiles([]);
      setViewMode('list');
      fetchAdminApps();
    } catch (err: any) {
      setErrorMsg(err.message || 'Upload error');
    } finally {
      setUploading(false);
    }
  };

  const filteredApps = apps.filter((a) => {
    if (filterStatus !== 'all' && a.status !== filterStatus) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        a.name.toLowerCase().includes(q) ||
        a.developerUsername.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Header & View Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#141328] border border-[#2B2944] p-5 rounded-2xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              LOT App Store Management
              <span className="text-[10px] bg-red-900/80 border border-red-500/40 text-red-200 px-2 py-0.5 rounded font-black">
                ADMIN
              </span>
            </h2>
            <p className="text-xs text-[#A5A3B8]">
              Publish official apps, delete inappropriate submissions, and manage featured store placement
            </p>
          </div>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode('list')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === 'list'
                ? 'bg-purple-600 text-white shadow'
                : 'bg-[#1D1B36] text-[#A5A3B8] hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Store Apps ({apps.length})</span>
          </button>

          <button
            onClick={() => setViewMode('upload')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              viewMode === 'upload'
                ? 'bg-purple-600 text-white shadow'
                : 'bg-[#1D1B36] text-[#A5A3B8] hover:text-white'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload New App</span>
          </button>
        </div>
      </div>

      {feedbackMsg && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{feedbackMsg}</span>
          </div>
          <button onClick={() => setFeedbackMsg(null)} className="text-emerald-400 hover:text-white text-xs">
            ×
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-red-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
          <button onClick={() => setErrorMsg(null)} className="text-red-400 hover:text-white text-xs">
            ×
          </button>
        </div>
      )}

      {/* VIEW MODE 1: LIST & MODERATE APPS */}
      {viewMode === 'list' && (
        <div className="space-y-4">
          {/* Search & Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-[#787693] absolute left-3 top-2.5" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by app name or developer..."
                className="w-full bg-[#141426] border border-[#2B2942] rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-[#787693] focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={filterStatus}
                onChange={(e: any) => setFilterStatus(e.target.value)}
                className="bg-[#141426] border border-[#2B2942] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
              >
                <option value="all">All Statuses</option>
                <option value="active">Active Only</option>
                <option value="suspended">Suspended</option>
                <option value="deleted">Marked Deleted</option>
              </select>

              <button
                onClick={fetchAdminApps}
                className="p-2 rounded-xl bg-[#141426] border border-[#2B2942] text-[#A5A3B8] hover:text-white transition-colors"
                title="Refresh Apps"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-purple-400' : ''}`} />
              </button>
            </div>
          </div>

          {/* Apps Table */}
          {loading ? (
            <div className="text-center py-16 text-xs text-[#A5A3B8]">Loading Store applications...</div>
          ) : filteredApps.length === 0 ? (
            <div className="p-8 text-center bg-[#121222] border border-[#26243A] rounded-2xl text-xs text-[#787693]">
              No applications match your filter.
            </div>
          ) : (
            <div className="bg-[#121224] border border-[#25243C] rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-[#D1D0E4]">
                  <thead className="bg-[#17162C] text-[#8C8AAB] uppercase text-[10px] tracking-wider border-b border-[#25243C]">
                    <tr>
                      <th className="py-3 px-4">Application</th>
                      <th className="py-3 px-3">Developer</th>
                      <th className="py-3 px-3">Category</th>
                      <th className="py-3 px-3">Price</th>
                      <th className="py-3 px-3">Downloads</th>
                      <th className="py-3 px-3">Status</th>
                      <th className="py-3 px-4 text-right">Admin Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#222138]">
                    {filteredApps.map((a) => (
                      <tr key={a.id} className="hover:bg-[#181730] transition-colors">
                        {/* App Icon & Name */}
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-black border border-[#2F2D48] p-1 shrink-0 overflow-hidden">
                              <img src={a.iconUrl} alt={a.name} className="w-full h-full object-contain rounded-lg" />
                            </div>
                            <div className="min-w-0">
                              <div className="font-bold text-white truncate max-w-xs flex items-center gap-1.5">
                                <span>{a.name}</span>
                                {a.isFeatured && (
                                  <span className="text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1 rounded font-bold">
                                    ★ FEATURED
                                  </span>
                                )}
                              </div>
                              <div className="text-[10px] text-[#787693]">
                                v{a.version} • {((a.fileSize || 0) / (1024 * 1024)).toFixed(1)} MB • {a.fileType?.toUpperCase()}
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span className="text-purple-300 font-semibold">@{a.developerUsername}</span>
                        </td>

                        <td className="py-3 px-3">
                          <span className="px-2 py-0.5 rounded-md bg-[#1F1E38] text-[#A5A3B8] text-[10px]">
                            {a.category}
                          </span>
                        </td>

                        <td className="py-3 px-3">
                          {a.isPaid ? (
                            <span className="text-amber-400 font-bold">£{a.priceLot} LOT</span>
                          ) : (
                            <span className="text-emerald-400">Free</span>
                          )}
                        </td>

                        <td className="py-3 px-3 text-[#A5A3B8]">
                          {formatCompactNumber(a.downloadsCount || 0)}
                        </td>

                        {/* Status Badge */}
                        <td className="py-3 px-3">
                          {a.status === 'active' ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-500/30">
                              Active
                            </span>
                          ) : a.status === 'suspended' ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-500/30">
                              Suspended
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-950/80 text-red-300 border border-red-500/30">
                              Deleted
                            </span>
                          )}
                        </td>

                        {/* Admin Action Buttons */}
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Toggle Featured */}
                            <button
                              onClick={() => handleToggleFeature(a)}
                              className={`p-1.5 rounded-lg border transition-colors ${
                                a.isFeatured
                                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                                  : 'bg-[#1C1B34] border-[#2C2A48] text-[#8C8AAB] hover:text-white'
                              }`}
                              title={a.isFeatured ? 'Remove from Featured' : 'Mark as Featured on Store'}
                            >
                              <Star className={`w-3.5 h-3.5 ${a.isFeatured ? 'fill-amber-400' : ''}`} />
                            </button>

                            {/* Suspend / Activate */}
                            <button
                              onClick={() => handleToggleStatus(a)}
                              className={`p-1.5 rounded-lg border transition-colors ${
                                a.status === 'suspended'
                                  ? 'bg-amber-950/60 border-amber-500/40 text-amber-300'
                                  : 'bg-[#1C1B34] border-[#2C2A48] text-[#8C8AAB] hover:text-white'
                              }`}
                              title={a.status === 'suspended' ? 'Reactivate App' : 'Suspend App'}
                            >
                              <Ban className="w-3.5 h-3.5" />
                            </button>

                            {/* Download APK to test */}
                            <a
                              href={`/api/apps/${a.id}/download`}
                              download
                              className="p-1.5 rounded-lg bg-[#1C1B34] border border-[#2C2A48] text-purple-300 hover:text-white transition-colors"
                              title="Download APK Package"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </a>

                            {/* Delete App */}
                            <button
                              onClick={() => setDeletingApp(a)}
                              className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900 border border-red-500/30 text-red-400 hover:text-red-200 transition-colors"
                              title="Delete from Store"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* VIEW MODE 2: UPLOAD APP AS ADMIN */}
      {viewMode === 'upload' && (
        <form onSubmit={handleAdminUpload} className="bg-[#121224] border border-[#26243C] p-6 rounded-2xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#26243C]">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Upload className="w-4 h-4 text-purple-400" />
              Upload & Publish Android Application to LOT App Store
            </h3>
            <span className="text-xs text-purple-300">Admin Publisher Mode</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">
                App Name <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. LOT VPay Authenticator 2.0"
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Developer Attribution</label>
              <input
                type="text"
                value={developerName}
                onChange={(e) => setDeveloperName(e.target.value)}
                placeholder="LOT Foundation"
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Version Number</label>
              <input
                type="text"
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                placeholder="1.0.0"
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c} className="bg-[#10101F]">
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Package Upload */}
          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1">
              Select APK or AAB Package <span className="text-red-400">*</span>
            </label>
            <input
              type="file"
              accept=".apk,.aab"
              onChange={(e) => setPackageFile(e.target.files ? e.target.files[0] : null)}
              className="w-full text-xs text-[#A5A3B8] bg-[#16162A] p-2 rounded-xl border border-[#2D2B44]"
              required
            />
          </div>

          {/* Icon Upload */}
          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1">App Icon / Logo (Optional)</label>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => setIconFile(e.target.files ? e.target.files[0] : null)}
              className="w-full text-xs text-[#A5A3B8] bg-[#16162A] p-2 rounded-xl border border-[#2D2B44]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Short Summary</label>
            <input
              type="text"
              value={shortDescription}
              onChange={(e) => setShortDescription(e.target.value)}
              placeholder="Quick 1-sentence tagline"
              className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1">
              Full Description <span className="text-red-400">*</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Full details, features, instructions..."
              rows={3}
              className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white resize-none"
              required
            />
          </div>

          {/* Pricing & Featured Toggles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#25243C]">
            <div className="flex items-center justify-between p-3 bg-[#181730] border border-[#2B2944] rounded-xl">
              <div>
                <span className="text-xs font-bold text-white block">Paid App in £ LOT</span>
                <span className="text-[10px] text-[#A5A3B8]">Require LOT payment to download</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={isPaid}
                  onChange={(e) => setIsPaid(e.target.checked)}
                  className="rounded text-purple-600"
                />
                {isPaid && (
                  <div className="flex items-center gap-1">
                    <span className="text-xs text-amber-400 font-bold">£</span>
                    <input
                      type="number"
                      min="1"
                      value={priceLot}
                      onChange={(e) => setPriceLot(e.target.value)}
                      className="w-16 bg-[#111122] border border-amber-500/40 rounded px-1.5 py-0.5 text-xs text-amber-300"
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-[#181730] border border-[#2B2944] rounded-xl">
              <div>
                <span className="text-xs font-bold text-white block">Feature on Storefront</span>
                <span className="text-[10px] text-[#A5A3B8]">Showcase in hero carousel banner</span>
              </div>
              <input
                type="checkbox"
                checked={isFeatured}
                onChange={(e) => setIsFeatured(e.target.checked)}
                className="rounded text-purple-600"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-[#A5A3B8] hover:bg-white/5"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={uploading}
              className="px-6 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 text-white shadow disabled:opacity-50"
            >
              {uploading ? 'Publishing App...' : 'Publish to App Store'}
            </button>
          </div>
        </form>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deletingApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-[#121226] border border-red-500/40 p-5 rounded-2xl space-y-4 shadow-2xl">
            <div className="flex items-center gap-2.5 text-red-400">
              <Trash2 className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-bold text-white">Delete Application from LOT App Store</h3>
            </div>

            <p className="text-xs text-[#D1D0E4] leading-relaxed">
              Are you sure you want to delete <strong>{deletingApp.name}</strong> (v{deletingApp.version}) by @{deletingApp.developerUsername}?
            </p>

            <label className="flex items-center gap-2 text-xs text-[#A5A3B8] cursor-pointer">
              <input
                type="checkbox"
                checked={permanentDelete}
                onChange={(e) => setPermanentDelete(e.target.checked)}
                className="rounded text-red-600"
              />
              <span>Permanently delete file and remove from database</span>
            </label>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeletingApp(null)}
                className="px-4 py-1.5 rounded-xl text-xs font-semibold text-[#A5A3B8] hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={isDeleting}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-red-600 hover:bg-red-500 text-white disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Delete Application'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
