import React, { useState, useEffect } from 'react';
import {
  Youtube,
  Play,
  Film,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Trash2,
  RefreshCw,
  Loader2,
  Sparkles,
  ShieldAlert,
  Info,
  Clock,
  Eye,
  Heart,
  MessageSquare,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { playTransactionSound, playErrorSound, playClickSound } from '../../lib/sounds';
import { formatCompactNumber } from '../../lib/formatNumber';

interface YouTubePreviewData {
  videoId: string;
  youtubeUrl: string;
  embedUrl: string;
  title: string;
  channelTitle: string;
  channelId?: string | null;
  channelUrl?: string | null;
  thumbnailUrl: string;
  duration?: number;
  description?: string;
  isAttributionVerified: boolean;
}

interface PublishedYouTubeShort {
  id: string;
  youtubeVideoId: string;
  youtubeUrl: string;
  youtubeChannelTitle?: string;
  caption: string;
  thumbnailUrl: string;
  hashtags: string[];
  likesCount: number;
  viewsCount: number;
  commentsCount: number;
  isAttributionVerified?: boolean;
  publishedByAdminUsername?: string;
  createdAt: string;
}

export const YouTubePublisherPanel: React.FC = () => {
  const { user } = useAuth();

  // Input & state
  const [urlInput, setUrlInput] = useState('');
  const [captionInput, setCaptionInput] = useState('');
  const [customTagsInput, setCustomTagsInput] = useState('');

  // Loading & status
  const [previewLoading, setPreviewLoading] = useState(false);
  const [publishLoading, setPublishLoading] = useState(false);
  const [previewData, setPreviewData] = useState<YouTubePreviewData | null>(null);

  // Published list
  const [publishedList, setPublishedList] = useState<PublishedYouTubeShort[]>([]);
  const [listLoading, setListLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Alerts
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [publishedShortId, setPublishedShortId] = useState<string | null>(null);

  // Fetch list of already published YouTube shorts
  const fetchPublishedList = async () => {
    if (!user || !user.token) return;
    setListLoading(true);
    try {
      const res = await fetch('/api/shorts/admin/youtube/list', {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      });
      if (!res.ok) {
        throw new Error('Failed to load published YouTube shorts');
      }
      const data = await res.json();
      setPublishedList(data.shorts || []);
    } catch (err: any) {
      console.warn('Could not load published YouTube list:', err);
    } finally {
      setListLoading(false);
    }
  };

  useEffect(() => {
    fetchPublishedList();
  }, [user]);

  // Handle URL change - reset preview if user edits URL
  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUrlInput(e.target.value);
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  // Preview Video
  const handlePreview = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = urlInput.trim();
    if (!trimmed) {
      setErrorMessage('Please enter a YouTube Shorts or Video URL.');
      playErrorSound();
      return;
    }

    setPreviewLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);
    setPreviewData(null);
    playClickSound();

    try {
      const res = await fetch('/api/shorts/admin/youtube/preview', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user?.token}`,
        },
        body: JSON.stringify({ url: trimmed }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to preview video');
      }

      setPreviewData(data);
      // Pre-fill caption with YouTube video title
      setCaptionInput(data.title || '');
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred while fetching video preview.');
      playErrorSound();
    } finally {
      setPreviewLoading(false);
    }
  };

  // Publish Short
  const handlePublish = async () => {
    if (!previewData || !user?.token) return;

    setPublishLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    // Extract tags from custom input
    const customTags = customTagsInput
      .split(/[\s,]+/)
      .map((t) => t.trim())
      .filter((t) => t.length > 0)
      .map((t) => (t.startsWith('#') ? t : `#${t}`));

    try {
      const res = await fetch('/api/shorts/admin/youtube/publish', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.token}`,
        },
        body: JSON.stringify({
          url: previewData.youtubeUrl,
          caption: captionInput.trim() || previewData.title,
          customHashtags: customTags,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to publish video');
      }

      playTransactionSound();
      setSuccessMessage('YouTube Short successfully published to the LOT Shorts feed!');
      setPublishedShortId(data.short?.id || null);

      // Reset form
      setUrlInput('');
      setCaptionInput('');
      setCustomTagsInput('');
      setPreviewData(null);

      // Refresh published list
      fetchPublishedList();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to publish video.');
      playErrorSound();
    } finally {
      setPublishLoading(false);
    }
  };

  // Delete Published YouTube Short
  const handleDeletePublished = async (shortId: string) => {
    if (!window.confirm('Are you sure you want to delete this YouTube Short from LOT Ecosystem?')) {
      return;
    }

    setDeletingId(shortId);
    try {
      const res = await fetch(`/api/shorts/${shortId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${user?.token}`,
        },
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to delete short');
      }

      setPublishedList((prev) => prev.filter((s) => s.id !== shortId));
      setSuccessMessage('YouTube Short removed from feed.');
      playClickSound();
    } catch (err: any) {
      setErrorMessage(err.message || 'Error deleting short');
      playErrorSound();
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-red-950/40 via-[#19192B] to-purple-950/40 border border-red-500/30 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center shadow-lg shadow-red-600/30 shrink-0">
              <Youtube className="w-8 h-8 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-red-500/20 text-red-400 border border-red-500/30">
                  Admin Tool Only
                </span>
                <span className="text-xs text-[#A5A3B8]">LOT Shorts Feed Integration</span>
              </div>
              <h1 className="text-2xl font-black text-white mt-1">YouTube Video Publisher</h1>
              <p className="text-xs text-[#A5A3B8] max-w-2xl mt-1">
                Publish YouTube Shorts and video links directly into the LOT Ecosystem Shorts feed. The video remains hosted on YouTube and streams via YouTube&apos;s official embedded player with full creator attribution.
              </p>
            </div>
          </div>

          <div className="bg-[#121222]/80 border border-[#302D46] px-4 py-2.5 rounded-2xl text-right shrink-0">
            <span className="text-[11px] text-[#A5A3B8] block">Published via YouTube</span>
            <span className="text-lg font-black text-white">{publishedList.length} Shorts</span>
          </div>
        </div>

        {/* Info alerts */}
        {errorMessage && (
          <div className="mt-5 p-4 rounded-2xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            <div className="flex-1 font-medium">{errorMessage}</div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-red-400 hover:text-white text-xs underline cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {successMessage && (
          <div className="mt-5 p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="flex-1 font-medium">{successMessage}</div>
            {publishedShortId && (
              <span className="text-[11px] bg-emerald-900/60 px-2.5 py-1 rounded-lg text-emerald-300 font-mono">
                ID: {publishedShortId}
              </span>
            )}
            <button
              onClick={() => {
                setSuccessMessage(null);
                setPublishedShortId(null);
              }}
              className="text-emerald-400 hover:text-white text-xs underline cursor-pointer"
            >
              Close
            </button>
          </div>
        )}
      </div>

      {/* Main Publishing Station: URL Input & Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Input & Settings (7 cols) */}
        <div className="lg:col-span-7 bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-7 shadow-xl space-y-6">
          <div className="flex items-center gap-2 pb-3 border-b border-[#302D46]">
            <Film className="w-5 h-5 text-red-400" />
            <h2 className="text-base font-bold text-white">Publish YouTube Link</h2>
          </div>

          <form onSubmit={handlePreview} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">
                YouTube Shorts or Video URL <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={urlInput}
                  onChange={handleUrlChange}
                  placeholder="https://www.youtube.com/shorts/5k_WzS6Zk6w or https://youtu.be/..."
                  className="w-full pl-4 pr-32 py-3 bg-[#121222] border border-[#302D46] focus:border-red-500 rounded-2xl text-white text-sm outline-none transition-colors"
                />
                <button
                  type="submit"
                  disabled={previewLoading || !urlInput.trim()}
                  className="absolute right-1.5 top-1.5 bottom-1.5 px-4 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
                >
                  {previewLoading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Checking...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Preview Video</span>
                    </>
                  )}
                </button>
              </div>
              <p className="text-[11px] text-[#7E7B9A] mt-1.5">
                Supports YouTube Shorts URLs (<code className="text-red-400">youtube.com/shorts/...</code>), standard watch links, and shortened <code className="text-red-400">youtu.be/...</code> links.
              </p>
            </div>
          </form>

          {/* If Preview Data is Loaded */}
          {previewData && (
            <div className="space-y-5 pt-4 border-t border-[#302D46] animate-fadeIn">
              <div className="p-4 rounded-2xl bg-[#121222] border border-purple-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    Verified Video Metadata
                  </span>
                  <span className="font-mono text-[11px] text-[#A5A3B8] bg-[#19192B] px-2 py-0.5 rounded">
                    ID: {previewData.videoId}
                  </span>
                </div>

                {/* Creator Attribution Badge */}
                <div className="flex items-center gap-2 p-2.5 rounded-xl bg-[#19192B] border border-[#302D46]">
                  <div className="w-8 h-8 rounded-full bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400 font-black text-xs shrink-0">
                    YT
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-white truncate">
                        {previewData.channelTitle}
                      </span>
                      {previewData.isAttributionVerified ? (
                        <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          Verified Creator
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                          Fallback Creator
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-[#A5A3B8]">Original YouTube Content Creator</p>
                  </div>

                  <a
                    href={previewData.youtubeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 rounded-lg bg-[#121222] text-[#A5A3B8] hover:text-white hover:bg-red-600/30 transition-colors"
                    title="Open on YouTube"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>

                {/* Editable Caption */}
                <div>
                  <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">
                    Short Caption (will appear in feed)
                  </label>
                  <textarea
                    rows={2}
                    value={captionInput}
                    onChange={(e) => setCaptionInput(e.target.value)}
                    placeholder="Enter short caption..."
                    className="w-full px-3.5 py-2.5 bg-[#19192B] border border-[#302D46] focus:border-purple-500 rounded-xl text-white text-xs outline-none transition-colors"
                  />
                </div>

                {/* Custom Hashtags */}
                <div>
                  <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">
                    Custom Hashtags (separated by spaces)
                  </label>
                  <input
                    type="text"
                    value={customTagsInput}
                    onChange={(e) => setCustomTagsInput(e.target.value)}
                    placeholder="#shorts #viral #gaming"
                    className="w-full px-3.5 py-2 bg-[#19192B] border border-[#302D46] focus:border-purple-500 rounded-xl text-white text-xs outline-none transition-colors"
                  />
                  <p className="text-[10px] text-[#7E7B9A] mt-1">
                    LOT automatically includes #youtube and #shorts tags.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handlePublish}
                  disabled={publishLoading}
                  className="flex-1 py-3 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-purple-600 hover:opacity-95 disabled:opacity-50 text-white font-extrabold text-sm shadow-xl shadow-red-600/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  {publishLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Publishing to Shorts Feed...</span>
                    </>
                  ) : (
                    <>
                      <Youtube className="w-4 h-4" />
                      <span>Publish Short to Feed</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setPreviewData(null)}
                  disabled={publishLoading}
                  className="px-4 py-3 rounded-2xl bg-[#121222] border border-[#302D46] text-[#A5A3B8] hover:text-white font-semibold text-xs cursor-pointer transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Backend Security & Hosting Guarantee Notice */}
          <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] text-xs text-[#A5A3B8] space-y-2">
            <div className="flex items-center gap-1.5 text-white font-bold">
              <ShieldAlert className="w-4 h-4 text-emerald-400" />
              <span>Architectural Guarantees & Constraints</span>
            </div>
            <ul className="space-y-1 list-disc pl-4 text-[11px] text-[#8F8CA8]">
              <li>Only authenticated administrators can preview or publish links. Backend validates admin claims.</li>
              <li>Actual videos remain hosted on YouTube CDN and are never downloaded to Firebase Storage.</li>
              <li>Duplicates are automatically prevented by matching existing YouTube video IDs in Cloud Firestore.</li>
              <li>Videos appear immediately in the normal LOT Shorts feed across all devices.</li>
            </ul>
          </div>
        </div>

        {/* Right Preview Player (5 cols) */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center">
          <div className="w-full max-w-[320px] bg-[#19192B] border border-[#302D46] rounded-3xl p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-white px-1">
              <span className="flex items-center gap-1.5">
                <Youtube className="w-4 h-4 text-red-500" />
                Live Player Preview
              </span>
              <span className="text-[10px] text-[#A5A3B8]">9:16 Aspect</span>
            </div>

            {/* Embedded Screen */}
            <div className="relative w-full aspect-[9/16] bg-black rounded-2xl overflow-hidden border border-[#302D46] flex items-center justify-center shadow-inner">
              {previewData ? (
                <iframe
                  src={`${previewData.embedUrl}?autoplay=1&mute=1&playsinline=1&rel=0&modestbranding=1`}
                  title={previewData.title}
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <div className="flex flex-col items-center justify-center p-6 text-center space-y-3">
                  <div className="w-16 h-16 rounded-full bg-red-600/10 border border-red-500/20 flex items-center justify-center text-red-500">
                    <Youtube className="w-8 h-8" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-white">No Video Loaded</p>
                    <p className="text-[10px] text-[#7E7B9A]">
                      Paste a YouTube Shorts URL on the left and click &quot;Preview Video&quot; to test playback.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {previewData && (
              <div className="p-2.5 rounded-xl bg-[#121222] border border-[#302D46] space-y-1">
                <p className="text-xs font-bold text-white line-clamp-2">{previewData.title}</p>
                <div className="flex items-center justify-between text-[10px] text-[#A5A3B8]">
                  <span>Creator: {previewData.channelTitle}</span>
                  <span>{previewData.isAttributionVerified ? '✓ Verified' : 'Admin Fallback'}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Published YouTube Shorts Archive */}
      <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#302D46]">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Youtube className="w-5 h-5 text-red-500" />
              Published YouTube Shorts in LOT Ecosystem
            </h2>
            <p className="text-xs text-[#A5A3B8] mt-0.5">
              Manage YouTube videos currently streaming in the LOT Shorts feed.
            </p>
          </div>

          <button
            onClick={fetchPublishedList}
            disabled={listLoading}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#121222] border border-[#302D46] hover:border-purple-500 text-xs font-semibold text-white transition-all cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${listLoading ? 'animate-spin' : ''}`} />
            <span>Refresh Archive</span>
          </button>
        </div>

        {listLoading ? (
          <div className="py-12 flex flex-col items-center justify-center gap-3 text-white">
            <Loader2 className="w-8 h-8 animate-spin text-red-500" />
            <span className="text-xs text-[#A5A3B8]">Loading YouTube Shorts collection...</span>
          </div>
        ) : publishedList.length === 0 ? (
          <div className="py-12 text-center space-y-2">
            <Film className="w-10 h-10 text-[#403D58] mx-auto" />
            <p className="text-sm font-semibold text-white">No YouTube Shorts published yet</p>
            <p className="text-xs text-[#A5A3B8] max-w-sm mx-auto">
              Use the publisher above to add your first YouTube Short directly to the LOT Shorts feed.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {publishedList.map((item) => (
              <div
                key={item.id}
                className="bg-[#121222] border border-[#302D46] hover:border-red-500/40 rounded-2xl overflow-hidden p-4 space-y-3 transition-all"
              >
                {/* Top media info */}
                <div className="flex gap-3">
                  <div className="relative w-20 h-28 bg-black rounded-xl overflow-hidden shrink-0 border border-[#302D46]">
                    {item.thumbnailUrl ? (
                      <img
                        src={item.thumbnailUrl}
                        alt={item.caption}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-zinc-900">
                        <Youtube className="w-6 h-6 text-red-500" />
                      </div>
                    )}
                    <div className="absolute top-1 left-1 bg-red-600 px-1 py-0.2 rounded text-[8px] font-black text-white">
                      YT
                    </div>
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <p className="text-xs font-bold text-white line-clamp-2" title={item.caption}>
                      {item.caption}
                    </p>

                    <div className="text-[11px] text-red-400 font-semibold truncate">
                      @{item.youtubeChannelTitle || 'Original Creator'}
                    </div>

                    <div className="flex items-center gap-3 text-[10px] text-[#A5A3B8] pt-1">
                      <span className="flex items-center gap-1">
                        <Heart className="w-3 h-3 text-rose-400" />
                        {formatCompactNumber(item.likesCount || 0)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3 text-purple-400" />
                        {formatCompactNumber(item.viewsCount || 0)}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageSquare className="w-3 h-3 text-blue-400" />
                        {formatCompactNumber(item.commentsCount || 0)}
                      </span>
                    </div>

                    <div className="text-[10px] text-[#7E7B9A] pt-1">
                      {new Date(item.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                {/* Hashtags */}
                {Array.isArray(item.hashtags) && item.hashtags.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {item.hashtags.slice(0, 4).map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-md bg-[#19192B] border border-[#302D46] text-[10px] text-purple-300 font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                {/* Footer Controls */}
                <div className="flex items-center justify-between pt-2 border-t border-[#302D46]">
                  <a
                    href={item.youtubeUrl || `https://www.youtube.com/watch?v=${item.youtubeVideoId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-[11px] text-[#A5A3B8] hover:text-white transition-colors"
                  >
                    <ExternalLink className="w-3 h-3 text-red-400" />
                    <span>View on YouTube</span>
                  </a>

                  <button
                    onClick={() => handleDeletePublished(item.id)}
                    disabled={deletingId === item.id}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-red-950/40 border border-red-500/30 hover:bg-red-900/50 text-red-400 text-[11px] font-semibold transition-colors cursor-pointer"
                  >
                    {deletingId === item.id ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <Trash2 className="w-3 h-3" />
                    )}
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
