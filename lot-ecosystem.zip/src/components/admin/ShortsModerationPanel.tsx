import React, { useState, useEffect } from 'react';
import {
  Film,
  MessageCircle,
  Flag,
  Trash2,
  Ban,
  CheckCircle,
  XCircle,
  Loader2,
  AlertTriangle,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { playNotificationSound, playErrorSound, playClickSound } from '../../lib/sounds';

interface ReportItem {
  id: string;
  targetType: 'short' | 'comment';
  targetId: string;
  reporterId: string;
  reporterUsername: string;
  reason: string;
  details?: string;
  shortSnippet?: string;
  commentSnippet?: string;
  status: 'pending' | 'resolved' | 'dismissed';
  actionTaken?: string;
  createdAt: string;
}

export const ShortsModerationPanel: React.FC = () => {
  const { user } = useAuth();
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'resolved'>('pending');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const loadReports = async () => {
    if (!user) return;
    setLoading(true);
    setErrorMessage(null);
    try {
      const res = await fetch('/api/admin/shorts/reports', {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      if (!res.ok) throw new Error('Failed to fetch reports');
      const data = await res.json();
      setReports(data.reports || []);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error loading reports');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, [user]);

  const handleAction = async (reportId: string, action: 'dismiss' | 'delete_content' | 'ban_user') => {
    if (!user) return;
    if (
      action === 'delete_content' &&
      !window.confirm('Are you sure you want to delete this content immediately?')
    ) {
      return;
    }
    if (
      action === 'ban_user' &&
      !window.confirm('Are you sure you want to ban the creator of this reported content?')
    ) {
      return;
    }

    setProcessingId(reportId);
    setActionMessage(null);
    setErrorMessage(null);

    try {
      const res = await fetch(`/api/admin/shorts/reports/${reportId}/action`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.token}`,
        },
        body: JSON.stringify({ action }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to process moderation action');
      }

      playNotificationSound();
      setActionMessage(
        action === 'delete_content'
          ? 'Content deleted and removed from feed successfully.'
          : action === 'ban_user'
          ? 'Content deleted and creator account suspended.'
          : 'Report dismissed.'
      );

      // Refresh reports
      setReports((prev) =>
        prev.map((r) =>
          r.id === reportId
            ? { ...r, status: action === 'dismiss' ? 'dismissed' : 'resolved', actionTaken: action }
            : r
        )
      );
    } catch (err: any) {
      playErrorSound();
      setErrorMessage(err.message || 'Moderation action failed');
    } finally {
      setProcessingId(null);
    }
  };

  const filteredReports = reports.filter((r) => {
    if (filter === 'pending') return r.status === 'pending';
    if (filter === 'resolved') return r.status === 'resolved' || r.status === 'dismissed';
    return true;
  });

  return (
    <div className="bg-[#121222] border border-[#302D46] rounded-3xl p-5 sm:p-6 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#25253e]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-purple-600 flex items-center justify-center text-white shadow-lg">
            <Flag className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white tracking-wide">LOT Shorts Content Moderation</h3>
            <p className="text-xs text-[#A5A3B8]">Review user flags, remove illicit videos, and protect ecosystem safety</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Filter tabs */}
          <div className="flex bg-[#191932] p-1 rounded-xl border border-[#2B2B48] text-xs">
            <button
              onClick={() => {
                playClickSound();
                setFilter('pending');
              }}
              className={`px-3 py-1 rounded-lg font-semibold transition ${
                filter === 'pending' ? 'bg-[#8B5CF6] text-white shadow-sm' : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              Pending ({reports.filter((r) => r.status === 'pending').length})
            </button>
            <button
              onClick={() => {
                playClickSound();
                setFilter('resolved');
              }}
              className={`px-3 py-1 rounded-lg font-semibold transition ${
                filter === 'resolved' ? 'bg-[#8B5CF6] text-white shadow-sm' : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              Actioned
            </button>
            <button
              onClick={() => {
                playClickSound();
                setFilter('all');
              }}
              className={`px-3 py-1 rounded-lg font-semibold transition ${
                filter === 'all' ? 'bg-[#8B5CF6] text-white shadow-sm' : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              All ({reports.length})
            </button>
          </div>

          <button
            onClick={loadReports}
            className="p-2 rounded-xl bg-[#191932] border border-[#2B2B48] text-[#A5A3B8] hover:text-white hover:bg-[#25254A] transition"
            title="Refresh reports"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-[#8B5CF6]' : ''}`} />
          </button>
        </div>
      </div>

      {actionMessage && (
        <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
          <span>{actionMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 rounded-xl bg-red-950/80 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Reports Table / Card List */}
      {loading ? (
        <div className="py-16 flex flex-col items-center justify-center gap-2 text-xs text-[#A5A3B8]">
          <Loader2 className="w-7 h-7 animate-spin text-[#8B5CF6]" />
          <span>Loading content moderation queue...</span>
        </div>
      ) : filteredReports.length === 0 ? (
        <div className="py-16 text-center text-xs text-[#A5A3B8]">
          <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
          <p className="font-bold text-white text-sm">Moderation Queue Clear</p>
          <p>No {filter !== 'all' ? filter : ''} reports found.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredReports.map((report) => (
            <div
              key={report.id}
              className="bg-[#17172F] border border-[#292947] rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 transition hover:border-[#3E3E68]"
            >
              <div className="space-y-1.5 flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 ${
                      report.targetType === 'short'
                        ? 'bg-purple-900/60 text-purple-300 border border-purple-500/30'
                        : 'bg-blue-900/60 text-blue-300 border border-blue-500/30'
                    }`}
                  >
                    {report.targetType === 'short' ? <Film className="w-3 h-3" /> : <MessageCircle className="w-3 h-3" />}
                    {report.targetType}
                  </span>

                  <span className="px-2.5 py-0.5 rounded-full bg-red-950/80 text-red-300 border border-red-500/30 text-[10px] font-bold">
                    {report.reason}
                  </span>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                      report.status === 'pending'
                        ? 'bg-amber-950/80 text-amber-300 border border-amber-500/30 animate-pulse'
                        : report.status === 'resolved'
                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                        : 'bg-[#252542] text-[#A5A3B8]'
                    }`}
                  >
                    {report.status}
                  </span>

                  <span className="text-[10px] text-[#6C6A84] ml-auto">
                    {new Date(report.createdAt).toLocaleString()}
                  </span>
                </div>

                <div className="text-xs text-white">
                  <span className="text-[#A5A3B8]">Reported by: </span>
                  <span className="font-semibold text-[#C4B5FD]">@{report.reporterUsername}</span>
                </div>

                {(report.shortSnippet || report.commentSnippet) && (
                  <div className="text-xs text-[#E2E1EC] bg-[#121224] p-2.5 rounded-xl border border-[#252540] italic">
                    "{report.shortSnippet || report.commentSnippet}"
                  </div>
                )}

                {report.details && (
                  <p className="text-[11px] text-[#A5A3B8]">
                    <strong>User notes:</strong> {report.details}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              {report.status === 'pending' && (
                <div className="flex items-center gap-2 shrink-0 pt-2 md:pt-0">
                  <button
                    onClick={() => handleAction(report.id, 'delete_content')}
                    disabled={processingId === report.id}
                    className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md disabled:opacity-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Content</span>
                  </button>

                  <button
                    onClick={() => handleAction(report.id, 'ban_user')}
                    disabled={processingId === report.id}
                    className="px-3 py-1.5 rounded-xl bg-[#2A1828] hover:bg-red-950 border border-red-500/40 text-red-300 text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Ban className="w-3.5 h-3.5" />
                    <span>Ban Creator</span>
                  </button>

                  <button
                    onClick={() => handleAction(report.id, 'dismiss')}
                    disabled={processingId === report.id}
                    className="px-3 py-1.5 rounded-xl bg-[#20203C] hover:bg-[#2B2B4E] text-[#A5A3B8] hover:text-white text-xs font-semibold transition cursor-pointer disabled:opacity-50"
                  >
                    Dismiss
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
