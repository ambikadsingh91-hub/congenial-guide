import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Shield,
  Users,
  Gift,
  Megaphone,
  FileText,
  Package,
  Activity,
  Search,
  PlusCircle,
  Trash2,
  Ban,
  CheckCircle,
  AlertCircle,
  Coins,
  KeyRound,
  Sliders,
  X,
  Clock,
  Eye,
  ShieldCheck,
  TrendingUp,
  Send,
  Zap,
  Award,
  Download,
  RefreshCw,
  DollarSign,
  UserCheck,
  RotateCcw,
  Sparkles,
  Radio,
  Flame,
  AlertTriangle,
  Copy,
  Check,
  Film,
  Youtube,
  Smartphone,
} from 'lucide-react';
import { formatCompactNumber } from '../../lib/formatNumber';
import { playTransactionSound, playRedeemSound, playErrorSound } from '../../lib/sounds';
import { ShortsModerationPanel } from './ShortsModerationPanel';
import { YouTubePublisherPanel } from './YouTubePublisherPanel';
import { AdminAppStorePanel } from './AdminAppStorePanel';

export const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<
    | 'cashier'
    | 'users'
    | 'transactions'
    | 'vpay'
    | 'vstocks'
    | 'shop'
    | 'orders'
    | 'redemption'
    | 'airdrop'
    | 'minigames'
    | 'vip'
    | 'notices'
    | 'radar'
    | 'logs'
    | 'stats'
    | 'shorts_mod'
    | 'youtube_publisher'
    | 'app_manager'
  >('cashier');

  // Global Feedback
  const [adminMsg, setAdminMsg] = useState<string | null>(null);
  const [adminError, setAdminError] = useState<string | null>(null);

  // 1. SET LOT BY USERNAME (CORE CASHIER FEATURE)
  const [cashierUsername, setCashierUsername] = useState('');
  const [cashierTargetUser, setCashierTargetUser] = useState<any | null>(null);
  const [cashierLookingUp, setCashierLookingUp] = useState(false);
  const [cashierMode, setCashierMode] = useState<'set' | 'add' | 'deduct'>('set');
  const [cashierAmount, setCashierAmount] = useState('1000');
  const [cashierReason, setCashierReason] = useState('Administrative balance update');
  const [cashierSubmitting, setCashierSubmitting] = useState(false);

  // 2. USERS MANAGEMENT & SEARCH
  const [users, setUsers] = useState<any[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'admin' | 'user' | 'banned'>('all');
  const [selectedUserForPassword, setSelectedUserForPassword] = useState<any | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);

  // 3. GLOBAL TRANSACTIONS SEARCH
  const [transactions, setTransactions] = useState<any[]>([]);
  const [txSearch, setTxSearch] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState('');
  const [txLoading, setTxLoading] = useState(false);

  // 4. VPAY TRANSFERS AUDIT & REVERSE
  const [vpayTransfers, setVpayTransfers] = useState<any[]>([]);
  const [vpaySearch, setVpaySearch] = useState('');
  const [vpayLoading, setVpayLoading] = useState(false);

  // 5. VSTOCKS MARKET CONTROLLER & PORTFOLIOS
  const [stocks, setStocks] = useState<any[]>([]);
  const [portfolios, setPortfolios] = useState<any[]>([]);
  const [portfolioSearch, setPortfolioSearch] = useState('');
  const [selectedStockForPrice, setSelectedStockForPrice] = useState<string>('LOTX');
  const [overridePriceVal, setOverridePriceVal] = useState('150');
  const [overrideStockReason, setOverrideStockReason] = useState('Admin market calibration');
  const [stockUpdating, setStockUpdating] = useState(false);

  // 6. SHOP CATALOG & INVENTORY EDITOR
  const [shopListings, setShopListings] = useState<any[]>([]);
  const [shopSearch, setShopSearch] = useState('');
  const [editingListing, setEditingListing] = useState<any | null>(null);
  const [editPriceLot, setEditPriceLot] = useState('');
  const [editStockCount, setEditStockCount] = useState('');
  const [editListingStatus, setEditListingStatus] = useState('active');

  // 7. ORDERS & DISPUTES
  const [allOrders, setAllOrders] = useState<any[]>([]);
  const [orderSearch, setOrderSearch] = useState('');

  // 8. REDEMPTION CODES & CODE MAKER
  const [codes, setCodes] = useState<any[]>([]);
  const [claimants, setClaimants] = useState<any[]>([]);
  const [codeSearch, setCodeSearch] = useState('');
  const [claimantSearch, setClaimantSearch] = useState('');
  const [codeMakerMode, setCodeMakerMode] = useState<'single' | 'batch'>('single');
  const [newCodeName, setNewCodeName] = useState('');
  const [newCodeReward, setNewCodeReward] = useState('500');
  const [newCodeMax, setNewCodeMax] = useState('50');
  const [newCodeExpiry, setNewCodeExpiry] = useState('');
  const [createCodeLoading, setCreateCodeLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Batch code generator state
  const [batchPrefix, setBatchPrefix] = useState('LOT');
  const [batchCount, setBatchCount] = useState('5');
  const [batchReward, setBatchReward] = useState('500');
  const [batchMaxClaims, setBatchMaxClaims] = useState('1');
  const [batchLoading, setBatchLoading] = useState(false);
  const [batchGeneratedCodes, setBatchGeneratedCodes] = useState<any[]>([]);
  const [copiedBatchAll, setCopiedBatchAll] = useState(false);

  // 9. BATCH AIRDROP
  const [airdropTarget, setAirdropTarget] = useState<'all' | 'custom'>('all');
  const [airdropUsernames, setAirdropUsernames] = useState('');
  const [airdropAmount, setAirdropAmount] = useState('250');
  const [airdropMemo, setAirdropMemo] = useState('Special seasonal ecosystem reward');
  const [airdropLoading, setAirdropLoading] = useState(false);

  // 10. MINIGAMES CONTROLLER
  const [cooldownTargetUser, setCooldownTargetUser] = useState('');
  const [cooldownResetting, setCooldownResetting] = useState(false);

  // 11. VIP PRESTIGE BADGES
  const [vipTargetUser, setVipTargetUser] = useState<any | null>(null);
  const [vipBadgeChoice, setVipBadgeChoice] = useState('⭐ Verified VIP');
  const [vipSubmitting, setVipSubmitting] = useState(false);

  // 12. NOTICES & DIRECT ALERTS
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annLoading, setAnnLoading] = useState(false);
  const [directUsername, setDirectUsername] = useState('');
  const [directTitle, setDirectTitle] = useState('');
  const [directMsg, setDirectMsg] = useState('');
  const [directLoading, setDirectLoading] = useState(false);

  // 13. ANTI-CHEAT RADAR
  const [radarData, setRadarData] = useState<any | null>(null);
  const [radarLoading, setRadarLoading] = useState(false);

  // 14. AUDIT LOGS
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [logSearch, setLogSearch] = useState('');

  // 15. PLATFORM STATS
  const [stats, setStats] = useState<any>(null);

  // Data Fetchers
  const fetchStats = async () => {
    try {
      const res = await fetch('/api/admin/stats');
      if (res.ok) setStats(await res.json());
    } catch {}
  };

  const fetchUsers = async () => {
    try {
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        setUsers(data.users || []);
      }
    } catch {}
  };

  const fetchTransactions = async () => {
    try {
      setTxLoading(true);
      const params = new URLSearchParams();
      if (txSearch) params.set('search', txSearch);
      if (txTypeFilter) params.set('type', txTypeFilter);
      const res = await fetch(`/api/admin/transactions/search?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setTransactions(data.transactions || []);
      }
    } catch {}
    finally {
      setTxLoading(false);
    }
  };

  const fetchVpayTransfers = async () => {
    try {
      setVpayLoading(true);
      const params = new URLSearchParams();
      if (vpaySearch) params.set('search', vpaySearch);
      const res = await fetch(`/api/admin/vpay/transfers?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setVpayTransfers(data.transfers || []);
      }
    } catch {}
    finally {
      setVpayLoading(false);
    }
  };

  const fetchVstocksData = async () => {
    try {
      const [stocksRes, portRes] = await Promise.all([
        fetch('/api/stocks'),
        fetch('/api/admin/vstocks/portfolios'),
      ]);
      if (stocksRes.ok) {
        const data = await stocksRes.json();
        setStocks(data.stocks || []);
      }
      if (portRes.ok) {
        const data = await portRes.json();
        setPortfolios(data.portfolios || []);
      }
    } catch {}
  };

  const fetchShopListings = async () => {
    try {
      const res = await fetch('/api/admin/shop/listings');
      if (res.ok) {
        const data = await res.json();
        setShopListings(data.listings || []);
      }
    } catch {}
  };

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/admin/all-orders');
      if (res.ok) {
        const data = await res.json();
        setAllOrders(data.orders || []);
      }
    } catch {}
  };

  const fetchCodes = async () => {
    try {
      const res = await fetch('/api/admin/redemption/list');
      if (res.ok) {
        const data = await res.json();
        setCodes(data.codes || []);
        setClaimants(data.claims || []);
      }
    } catch {}
  };

  const fetchAnnouncements = async () => {
    try {
      const res = await fetch('/api/announcements');
      if (res.ok) {
        const data = await res.json();
        setAnnouncements(data.announcements || []);
      }
    } catch {}
  };

  const fetchAuditLogs = async () => {
    try {
      const res = await fetch('/api/admin/audit-logs');
      if (res.ok) {
        const data = await res.json();
        setAuditLogs(data.logs || []);
      }
    } catch {}
  };

  const fetchRadar = async () => {
    try {
      setRadarLoading(true);
      const res = await fetch('/api/admin/anti-cheat/radar');
      if (res.ok) setRadarData(await res.json());
    } catch {}
    finally {
      setRadarLoading(false);
    }
  };

  useEffect(() => {
    if (user?.isAdmin) {
      fetchStats();
      fetchUsers();
      fetchCodes();
      fetchAnnouncements();
      fetchAuditLogs();
      fetchShopListings();
      fetchOrders();
      fetchVstocksData();
      fetchVpayTransfers();
      fetchTransactions();
      fetchRadar();
    }
  }, [user?.isAdmin]);

  // Lookup target user for Cashier
  const handleLookupUser = async (uname: string) => {
    const clean = uname.replace(/^@/, '').trim();
    if (!clean) {
      setCashierTargetUser(null);
      return;
    }
    try {
      setCashierLookingUp(true);
      const res = await fetch(`/api/admin/lookup-user/${clean}`);
      if (res.ok) {
        const data = await res.json();
        setCashierTargetUser(data.user);
        setAdminError(null);
      } else {
        const err = await res.json();
        setCashierTargetUser(null);
        setAdminError(err.error || `User "@${clean}" not found.`);
      }
    } catch {
      setCashierTargetUser(null);
    } finally {
      setCashierLookingUp(false);
    }
  };

  // Submit Set LOT by Username
  const handleSetLotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cashierUsername.trim()) return;
    setCashierSubmitting(true);
    setAdminMsg(null);
    setAdminError(null);

    try {
      const res = await fetch('/api/admin/set-lot-by-username', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: cashierUsername.trim(),
          mode: cashierMode,
          amount: Number(cashierAmount),
          reason: cashierReason.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        playErrorSound();
        setAdminError(data.error || 'Failed to update LOT balance.');
      } else {
        playTransactionSound();
        setAdminMsg(data.message || 'LOT Balance successfully updated!');
        await handleLookupUser(cashierUsername);
        await fetchUsers();
        await fetchAuditLogs();
        await fetchStats();
      }
    } catch {
      playErrorSound();
      setAdminError('Network error while processing LOT update.');
    } finally {
      setCashierSubmitting(false);
    }
  };

  // Toggle Ban
  const handleToggleBan = async (u: any) => {
    if (!confirm(`Are you sure you want to ${u.isBanned ? 'unban' : 'ban'} user @${u.username}?`)) return;
    try {
      const res = await fetch(`/api/admin/users/${u.id}/ban`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          isBanned: !u.isBanned,
          reason: 'Administrative moderation action',
        }),
      });
      if (res.ok) {
        setAdminMsg(`User @${u.username} has been ${u.isBanned ? 'unbanned' : 'banned'}.`);
        await fetchUsers();
        await fetchAuditLogs();
      }
    } catch {}
  };

  // Password Reset
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserForPassword) return;
    setPasswordLoading(true);
    try {
      const res = await fetch(`/api/admin/users/${selectedUserForPassword.id}/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(`Successfully reset password for @${selectedUserForPassword.username}`);
        setSelectedUserForPassword(null);
        setNewPassword('');
        await fetchAuditLogs();
      } else {
        setAdminError(data.error || 'Failed to reset password.');
      }
    } catch {
      setAdminError('Network error resetting password.');
    } finally {
      setPasswordLoading(false);
    }
  };

  // Delete User
  const handleDeleteUser = async (u: any) => {
    if (!confirm(`CRITICAL WARNING: Permanently delete account @${u.username}?`)) return;
    try {
      const res = await fetch(`/api/admin/users/${u.id}`, { method: 'DELETE' });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(`Deleted account @${u.username}`);
        await fetchUsers();
        await fetchAuditLogs();
        await fetchStats();
      } else {
        setAdminError(data.error || 'Failed to delete user.');
      }
    } catch {
      setAdminError('Network error deleting user.');
    }
  };

  // VIP Badge assignment
  const handleAssignVip = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vipTargetUser) return;
    setVipSubmitting(true);
    try {
      const res = await fetch(`/api/admin/users/${vipTargetUser.id}/vip`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vipBadge: vipBadgeChoice }),
      });
      if (res.ok) {
        setAdminMsg(`Updated prestige badge for @${vipTargetUser.username}!`);
        setVipTargetUser(null);
        await fetchUsers();
        await fetchAuditLogs();
      }
    } catch {}
    finally {
      setVipSubmitting(false);
    }
  };

  // Reverse VPay transfer
  const handleReverseVPay = async (transferId: string) => {
    const reason = prompt('Please enter administrative reason for reversing this VPay transfer:');
    if (!reason) return;
    try {
      const res = await fetch(`/api/admin/vpay/reverse/${transferId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(data.message || 'Transfer reversed successfully.');
        await fetchVpayTransfers();
        await fetchUsers();
        await fetchAuditLogs();
      } else {
        setAdminError(data.error || 'Failed to reverse transfer.');
      }
    } catch {
      setAdminError('Error reversing transfer.');
    }
  };

  // VStocks Override Price
  const handleOverrideStockPrice = async (e: React.FormEvent) => {
    e.preventDefault();
    setStockUpdating(true);
    try {
      const res = await fetch('/api/admin/vstocks/override-price', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol: selectedStockForPrice,
          newPrice: Number(overridePriceVal),
          reason: overrideStockReason,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(`Stock ${selectedStockForPrice} price set to ${overridePriceVal} LOT!`);
        await fetchVstocksData();
        await fetchAuditLogs();
      } else {
        setAdminError(data.error || 'Failed to set price.');
      }
    } catch {
      setAdminError('Error setting stock price.');
    } finally {
      setStockUpdating(false);
    }
  };

  // VStocks Market Event Trigger
  const handleMarketEvent = async (eventType: 'surge' | 'dip') => {
    if (!confirm(`Are you sure you want to trigger a ${eventType === 'surge' ? 'BULL SURGE (+15%)' : 'BEAR DIP (-15%)'} across all market stocks?`)) return;
    try {
      const res = await fetch('/api/admin/vstocks/trigger-event', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventType, percentage: 15 }),
      });
      if (res.ok) {
        setAdminMsg(`Market event ${eventType.toUpperCase()} applied to all instruments!`);
        await fetchVstocksData();
        await fetchAuditLogs();
      }
    } catch {}
  };

  // Liquidate stock position
  const handleLiquidateStock = async (portfolioId: string, symbol: string) => {
    if (!confirm(`Force liquidate this holding in ${symbol} at current market value?`)) return;
    try {
      const res = await fetch(`/api/admin/vstocks/liquidate/${portfolioId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: 'Admin forced portfolio liquidation' }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(data.message || 'Position liquidated.');
        await fetchVstocksData();
        await fetchUsers();
        await fetchAuditLogs();
      } else {
        setAdminError(data.error || 'Failed to liquidate.');
      }
    } catch {}
  };

  // Shop Listing Edit
  const handleSaveListingEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingListing) return;
    try {
      const res = await fetch(`/api/admin/shop/listings/${editingListing.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          priceLot: Number(editPriceLot),
          stock: Number(editStockCount),
          status: editListingStatus,
        }),
      });
      if (res.ok) {
        setAdminMsg(`Updated listing "${editingListing.title}"!`);
        setEditingListing(null);
        await fetchShopListings();
        await fetchAuditLogs();
      }
    } catch {}
  };

  // Force Order Refund
  const handleOrderRefund = async (orderId: string) => {
    const reason = prompt('Please enter administrative reason for refunding this order:');
    if (!reason) return;
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/refund`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(data.message || 'Order refunded successfully.');
        await fetchOrders();
        await fetchUsers();
        await fetchAuditLogs();
      } else {
        setAdminError(data.error || 'Failed to refund order.');
      }
    } catch {
      setAdminError('Error refunding order.');
    }
  };

  // Create Code
  const handleCreateCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateCodeLoading(true);
    try {
      const res = await fetch('/api/admin/redemption/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: newCodeName.trim(),
          rewardLot: Number(newCodeReward),
          maxClaims: Number(newCodeMax),
          expiresAt: newCodeExpiry ? new Date(newCodeExpiry).toISOString() : null,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(`Redemption code "${newCodeName.toUpperCase()}" created!`);
        setNewCodeName('');
        setNewCodeReward('500');
        setNewCodeMax('50');
        setNewCodeExpiry('');
        await fetchCodes();
      } else {
        setAdminError(data.error || 'Failed to create code.');
      }
    } catch {
      setAdminError('Network error creating code.');
    } finally {
      setCreateCodeLoading(false);
    }
  };

  // Toggle Code Status
  const handleToggleCode = async (codeStr: string, currentActive: boolean) => {
    try {
      await fetch(`/api/admin/redemption/${codeStr}/toggle`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !currentActive }),
      });
      await fetchCodes();
    } catch {}
  };

  // Copy Code to Clipboard
  const handleCopyCode = (codeStr: string) => {
    navigator.clipboard.writeText(codeStr);
    setCopiedCode(codeStr);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Generate Random Code
  const handleGenerateRandomCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let rand = '';
    for (let i = 0; i < 6; i++) {
      rand += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewCodeName(`LOT-${rand}`);
  };

  // Delete Code Permanently
  const handleDeleteCode = async (codeStr: string) => {
    if (!confirm(`Are you sure you want to permanently delete redemption code "${codeStr}"?`)) return;
    try {
      const res = await fetch(`/api/admin/redemption/${codeStr}`, { method: 'DELETE' });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(data.message || `Deleted redemption code ${codeStr}`);
        await fetchCodes();
        await fetchAuditLogs();
      } else {
        setAdminError(data.error || 'Failed to delete redemption code.');
      }
    } catch {
      setAdminError('Error deleting redemption code.');
    }
  };

  // Batch Generate Redemption Codes
  const handleBatchCreateCodes = async (e: React.FormEvent) => {
    e.preventDefault();
    setBatchLoading(true);
    setAdminMsg(null);
    setAdminError(null);
    try {
      const res = await fetch('/api/admin/redemption/batch-create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prefix: batchPrefix.trim() || 'LOT',
          count: Number(batchCount) || 5,
          rewardLot: Number(batchReward) || 500,
          maxClaims: Number(batchMaxClaims) || 1,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(`Successfully generated ${data.count} new redemption voucher codes!`);
        setBatchGeneratedCodes(data.codes || []);
        await fetchCodes();
        await fetchAuditLogs();
      } else {
        setAdminError(data.error || 'Failed to batch generate codes.');
      }
    } catch {
      setAdminError('Network error batch generating codes.');
    } finally {
      setBatchLoading(false);
    }
  };

  // Copy All Batch Codes
  const handleCopyAllBatchCodes = () => {
    if (batchGeneratedCodes.length === 0) return;
    const text = batchGeneratedCodes.map((c) => `${c.code} (+${c.rewardLot} LOT)`).join('\n');
    navigator.clipboard.writeText(text);
    setCopiedBatchAll(true);
    setTimeout(() => setCopiedBatchAll(false), 2500);
  };

  // Batch Airdrop
  const handleBatchAirdrop = async (e: React.FormEvent) => {
    e.preventDefault();
    const usernamesArr = airdropUsernames
      .split(',')
      .map((u) => u.trim())
      .filter((u) => u.length > 0);

    if (airdropTarget === 'custom' && usernamesArr.length === 0) {
      setAdminError('Please provide at least one username.');
      return;
    }

    if (!confirm(`Are you sure you want to distribute ${airdropAmount} LOT each?`)) return;
    setAirdropLoading(true);
    try {
      const res = await fetch('/api/admin/batch-airdrop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetType: airdropTarget,
          usernames: usernamesArr,
          amount: Number(airdropAmount),
          memo: airdropMemo.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(data.message || 'Airdrop executed successfully!');
        setAirdropUsernames('');
        await fetchUsers();
        await fetchAuditLogs();
        await fetchStats();
      } else {
        setAdminError(data.error || 'Failed to complete airdrop.');
      }
    } catch {
      setAdminError('Error during batch airdrop.');
    } finally {
      setAirdropLoading(false);
    }
  };

  // Reset Minigame Cooldown
  const handleResetCooldown = async (clearAll: boolean) => {
    setCooldownResetting(true);
    try {
      const res = await fetch('/api/admin/minigames/reset-cooldown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: clearAll ? '' : cooldownTargetUser.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(data.message || 'Cooldowns reset.');
        setCooldownTargetUser('');
      } else {
        setAdminError(data.error || 'Failed to reset cooldown.');
      }
    } catch {}
    finally {
      setCooldownResetting(false);
    }
  };

  // Create Broadcast Announcement
  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    setAnnLoading(true);
    try {
      const res = await fetch('/api/admin/announcements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: annTitle, content: annContent }),
      });
      if (res.ok) {
        setAnnTitle('');
        setAnnContent('');
        setAdminMsg('Announcement published across the entire ecosystem!');
        await fetchAnnouncements();
      }
    } catch {}
    finally {
      setAnnLoading(false);
    }
  };

  const handleDeleteAnnouncement = async (id: string) => {
    try {
      await fetch(`/api/admin/announcements/${id}`, { method: 'DELETE' });
      await fetchAnnouncements();
    } catch {}
  };

  // Send Direct Alert to Username
  const handleSendDirectMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    setDirectLoading(true);
    try {
      const res = await fetch('/api/admin/direct-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: directUsername.trim(),
          title: directTitle.trim(),
          message: directMsg.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminMsg(data.message || `Alert sent to @${directUsername}!`);
        setDirectUsername('');
        setDirectTitle('');
        setDirectMsg('');
      } else {
        setAdminError(data.error || 'Failed to send alert.');
      }
    } catch {
      setAdminError('Error sending alert.');
    } finally {
      setDirectLoading(false);
    }
  };

  // Export Audit Trail
  const handleExportAuditLogs = () => {
    const jsonStr = JSON.stringify(auditLogs, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lot_admin_audit_logs_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Filtered views
  const filteredUsers = users.filter((u) => {
    const matchesQuery = u.username.toLowerCase().includes(userSearch.toLowerCase());
    if (!matchesQuery) return false;
    if (userRoleFilter === 'admin') return !!u.isAdmin;
    if (userRoleFilter === 'banned') return !!u.isBanned;
    if (userRoleFilter === 'user') return !u.isAdmin && !u.isBanned;
    return true;
  });

  const filteredCodes = codes.filter((c) =>
    c.code.toLowerCase().includes(codeSearch.toLowerCase())
  );

  const filteredClaimants = claimants.filter((cl) =>
    (cl.username && cl.username.toLowerCase().includes(claimantSearch.toLowerCase())) ||
    (cl.code && cl.code.toLowerCase().includes(claimantSearch.toLowerCase()))
  );

  const filteredShop = shopListings.filter((s) =>
    s.title.toLowerCase().includes(shopSearch.toLowerCase()) ||
    s.sellerUsername.toLowerCase().includes(shopSearch.toLowerCase())
  );

  const filteredOrders = allOrders.filter((o) =>
    o.id.toLowerCase().includes(orderSearch.toLowerCase()) ||
    o.listingTitle.toLowerCase().includes(orderSearch.toLowerCase()) ||
    o.buyerUsername.toLowerCase().includes(orderSearch.toLowerCase()) ||
    o.sellerUsername.toLowerCase().includes(orderSearch.toLowerCase())
  );

  const filteredPortfolios = portfolios.filter((p) =>
    p.symbol.toLowerCase().includes(portfolioSearch.toLowerCase()) ||
    (p.userId && p.userId.toLowerCase().includes(portfolioSearch.toLowerCase()))
  );

  const filteredAuditLogs = auditLogs.filter((l) =>
    (l.action && l.action.toLowerCase().includes(logSearch.toLowerCase())) ||
    (l.adminUsername && l.adminUsername.toLowerCase().includes(logSearch.toLowerCase())) ||
    (l.details && l.details.toLowerCase().includes(logSearch.toLowerCase()))
  );

  // Computed preview for Cashier
  const currentTargetBalance = cashierTargetUser ? cashierTargetUser.lotBalance : 0;
  let previewNewBalance = currentTargetBalance;
  let previewDelta = 0;
  const numAmt = Number(cashierAmount) || 0;
  if (cashierMode === 'set') {
    previewNewBalance = numAmt;
    previewDelta = previewNewBalance - currentTargetBalance;
  } else if (cashierMode === 'add') {
    previewDelta = numAmt;
    previewNewBalance = currentTargetBalance + previewDelta;
  } else if (cashierMode === 'deduct') {
    previewDelta = -numAmt;
    previewNewBalance = Math.max(0, currentTargetBalance + previewDelta);
  }

  // Security guard: strict admin access only
  if (!user || !user.isAdmin) {
    return (
      <div className="py-20 text-center bg-[#19192B] border border-red-500/30 rounded-3xl p-8 max-w-lg mx-auto">
        <Shield className="w-12 h-12 text-red-400 mx-auto mb-3" />
        <h2 className="text-xl font-bold text-white">Access Denied</h2>
        <p className="text-xs text-[#A5A3B8] mt-1">
          Administrator privileges are strictly restricted to the authorized administrative account validated by the server.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn pb-20">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-[#19192B] to-[#121222] border border-purple-500/40 p-5 sm:p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/50 text-red-200 text-xs font-bold mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              Central Administrative Control Console
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">System Operations & Governance</h1>
            <p className="text-xs sm:text-sm text-[#A5A3B8] mt-1 max-w-2xl">
              15 dedicated administration suites: Direct LOT cashier by username, promo code maker, user dossiers, ledger searches, market overrides, P2P fraud tracking, dispute refunds, and anti-cheat radar.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveTab('cashier')}
              className={`text-xs font-semibold px-3 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'cashier'
                  ? 'bg-emerald-600 text-white border-emerald-500'
                  : 'bg-[#202039] border-[#302D46] text-[#C4B5FD] hover:text-white'
              }`}
            >
              <Coins className="w-3.5 h-3.5" />
              <span>Set LOT Cashier</span>
            </button>
            <button
              onClick={() => setActiveTab('redemption')}
              className={`text-xs font-semibold px-3 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'redemption'
                  ? 'bg-gradient-to-r from-amber-600 to-purple-600 text-white border-purple-500 shadow-md'
                  : 'bg-[#202039] border-[#302D46] text-amber-300 hover:text-white'
              }`}
            >
              <Gift className="w-3.5 h-3.5" />
              <span>Code Maker Studio</span>
            </button>
            <span className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-[#202039] border border-[#302D46] text-[#A5A3B8] whitespace-nowrap">
              Admin: @{user.username}
            </span>
          </div>
        </div>

        {/* Global Feedback Notifications */}
        {adminMsg && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center justify-between animate-fadeIn">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{adminMsg}</span>
            </div>
            <button onClick={() => setAdminMsg(null)} className="p-1 hover:text-white cursor-pointer"><X className="w-4 h-4" /></button>
          </div>
        )}
        {adminError && (
          <div className="mt-4 p-3 rounded-xl bg-red-950/80 border border-red-500/40 text-red-200 text-xs flex items-center justify-between animate-fadeIn">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{adminError}</span>
            </div>
            <button onClick={() => setAdminError(null)} className="p-1 hover:text-white cursor-pointer"><X className="w-4 h-4" /></button>
          </div>
        )}
      </div>

      {/* Navigation Sub-Tabs Bar (Scrollable on mobile) */}
      <div className="flex bg-[#121222] p-1.5 rounded-2xl border border-[#302D46] overflow-x-auto scrollbar-none gap-1 max-w-full">
        {[
          { id: 'cashier', label: 'Set LOT Cashier', icon: Coins, highlight: true },
          { id: 'redemption', label: 'Code Maker Studio', icon: Gift, highlight: true },
          { id: 'users', label: 'Users Search', icon: Users },
          { id: 'transactions', label: 'Ledger Search', icon: FileText },
          { id: 'vpay', label: 'VPay Audit', icon: Send },
          { id: 'vstocks', label: 'VStocks Controller', icon: TrendingUp },
          { id: 'shop', label: 'Shop Manager', icon: Package },
          { id: 'orders', label: 'Orders & Disputes', icon: Package },
          { id: 'airdrop', label: 'Batch Airdrop', icon: Sparkles },
          { id: 'minigames', label: 'Minigames Control', icon: Zap },
          { id: 'vip', label: 'VIP Badges', icon: Award },
          { id: 'notices', label: 'Notices & PM', icon: Megaphone },
          { id: 'radar', label: 'Anti-Cheat Radar', icon: Flame },
          { id: 'shorts_mod', label: 'Shorts Moderation', icon: Film, highlight: true },
          { id: 'youtube_publisher', label: 'YouTube Publisher', icon: Youtube, highlight: true },
          { id: 'app_manager', label: 'App Store Manager', icon: Smartphone, highlight: true },
          { id: 'logs', label: 'Audit Trail', icon: ShieldCheck },
          { id: 'stats', label: 'Metrics', icon: Activity },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setAdminMsg(null);
                setAdminError(null);
              }}
              className={`flex items-center gap-1.5 sm:gap-2 px-3 py-2 text-xs font-semibold rounded-xl whitespace-nowrap transition-all cursor-pointer shrink-0 ${
                isActive
                  ? tab.highlight
                    ? 'bg-gradient-to-r from-emerald-600 to-purple-600 text-white shadow-md'
                    : 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md'
                  : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
              }`}
            >
              <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ---------------------------------------------------- */}
      {/* 1. SET LOT BALANCE BY USERNAME (THE CORE CASHIER STATION) */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'cashier' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
            <div className="border-b border-[#302D46] pb-4">
              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold mb-2">
                <Coins className="w-3.5 h-3.5" />
                Authoritative User Balance Cashier
              </div>
              <h2 className="text-xl font-bold text-white">Direct LOT Balance Management by Username</h2>
              <p className="text-xs text-[#A5A3B8] mt-1">
                Enter any username in the ecosystem to inspect their current wallet balance, then set their exact LOT balance or add/deduct tokens. Every adjustment is recorded in the immutable audit ledger.
              </p>
            </div>

            <form onSubmit={handleSetLotSubmit} className="space-y-5">
              {/* Username Input & Live Resolver */}
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">
                  Target Username <span className="text-red-400">*</span>
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-[#8B5CF6]">@</span>
                    <input
                      type="text"
                      required
                      value={cashierUsername}
                      onChange={(e) => {
                        setCashierUsername(e.target.value);
                      }}
                      onBlur={() => handleLookupUser(cashierUsername)}
                      placeholder="e.g. alice, bob, virat"
                      className="w-full pl-8 pr-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-bold text-sm focus:outline-none focus:border-[#8B5CF6]"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => handleLookupUser(cashierUsername)}
                    disabled={cashierLookingUp || !cashierUsername.trim()}
                    className="px-4 py-2.5 rounded-xl bg-[#202039] hover:bg-[#302D46] border border-[#302D46] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <Search className="w-3.5 h-3.5" />
                    <span>{cashierLookingUp ? 'Looking up...' : 'Lookup'}</span>
                  </button>
                </div>
              </div>

              {/* Mode Selector */}
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Modification Mode</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setCashierMode('set')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      cashierMode === 'set'
                        ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md'
                        : 'bg-[#121222] text-[#A5A3B8] border border-[#302D46] hover:text-white'
                    }`}
                  >
                    <Coins className="w-3.5 h-3.5" />
                    <span>Set Exact LOT</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCashierMode('add')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      cashierMode === 'add'
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                        : 'bg-[#121222] text-[#A5A3B8] border border-[#302D46] hover:text-white'
                    }`}
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Add LOT (+)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCashierMode('deduct')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      cashierMode === 'deduct'
                        ? 'bg-gradient-to-r from-amber-600 to-red-600 text-white shadow-md'
                        : 'bg-[#121222] text-[#A5A3B8] border border-[#302D46] hover:text-white'
                    }`}
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Deduct LOT (-)</span>
                  </button>
                </div>
              </div>

              {/* Amount & Presets */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-[#A5A3B8]">
                    {cashierMode === 'set' ? 'New Target LOT Balance' : cashierMode === 'add' ? 'LOT Amount to Credit' : 'LOT Amount to Debit'}
                  </label>
                  <span className="text-[11px] text-[#C4B5FD] font-mono">
                    {cashierMode === 'set' ? 'Exact replacement' : cashierMode === 'add' ? '+ Credit delta' : '- Debit delta'}
                  </span>
                </div>
                <input
                  type="number"
                  min="0"
                  step="1"
                  required
                  value={cashierAmount}
                  onChange={(e) => setCashierAmount(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-mono font-bold text-base focus:outline-none focus:border-[#8B5CF6]"
                />

                {/* Quick Presets */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <span className="text-[10px] text-[#A5A3B8] self-center mr-1">Presets:</span>
                  {cashierMode === 'set'
                    ? [1000, 5000, 25000, 100000, 500000, 1000000].map((p) => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => setCashierAmount(p.toString())}
                          className="px-2 py-0.5 rounded-lg bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] text-[10px] font-semibold cursor-pointer border border-[#302D46]"
                        >
                          {p >= 1000000 ? `${p / 1000000}M` : p >= 1000 ? `${p / 1000}K` : p} LOT
                        </button>
                      ))
                    : [100, 500, 1000, 2500, 10000, 50000].map((p) => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => setCashierAmount(p.toString())}
                          className="px-2 py-0.5 rounded-lg bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] text-[10px] font-semibold cursor-pointer border border-[#302D46]"
                        >
                          +{p.toLocaleString()}
                        </button>
                      ))}
                </div>
              </div>

              {/* Mandatory Reason */}
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">
                  Administrative Ledger Memo / Reason <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  minLength={3}
                  value={cashierReason}
                  onChange={(e) => setCashierReason(e.target.value)}
                  placeholder="e.g. Tournament reward prize, customer support reconciliation, admin grant"
                  className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              {/* Action Button */}
              <button
                type="submit"
                disabled={cashierSubmitting || !cashierUsername.trim()}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 via-purple-600 to-indigo-600 text-white font-bold text-sm shadow-xl hover:opacity-95 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Coins className="w-4 h-4" />
                <span>
                  {cashierSubmitting
                    ? 'Updating Authoritative Ledger...'
                    : `Execute ${cashierMode.toUpperCase()} (${cashierAmount} LOT) for @${cashierUsername || '...'}`}
                </span>
              </button>
            </form>
          </div>

          {/* Right Column: Live Target User Preview Card */}
          <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 shadow-xl flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-[#8B5CF6]" />
                Target User Dossier
              </h3>

              {cashierTargetUser ? (
                <div className="space-y-4 animate-fadeIn">
                  <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46]">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-lg font-bold text-white shadow overflow-hidden shrink-0">
                        {cashierTargetUser.avatarUrl ? (
                          <img src={cashierTargetUser.avatarUrl} alt={cashierTargetUser.username} className="w-full h-full object-cover" />
                        ) : (
                          cashierTargetUser.username.charAt(0).toUpperCase()
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-bold text-white text-base">@{cashierTargetUser.username}</h4>
                          {cashierTargetUser.isAdmin && (
                            <span className="text-[9px] bg-red-950 text-red-300 border border-red-800 px-1.5 py-0.2 rounded font-bold">
                              ADMIN
                            </span>
                          )}
                          {cashierTargetUser.vipBadge && (
                            <span className="text-[9px] bg-purple-950 text-purple-200 border border-purple-800 px-1.5 py-0.2 rounded font-semibold">
                              {cashierTargetUser.vipBadge}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-[#A5A3B8]">
                          Member since {new Date(cashierTargetUser.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs pt-3 border-t border-[#302D46]">
                      <div>
                        <span className="text-[10px] text-[#A5A3B8]">Current Balance</span>
                        <div
                          className="text-base font-black text-white"
                          title={`${cashierTargetUser.lotBalance.toLocaleString()} LOT`}
                        >
                          {formatCompactNumber(cashierTargetUser.lotBalance)} <span className="text-xs text-[#8B5CF6]">LOT</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-[#A5A3B8]">Account Status</span>
                        <div className="text-xs font-bold mt-1">
                          {cashierTargetUser.isBanned ? (
                            <span className="text-red-400">Suspended</span>
                          ) : (
                            <span className="text-emerald-400">Active & Verified</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Balance Adjustment Calculator Preview */}
                  <div className="p-4 rounded-2xl bg-[#202039]/60 border border-purple-500/30">
                    <span className="text-[10px] font-bold text-[#C4B5FD] uppercase tracking-wider block mb-2">
                      Transaction Preview
                    </span>
                    <div className="space-y-1.5 text-xs">
                      <div className="flex justify-between">
                        <span className="text-[#A5A3B8]">Starting Balance:</span>
                        <span className="font-mono text-white" title={`${currentTargetBalance.toLocaleString()} LOT`}>
                          {formatCompactNumber(currentTargetBalance)} LOT
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#A5A3B8]">Calculated Delta:</span>
                        <span
                          className={`font-mono font-bold ${previewDelta >= 0 ? 'text-emerald-400' : 'text-red-400'}`}
                          title={`${previewDelta >= 0 ? `+${previewDelta.toLocaleString()}` : previewDelta.toLocaleString()} LOT`}
                        >
                          {previewDelta >= 0 ? `+${formatCompactNumber(previewDelta)}` : formatCompactNumber(previewDelta)} LOT
                        </span>
                      </div>
                      <div className="pt-2 border-t border-[#302D46] flex justify-between font-bold">
                        <span className="text-white">Projected Balance:</span>
                        <span
                          className="text-base font-black text-white font-mono"
                          title={`${previewNewBalance.toLocaleString()} LOT`}
                        >
                          {formatCompactNumber(previewNewBalance)} LOT
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="py-12 px-4 rounded-2xl bg-[#121222] border border-dashed border-[#302D46] text-center text-xs text-[#A5A3B8]">
                  <Users className="w-8 h-8 mx-auto mb-2 text-[#302D46]" />
                  Enter a target username on the left and click "Lookup" to load their account profile and balance calculation.
                </div>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-[#302D46] flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-[#A5A3B8]">
              <div>
                💡 <strong>Tip:</strong> You can set anyone's balance directly by username without needing their internal account ID.
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('redemption')}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-gradient-to-r from-purple-900 to-indigo-900 border border-purple-500/40 text-purple-200 hover:text-white font-semibold cursor-pointer shrink-0 transition-colors"
              >
                <Gift className="w-3.5 h-3.5 text-amber-300" />
                <span>Open Code Maker Studio &rarr;</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 2. USER ACCOUNTS & DOSSIERS SEARCH */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'users' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white">Registered Ecosystem Accounts ({filteredUsers.length})</h2>
              <p className="text-xs text-[#A5A3B8]">Live search across all accounts, modify balances, assign VIP badges, or moderate status.</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative w-full sm:w-56">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A5A3B8]" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Search usernames..."
                  className="w-full pl-8 pr-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>
              <div className="flex bg-[#121222] border border-[#302D46] rounded-xl p-0.5 text-xs">
                {(['all', 'user', 'admin', 'banned'] as const).map((rf) => (
                  <button
                    key={rf}
                    onClick={() => setUserRoleFilter(rf)}
                    className={`px-2.5 py-1 rounded-lg capitalize cursor-pointer text-[11px] font-semibold ${
                      userRoleFilter === rf ? 'bg-[#8B5CF6] text-white' : 'text-[#A5A3B8] hover:text-white'
                    }`}
                  >
                    {rf}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#302D46] text-[#A5A3B8]">
                  <th className="pb-3">Username</th>
                  <th className="pb-3">Role & Prestige</th>
                  <th className="pb-3">LOT Balance</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3">Registered</th>
                  <th className="pb-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#302D46]/60">
                {filteredUsers.map((u) => (
                  <tr key={u.id} className="hover:bg-[#121222]/40 transition-colors">
                    <td className="py-3 font-bold text-white">
                      @{u.username}
                      {u.id === user.id && <span className="ml-1 text-[10px] text-[#C4B5FD]">(You)</span>}
                    </td>
                    <td className="py-3">
                      <div className="flex items-center gap-1.5">
                        {u.isAdmin ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-800">
                            Admin
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] bg-[#202039] text-[#A5A3B8]">
                            User
                          </span>
                        )}
                        {u.vipBadge && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-purple-950 text-purple-200 border border-purple-800 font-semibold">
                            {u.vipBadge}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 font-semibold text-[#C4B5FD]" title={`${u.lotBalance.toLocaleString()} LOT`}>
                      {formatCompactNumber(u.lotBalance)} LOT
                    </td>
                    <td className="py-3">
                      {u.isBanned ? (
                        <span className="text-red-400 font-bold text-[11px]">Banned</span>
                      ) : (
                        <span className="text-emerald-400 font-medium text-[11px]">Active</span>
                      )}
                    </td>
                    <td className="py-3 text-[#A5A3B8]">{new Date(u.createdAt).toLocaleDateString()}</td>
                    <td className="py-3 text-right space-x-1.5">
                      <button
                        onClick={() => {
                          setCashierUsername(u.username);
                          setActiveTab('cashier');
                          handleLookupUser(u.username);
                        }}
                        className="px-2 py-1 rounded-lg bg-emerald-950/70 hover:bg-emerald-900 text-emerald-200 border border-emerald-800 text-[10px] font-semibold"
                        title="Set LOT balance directly"
                      >
                        Set LOT
                      </button>
                      <button
                        onClick={() => {
                          setVipTargetUser(u);
                          setVipBadgeChoice(u.vipBadge || '⭐ Verified VIP');
                        }}
                        className="px-2 py-1 rounded-lg bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] border border-[#302D46] text-[10px]"
                        title="VIP badge"
                      >
                        VIP
                      </button>
                      <button
                        onClick={() => {
                          setSelectedUserForPassword(u);
                          setNewPassword('');
                        }}
                        className="px-2 py-1 rounded-lg bg-[#202039] hover:bg-[#302D46] text-white border border-[#302D46] text-[10px]"
                        title="Reset password"
                      >
                        Password
                      </button>
                      {u.id !== user.id && (
                        <>
                          <button
                            onClick={() => handleToggleBan(u)}
                            className={`px-2 py-1 rounded-lg border text-[10px] ${
                              u.isBanned
                                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                                : 'bg-amber-950/60 text-amber-300 border-amber-800'
                            }`}
                          >
                            {u.isBanned ? 'Unban' : 'Ban'}
                          </button>
                          <button
                            onClick={() => handleDeleteUser(u)}
                            className="px-2 py-1 rounded-lg bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-800 text-[10px]"
                            title="Delete user"
                          >
                            Delete
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 3. GLOBAL TRANSACTIONS & LEDGER SEARCH */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'transactions' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white">Global Ledger & Transactions Search</h2>
              <p className="text-xs text-[#A5A3B8]">Immutable history of all financial transactions across the ecosystem.</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A5A3B8]" />
                <input
                  type="text"
                  value={txSearch}
                  onChange={(e) => setTxSearch(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && fetchTransactions()}
                  placeholder="Search memo, ID, user..."
                  className="w-full pl-8 pr-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>
              <select
                value={txTypeFilter}
                onChange={(e) => {
                  setTxTypeFilter(e.target.value);
                  setTimeout(() => fetchTransactions(), 100);
                }}
                className="bg-[#121222] border border-[#302D46] rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
              >
                <option value="">All Types</option>
                <option value="admin_adjustment">Admin Adjustment</option>
                <option value="vpay_send">VPay Send</option>
                <option value="vpay_receive">VPay Receive</option>
                <option value="shop_purchase">Shop Purchase</option>
                <option value="stock_buy">Stock Buy</option>
                <option value="stock_sell">Stock Sell</option>
                <option value="minigame_reward">Minigame Reward</option>
                <option value="redemption">Redemption</option>
              </select>
              <button
                onClick={fetchTransactions}
                disabled={txLoading}
                className="p-1.5 bg-[#202039] hover:bg-[#302D46] border border-[#302D46] rounded-xl text-white cursor-pointer"
                title="Refresh transactions"
              >
                <RefreshCw className={`w-4 h-4 ${txLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#302D46] text-[#A5A3B8] sticky top-0 bg-[#19192B]">
                  <th className="pb-3">Timestamp</th>
                  <th className="pb-3">Transaction ID</th>
                  <th className="pb-3">Type</th>
                  <th className="pb-3">Delta</th>
                  <th className="pb-3">Balance After</th>
                  <th className="pb-3">Description</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#302D46]/60">
                {transactions.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-[#A5A3B8]">
                      No transactions found matching your search.
                    </td>
                  </tr>
                ) : (
                  transactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-[#121222]/40 transition-colors">
                      <td className="py-3 text-[#A5A3B8] whitespace-nowrap">
                        {new Date(tx.createdAt).toLocaleString()}
                      </td>
                      <td className="py-3 font-mono text-[10px] text-[#A5A3B8]">{tx.id}</td>
                      <td className="py-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#202039] text-[#C4B5FD] border border-[#302D46]">
                          {tx.type}
                        </span>
                      </td>
                      <td
                        className={`py-3 font-bold ${tx.amount >= 0 ? 'text-emerald-400' : 'text-red-400'}`}
                        title={`${tx.amount >= 0 ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()} LOT`}
                      >
                        {tx.amount >= 0 ? `+${formatCompactNumber(tx.amount)}` : formatCompactNumber(tx.amount)} LOT
                      </td>
                      <td className="py-3 font-mono text-white" title={tx.balanceAfter !== undefined ? `${tx.balanceAfter.toLocaleString()} LOT` : undefined}>
                        {tx.balanceAfter !== undefined ? `${formatCompactNumber(tx.balanceAfter)} LOT` : '-'}
                      </td>
                      <td className="py-3 text-[#F5F3FF] max-w-xs truncate">{tx.description}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 4. VPAY TRANSFERS AUDIT & REVERSE */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'vpay' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white">VPay Peer-to-Peer Transfers Audit</h2>
              <p className="text-xs text-[#A5A3B8]">Inspect transfers between accounts and execute emergency admin reversals.</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A5A3B8]" />
                <input
                  type="text"
                  value={vpaySearch}
                  onChange={(e) => setVpaySearch(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && fetchVpayTransfers()}
                  placeholder="Search sender, recipient, note..."
                  className="w-full pl-8 pr-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>
              <button
                onClick={fetchVpayTransfers}
                disabled={vpayLoading}
                className="p-1.5 bg-[#202039] hover:bg-[#302D46] border border-[#302D46] rounded-xl text-white cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${vpayLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#302D46] text-[#A5A3B8] sticky top-0 bg-[#19192B]">
                  <th className="pb-3">Timestamp</th>
                  <th className="pb-3">Sender</th>
                  <th className="pb-3">Recipient</th>
                  <th className="pb-3">Amount</th>
                  <th className="pb-3">Memo Note</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Emergency Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#302D46]/60">
                {vpayTransfers.map((tr) => (
                  <tr key={tr.id} className="hover:bg-[#121222]/40 transition-colors">
                    <td className="py-3 text-[#A5A3B8] whitespace-nowrap">
                      {new Date(tr.createdAt).toLocaleString()}
                    </td>
                    <td className="py-3 font-bold text-white">@{tr.senderUsername}</td>
                    <td className="py-3 font-bold text-white">@{tr.recipientUsername}</td>
                    <td className="py-3 font-bold text-[#C4B5FD]" title={`${tr.amount.toLocaleString()} LOT`}>
                      {formatCompactNumber(tr.amount)} LOT
                      {tr.amount >= 5000 && (
                        <span className="ml-1.5 text-[9px] bg-amber-950 text-amber-300 border border-amber-800 px-1 py-0.2 rounded font-bold">
                          HIGH VALUE
                        </span>
                      )}
                    </td>
                    <td className="py-3 text-[#A5A3B8] max-w-xs truncate">{tr.note || 'No memo'}</td>
                    <td className="py-3">
                      {tr.reversed ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-800">
                          Reversed
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                          Completed
                        </span>
                      )}
                    </td>
                    <td className="py-3 text-right">
                      {!tr.reversed && (
                        <button
                          onClick={() => handleReverseVPay(tr.id)}
                          className="px-2.5 py-1 rounded-lg bg-red-950/70 hover:bg-red-900 border border-red-800 text-red-200 text-[10px] font-semibold cursor-pointer"
                        >
                          Reverse Transfer
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 5. VSTOCKS CONTROLLER & PORTFOLIOS SEARCH */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'vstocks' && (
        <div className="space-y-6">
          {/* Price Override Station */}
          <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
            <h2 className="text-lg font-bold text-white mb-1">VStocks Real-Time Market Controller</h2>
            <p className="text-xs text-[#A5A3B8] mb-6">
              Calibrate stock market valuation, set price targets, or trigger macro bull/bear events across instruments.
            </p>

            <form onSubmit={handleOverrideStockPrice} className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Select Instrument</label>
                <select
                  value={selectedStockForPrice}
                  onChange={(e) => {
                    setSelectedStockForPrice(e.target.value);
                    const s = stocks.find((item) => item.symbol === e.target.value);
                    if (s) setOverridePriceVal(s.currentPrice.toString());
                  }}
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white font-bold text-xs focus:outline-none"
                >
                  {stocks.map((s) => (
                    <option key={s.symbol} value={s.symbol}>
                      {s.symbol} - {s.name} ({s.currentPrice} LOT)
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">New Target Price (LOT)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.1"
                  required
                  value={overridePriceVal}
                  onChange={(e) => setOverridePriceVal(e.target.value)}
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white font-mono font-bold text-xs focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Reason / Market Memo</label>
                <input
                  type="text"
                  required
                  value={overrideStockReason}
                  onChange={(e) => setOverrideStockReason(e.target.value)}
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none"
                />
              </div>
              <div className="flex items-end">
                <button
                  type="submit"
                  disabled={stockUpdating}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white font-bold text-xs shadow-md cursor-pointer"
                >
                  {stockUpdating ? 'Updating Price...' : 'Set Stock Price'}
                </button>
              </div>
            </form>

            {/* Quick Macro Event Buttons */}
            <div className="mt-6 pt-4 border-t border-[#302D46] flex flex-wrap items-center gap-3">
              <span className="text-xs text-[#A5A3B8] font-semibold">Macro Events:</span>
              <button
                type="button"
                onClick={() => handleMarketEvent('surge')}
                className="px-3 py-1.5 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Trigger Bull Surge (+15%)</span>
              </button>
              <button
                type="button"
                onClick={() => handleMarketEvent('dip')}
                className="px-3 py-1.5 rounded-xl bg-red-950/80 hover:bg-red-900 border border-red-500/40 text-red-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <TrendingUp className="w-3.5 h-3.5 rotate-180" />
                <span>Trigger Bear Correction (-15%)</span>
              </button>
            </div>
          </div>

          {/* Portfolios Search & Force Liquidation */}
          <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <h3 className="text-base font-bold text-white">User Stock Holdings & Portfolios ({filteredPortfolios.length})</h3>
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A5A3B8]" />
                <input
                  type="text"
                  value={portfolioSearch}
                  onChange={(e) => setPortfolioSearch(e.target.value)}
                  placeholder="Search symbol or user UID..."
                  className="w-full pl-8 pr-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none"
                />
              </div>
            </div>

            <div className="overflow-x-auto max-h-[400px]">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#302D46] text-[#A5A3B8]">
                    <th className="pb-3">Symbol</th>
                    <th className="pb-3">Shares Owned</th>
                    <th className="pb-3">Avg Buy Price</th>
                    <th className="pb-3">User UID</th>
                    <th className="pb-3 text-right">Admin Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#302D46]/60">
                  {filteredPortfolios.map((p) => (
                    <tr key={p.id} className="hover:bg-[#121222]/40 transition-colors">
                      <td className="py-3 font-mono font-bold text-white text-sm">{p.symbol}</td>
                      <td className="py-3 font-bold text-[#C4B5FD]">{p.quantity.toLocaleString()}</td>
                      <td className="py-3 text-white font-mono">{p.averageBuyPrice} LOT</td>
                      <td className="py-3 font-mono text-[11px] text-[#A5A3B8]">{p.userId}</td>
                      <td className="py-3 text-right">
                        <button
                          onClick={() => handleLiquidateStock(p.id, p.symbol)}
                          className="px-2.5 py-1 rounded-lg bg-amber-950/70 hover:bg-amber-900 border border-amber-800 text-amber-200 text-[10px] font-semibold cursor-pointer"
                        >
                          Force Liquidate
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 6. SHOP CATALOG & INVENTORY EDITOR */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'shop' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white">LOT Shop Catalog Management ({filteredShop.length})</h2>
              <p className="text-xs text-[#A5A3B8]">Search items, update LOT pricing, restock items, or modify status.</p>
            </div>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A5A3B8]" />
              <input
                type="text"
                value={shopSearch}
                onChange={(e) => setShopSearch(e.target.value)}
                placeholder="Search item title or seller..."
                className="w-full pl-8 pr-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none"
              />
            </div>
          </div>

          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#302D46] text-[#A5A3B8]">
                  <th className="pb-3">Item Title</th>
                  <th className="pb-3">Category</th>
                  <th className="pb-3">Seller</th>
                  <th className="pb-3">Price LOT</th>
                  <th className="pb-3">Stock Available</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Edit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#302D46]/60">
                {filteredShop.map((item) => (
                  <tr key={item.id} className="hover:bg-[#121222]/40 transition-colors">
                    <td className="py-3 font-bold text-white">{item.title}</td>
                    <td className="py-3 text-[#A5A3B8]">{item.category}</td>
                    <td className="py-3 text-white">@{item.sellerUsername}</td>
                    <td className="py-3 font-bold text-[#C4B5FD]" title={`${item.priceLot.toLocaleString()} LOT`}>
                      {formatCompactNumber(item.priceLot)} LOT
                    </td>
                    <td className="py-3 text-white">{item.stock}</td>
                    <td className="py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.status === 'active' ? 'bg-emerald-950 text-emerald-300' : 'bg-red-950 text-red-300'
                      }`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="py-3 text-right">
                      <button
                        onClick={() => {
                          setEditingListing(item);
                          setEditPriceLot(item.priceLot.toString());
                          setEditStockCount(item.stock.toString());
                          setEditListingStatus(item.status);
                        }}
                        className="px-2.5 py-1 rounded bg-[#202039] hover:bg-[#302D46] border border-[#302D46] text-white text-[10px]"
                      >
                        Configure
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 7. ORDERS & DISPUTE REFUNDS */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'orders' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white">Orders & Trade Dispute Resolution ({filteredOrders.length})</h2>
              <p className="text-xs text-[#A5A3B8]">Review marketplace orders and execute authoritative refunds for buyer protection.</p>
            </div>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A5A3B8]" />
              <input
                type="text"
                value={orderSearch}
                onChange={(e) => setOrderSearch(e.target.value)}
                placeholder="Search order ID, buyer, seller..."
                className="w-full pl-8 pr-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none"
              />
            </div>
          </div>

          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#302D46] text-[#A5A3B8]">
                  <th className="pb-3">Order ID</th>
                  <th className="pb-3">Item</th>
                  <th className="pb-3">Buyer</th>
                  <th className="pb-3">Seller</th>
                  <th className="pb-3">Total LOT</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Dispute Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#302D46]/60">
                {filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-[#121222]/40 transition-colors">
                    <td className="py-3 font-mono text-[10px] text-[#A5A3B8]">{ord.id}</td>
                    <td className="py-3 font-bold text-white">{ord.listingTitle}</td>
                    <td className="py-3 text-white">@{ord.buyerUsername}</td>
                    <td className="py-3 text-white">@{ord.sellerUsername}</td>
                    <td className="py-3 font-bold text-[#C4B5FD]" title={`${ord.totalLot.toLocaleString()} LOT`}>
                      {formatCompactNumber(ord.totalLot)} LOT
                    </td>
                    <td className="py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        ord.status === 'Refunded' ? 'bg-red-950 text-red-300' : 'bg-[#202039] text-white'
                      }`}>
                        {ord.status}
                      </span>
                    </td>
                    <td className="py-3 text-right">
                      {ord.status !== 'Refunded' && (
                        <button
                          onClick={() => handleOrderRefund(ord.id)}
                          className="px-2.5 py-1 rounded bg-red-950/70 hover:bg-red-900 border border-red-800 text-red-200 text-[10px] font-semibold cursor-pointer"
                        >
                          Force Refund
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 8. REDEMPTION PROMO CODES & CODE MAKER STUDIO */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'redemption' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Studio Header Card with Mode Toggle */}
          <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#302D46] pb-5 mb-6">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-amber-950 to-purple-950 border border-amber-500/40 text-amber-200 text-xs font-bold mb-2">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Code Maker Studio & Voucher Mint
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-white">Promotional Code Generator</h2>
                <p className="text-xs text-[#A5A3B8] mt-1 max-w-xl">
                  Mint promotional gift vouchers with custom LOT rewards, claim limits, and expiry dates, or batch-generate codes for giveaways.
                </p>
              </div>

              {/* Mode Switcher */}
              <div className="flex bg-[#121222] p-1 rounded-xl border border-[#302D46] self-start sm:self-auto shrink-0">
                <button
                  type="button"
                  onClick={() => setCodeMakerMode('single')}
                  className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    codeMakerMode === 'single'
                      ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow'
                      : 'text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  Single Code Mint
                </button>
                <button
                  type="button"
                  onClick={() => setCodeMakerMode('batch')}
                  className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    codeMakerMode === 'batch'
                      ? 'bg-gradient-to-r from-amber-600 to-purple-600 text-white shadow'
                      : 'text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  Batch Vouchers (5-50x)
                </button>
              </div>
            </div>

            {/* SINGLE CODE FORM */}
            {codeMakerMode === 'single' ? (
              <form onSubmit={handleCreateCode} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  {/* Code Name Input */}
                  <div className="sm:col-span-2">
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-semibold text-[#A5A3B8]">Code String / Voucher Name</label>
                      <button
                        type="button"
                        onClick={handleGenerateRandomCode}
                        className="text-[11px] text-[#C4B5FD] hover:text-white flex items-center gap-1 cursor-pointer font-medium"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>🎲 Generate Random</span>
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        value={newCodeName}
                        onChange={(e) => setNewCodeName(e.target.value.toUpperCase().replace(/\s+/g, ''))}
                        placeholder="e.g. LOT-BONUS2026"
                        className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-mono font-bold text-sm tracking-wide focus:outline-none focus:border-[#8B5CF6]"
                      />
                    </div>
                    {/* Quick Suggestions */}
                    <div className="flex items-center gap-1.5 mt-2 flex-wrap text-[10px]">
                      <span className="text-[#A5A3B8]">Suggestions:</span>
                      {['LOT-WELCOME', 'LOT-VIP2026', 'LOT-BONUS', 'LOT-MEGA', 'VIRAT-GIFT'].map((sug) => (
                        <button
                          key={sug}
                          type="button"
                          onClick={() => setNewCodeName(sug)}
                          className="px-2 py-0.5 rounded-md bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] font-mono cursor-pointer transition-colors"
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Reward Amount */}
                  <div>
                    <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">LOT Reward Amount</label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={newCodeReward}
                      onChange={(e) => setNewCodeReward(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-mono font-bold text-sm focus:outline-none focus:border-[#8B5CF6]"
                    />
                    {/* Preset amounts */}
                    <div className="flex gap-1 mt-2 flex-wrap">
                      {['100', '250', '500', '1000', '5000'].map((amt) => (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => setNewCodeReward(amt)}
                          className={`px-1.5 py-0.5 text-[10px] rounded font-semibold cursor-pointer ${
                            newCodeReward === amt ? 'bg-purple-600 text-white' : 'bg-[#202039] text-[#A5A3B8] hover:text-white'
                          }`}
                        >
                          +{amt}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Max Claims */}
                  <div>
                    <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Max Total Claims</label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={newCodeMax}
                      onChange={(e) => setNewCodeMax(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-mono font-bold text-sm focus:outline-none focus:border-[#8B5CF6]"
                    />
                    {/* Preset claims */}
                    <div className="flex gap-1 mt-2 flex-wrap">
                      {[
                        { label: '1 (Single)', val: '1' },
                        { label: '10', val: '10' },
                        { label: '50', val: '50' },
                        { label: '100', val: '100' },
                        { label: 'Unlimited', val: '9999' },
                      ].map((c) => (
                        <button
                          key={c.val}
                          type="button"
                          onClick={() => setNewCodeMax(c.val)}
                          className={`px-1.5 py-0.5 text-[10px] rounded font-semibold cursor-pointer ${
                            newCodeMax === c.val ? 'bg-purple-600 text-white' : 'bg-[#202039] text-[#A5A3B8] hover:text-white'
                          }`}
                        >
                          {c.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Optional Expiry Date */}
                <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-semibold text-[#A5A3B8]">Optional Expiry:</label>
                    <input
                      type="date"
                      value={newCodeExpiry}
                      onChange={(e) => setNewCodeExpiry(e.target.value)}
                      className="px-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                    />
                    {newCodeExpiry && (
                      <button
                        type="button"
                        onClick={() => setNewCodeExpiry('')}
                        className="text-xs text-[#A5A3B8] hover:text-white cursor-pointer"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={createCodeLoading || !newCodeName.trim()}
                    className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-[#8B5CF6] to-[#A855F7] text-white font-bold text-xs shadow-lg hover:opacity-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Gift className="w-4 h-4" />
                    <span>{createCodeLoading ? 'Minting Code...' : 'Mint Promotional Code'}</span>
                  </button>
                </div>
              </form>
            ) : (
              /* BATCH CODE FORM */
              <form onSubmit={handleBatchCreateCodes} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Prefix</label>
                    <input
                      type="text"
                      required
                      value={batchPrefix}
                      onChange={(e) => setBatchPrefix(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))}
                      placeholder="e.g. VIP or GIFT"
                      className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-mono font-bold text-sm focus:outline-none focus:border-[#8B5CF6]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Number of Vouchers</label>
                    <select
                      value={batchCount}
                      onChange={(e) => setBatchCount(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-sm focus:outline-none focus:border-[#8B5CF6]"
                    >
                      <option value="5">5 Unique Codes</option>
                      <option value="10">10 Unique Codes</option>
                      <option value="20">20 Unique Codes</option>
                      <option value="50">50 Unique Codes</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">LOT Reward per Code</label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={batchReward}
                      onChange={(e) => setBatchReward(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-mono font-bold text-sm focus:outline-none focus:border-[#8B5CF6]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Claims per Voucher</label>
                    <select
                      value={batchMaxClaims}
                      onChange={(e) => setBatchMaxClaims(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-sm focus:outline-none focus:border-[#8B5CF6]"
                    >
                      <option value="1">1 Claim (Single-Use)</option>
                      <option value="5">5 Claims</option>
                      <option value="10">10 Claims</option>
                      <option value="50">50 Claims</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    disabled={batchLoading}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 via-purple-600 to-indigo-600 text-white font-bold text-xs shadow-lg hover:opacity-95 transition-all cursor-pointer flex items-center gap-2"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>{batchLoading ? 'Generating Batch Codes...' : `Generate ${batchCount} Batch Voucher Codes`}</span>
                  </button>
                </div>

                {/* Batch Generated Result Box */}
                {batchGeneratedCodes.length > 0 && (
                  <div className="mt-4 p-4 rounded-2xl bg-[#121222] border border-amber-500/40 animate-fadeIn">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                        <CheckCircle className="w-4 h-4" />
                        {batchGeneratedCodes.length} Codes Minted Ready for Distribution:
                      </span>
                      <button
                        type="button"
                        onClick={handleCopyAllBatchCodes}
                        className="px-3 py-1 rounded-lg bg-[#202039] hover:bg-[#302D46] border border-[#302D46] text-xs font-semibold text-[#C4B5FD] flex items-center gap-1.5 cursor-pointer"
                      >
                        {copiedBatchAll ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedBatchAll ? 'All Codes Copied!' : 'Copy All to Clipboard'}</span>
                      </button>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 max-h-48 overflow-y-auto">
                      {batchGeneratedCodes.map((c) => (
                        <div
                          key={c.id}
                          onClick={() => handleCopyCode(c.code)}
                          className="p-2 rounded-xl bg-[#19192B] border border-[#302D46] hover:border-[#8B5CF6] flex items-center justify-between text-xs cursor-pointer group"
                        >
                          <span className="font-mono font-bold text-white text-[11px] truncate">{c.code}</span>
                          <span className="text-[10px] text-emerald-400 font-bold shrink-0 ml-1">+{c.rewardLot}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </form>
            )}
          </div>

          {/* CODES DIRECTORY TABLE & SEARCH */}
          <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Gift className="w-4 h-4 text-[#8B5CF6]" />
                  Active & Historical Codes ({filteredCodes.length})
                </h3>
                <p className="text-xs text-[#A5A3B8]">
                  Manage minted codes, monitor claim rates, toggle status, or permanently delete codes.
                </p>
              </div>
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A5A3B8]" />
                <input
                  type="text"
                  value={codeSearch}
                  onChange={(e) => setCodeSearch(e.target.value)}
                  placeholder="Filter code by name..."
                  className="w-full pl-8 pr-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#302D46] text-[#A5A3B8]">
                    <th className="pb-3">Code String</th>
                    <th className="pb-3">Reward</th>
                    <th className="pb-3">Claims Progress</th>
                    <th className="pb-3">Status</th>
                    <th className="pb-3">Expires</th>
                    <th className="pb-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#302D46]/60">
                  {filteredCodes.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-xs text-[#A5A3B8]">
                        No promotional codes match your search criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredCodes.map((c) => {
                      const isExhausted = c.claimsCount >= c.maxClaims;
                      const progressPct = Math.min(100, Math.round((c.claimsCount / c.maxClaims) * 100));
                      const isCopied = copiedCode === c.code;

                      return (
                        <tr key={c.id} className="hover:bg-[#121222]/40 transition-colors">
                          <td className="py-3">
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-black text-white text-sm tracking-wide">{c.code}</span>
                              <button
                                type="button"
                                onClick={() => handleCopyCode(c.code)}
                                title="Copy code string"
                                className="p-1 rounded-md bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] transition-colors cursor-pointer"
                              >
                                {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                              </button>
                            </div>
                          </td>
                          <td className="py-3 font-bold text-emerald-400" title={`+${c.rewardLot.toLocaleString()} LOT`}>
                            +{formatCompactNumber(c.rewardLot)} LOT
                          </td>
                          <td className="py-3">
                            <div className="space-y-1 w-32">
                              <div className="flex justify-between text-[10px] text-[#A5A3B8]">
                                <span>{c.claimsCount} claimed</span>
                                <span>of {c.maxClaims}</span>
                              </div>
                              <div className="w-full h-1.5 rounded-full bg-[#121222] overflow-hidden">
                                <div
                                  className={`h-full rounded-full ${
                                    isExhausted ? 'bg-amber-500' : 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7]'
                                  }`}
                                  style={{ width: `${progressPct}%` }}
                                />
                              </div>
                            </div>
                          </td>
                          <td className="py-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                !c.isActive
                                  ? 'bg-red-950 text-red-300 border border-red-800'
                                  : isExhausted
                                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                  : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              }`}
                            >
                              {!c.isActive ? 'Disabled' : isExhausted ? 'Fully Claimed' : 'Active'}
                            </span>
                          </td>
                          <td className="py-3 text-[#A5A3B8]">
                            {c.expiresAt ? new Date(c.expiresAt).toLocaleDateString() : 'Never'}
                          </td>
                          <td className="py-3 text-right">
                            <div className="inline-flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleToggleCode(c.code, c.isActive)}
                                className={`px-2.5 py-1 rounded text-[10px] font-semibold cursor-pointer border transition-colors ${
                                  c.isActive
                                    ? 'bg-[#202039] hover:bg-[#302D46] border-[#302D46] text-white'
                                    : 'bg-emerald-950/70 hover:bg-emerald-900 border-emerald-800 text-emerald-200'
                                }`}
                              >
                                {c.isActive ? 'Disable' : 'Enable'}
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteCode(c.code)}
                                title="Permanently delete code"
                                className="p-1 rounded bg-red-950/50 hover:bg-red-900 border border-red-800/80 text-red-300 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* LIVE CLAIMANTS AUDIT */}
            <div className="mt-8 pt-6 border-t border-[#302D46]">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Users className="w-4 h-4 text-emerald-400" />
                    Live Claimants Inspection Log ({claimants.length})
                  </h4>
                  <p className="text-[11px] text-[#A5A3B8]">
                    Real-time feed of users who claimed promotional codes across the platform.
                  </p>
                </div>
                <div className="relative w-full sm:w-56">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-[#A5A3B8]" />
                  <input
                    type="text"
                    value={claimantSearch}
                    onChange={(e) => setClaimantSearch(e.target.value)}
                    placeholder="Search claimant username..."
                    className="w-full pl-8 pr-3 py-1 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none"
                  />
                </div>
              </div>

              <div className="max-h-60 overflow-y-auto space-y-2">
                {filteredClaimants.length === 0 ? (
                  <p className="text-xs text-[#A5A3B8] py-4 text-center">No matching redemption claims recorded.</p>
                ) : (
                  filteredClaimants.map((cl) => (
                    <div
                      key={cl.id}
                      className="p-3 rounded-xl bg-[#121222] border border-[#302D46] flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-lg bg-purple-900/60 border border-purple-500/30 flex items-center justify-center text-[10px] font-bold text-white">
                          @
                        </div>
                        <div>
                          <span className="font-bold text-white">@{cl.username}</span> claimed code{' '}
                          <strong className="text-[#C4B5FD] font-mono">{cl.code}</strong>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-emerald-400 font-bold block">+{cl.rewardLot} LOT</span>
                        <span className="text-[10px] text-[#A5A3B8]">{new Date(cl.claimedAt).toLocaleString()}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 9. BATCH TREASURY AIRDROP */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'airdrop' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="border-b border-[#302D46] pb-4">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg bg-purple-950/80 border border-purple-500/40 text-purple-300 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              Treasury Multi-User Airdrop Engine
            </div>
            <h2 className="text-xl font-bold text-white">Mass LOT Distribution</h2>
            <p className="text-xs text-[#A5A3B8] mt-1">
              Airdrop LOT tokens across the community to celebrate milestones, conduct marketing incentives, or grant rewards.
            </p>
          </div>

          <form onSubmit={handleBatchAirdrop} className="space-y-4 max-w-xl">
            <div>
              <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Target Audience</label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
                  <input
                    type="radio"
                    name="airdropTarget"
                    checked={airdropTarget === 'all'}
                    onChange={() => setAirdropTarget('all')}
                  />
                  <span>All Registered Active Users ({users.filter(u => !u.isBanned).length} recipients)</span>
                </label>
                <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
                  <input
                    type="radio"
                    name="airdropTarget"
                    checked={airdropTarget === 'custom'}
                    onChange={() => setAirdropTarget('custom')}
                  />
                  <span>Specific Usernames List</span>
                </label>
              </div>
            </div>

            {airdropTarget === 'custom' && (
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">
                  Usernames (Comma Separated)
                </label>
                <input
                  type="text"
                  required={airdropTarget === 'custom'}
                  value={airdropUsernames}
                  onChange={(e) => setAirdropUsernames(e.target.value)}
                  placeholder="e.g. alice, bob, charlie"
                  className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">LOT Amount Per User</label>
              <input
                type="number"
                min="1"
                required
                value={airdropAmount}
                onChange={(e) => setAirdropAmount(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-mono font-bold text-sm focus:outline-none focus:border-[#8B5CF6]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Notification Memo</label>
              <input
                type="text"
                required
                value={airdropMemo}
                onChange={(e) => setAirdropMemo(e.target.value)}
                placeholder="e.g. Community holiday celebration bonus!"
                className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
              />
            </div>

            <button
              type="submit"
              disabled={airdropLoading}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs shadow-md cursor-pointer flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>{airdropLoading ? 'Processing Airdrop...' : 'Launch Treasury Airdrop'}</span>
            </button>
          </form>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 10. MINIGAMES CONTROLLER */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'minigames' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="border-b border-[#302D46] pb-4">
            <h2 className="text-xl font-bold text-white">Minigames Engine & Cooldown Controller</h2>
            <p className="text-xs text-[#A5A3B8] mt-1">
              Reset player rate-limit cooldowns, clear challenge replay restrictions, or test reward distributions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-2xl bg-[#121222] border border-[#302D46] space-y-4">
              <h3 className="font-bold text-white text-sm">Clear Cooldown for Specific Player</h3>
              <p className="text-xs text-[#A5A3B8]">
                Allows a player to immediately replay games and claim rewards without waiting for timer expiry.
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={cooldownTargetUser}
                  onChange={(e) => setCooldownTargetUser(e.target.value)}
                  placeholder="Target username..."
                  className="flex-1 px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs"
                />
                <button
                  onClick={() => handleResetCooldown(false)}
                  disabled={cooldownResetting || !cooldownTargetUser.trim()}
                  className="px-4 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-semibold"
                >
                  Reset User
                </button>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-[#121222] border border-[#302D46] space-y-4 flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-white text-sm">Global Server Cooldown Purge</h3>
                <p className="text-xs text-[#A5A3B8]">
                  Clears all active minigame and daily challenge cooldown locks for every player in the ecosystem.
                </p>
              </div>
              <button
                onClick={() => handleResetCooldown(true)}
                disabled={cooldownResetting}
                className="w-full py-2.5 rounded-xl bg-amber-950/70 hover:bg-amber-900 border border-amber-800 text-amber-200 text-xs font-bold"
              >
                Clear All Player Cooldowns Globally
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 11. VIP PRESTIGE BADGES */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'vip' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="border-b border-[#302D46] pb-4">
            <h2 className="text-xl font-bold text-white">VIP Status & Prestige Badge Studio</h2>
            <p className="text-xs text-[#A5A3B8] mt-1">
              Assign honorary status badges to notable community members. Badges display across VPay, LOT Shop, and public profiles.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white">Select User to Award</h3>
              <div className="max-h-72 overflow-y-auto space-y-1.5 p-2 rounded-2xl bg-[#121222] border border-[#302D46]">
                {users.map((u) => (
                  <div
                    key={u.id}
                    onClick={() => {
                      setVipTargetUser(u);
                      setVipBadgeChoice(u.vipBadge || '⭐ Verified VIP');
                    }}
                    className={`p-2.5 rounded-xl flex items-center justify-between text-xs cursor-pointer transition-colors ${
                      vipTargetUser?.id === u.id ? 'bg-[#8B5CF6]/30 border border-[#8B5CF6]' : 'hover:bg-[#19192B]'
                    }`}
                  >
                    <div>
                      <span className="font-bold text-white">@{u.username}</span>
                      {u.vipBadge && (
                        <span className="ml-2 text-[10px] bg-purple-950 text-purple-200 px-1.5 py-0.2 rounded font-semibold">
                          {u.vipBadge}
                        </span>
                      )}
                    </div>
                    <span className="text-[#A5A3B8] font-mono">{u.lotBalance.toLocaleString()} LOT</span>
                  </div>
                ))}
              </div>
            </div>

            {vipTargetUser ? (
              <form onSubmit={handleAssignVip} className="p-5 rounded-2xl bg-[#121222] border border-[#302D46] space-y-4">
                <h3 className="text-sm font-bold text-white">Configure Badge for @{vipTargetUser.username}</h3>
                <div>
                  <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Prestige Title Badge</label>
                  <select
                    value={vipBadgeChoice}
                    onChange={(e) => setVipBadgeChoice(e.target.value)}
                    className="w-full px-3 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-white text-xs font-bold"
                  >
                    <option value="⭐ Verified VIP">⭐ Verified VIP</option>
                    <option value="🐋 Ecosystem Whale">🐋 Ecosystem Whale</option>
                    <option value="🛡️ Guardian">🛡️ Guardian</option>
                    <option value="💎 Diamond Trader">💎 Diamond Trader</option>
                    <option value="⚡ Early Pioneer">⚡ Early Pioneer</option>
                    <option value="">None (Remove Badge)</option>
                  </select>
                </div>
                <button
                  type="submit"
                  disabled={vipSubmitting}
                  className="w-full py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-xs"
                >
                  {vipSubmitting ? 'Saving Badge...' : 'Save Prestige Badge'}
                </button>
              </form>
            ) : (
              <div className="p-8 rounded-2xl bg-[#121222] border border-dashed border-[#302D46] text-center text-xs text-[#A5A3B8] flex items-center justify-center">
                Select any user from the list on the left to assign or edit their VIP badge.
              </div>
            )}
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 12. NOTICES & DIRECT ADMIN ALERTS */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'notices' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Global Broadcast */}
          <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-4">
            <h2 className="text-base font-bold text-white">Global Broadcast Announcement</h2>
            <form onSubmit={handleCreateAnnouncement} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Headline</label>
                <input
                  type="text"
                  required
                  value={annTitle}
                  onChange={(e) => setAnnTitle(e.target.value)}
                  placeholder="e.g. Flash Market Surge Active!"
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Announcement Body</label>
                <textarea
                  rows={3}
                  required
                  value={annContent}
                  onChange={(e) => setAnnContent(e.target.value)}
                  placeholder="Message for all users..."
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs"
                />
              </div>
              <button
                type="submit"
                disabled={annLoading}
                className="px-5 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-xs"
              >
                {annLoading ? 'Broadcasting...' : 'Publish Global Notice'}
              </button>
            </form>

            <div className="mt-4 pt-4 border-t border-[#302D46] space-y-2">
              <span className="text-xs font-bold text-white block">Active Broadcasts</span>
              {announcements.map((a) => (
                <div key={a.id} className="p-3 rounded-xl bg-[#121222] border border-[#302D46] flex justify-between items-start text-xs">
                  <div>
                    <h5 className="font-bold text-white">{a.title}</h5>
                    <p className="text-[#A5A3B8] text-[11px] mt-0.5">{a.content}</p>
                  </div>
                  <button onClick={() => handleDeleteAnnouncement(a.id)} className="p-1 text-red-400 hover:text-white">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Direct Targeted Alert to Username */}
          <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-4">
            <h2 className="text-base font-bold text-white">Targeted Direct User Notification</h2>
            <form onSubmit={handleSendDirectMessage} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Target Username</label>
                <input
                  type="text"
                  required
                  value={directUsername}
                  onChange={(e) => setDirectUsername(e.target.value)}
                  placeholder="e.g. alice"
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Subject</label>
                <input
                  type="text"
                  required
                  value={directTitle}
                  onChange={(e) => setDirectTitle(e.target.value)}
                  placeholder="e.g. Security Verification Complete"
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Direct Message</label>
                <textarea
                  rows={3}
                  required
                  value={directMsg}
                  onChange={(e) => setDirectMsg(e.target.value)}
                  placeholder="Private official message delivered to target user's notification bell..."
                  className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs"
                />
              </div>
              <button
                type="submit"
                disabled={directLoading}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs"
              >
                {directLoading ? 'Sending...' : 'Send Direct Admin Alert'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 13. ANTI-CHEAT & WEALTH RADAR */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'radar' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-[#302D46] pb-4">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-400" />
                Anti-Cheat & Wealth Inequality Radar
              </h2>
              <p className="text-xs text-[#A5A3B8] mt-1">
                Automated detection of wealth concentration, rapid high-value transfers, and account moderation.
              </p>
            </div>
            <button
              onClick={fetchRadar}
              disabled={radarLoading}
              className="px-3 py-1.5 rounded-xl bg-[#202039] hover:bg-[#302D46] border border-[#302D46] text-white text-xs flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${radarLoading ? 'animate-spin' : ''}`} />
              <span>Rescan</span>
            </button>
          </div>

          {radarData && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Top 10 Richest Wallets */}
              <div className="p-5 rounded-2xl bg-[#121222] border border-[#302D46]">
                <h3 className="font-bold text-white text-sm mb-3">Top 10 Wealthiest Accounts (Whale Watch)</h3>
                <div className="space-y-2">
                  {radarData.topWallets.map((w: any, idx: number) => (
                    <div key={w.username} className="p-2.5 rounded-xl bg-[#19192B] border border-[#302D46] flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-5 text-[11px] font-bold text-[#A5A3B8]">#{idx + 1}</span>
                        <span className="font-bold text-white">@{w.username}</span>
                        {w.isAdmin && <span className="text-[9px] bg-red-950 text-red-300 px-1 rounded">ADMIN</span>}
                      </div>
                      <span className="font-mono font-bold text-[#C4B5FD]">{w.lotBalance.toLocaleString()} LOT</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* High-Value Transfer Monitor */}
              <div className="p-5 rounded-2xl bg-[#121222] border border-[#302D46]">
                <h3 className="font-bold text-white text-sm mb-3">High-Volume P2P Transfers (&gt;= 5,000 LOT)</h3>
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {radarData.largeTransfers.length === 0 ? (
                    <p className="text-xs text-[#A5A3B8] py-4 text-center">No suspicious large transfers found.</p>
                  ) : (
                    radarData.largeTransfers.map((t: any) => (
                      <div key={t.id} className="p-2.5 rounded-xl bg-[#19192B] border border-[#302D46] flex items-center justify-between text-xs">
                        <div>
                          <span className="font-bold text-white">@{t.senderUsername}</span> ➔{' '}
                          <span className="font-bold text-white">@{t.recipientUsername}</span>
                        </div>
                        <span className="font-mono font-bold text-amber-400">{t.amount.toLocaleString()} LOT</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 14. PROTECTED AUDIT LOGS SEARCH & EXPORT */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'logs' && (
        <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white">Authoritative Audit Trail ({filteredAuditLogs.length})</h2>
              <p className="text-xs text-[#A5A3B8]">Immutable system intervention log with timestamp, operator, and payload delta.</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#A5A3B8]" />
                <input
                  type="text"
                  value={logSearch}
                  onChange={(e) => setLogSearch(e.target.value)}
                  placeholder="Search action or details..."
                  className="w-full pl-8 pr-3 py-1.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none"
                />
              </div>
              <button
                onClick={handleExportAuditLogs}
                className="px-3 py-1.5 rounded-xl bg-[#202039] hover:bg-[#302D46] border border-[#302D46] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export JSON</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#302D46] text-[#A5A3B8] sticky top-0 bg-[#19192B]">
                  <th className="pb-3">Timestamp</th>
                  <th className="pb-3">Admin</th>
                  <th className="pb-3">Action</th>
                  <th className="pb-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#302D46]/60">
                {filteredAuditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-[#121222]/40 transition-colors">
                    <td className="py-3 text-[#A5A3B8] whitespace-nowrap">
                      {new Date(log.createdAt).toLocaleString()}
                    </td>
                    <td className="py-3 font-bold text-white">@{log.adminUsername}</td>
                    <td className="py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#202039] text-[#C4B5FD] border border-[#302D46]">
                        {log.action}
                      </span>
                    </td>
                    <td className="py-3 text-[#F5F3FF]">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* 15. PLATFORM METRICS */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'stats' && stats && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="p-5 rounded-2xl bg-[#19192B] border border-[#302D46]">
            <span className="text-[11px] text-[#A5A3B8]">Total Accounts</span>
            <div className="text-2xl font-black text-white mt-1">{stats.totalUsers}</div>
          </div>
          <div className="p-5 rounded-2xl bg-[#19192B] border border-[#302D46]">
            <span className="text-[11px] text-[#A5A3B8]">Circulating LOT</span>
            <div
              className="text-2xl font-black text-[#C4B5FD] mt-1"
              title={`${stats.circulatingLot.toLocaleString()} LOT`}
            >
              {formatCompactNumber(stats.circulatingLot)}
            </div>
          </div>
          <div className="p-5 rounded-2xl bg-[#19192B] border border-[#302D46]">
            <span className="text-[11px] text-[#A5A3B8]">Active Listings</span>
            <div className="text-2xl font-black text-white mt-1">{stats.activeListings}</div>
          </div>
          <div className="p-5 rounded-2xl bg-[#19192B] border border-[#302D46]">
            <span className="text-[11px] text-[#A5A3B8]">Shop Orders</span>
            <div className="text-2xl font-black text-emerald-400 mt-1">{stats.completedOrders}</div>
          </div>
          <div className="p-5 rounded-2xl bg-[#19192B] border border-[#302D46]">
            <span className="text-[11px] text-[#A5A3B8]">VStocks Trades</span>
            <div className="text-2xl font-black text-white mt-1">{stats.totalTrades}</div>
          </div>
          <div className="p-5 rounded-2xl bg-[#19192B] border border-[#302D46]">
            <span className="text-[11px] text-[#A5A3B8]">VPay Transfers</span>
            <div className="text-2xl font-black text-white mt-1">{stats.totalTransfers}</div>
          </div>
        </div>
      )}

      {/* Modal: Password Reset */}
      {selectedUserForPassword && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 text-[#F5F3FF]">
            <button
              onClick={() => setSelectedUserForPassword(null)}
              className="absolute top-4 right-4 p-2 text-[#A5A3B8] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <h3 className="text-lg font-bold text-white mb-1">Reset User Password</h3>
            <p className="text-xs text-[#A5A3B8] mb-4">Set a secure new password for @{selectedUserForPassword.username}</p>

            <form onSubmit={handleResetPassword} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">New Password</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter at least 6 characters"
                  className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-sm focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>
              <button
                type="submit"
                disabled={passwordLoading}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white font-bold text-xs shadow-md cursor-pointer"
              >
                {passwordLoading ? 'Updating Hash...' : 'Set New Password'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Shop Listing Configure */}
      {editingListing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 text-[#F5F3FF]">
            <button
              onClick={() => setEditingListing(null)}
              className="absolute top-4 right-4 p-2 text-[#A5A3B8] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <h3 className="text-lg font-bold text-white mb-1">Configure Shop Listing</h3>
            <p className="text-xs text-[#A5A3B8] mb-4">Item: {editingListing.title}</p>

            <form onSubmit={handleSaveListingEdit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Price (LOT)</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={editPriceLot}
                  onChange={(e) => setEditPriceLot(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-bold text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Available Stock Units</label>
                <input
                  type="number"
                  min="0"
                  required
                  value={editStockCount}
                  onChange={(e) => setEditStockCount(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-bold text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1">Listing Status</label>
                <select
                  value={editListingStatus}
                  onChange={(e) => setEditListingStatus(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs"
                >
                  <option value="active">Active</option>
                  <option value="sold_out">Sold Out</option>
                  <option value="delisted">Delisted</option>
                </select>
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white font-bold text-xs shadow-md cursor-pointer"
              >
                Save Listing Changes
              </button>
            </form>
          </div>
        </div>
      )}

      {/* LOT Shorts Content Moderation & Abuse Control */}
      {activeTab === 'shorts_mod' && <ShortsModerationPanel />}

      {/* YouTube Video Publisher Section */}
      {activeTab === 'youtube_publisher' && <YouTubePublisherPanel />}

      {/* LOT App Store Management Section (Upload, Delete, Moderate APKs) */}
      {activeTab === 'app_manager' && <AdminAppStorePanel />}
    </div>
  );
};
