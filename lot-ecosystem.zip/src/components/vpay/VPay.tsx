import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { VPayTransfer } from '../../types';
import {
  Send,
  ArrowDownLeft,
  ArrowUpRight,
  Copy,
  Check,
  Coins,
  ShieldCheck,
  AlertCircle,
  QrCode,
  Sparkles,
  Info,
  Clock,
  Camera,
  Maximize2,
  Download,
  X,
  Upload,
  RefreshCw,
  Receipt,
  CheckCircle2,
  Share2,
} from 'lucide-react';
import QRCode from 'qrcode';
import jsQR from 'jsqr';
import confetti from 'canvas-confetti';
import { formatCompactNumber } from '../../lib/formatNumber';
import { playPaymentSound, playErrorSound, playClickSound, playNotificationSound } from '../../lib/sounds';

interface VerifiedRecipient {
  id: string;
  username: string;
  avatarUrl: string;
  vipBadge: string | null;
  vpayTag: string;
  isVerified: boolean;
}

export const VPay: React.FC = () => {
  const { user, openAuthModal, refreshUser } = useAuth();
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [transfers, setTransfers] = useState<VPayTransfer[]>([]);
  const [transfersLoading, setTransfersLoading] = useState(false);
  const [copiedId, setCopiedId] = useState(false);

  // QR Code Generation State
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [qrLoading, setQrLoading] = useState<boolean>(false);
  const [showEnlargeQr, setShowEnlargeQr] = useState<boolean>(false);

  // Scan & Pay State
  const [showScanner, setShowScanner] = useState<boolean>(false);
  const [scannerError, setScannerError] = useState<string | null>(null);
  const [scannerResolving, setScannerResolving] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanAnimationId = useRef<number | null>(null);
  const scanFileInputRef = useRef<HTMLInputElement | null>(null);

  // QR Payment Flow State (post-scan)
  const [scannedRecipient, setScannedRecipient] = useState<VerifiedRecipient | null>(null);
  const [qrPayAmount, setQrPayAmount] = useState<string>('');
  const [qrPayNote, setQrPayNote] = useState<string>('');
  const [qrPayError, setQrPayError] = useState<string | null>(null);
  const [qrPaySubmitting, setQrPaySubmitting] = useState<boolean>(false);

  // Standard Confirmation Dialog
  const [showConfirm, setShowConfirm] = useState(false);

  // Real-time Transaction Receipt Modal
  const [transactionReceipt, setTransactionReceipt] = useState<{
    transferId: string;
    amount: number;
    recipientUsername: string;
    note?: string;
    newBalance: number;
    createdAt: string;
  } | null>(null);

  // 1. Generate unique, real scannable QR Code for authenticated user
  useEffect(() => {
    const currentUser = user;
    if (!currentUser) {
      setQrDataUrl('');
      return;
    }

    let isMounted = true;
    async function generateUserQr() {
      if (!currentUser) return;
      try {
        setQrLoading(true);
        // Authoritative payment URI and JSON routing payload
        const paymentUri = `vpay://pay?recipientId=${currentUser.id}&username=${encodeURIComponent(currentUser.username)}`;
        const url = await QRCode.toDataURL(paymentUri, {
          errorCorrectionLevel: 'H',
          margin: 2,
          width: 320,
          color: {
            dark: '#121222',
            light: '#FFFFFF',
          },
        });
        if (isMounted) {
          setQrDataUrl(url);
        }
      } catch (err) {
        console.error('Failed to generate VPay QR code:', err);
      } finally {
        if (isMounted) setQrLoading(false);
      }
    }

    generateUserQr();
    return () => {
      isMounted = false;
    };
  }, [user?.id, user?.username]);

  // 2. Fetch transaction history
  const fetchTransfers = async () => {
    if (!user) return;
    try {
      setTransfersLoading(true);
      const token = localStorage.getItem('lot_session_token') || user?.token;
      const res = await fetch('/api/vpay/history', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        const data = await res.json();
        setTransfers(data.transfers || []);
      }
    } catch {
      // non-critical
    } finally {
      setTransfersLoading(false);
    }
  };

  useEffect(() => {
    fetchTransfers();
  }, [user?.id]);

  // Copy payment handle
  const copyPaymentIdentifier = () => {
    if (!user) return;
    navigator.clipboard.writeText(`lotpay:${user.username}`);
    setCopiedId(true);
    playClickSound();
    setTimeout(() => setCopiedId(false), 2000);
  };

  // Download QR Code PNG
  const downloadQrCode = () => {
    if (!qrDataUrl || !user) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `VPay_QR_${user.username}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    playClickSound();
  };

  // ==========================================
  // CAMERA SCANNER & QR DECODING LOGIC
  // ==========================================

  const startCameraScanner = async () => {
    if (!user) {
      openAuthModal('login');
      return;
    }

    setScannerError(null);
    setShowScanner(true);
    playClickSound();

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
      });
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        scanAnimationId.current = requestAnimationFrame(scanVideoFrame);
      }
    } catch (err: any) {
      console.error('Camera permission or access error:', err);
      setScannerError('Camera access unavailable. Please grant camera permission or upload a QR image.');
    }
  };

  const stopCameraScanner = () => {
    if (scanAnimationId.current) {
      cancelAnimationFrame(scanAnimationId.current);
      scanAnimationId.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setShowScanner(false);
    setScannerError(null);
  };

  // Process video stream frames with jsQR
  const scanVideoFrame = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data) {
          handleDecodedQr(code.data);
          return;
        }
      }
    }

    scanAnimationId.current = requestAnimationFrame(scanVideoFrame);
  };

  // Scan QR from local file (image upload fallback)
  const handleScanFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setScannerError(null);
    setScannerResolving(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imgData.data, imgData.width, imgData.height);
          if (code && code.data) {
            handleDecodedQr(code.data);
          } else {
            setScannerError('Could not find a valid VPay QR code in this image. Please try another photo.');
            setScannerResolving(false);
          }
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Resolve decoded QR payload with backend
  const handleDecodedQr = async (qrData: string) => {
    stopCameraScanner();
    setScannerResolving(true);
    setQrPayError(null);

    try {
      const token = localStorage.getItem('lot_session_token') || user?.token;
      const res = await fetch('/api/vpay/resolve-qr', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ qrData }),
      });

      const data = await res.json();
      if (!res.ok) {
        playErrorSound();
        setError(data.error || 'Invalid or unrecognized VPay QR code.');
        return;
      }

      playNotificationSound();
      setScannedRecipient(data.recipient);
      setQrPayAmount('');
      setQrPayNote('');
    } catch (err: any) {
      console.error('Resolve QR error:', err);
      setError('Network error while verifying recipient QR code.');
    } finally {
      setScannerResolving(false);
    }
  };

  // Confirm and execute QR Scan & Pay transfer
  const handleExecuteQrPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scannedRecipient || !user) return;

    const num = Number(qrPayAmount);
    if (!num || isNaN(num) || num <= 0) {
      playErrorSound();
      setQrPayError('Please enter a valid amount of LOT greater than 0.');
      return;
    }

    if (num > user.lotBalance) {
      playErrorSound();
      setQrPayError(`Insufficient balance. You currently have ${formatCompactNumber(user.lotBalance)} LOT.`);
      return;
    }

    setQrPaySubmitting(true);
    setQrPayError(null);

    try {
      const token = localStorage.getItem('lot_session_token') || user?.token;
      const idempotencyKey = `${user.id}_${scannedRecipient.id}_${Date.now()}`;

      const res = await fetch('/api/vpay/transfer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          recipientId: scannedRecipient.id,
          recipientUsername: scannedRecipient.username,
          amount: num,
          note: qrPayNote.trim() || 'VPay QR Payment',
          idempotencyKey,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Payment execution failed');
      }

      // Success
      playPaymentSound();
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });

      setTransactionReceipt({
        transferId: data.transferId,
        amount: num,
        recipientUsername: scannedRecipient.username,
        note: qrPayNote.trim(),
        newBalance: data.newBalance,
        createdAt: new Date().toISOString(),
      });

      setScannedRecipient(null);
      refreshUser();
      fetchTransfers();
    } catch (err: any) {
      playErrorSound();
      setQrPayError(err.message || 'Payment failed. Your balance was not charged.');
    } finally {
      setQrPaySubmitting(false);
    }
  };

  // Standard Username Form Transfer
  const handleInitiateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!user) {
      openAuthModal('login');
      return;
    }

    const num = Number(amount);
    if (!num || isNaN(num) || num <= 0) {
      playErrorSound();
      setError('Please enter a valid amount of LOT greater than 0.');
      return;
    }

    if (num > user.lotBalance) {
      playErrorSound();
      setError(`Insufficient balance. You currently have ${formatCompactNumber(user.lotBalance)} LOT.`);
      return;
    }

    if (!recipient.trim()) {
      playErrorSound();
      setError('Please specify a recipient username.');
      return;
    }

    if (recipient.trim().toLowerCase() === user.username.toLowerCase()) {
      playErrorSound();
      setError('You cannot send LOT to yourself.');
      return;
    }

    setShowConfirm(true);
  };

  const handleExecuteTransfer = async () => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('lot_session_token') || user?.token;
      const idempotencyKey = `${user?.id}_${recipient.trim()}_${Date.now()}`;

      const res = await fetch('/api/vpay/transfer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          recipientUsername: recipient.trim(),
          amount: Number(amount),
          note: note.trim(),
          idempotencyKey,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Transfer failed');
      }

      playPaymentSound();
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });

      setShowConfirm(false);
      setTransactionReceipt({
        transferId: data.transferId,
        amount: Number(amount),
        recipientUsername: recipient.trim(),
        note: note.trim(),
        newBalance: data.newBalance,
        createdAt: new Date().toISOString(),
      });

      setAmount('');
      setRecipient('');
      setNote('');
      refreshUser();
      fetchTransfers();
    } catch (err: any) {
      playErrorSound();
      setError(err.message || 'Transfer failed. Your balance was not charged.');
      setShowConfirm(false);
    } finally {
      setLoading(false);
    }
  };

  const quickAmounts = [25, 50, 100, 250, 500];

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* VPay Header & Balance Display */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#121222] via-[#19192B] to-[#202039] border border-[#302D46] p-8 sm:p-10 shadow-2xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#202039] border border-[#8B5CF6]/40 text-[#C4B5FD] text-xs font-semibold mb-3">
              <Sparkles className="w-3.5 h-3.5 text-[#8B5CF6]" />
              Internal Peer-to-Peer Transfer Engine & QR Payments
            </div>
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-black border border-[#302D46] p-1.5 flex items-center justify-center shadow-xl shadow-purple-500/20 shrink-0">
                <img
                  src="/assets/aistudio/VPay_icon_512_4f9ce408.png"
                  alt="VPay Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
                VPay Instant Transfer
              </h1>
            </div>
            <p className="text-sm text-[#A5A3B8] max-w-xl mt-2 leading-relaxed">
              Send and receive authoritative LOT currency instantaneously between ecosystem members. Free, atomic, and
              cryptographically secured with real-time digital payment QR codes.
            </p>
          </div>

          {/* User Account Card & Scan Button */}
          {user ? (
            <div className="bg-[#121222]/90 border border-[#8B5CF6]/40 p-5 rounded-2xl min-w-[260px] shadow-xl space-y-3">
              <div className="flex items-center justify-between text-xs text-[#A5A3B8]">
                <span>Available LOT</span>
                <span className="font-semibold text-white">@{user.username}</span>
              </div>
              <div className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2">
                <Coins className="w-6 h-6 text-[#8B5CF6]" />
                <span title={`${user.lotBalance.toLocaleString()} LOT`}>
                  {formatCompactNumber(user.lotBalance)}
                </span>
                <span className="text-sm text-[#C4B5FD] font-semibold">LOT</span>
              </div>

              {/* Action Buttons: Scan & Pay + Copy ID */}
              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={startCameraScanner}
                  className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-xs transition-all flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Scan QR</span>
                </button>

                <button
                  type="button"
                  onClick={copyPaymentIdentifier}
                  className="py-2 px-3 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] hover:text-white text-xs font-medium border border-[#302D46] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  title="Copy payment identifier"
                >
                  {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedId ? 'Copied!' : 'ID'}</span>
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => openAuthModal('login')}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white font-semibold text-sm shadow-lg shadow-purple-500/20 cursor-pointer"
            >
              Sign In to Use VPay
            </button>
          )}
        </div>

        {/* System Disclaimer */}
        <div className="mt-6 pt-4 border-t border-[#302D46]/80 flex items-center gap-2 text-[11px] text-[#A5A3B8]">
          <Info className="w-4 h-4 shrink-0 text-[#8B5CF6]" />
          <span>
            VPay is an internal peer-to-peer LOT token ledger. Transactions are validated atomically on the cloud database ledger.
          </span>
        </div>
      </div>

      {/* Main Send & Receive Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Send LOT Form (7 Cols) */}
        <div className="lg:col-span-7 bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 flex items-center justify-center text-[#C4B5FD]">
                <Send className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Send LOT</h2>
                <p className="text-xs text-[#A5A3B8]">Transfer funds to any registered username or scan a QR code.</p>
              </div>
            </div>

            {/* Quick Scan Button */}
            <button
              type="button"
              onClick={startCameraScanner}
              className="px-3 py-1.5 rounded-xl bg-[#202039] hover:bg-[#302D46] border border-[#8B5CF6]/40 text-[#C4B5FD] hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <QrCode className="w-3.5 h-3.5 text-[#8B5CF6]" />
              <span>Scan & Pay</span>
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3.5 rounded-xl bg-red-950/60 border border-red-500/30 text-red-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-4 p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{success}</span>
            </div>
          )}

          <form onSubmit={handleInitiateTransfer} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Recipient Username</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#A5A3B8] text-sm font-bold">@</span>
                <input
                  type="text"
                  required
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  placeholder="Enter recipient's username"
                  className="w-full pl-8 pr-4 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-sm placeholder-[#A5A3B8]/50 focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-[#A5A3B8]">Amount (LOT)</label>
                {user && (
                  <button
                    type="button"
                    onClick={() => setAmount(String(user.lotBalance))}
                    className="text-[11px] text-[#C4B5FD] hover:underline font-medium cursor-pointer"
                    title={`Max balance: ${user.lotBalance.toLocaleString()} LOT`}
                  >
                    Send Max ({formatCompactNumber(user.lotBalance)} LOT)
                  </button>
                )}
              </div>
              <input
                type="number"
                min="1"
                step="any"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-4 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-base font-semibold placeholder-[#A5A3B8]/50 focus:outline-none focus:border-[#8B5CF6]"
              />

              {/* Quick Chips */}
              <div className="flex gap-2 mt-2">
                {quickAmounts.map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setAmount(String(q))}
                    className="px-2.5 py-1 text-xs rounded-lg bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] border border-[#302D46] transition-all cursor-pointer font-medium"
                  >
                    +{q}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Payment Memo (Optional)</label>
              <input
                type="text"
                maxLength={200}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="e.g. Weapon trade, thank you gift..."
                className="w-full px-4 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs placeholder-[#A5A3B8]/50 focus:outline-none focus:border-[#8B5CF6]"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 mt-2 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:from-[#7C3AED] hover:to-[#9333EA] text-white font-bold text-sm shadow-lg shadow-purple-500/25 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Continue to Transfer Preview</span>
            </button>
          </form>
        </div>

        {/* Receive LOT Card - Real Scannable QR Code (5 Cols) */}
        <div className="lg:col-span-5 bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <QrCode className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Receive LOT</h2>
                  <p className="text-xs text-[#A5A3B8]">Your authentic payment QR code.</p>
                </div>
              </div>

              {user && qrDataUrl && (
                <button
                  type="button"
                  onClick={() => setShowEnlargeQr(true)}
                  className="p-2 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#A5A3B8] hover:text-white transition-colors cursor-pointer"
                  title="Enlarge QR Code"
                >
                  <Maximize2 className="w-4 h-4" />
                </button>
              )}
            </div>

            {user ? (
              <div className="text-center space-y-4">
                {/* Authentic Digital Payment QR Code */}
                <div className="relative group mx-auto w-56 h-56 bg-white p-3 rounded-2xl shadow-2xl flex flex-col items-center justify-center cursor-pointer transition-transform hover:scale-[1.02]">
                  {qrLoading ? (
                    <div className="flex flex-col items-center gap-2 text-gray-500 text-xs">
                      <RefreshCw className="w-6 h-6 animate-spin text-purple-600" />
                      <span>Generating QR...</span>
                    </div>
                  ) : qrDataUrl ? (
                    <>
                      <img
                        src={qrDataUrl}
                        alt={`VPay QR for @${user.username}`}
                        className="w-full h-full object-contain"
                        onClick={() => setShowEnlargeQr(true)}
                      />
                      {/* Center Brand Badge on QR */}
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="w-10 h-10 rounded-xl bg-[#121222] border-2 border-[#8B5CF6] flex items-center justify-center shadow-lg">
                          <Coins className="w-5 h-5 text-[#8B5CF6]" />
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="text-xs text-gray-400">Unable to generate QR code</div>
                  )}
                </div>

                {/* User Identity Details */}
                <div className="space-y-1">
                  <div className="flex items-center justify-center gap-1.5">
                    <span className="text-sm font-bold text-white">@{user.username}</span>
                    <span title="Verified VPay Account">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    </span>
                  </div>
                  <p className="text-[11px] text-[#A5A3B8]">
                    Scannable with any device camera or VPay scanner
                  </p>
                </div>

                {/* Action buttons: Download & Copy handle */}
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={downloadQrCode}
                    disabled={!qrDataUrl}
                    className="flex-1 py-2 px-3 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] hover:text-white text-xs font-semibold border border-[#302D46] transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download QR</span>
                  </button>

                  <button
                    type="button"
                    onClick={copyPaymentIdentifier}
                    className="flex-1 py-2 px-3 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] hover:text-white text-xs font-semibold border border-[#302D46] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId ? 'Copied ID' : 'Copy Handle'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-xs text-[#A5A3B8]">
                Please sign in to generate your unique VPay receive ID.
              </div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-[#302D46] text-xs text-[#A5A3B8] flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Transfers are validated atomically on the cloud database ledger.</span>
          </div>
        </div>
      </div>

      {/* Transfer History Table */}
      <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 text-[#8B5CF6]" />
            <h3 className="text-lg font-bold text-white">VPay Transfer History</h3>
          </div>
          <span className="text-xs text-[#A5A3B8]">{transfers.length} recorded transfers</span>
        </div>

        {transfersLoading ? (
          <div className="text-center py-10 text-xs text-[#A5A3B8]">Loading transfers...</div>
        ) : !user ? (
          <div className="text-center py-10 text-xs text-[#A5A3B8]">Please sign in to view your transfer history.</div>
        ) : transfers.length === 0 ? (
          <div className="text-center py-10 text-xs text-[#A5A3B8]">No transfers yet. Send or receive LOT to get started!</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#302D46] text-[#A5A3B8]">
                  <th className="pb-3 font-semibold">Type</th>
                  <th className="pb-3 font-semibold">Party</th>
                  <th className="pb-3 font-semibold">Amount</th>
                  <th className="pb-3 font-semibold">Memo</th>
                  <th className="pb-3 font-semibold">Date & Time</th>
                  <th className="pb-3 font-semibold text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#302D46]/50">
                {transfers.map((tx) => {
                  const isSent = tx.senderId === user.id;
                  return (
                    <tr key={tx.id} className="hover:bg-[#121222]/40 transition-colors">
                      <td className="py-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                            isSent
                              ? 'bg-red-950/80 text-red-300 border border-red-800'
                              : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                          }`}
                        >
                          {isSent ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownLeft className="w-3 h-3" />}
                          {isSent ? 'Sent' : 'Received'}
                        </span>
                      </td>
                      <td className="py-3 font-medium text-white">
                        {isSent ? `@${tx.recipientUsername}` : `@${tx.senderUsername}`}
                      </td>
                      <td className="py-3 font-bold">
                        <span
                          className={isSent ? 'text-red-400' : 'text-emerald-400'}
                          title={`${tx.amount.toLocaleString()} LOT`}
                        >
                          {isSent ? '-' : '+'}{formatCompactNumber(tx.amount)} LOT
                        </span>
                      </td>
                      <td className="py-3 text-[#A5A3B8] max-w-xs truncate">
                        {tx.note || <span className="opacity-40 italic">No note</span>}
                      </td>
                      <td className="py-3 text-[#A5A3B8]">
                        {new Date(tx.createdAt).toLocaleString()}
                      </td>
                      <td className="py-3 text-right">
                        <span className="text-emerald-400 font-semibold text-[11px]">Completed</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ==================================================== */}
      {/* 1. CAMERA SCANNER MODAL */}
      {/* ==================================================== */}
      {showScanner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-md bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 text-[#F5F3FF]">
            <div className="flex items-center justify-between pb-3 border-b border-[#302D46] mb-4">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-white text-base">Scan VPay QR Code</h3>
              </div>
              <button
                type="button"
                onClick={stopCameraScanner}
                className="p-1.5 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-[#202039] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {scannerError ? (
              <div className="p-4 rounded-2xl bg-amber-950/60 border border-amber-500/40 text-amber-200 text-xs mb-4">
                <p className="font-semibold mb-1">Camera Notice</p>
                <p className="text-[11px] opacity-90 mb-3">{scannerError}</p>
                <button
                  type="button"
                  onClick={() => scanFileInputRef.current?.click()}
                  className="w-full py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-black font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>Upload QR Image from Device</span>
                </button>
              </div>
            ) : (
              <div className="relative w-full aspect-square bg-black rounded-2xl overflow-hidden border border-[#302D46] flex items-center justify-center mb-4">
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  playsInline
                  muted
                />
                <canvas ref={canvasRef} className="hidden" />

                {/* Animated Targeting Viewfinder Reticle */}
                <div className="absolute inset-10 border-2 border-emerald-400/80 rounded-2xl pointer-events-none flex flex-col justify-between p-2 shadow-2xl">
                  <div className="flex justify-between">
                    <span className="w-4 h-4 border-t-2 border-l-2 border-emerald-400" />
                    <span className="w-4 h-4 border-t-2 border-r-2 border-emerald-400" />
                  </div>
                  <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent animate-pulse" />
                  <div className="flex justify-between">
                    <span className="w-4 h-4 border-b-2 border-l-2 border-emerald-400" />
                    <span className="w-4 h-4 border-b-2 border-r-2 border-emerald-400" />
                  </div>
                </div>

                {scannerResolving && (
                  <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center gap-2">
                    <RefreshCw className="w-8 h-8 animate-spin text-emerald-400" />
                    <span className="text-xs font-bold text-white">Resolving payment recipient...</span>
                  </div>
                )}
              </div>
            )}

            <div className="flex items-center justify-between text-xs text-[#A5A3B8]">
              <span>Point camera at any VPay payment QR code</span>
              <button
                type="button"
                onClick={() => scanFileInputRef.current?.click()}
                className="text-purple-300 hover:underline flex items-center gap-1 cursor-pointer font-semibold"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload QR Image</span>
              </button>
            </div>

            {/* Hidden file picker fallback */}
            <input
              type="file"
              ref={scanFileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleScanFile}
            />
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 2. CONFIRM SCANNED QR PAYMENT MODAL */}
      {/* ==================================================== */}
      {scannedRecipient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-md bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 text-[#F5F3FF]">
            <div className="flex items-center justify-between pb-3 border-b border-[#302D46] mb-4">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-white text-base">Verified Recipient Found</h3>
              </div>
              <button
                type="button"
                onClick={() => setScannedRecipient(null)}
                className="p-1.5 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-[#202039] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Recipient Profile Banner */}
            <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] flex items-center gap-3.5 mb-5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-sm font-bold text-white overflow-hidden shrink-0 shadow-md">
                {scannedRecipient.avatarUrl ? (
                  <img src={scannedRecipient.avatarUrl} alt={scannedRecipient.username} className="w-full h-full object-cover" />
                ) : (
                  scannedRecipient.username.charAt(0).toUpperCase()
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-white text-sm truncate">@{scannedRecipient.username}</span>
                  <span title="Verified Account">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  </span>
                </div>
                <p className="text-[11px] font-mono text-[#C4B5FD] truncate">{scannedRecipient.vpayTag}</p>
                <span className="text-[10px] text-emerald-400 font-semibold">Account Verified • Ready to receive</span>
              </div>
            </div>

            {qrPayError && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/30 text-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{qrPayError}</span>
              </div>
            )}

            <form onSubmit={handleExecuteQrPayment} className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1.5 text-xs text-[#A5A3B8]">
                  <span>Amount to Send (LOT)</span>
                  {user && (
                    <span className="font-medium text-[#C4B5FD]">
                      Available: {formatCompactNumber(user.lotBalance)} LOT
                    </span>
                  )}
                </div>
                <input
                  type="number"
                  min="1"
                  step="any"
                  required
                  value={qrPayAmount}
                  onChange={(e) => setQrPayAmount(e.target.value)}
                  placeholder="0.00"
                  autoFocus
                  className="w-full px-4 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-base font-semibold placeholder-[#A5A3B8]/50 focus:outline-none focus:border-emerald-500"
                />

                {/* Quick Chips */}
                <div className="flex gap-2 mt-2">
                  {quickAmounts.map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setQrPayAmount(String(q))}
                      className="px-2.5 py-1 text-xs rounded-lg bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] border border-[#302D46] transition-all cursor-pointer font-medium"
                    >
                      +{q}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">Payment Memo (Optional)</label>
                <input
                  type="text"
                  maxLength={200}
                  value={qrPayNote}
                  onChange={(e) => setQrPayNote(e.target.value)}
                  placeholder="e.g. Scanned payment..."
                  className="w-full px-4 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs placeholder-[#A5A3B8]/50 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setScannedRecipient(null)}
                  className="flex-1 py-2.5 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#A5A3B8] hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={qrPaySubmitting || !qrPayAmount}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-xs transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer disabled:opacity-40"
                >
                  {qrPaySubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Confirm & Pay</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 3. ENLARGE & DOWNLOAD QR MODAL */}
      {/* ==================================================== */}
      {showEnlargeQr && user && qrDataUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
          onClick={() => setShowEnlargeQr(false)}
        >
          <div
            className="relative w-full max-w-sm bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 text-[#F5F3FF] text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#302D46] mb-4">
              <span className="font-bold text-white text-sm">VPay Payment QR</span>
              <button
                type="button"
                onClick={() => setShowEnlargeQr(false)}
                className="p-1 rounded-lg text-[#A5A3B8] hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-white p-4 rounded-2xl shadow-xl w-64 h-64 mx-auto mb-4 flex items-center justify-center relative">
              <img src={qrDataUrl} alt={`QR for @${user.username}`} className="w-full h-full object-contain" />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-11 h-11 rounded-xl bg-[#121222] border-2 border-[#8B5CF6] flex items-center justify-center shadow-lg">
                  <Coins className="w-6 h-6 text-[#8B5CF6]" />
                </div>
              </div>
            </div>

            <div className="space-y-1 mb-5">
              <h4 className="text-base font-bold text-white">@{user.username}</h4>
              <p className="text-xs font-mono text-[#C4B5FD]">lotpay:{user.username}</p>
              <p className="text-[11px] text-[#A5A3B8]">Show this QR code to any LOT member to receive payments.</p>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={downloadQrCode}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-purple-500/20 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Save Image</span>
              </button>
              <button
                type="button"
                onClick={copyPaymentIdentifier}
                className="py-2.5 px-4 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#C4B5FD] hover:text-white text-xs font-semibold border border-[#302D46] cursor-pointer"
              >
                {copiedId ? 'Copied' : 'Copy ID'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 4. AUTHORITATIVE TRANSACTION RECEIPT MODAL */}
      {/* ==================================================== */}
      {transactionReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-md bg-[#19192B] border border-emerald-500/40 rounded-3xl shadow-2xl p-6 text-[#F5F3FF]">
            <div className="text-center mb-5">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 border-2 border-emerald-500/50 flex items-center justify-center mx-auto mb-3 text-emerald-400">
                <Receipt className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-black text-white">Transfer Successful!</h3>
              <p className="text-xs text-[#A5A3B8] mt-1">Authoritative Ledger Transaction Settled</p>
            </div>

            {/* Receipt Summary Card */}
            <div className="bg-[#121222] p-4 rounded-2xl border border-[#302D46] space-y-3 text-xs mb-5">
              <div className="flex justify-between items-center pb-2 border-b border-[#302D46]">
                <span className="text-[#A5A3B8]">Amount Debited:</span>
                <span className="text-base font-black text-emerald-400">
                  {formatCompactNumber(transactionReceipt.amount)} LOT
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#A5A3B8]">Recipient:</span>
                <span className="font-bold text-white">@{transactionReceipt.recipientUsername}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#A5A3B8]">Transaction ID:</span>
                <span className="font-mono text-[10px] text-[#A5A3B8] truncate max-w-[180px]">
                  {transactionReceipt.transferId}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#A5A3B8]">Remaining Balance:</span>
                <span className="font-bold text-white">
                  {formatCompactNumber(transactionReceipt.newBalance)} LOT
                </span>
              </div>
              {transactionReceipt.note && (
                <div className="flex justify-between items-center pt-2 border-t border-[#302D46]">
                  <span className="text-[#A5A3B8]">Memo:</span>
                  <span className="italic text-white">"{transactionReceipt.note}"</span>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => setTransactionReceipt(null)}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-black font-black text-xs hover:brightness-110 shadow-lg shadow-emerald-500/20 cursor-pointer"
            >
              Done & Return to VPay
            </button>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 5. STANDARD CONFIRMATION MODAL */}
      {/* ==================================================== */}
      {showConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl p-6 text-[#F5F3FF]">
            <h3 className="text-xl font-bold text-white mb-2">Confirm VPay Transfer</h3>
            <p className="text-xs text-[#A5A3B8] mb-4">Please review the transfer details before executing.</p>

            <div className="bg-[#121222] p-4 rounded-2xl border border-[#302D46] space-y-2.5 text-xs mb-5">
              <div className="flex justify-between">
                <span className="text-[#A5A3B8]">Recipient:</span>
                <span className="font-bold text-white">@{recipient.trim()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#A5A3B8]">Transfer Amount:</span>
                <span className="font-bold text-[#C4B5FD] text-sm" title={`${Number(amount).toLocaleString()} LOT`}>
                  {formatCompactNumber(Number(amount))} LOT
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#A5A3B8]">Network Transfer Fee:</span>
                <span className="font-bold text-emerald-400">0 LOT (Free)</span>
              </div>
              {note.trim() && (
                <div className="flex justify-between pt-2 border-t border-[#302D46]">
                  <span className="text-[#A5A3B8]">Memo:</span>
                  <span className="text-white italic">"{note.trim()}"</span>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setShowConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#A5A3B8] hover:text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={handleExecuteTransfer}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-purple-500/20 cursor-pointer"
              >
                {loading ? 'Processing...' : 'Authorize Send'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
