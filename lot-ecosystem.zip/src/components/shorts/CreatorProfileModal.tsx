import React, { useState, useEffect } from 'react';
import {
  X,
  UserPlus,
  UserCheck,
  Eye,
  Heart,
  Film,
  Trash2,
  Edit2,
  Loader2,
  Calendar,
  Share2,
} from 'lucide-react';
import { ShortVideo, CreatorProfileData } from './types';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';
import { playMenuSound } from '../../lib/sounds';

interface CreatorProfileModalProps {
  username: string;
  isOpen: boolean;
  onClose: () => void;
  onSelectShort: (short: ShortVideo) => void;
  onShortDeleted?: (shortId: string) => void;
  onShortUpdated?: (updatedShort: ShortVideo) => void;
}

export const CreatorProfileModal: React.FC<CreatorProfileModalProps> = ({
  username,
  isOpen,
  onClose,
  onSelectShort,
  onShortDeleted,
  onShortUpdated,
}) => {
  const { user, openAuthModal } = useAuth();
  const [profile, setProfile] = useState<CreatorProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [following, setFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);
  const [editingShort, setEditingShort] = useState<ShortVideo | null>(null);
  const [editCaption, setEditCaption] = useState('');

  useEffect(() => {
    if (!isOpen || !username) return;

    let isMounted = true;
    async function loadCreator() {
      setLoading(true);
      try {
        const headers: Record<string, string> = {};
        if (user?.token) {
          headers['Authorization'] = `Bearer ${user.token}`;
        }
        const res = await fetch(`/api/shorts/creator/${encodeURIComponent(username)}`, { headers });
        if (res.ok) {
          const data = await res.json();
          if (isMounted) {
            const creatorData: CreatorProfileData = {
              ...data.creator,
              shorts: data.shorts || [],
            };
            setProfile(creatorData);
            setFollowing(!!data.creator?.isFollowing);
            setFollowersCount(data.creator?.followersCount || 0);
          }
        }
      } catch (err) {
        console.error('Failed to load creator profile:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadCreator();

    return () => {
      isMounted = false;
    };
  }, [isOpen, username, user?.token]);

  if (!isOpen) return null;

  const handleToggleFollow = async () => {
    if (!user) {
      openAuthModal();
      return;
    }
    if (!profile) return;

    playMenuSound();
    const nextFollowing = !following;
    setFollowing(nextFollowing);
    setFollowersCount((prev) => (nextFollowing ? prev + 1 : Math.max(0, prev - 1)));

    try {
      await fetch(`/api/shorts/creator/${profile.id}/follow`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${user.token}` },
      });
    } catch (err) {
      console.error('Failed to toggle follow:', err);
    }
  };

  const handleDeleteShort = async (shortId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user || !window.confirm('Are you sure you want to delete this Short?')) return;

    try {
      const headers: Record<string, string> = {};
      if (user?.token && user.token !== 'undefined') {
        headers['Authorization'] = `Bearer ${user.token}`;
      }
      const res = await fetch(`/api/shorts/${shortId}`, {
        method: 'DELETE',
        headers,
        credentials: 'include',
      });
      if (res.ok) {
        if (profile) {
          setProfile({
            ...profile,
            shorts: profile.shorts.filter((s) => s.id !== shortId),
          });
        }
        if (onShortDeleted) {
          onShortDeleted(shortId);
        }
      }
    } catch (err) {
      console.error('Failed to delete short:', err);
    }
  };

  const handleSaveCaption = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !editingShort) return;

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (user?.token && user.token !== 'undefined') {
        headers['Authorization'] = `Bearer ${user.token}`;
      }
      const res = await fetch(`/api/shorts/${editingShort.id}`, {
        method: 'PATCH',
        headers,
        credentials: 'include',
        body: JSON.stringify({ caption: editCaption }),
      });
      if (res.ok) {
        const data = await res.json();
        if (profile) {
          setProfile({
            ...profile,
            shorts: profile.shorts.map((s) => (s.id === editingShort.id ? { ...s, caption: editCaption } : s)),
          });
        }
        if (onShortUpdated) {
          onShortUpdated({ ...editingShort, caption: editCaption });
        }
        setEditingShort(null);
      }
    } catch (err) {
      console.error('Failed to update caption:', err);
    }
  };

  const isOwnProfile = user && profile && (user.id === profile.id || user.username.toLowerCase() === profile.username.toLowerCase());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div
        className="bg-[#10101F] border border-[#302D46] rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl relative custom-scrollbar flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between p-4 border-b border-[#202035] sticky top-0 bg-[#10101F]/90 backdrop-blur-sm z-10">
          <h3 className="text-sm font-bold text-white tracking-wide">Creator Channel</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-[#1C1C35] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {loading ? (
          <div className="py-24 flex flex-col items-center justify-center gap-2 text-[#A5A3B8] text-xs">
            <Loader2 className="w-8 h-8 animate-spin text-[#8B5CF6]" />
            <span>Loading channel profile...</span>
          </div>
        ) : !profile ? (
          <div className="py-24 text-center text-xs text-[#A5A3B8]">
            Creator channel not found.
          </div>
        ) : (
          <div className="p-5 sm:p-6 space-y-6">
            {/* Profile Info Header */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#8B5CF6] via-[#A855F7] to-[#C4B5FD] p-1 shadow-xl shrink-0">
                <div className="w-full h-full rounded-full overflow-hidden bg-[#151528] flex items-center justify-center text-2xl font-black text-white">
                  {profile.avatarUrl ? (
                    <img src={profile.avatarUrl} alt={profile.username} className="w-full h-full object-cover" />
                  ) : (
                    profile.username.charAt(0).toUpperCase()
                  )}
                </div>
              </div>

              <div className="flex-1 text-center sm:text-left space-y-1.5">
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 justify-between">
                  <div>
                    <h2 className="text-xl font-black text-white">@{profile.username}</h2>
                    <p className="text-xs text-[#A5A3B8]">LOT Shorts Creator</p>
                  </div>

                  {!isOwnProfile && (
                    <button
                      onClick={handleToggleFollow}
                      className={`px-5 py-2 rounded-xl text-xs font-bold transition shadow-md cursor-pointer flex items-center justify-center gap-1.5 ${
                        following
                          ? 'bg-[#20203B] text-white border border-[#3A3855] hover:bg-[#2A2A4E]'
                          : 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white hover:brightness-110 shadow-purple-500/25'
                      }`}
                    >
                      {following ? (
                        <>
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Following</span>
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>Follow</span>
                        </>
                      )}
                    </button>
                  )}
                </div>

                {/* Stats row */}
                <div className="flex items-center justify-center sm:justify-start gap-6 pt-2 text-xs">
                  <div>
                    <span className="font-bold text-white block">{profile.shorts.length}</span>
                    <span className="text-[11px] text-[#A5A3B8]">Shorts</span>
                  </div>
                  <div>
                    <span className="font-bold text-white block">{formatCompactNumber(followersCount)}</span>
                    <span className="text-[11px] text-[#A5A3B8]">Followers</span>
                  </div>
                  <div>
                    <span className="font-bold text-white block">{formatCompactNumber(profile.totalViews)}</span>
                    <span className="text-[11px] text-[#A5A3B8]">Total Views</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Published Shorts Grid */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-2 border-b border-[#202035] pb-2">
                <Film className="w-4 h-4 text-[#C4B5FD]" />
                <h4 className="text-xs font-bold text-white tracking-wider uppercase">Published Shorts</h4>
              </div>

              {profile.shorts.length === 0 ? (
                <div className="py-12 text-center text-xs text-[#A5A3B8]">
                  No Shorts published yet.
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {profile.shorts.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        onSelectShort(item);
                        onClose();
                      }}
                      className="group relative aspect-[9/16] rounded-2xl overflow-hidden bg-[#16162D] border border-[#2B2B48] hover:border-[#8B5CF6] transition-all cursor-pointer shadow-md"
                    >
                      {item.thumbnailUrl ? (
                        <img
                          src={item.thumbnailUrl}
                          alt={item.caption}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                        />
                      ) : (
                        <video
                          src={item.videoUrl}
                          className="w-full h-full object-cover"
                          preload="metadata"
                        />
                      )}

                      {/* Top Overlay Badge */}
                      <div className="absolute top-2 left-2 flex items-center gap-1 bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded-md text-[10px] text-white">
                        <Eye className="w-3 h-3 text-[#C4B5FD]" />
                        <span>{formatCompactNumber(item.viewsCount)}</span>
                      </div>

                      {/* Bottom Overlay Info */}
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-2.5 flex flex-col justify-end">
                        <p className="text-[11px] text-white font-medium line-clamp-2 leading-tight">
                          {item.caption || 'Untitled Short'}
                        </p>
                        <div className="flex items-center justify-between text-[10px] text-[#A5A3B8] mt-1">
                          <span className="flex items-center gap-1">
                            <Heart className="w-3 h-3 text-red-400 fill-current" />
                            {formatCompactNumber(item.likesCount)}
                          </span>
                          <span>{item.duration}s</span>
                        </div>
                      </div>

                      {/* Owner controls: Edit / Delete */}
                      {(isOwnProfile || user?.isAdmin) && (
                        <div className="absolute top-2 right-2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition z-10">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingShort(item);
                              setEditCaption(item.caption);
                            }}
                            className="p-1.5 rounded-lg bg-black/70 hover:bg-black text-white hover:text-[#C4B5FD] transition"
                            title="Edit caption"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleDeleteShort(item.id, e)}
                            className="p-1.5 rounded-lg bg-black/70 hover:bg-red-600 text-white transition"
                            title="Delete Short"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Edit Caption Dialog */}
        {editingShort && (
          <div className="absolute inset-0 z-20 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <form onSubmit={handleSaveCaption} className="bg-[#15152A] p-5 rounded-2xl border border-[#302D46] w-full max-w-sm space-y-3">
              <h4 className="text-sm font-bold text-white">Edit Short Caption</h4>
              <textarea
                value={editCaption}
                onChange={(e) => setEditCaption(e.target.value)}
                rows={3}
                className="w-full bg-[#1C1C35] border border-[#302D46] rounded-xl p-2.5 text-xs text-white resize-none"
              />
              <div className="flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setEditingShort(null)}
                  className="px-3 py-1.5 rounded-xl text-[#A5A3B8] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-[#8B5CF6] text-white font-semibold hover:bg-[#7C3AED]"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
