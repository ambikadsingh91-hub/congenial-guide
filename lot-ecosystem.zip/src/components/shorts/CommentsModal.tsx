import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  MessageCircle,
  Heart,
  Send,
  Trash2,
  Edit2,
  CornerDownRight,
  Sparkles,
  Loader2,
  Flag,
  Check,
  Smile,
  Paperclip,
  Image as ImageIcon,
} from 'lucide-react';
import { ShortComment, ShortVideo, GifItem } from './types';
import { GifPicker } from './GifPicker';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';
import { playNotificationSound, playErrorSound, playMenuSound } from '../../lib/sounds';

interface CommentsModalProps {
  short: ShortVideo;
  isOpen: boolean;
  onClose: () => void;
  onCommentsCountChange?: (count: number) => void;
  onOpenReportModal?: (commentId: string, commentSnippet: string) => void;
}

export const CommentsModal: React.FC<CommentsModalProps> = ({
  short,
  isOpen,
  onClose,
  onCommentsCountChange,
  onOpenReportModal,
}) => {
  const { user, openAuthModal } = useAuth();
  const [comments, setComments] = useState<ShortComment[]>([]);
  const [loading, setLoading] = useState(true);
  const [inputText, setInputText] = useState('');
  const [selectedGif, setSelectedGif] = useState<GifItem | null>(null);
  const [pendingMediaFile, setPendingMediaFile] = useState<{
    file: File;
    previewUrl: string;
    isGif: boolean;
    name: string;
  } | null>(null);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [lightboxGif, setLightboxGif] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [showGifPicker, setShowGifPicker] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [replyingTo, setReplyingTo] = useState<ShortComment | null>(null);
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');

  // Fetch comments
  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    async function loadComments() {
      setLoading(true);
      try {
        const headers: Record<string, string> = {};
        if (user?.token) {
          headers['Authorization'] = `Bearer ${user.token}`;
        }
        const res = await fetch(`/api/shorts/${short.id}/comments`, { headers });
        if (res.ok) {
          const data = await res.json();
          if (isMounted) {
            setComments(data.comments || []);
            if (onCommentsCountChange && typeof data.totalCount === 'number') {
              onCommentsCountChange(data.totalCount);
            }
          }
        }
      } catch (err) {
        console.error('Failed to load comments:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadComments();

    return () => {
      isMounted = false;
    };
  }, [isOpen, short.id, user?.token]);

  if (!isOpen) return null;

  // Handle native keyboard GIFs and file attachments
  const handleFileSelect = (file: File) => {
    const isGif = file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif');
    if (!file.type.startsWith('image/')) {
      alert('Please select a valid GIF or photo.');
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      alert('File size exceeds 15MB limit.');
      return;
    }
    if (pendingMediaFile?.previewUrl) {
      URL.revokeObjectURL(pendingMediaFile.previewUrl);
    }
    setSelectedGif(null);
    setShowGifPicker(false);
    setPendingMediaFile({
      file,
      previewUrl: URL.createObjectURL(file),
      isGif,
      name: file.name,
    });
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const items = e.clipboardData?.items;
    if (!items || items.length === 0) return;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.type.indexOf('image') !== -1) {
        const file = item.getAsFile();
        if (file) {
          e.preventDefault();
          handleFileSelect(file);
          return;
        }
      }
    }
  };

  // Submit comment or reply (supports text-only, GIF-only, or text + animated GIF)
  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal();
      return;
    }

    if (!inputText.trim() && !selectedGif && !pendingMediaFile) {
      return;
    }

    setSubmitting(true);
    try {
      let finalGifUrl = selectedGif?.url || null;
      let finalGifTitle = selectedGif?.title || null;

      // Upload native keyboard GIF / image file if attached
      if (pendingMediaFile) {
        setUploadingMedia(true);
        const formData = new FormData();
        formData.append('file', pendingMediaFile.file);

        const uploadRes = await fetch('/api/media/upload', {
          method: 'POST',
          headers: user.token ? { Authorization: `Bearer ${user.token}` } : {},
          body: formData,
        });

        if (!uploadRes.ok) {
          const errData = await uploadRes.json().catch(() => ({}));
          throw new Error(errData.error || 'Failed to upload GIF comment');
        }

        const uploadData = await uploadRes.json();
        finalGifUrl = uploadData.url;
        finalGifTitle = pendingMediaFile.name;
        setUploadingMedia(false);
      }

      const res = await fetch(`/api/shorts/${short.id}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.token}`,
        },
        body: JSON.stringify({
          text: inputText.trim(),
          gifUrl: finalGifUrl,
          gifTitle: finalGifTitle,
          replyToCommentId: replyingTo?.id || null,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to post comment');
      }

      const data = await res.json();
      playNotificationSound();

      if (replyingTo) {
        // Nested reply
        setComments((prev) =>
          prev.map((c) => {
            if (c.id === replyingTo.id) {
              return {
                ...c,
                replies: [...(c.replies || []), data.comment],
              };
            }
            return c;
          })
        );
      } else {
        // Top-level comment
        setComments((prev) => [data.comment, ...prev]);
      }

      if (onCommentsCountChange && typeof data.commentsCount === 'number') {
        onCommentsCountChange(data.commentsCount);
      }

      if (pendingMediaFile?.previewUrl) {
        URL.revokeObjectURL(pendingMediaFile.previewUrl);
      }
      setPendingMediaFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';

      setInputText('');
      setSelectedGif(null);
      setShowGifPicker(false);
      setReplyingTo(null);
    } catch (err: any) {
      playErrorSound();
      alert(err.message || 'Error posting comment');
    } finally {
      setSubmitting(false);
      setUploadingMedia(false);
    }
  };

  // Like comment
  const handleLikeComment = async (commentId: string) => {
    if (!user) {
      openAuthModal();
      return;
    }

    playMenuSound();

    // Optimistic update
    setComments((prev) =>
      prev.map((c) => {
        if (c.id === commentId) {
          const isLiked = !c.isLiked;
          return {
            ...c,
            isLiked,
            likesCount: isLiked ? c.likesCount + 1 : Math.max(0, c.likesCount - 1),
          };
        }
        if (c.replies) {
          return {
            ...c,
            replies: c.replies.map((r) => {
              if (r.id === commentId) {
                const isLiked = !r.isLiked;
                return {
                  ...r,
                  isLiked,
                  likesCount: isLiked ? r.likesCount + 1 : Math.max(0, r.likesCount - 1),
                };
              }
              return r;
            }),
          };
        }
        return c;
      })
    );

    try {
      await fetch(`/api/shorts/comments/${commentId}/like`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${user.token}` },
      });
    } catch (err) {
      console.error('Failed to like comment:', err);
    }
  };

  // Delete comment
  const handleDeleteComment = async (commentId: string) => {
    if (!user || !window.confirm('Delete this comment?')) return;

    try {
      const res = await fetch(`/api/shorts/comments/${commentId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${user.token}` },
      });
      if (res.ok) {
        setComments((prev) =>
          prev
            .filter((c) => c.id !== commentId)
            .map((c) => ({
              ...c,
              replies: c.replies ? c.replies.filter((r) => r.id !== commentId) : [],
            }))
        );
      }
    } catch (err) {
      console.error('Failed to delete comment:', err);
    }
  };

  // Save edited comment
  const handleSaveEdit = async (commentId: string) => {
    if (!user || !editText.trim()) return;

    try {
      const res = await fetch(`/api/shorts/comments/${commentId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.token}`,
        },
        body: JSON.stringify({ text: editText.trim() }),
      });
      if (res.ok) {
        setComments((prev) =>
          prev.map((c) => {
            if (c.id === commentId) {
              return { ...c, text: editText.trim(), updatedAt: new Date().toISOString() };
            }
            if (c.replies) {
              return {
                ...c,
                replies: c.replies.map((r) =>
                  r.id === commentId
                    ? { ...r, text: editText.trim(), updatedAt: new Date().toISOString() }
                    : r
                ),
              };
            }
            return c;
          })
        );
        setEditingCommentId(null);
      }
    } catch (err) {
      console.error('Failed to update comment:', err);
    }
  };

  const renderCommentItem = (comment: ShortComment, isReply = false) => {
    const isOwner = user?.id === comment.userId || user?.isAdmin;
    const isEditing = editingCommentId === comment.id;

    return (
      <div
        key={comment.id}
        className={`group relative flex gap-3 ${isReply ? 'ml-8 mt-2.5 pt-2 border-l-2 border-[#25253e] pl-3' : 'py-3 border-b border-[#1f1f33]'}`}
      >
        {/* Avatar */}
        <div className="shrink-0">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#8B5CF6] to-[#C4B5FD] flex items-center justify-center text-xs font-bold text-white overflow-hidden shadow-sm">
            {comment.userAvatar ? (
              <img src={comment.userAvatar} alt={comment.username} className="w-full h-full object-cover" />
            ) : (
              comment.username.charAt(0).toUpperCase()
            )}
          </div>
        </div>

        {/* Comment Body */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-xs font-bold text-white truncate">@{comment.username}</span>
            {comment.replyToUsername && (
              <span className="text-[10px] text-[#A5A3B8] flex items-center gap-1">
                <CornerDownRight className="w-3 h-3 text-[#8B5CF6]" />
                @{comment.replyToUsername}
              </span>
            )}
            <span className="text-[10px] text-[#6C6A84]">
              {new Date(comment.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
            </span>
          </div>

          {isEditing ? (
            <div className="mt-1 space-y-1.5">
              <input
                type="text"
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                className="w-full bg-[#18182E] border border-[#8B5CF6] rounded-lg px-2.5 py-1 text-xs text-white"
                autoFocus
              />
              <div className="flex gap-2 justify-end text-xs">
                <button
                  onClick={() => setEditingCommentId(null)}
                  className="px-2 py-0.5 rounded text-[#A5A3B8] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleSaveEdit(comment.id)}
                  className="px-2.5 py-0.5 rounded bg-[#8B5CF6] text-white font-medium hover:bg-[#7C3AED]"
                >
                  Save
                </button>
              </div>
            </div>
          ) : (
            <>
              {comment.text && <p className="text-xs text-[#E2E1EC] break-words leading-relaxed">{comment.text}</p>}

              {/* GIF display inside comment */}
              {comment.gifUrl && (
                <div
                  className="mt-2 max-w-[200px] rounded-xl overflow-hidden border border-[#302D46] shadow-md cursor-pointer hover:border-purple-500/60 transition-all group relative"
                  onClick={() => setLightboxGif(comment.gifUrl || null)}
                  title="Click to view full size"
                >
                  <img
                    src={comment.gifUrl}
                    alt={comment.gifTitle || 'Comment GIF'}
                    className="w-full h-auto object-cover max-h-40 rounded-lg group-hover:scale-105 transition-transform"
                    loading="lazy"
                  />
                  <span className="absolute top-1 left-1 px-1 py-0.2 rounded bg-black/70 text-[9px] font-black text-purple-300 uppercase pointer-events-none">
                    GIF
                  </span>
                </div>
              )}
            </>
          )}

          {/* Comment Actions Footer */}
          <div className="flex items-center gap-4 mt-2 text-[11px] text-[#A5A3B8]">
            <button
              onClick={() => handleLikeComment(comment.id)}
              className={`flex items-center gap-1 transition cursor-pointer ${
                comment.isLiked ? 'text-red-400 font-semibold' : 'hover:text-white'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${comment.isLiked ? 'fill-current' : ''}`} />
              <span>{formatCompactNumber(comment.likesCount)}</span>
            </button>

            {!isReply && (
              <button
                onClick={() => {
                  setReplyingTo(comment);
                  setInputText(`@${comment.username} `);
                }}
                className="hover:text-white font-medium transition cursor-pointer"
              >
                Reply
              </button>
            )}

            {isOwner && (
              <>
                <button
                  onClick={() => {
                    setEditingCommentId(comment.id);
                    setEditText(comment.text);
                  }}
                  className="hover:text-white opacity-0 group-hover:opacity-100 transition cursor-pointer"
                  title="Edit comment"
                >
                  <Edit2 className="w-3 h-3" />
                </button>
                <button
                  onClick={() => handleDeleteComment(comment.id)}
                  className="hover:text-red-400 opacity-0 group-hover:opacity-100 transition cursor-pointer"
                  title="Delete comment"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </>
            )}

            {onOpenReportModal && (
              <button
                onClick={() => onOpenReportModal(comment.id, comment.text || 'GIF comment')}
                className="hover:text-yellow-400 opacity-0 group-hover:opacity-100 transition cursor-pointer ml-auto"
                title="Report comment"
              >
                <Flag className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Nested Replies */}
          {comment.replies && comment.replies.length > 0 && (
            <div className="mt-2 space-y-2">
              {comment.replies.map((reply) => renderCommentItem(reply, true))}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:justify-end bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-[#0F0F1D] border-t sm:border-l border-[#302D46] w-full sm:w-[420px] md:w-[460px] h-[80vh] sm:h-full flex flex-col rounded-t-3xl sm:rounded-none shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-[#202035] shrink-0">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-[#C4B5FD]" />
            <h3 className="text-sm font-bold text-white tracking-wide">
              Comments <span className="text-[#A5A3B8] font-normal text-xs">({comments.length})</span>
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-[#1E1E38] transition cursor-pointer"
            aria-label="Close comments"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Replying banner */}
        {replyingTo && (
          <div className="bg-[#1A1A30] px-4 py-2 border-b border-[#2A2A46] flex items-center justify-between text-xs text-[#C4B5FD] shrink-0">
            <div className="flex items-center gap-1.5 truncate">
              <CornerDownRight className="w-3.5 h-3.5 text-[#8B5CF6] shrink-0" />
              <span>Replying to <strong className="text-white">@{replyingTo.username}</strong></span>
            </div>
            <button
              onClick={() => {
                setReplyingTo(null);
                setInputText('');
              }}
              className="text-[#A5A3B8] hover:text-white text-xs ml-2"
            >
              Cancel
            </button>
          </div>
        )}

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto px-4 divide-y divide-[#18182B] custom-scrollbar">
          {!short.allowComments ? (
            <div className="py-12 text-center text-xs text-[#A5A3B8]">
              Comments have been turned off by the creator.
            </div>
          ) : loading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-2 text-[#A5A3B8] text-xs">
              <Loader2 className="w-6 h-6 animate-spin text-[#8B5CF6]" />
              <span>Loading conversation...</span>
            </div>
          ) : comments.length === 0 ? (
            <div className="py-16 text-center">
              <div className="w-12 h-12 rounded-2xl bg-[#18182E] flex items-center justify-center mx-auto mb-3 text-[#C4B5FD]">
                <MessageCircle className="w-6 h-6" />
              </div>
              <p className="text-sm font-medium text-white mb-1">No comments yet</p>
              <p className="text-xs text-[#A5A3B8]">Be the first to share your thoughts or post a GIF!</p>
            </div>
          ) : (
            comments.map((comment) => renderCommentItem(comment))
          )}
        </div>

        {/* Floating GIF Picker Popover */}
        {showGifPicker && (
          <div className="absolute bottom-20 left-4 right-4 z-20">
            <GifPicker
              onSelectGif={(gif) => {
                setSelectedGif(gif);
                setShowGifPicker(false);
              }}
              onClose={() => setShowGifPicker(false)}
            />
          </div>
        )}

        {/* Bottom Input Area */}
        {short.allowComments && (
          <div className="p-3 bg-[#121224] border-t border-[#202035] shrink-0">
            {/* Selected Preset GIF Preview Tag */}
            {selectedGif && (
              <div className="mb-2 flex items-center gap-2 bg-[#1B1B36] p-1.5 rounded-xl border border-[#302D46] w-fit">
                <img
                  src={selectedGif.previewUrl || selectedGif.url}
                  alt={selectedGif.title}
                  className="w-10 h-10 object-cover rounded-lg"
                />
                <span className="text-xs text-white max-w-[120px] truncate">{selectedGif.title}</span>
                <button
                  type="button"
                  onClick={() => setSelectedGif(null)}
                  className="p-1 rounded-full hover:bg-black/40 text-[#A5A3B8] hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Native Keyboard GIF / Attached Media Preview Tag */}
            {pendingMediaFile && (
              <div className="mb-2 flex items-center gap-2 bg-[#1B1B36] p-1.5 rounded-xl border border-purple-500/50 w-fit">
                <img
                  src={pendingMediaFile.previewUrl}
                  alt={pendingMediaFile.name}
                  className="w-10 h-10 object-cover rounded-lg"
                />
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-purple-300 uppercase">
                    {pendingMediaFile.isGif ? 'Native Keyboard GIF' : 'Image Attachment'}
                  </span>
                  <span className="text-xs text-white max-w-[120px] truncate">{pendingMediaFile.name}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (pendingMediaFile.previewUrl) URL.revokeObjectURL(pendingMediaFile.previewUrl);
                    setPendingMediaFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  className="p-1 rounded-full hover:bg-black/40 text-[#A5A3B8] hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <form onSubmit={handleSubmitComment} className="flex items-center gap-2">
              {/* Hidden file input for native gallery/keyboard GIF attachments */}
              <input
                type="file"
                ref={fileInputRef}
                accept="image/gif,image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileSelect(file);
                }}
              />

              {/* Attachment Button */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={!user || submitting || uploadingMedia}
                className="p-2.5 rounded-xl bg-[#18182E] hover:bg-[#252542] text-[#A5A3B8] hover:text-purple-300 border border-[#302D46] transition cursor-pointer disabled:opacity-40 shrink-0"
                title="Attach GIF or photo from device"
              >
                <Paperclip className="w-4 h-4" />
              </button>

              <div className="relative flex-1">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onPaste={handlePaste}
                  placeholder={
                    user
                      ? replyingTo
                        ? `Reply to @${replyingTo.username}...`
                        : pendingMediaFile || selectedGif
                        ? 'Add a caption (optional)...'
                        : 'Add comment or paste GIF directly...'
                      : 'Log in to join the conversation...'
                  }
                  disabled={!user || submitting || uploadingMedia}
                  className="w-full bg-[#18182E] border border-[#302D46] rounded-xl pl-3 pr-10 py-2.5 text-xs text-white placeholder-[#6C6A84] focus:outline-none focus:border-[#8B5CF6]"
                />
                {/* Preset GIF Button beside input */}
                <button
                  type="button"
                  onClick={() => setShowGifPicker((prev) => !prev)}
                  disabled={!user || submitting || uploadingMedia}
                  className={`absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center justify-center ${
                    showGifPicker || selectedGif
                      ? 'bg-purple-600 text-white'
                      : 'text-[#C4B5FD] hover:bg-[#252542] hover:text-white'
                  }`}
                  title="Browse preset GIFs"
                >
                  <span className="text-[10px] uppercase tracking-wider font-black">GIF</span>
                </button>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={!user || submitting || uploadingMedia || (!inputText.trim() && !selectedGif && !pendingMediaFile)}
                className="p-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white hover:brightness-110 disabled:opacity-40 transition cursor-pointer shadow-md shadow-purple-500/20 shrink-0 min-w-[38px] flex items-center justify-center"
              >
                {submitting || uploadingMedia ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </button>
            </form>
          </div>
        )}

        {/* Enlarged Comment GIF Modal */}
        {lightboxGif && (
          <div
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn"
            onClick={() => setLightboxGif(null)}
          >
            <div
              className="relative max-w-sm sm:max-w-md w-full bg-[#121222] border border-[#302D46] rounded-2xl p-3 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#202035]">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-600 text-white font-black uppercase">
                    GIF
                  </span>
                  <span>Animated GIF</span>
                </span>
                <button
                  type="button"
                  onClick={() => setLightboxGif(null)}
                  className="p-1 rounded-lg text-[#A5A3B8] hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <img
                src={lightboxGif}
                alt="Enlarged GIF"
                className="w-full max-h-[60vh] object-contain rounded-xl bg-black/40"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
