export interface ShortVideo {
  id: string;
  creatorId: string;
  creatorUsername: string;
  creatorAvatar?: string;
  videoUrl: string;
  thumbnailUrl?: string;
  caption: string;
  hashtags: string[];
  duration: number; // in seconds (<= 60)
  likesCount: number;
  viewsCount: number;
  commentsCount: number;
  isLiked?: boolean;
  isSaved?: boolean;
  isFollowing?: boolean;
  allowComments: boolean;
  status: 'active' | 'hidden' | 'deleted';
  createdAt: string;
  updatedAt?: string;
  // YouTube Video Publisher Integration
  source?: 'upload' | 'youtube';
  youtubeVideoId?: string;
  youtubeUrl?: string;
  youtubeChannelTitle?: string;
  youtubeChannelId?: string;
  youtubeChannelUrl?: string;
  isAttributionVerified?: boolean;
  publishedByAdminId?: string;
  publishedByAdminUsername?: string;
}

export interface ShortComment {
  id: string;
  shortId: string;
  userId: string;
  username: string;
  userAvatar?: string;
  text: string;
  gifUrl?: string;
  gifTitle?: string;
  mediaType?: 'gif' | 'image';
  likesCount: number;
  isLiked?: boolean;
  replyToCommentId?: string | null;
  replyToUsername?: string | null;
  createdAt: string;
  updatedAt?: string;
  replies?: ShortComment[];
}

export interface GifItem {
  id: string;
  title: string;
  url: string;
  previewUrl: string;
}

export interface CreatorProfileData {
  id: string;
  username: string;
  avatarUrl?: string;
  bio?: string;
  followersCount: number;
  followingCount: number;
  totalViews: number;
  isFollowing?: boolean;
  shorts: ShortVideo[];
}

export interface ShortReport {
  id: string;
  targetType: 'short' | 'comment';
  targetId: string;
  reporterId: string;
  reporterUsername: string;
  reason: string;
  details?: string;
  shortSnippet?: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
}
