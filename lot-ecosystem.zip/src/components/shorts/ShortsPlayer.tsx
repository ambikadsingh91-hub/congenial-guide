import React, { useState, useRef, useEffect } from 'react';
import {
  Heart,
  MessageCircle,
  Bookmark,
  Share2,
  Volume2,
  VolumeX,
  Play,
  Pause,
  MoreVertical,
  Flag,
  UserPlus,
  UserCheck,
  Check,
  Sparkles,
  ChevronUp,
  ChevronDown,
  AlertCircle,
  Edit3,
  Trash2,
  Loader2,
  Youtube,
  ExternalLink,
} from 'lucide-react';
import { ShortVideo } from './types';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';
import { playClickSound, playNotificationSound, playMenuSound } from '../../lib/sounds';

interface ShortsPlayerProps {
  shorts: ShortVideo[];
  currentIndex: number;
  onIndexChange: (newIndex: number) => void;
  onOpenComments: (short: ShortVideo) => void;
  onOpenCreator: (username: string) => void;
  onOpenReport: (short: ShortVideo) => void;
  onHashtagClick: (hashtag: string) => void;
  onShortUpdated?: (updated: ShortVideo) => void;
  onShortDeleted?: (shortId: string) => void;
}

export const ShortsPlayer: React.FC<ShortsPlayerProps> = ({
  shorts,
  currentIndex,
  onIndexChange,
  onOpenComments,
  onOpenCreator,
  onOpenReport,
  onHashtagClick,
  onShortUpdated,
  onShortDeleted,
}) => {
  const { user, openAuthModal } = useAuth();
  const currentShort = shorts[currentIndex];

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showPlayPulse, setShowPlayPulse] = useState(false);
  const [showHeartBurst, setShowHeartBurst] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [captionExpanded, setCaptionExpanded] = useState(false);
  const [isBuffering, setIsBuffering] = useState(false);
  const [videoError, setVideoError] = useState(false);

  // Local engagement state for the current video to guarantee instant UI responsiveness
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(0);
  const [isSaved, setIsSaved] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);

  // Check if current user is creator or admin
  const isCreator = Boolean(
    user &&
      currentShort &&
      (user.id === currentShort.creatorId ||
        user.username?.toLowerCase() === currentShort.creatorUsername?.toLowerCase() ||
        user.isAdmin)
  );

  // Edit short state
  const [isEditing, setIsEditing] = useState(false);
  const [editCaption, setEditCaption] = useState('');
  const [editAllowComments, setEditAllowComments] = useState(true);
  const [savingEdit, setSavingEdit] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  // Delete short state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingShort, setDeletingShort] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const handleOpenEdit = () => {
    if (!currentShort) return;
    setShowMoreMenu(false);
    setEditCaption(currentShort.caption || '');
    setEditAllowComments(currentShort.allowComments !== false);
    setEditError(null);
    setIsEditing(true);
  };

  const handleOpenDelete = () => {
    setShowMoreMenu(false);
    setDeleteError(null);
    setShowDeleteConfirm(true);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !currentShort) return;
    setSavingEdit(true);
    setEditError(null);
    try {
      const res = await fetch(`/api/shorts/${currentShort.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.token}`,
        },
        credentials: 'include',
        body: JSON.stringify({
          caption: editCaption.trim(),
          allowComments: editAllowComments,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update short.');
      }
      playNotificationSound();
      if (onShortUpdated && data.short) {
        onShortUpdated(data.short);
      }
      setIsEditing(false);
    } catch (err: any) {
      setEditError(err.message || 'Failed to save changes.');
    } finally {
      setSavingEdit(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!user || !currentShort) return;
    setDeletingShort(true);
    setDeleteError(null);
    try {
      const res = await fetch(`/api/shorts/${currentShort.id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
        credentials: 'include',
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to delete short.');
      }
      playClickSound();
      setShowDeleteConfirm(false);
      if (onShortDeleted) {
        onShortDeleted(currentShort.id);
      }
    } catch (err: any) {
      setDeleteError(err.message || 'Failed to delete short.');
    } finally {
      setDeletingShort(false);
    }
  };

  // Sync state whenever currentIndex changes
  useEffect(() => {
    if (!currentShort) return;
    setIsLiked(!!currentShort.isLiked);
    setLikesCount(currentShort.likesCount || 0);
    setIsSaved(!!currentShort.isSaved);
    setIsFollowing(!!currentShort.isFollowing);
    setProgress(0);
    setCurrentTime(0);
    setShowMoreMenu(false);
    setCaptionExpanded(false);
    setVideoError(false);

    // Record view after 1.5 seconds of watching
    const viewTimer = setTimeout(() => {
      fetch(`/api/shorts/${currentShort.id}/view`, { method: 'POST' }).catch(() => {});
    }, 1500);

    return () => clearTimeout(viewTimer);
  }, [currentIndex, currentShort?.id]);

  // Handle video element play / pause when active short changes
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !currentShort?.videoUrl) return;

    setVideoError(false);
    setIsBuffering(true);

    try {
      video.currentTime = 0;
      video.load();
    } catch {}

    const playPromise = video.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          setIsPlaying(true);
          setIsBuffering(false);
        })
        .catch(() => {
          // Autoplay policy fallback: mute and retry
          video.muted = true;
          setIsMuted(true);
          video
            .play()
            .then(() => {
              setIsPlaying(true);
              setIsBuffering(false);
            })
            .catch(() => {
              setIsPlaying(false);
              setIsBuffering(false);
            });
        });
    }

    // Buffering watchdog: auto-clear stuck buffering spinner after 3.5 seconds
    const watchdog = setTimeout(() => {
      setIsBuffering(false);
    }, 3500);

    return () => clearTimeout(watchdog);
  }, [currentIndex, currentShort?.videoUrl]);

  // Keyboard navigation (Arrow Up, Arrow Down, Space to play/pause, M to mute)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['input', 'textarea'].includes((document.activeElement?.tagName || '').toLowerCase())) {
        return;
      }

      if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        handlePrev();
      } else if (e.key === ' ') {
        e.preventDefault();
        togglePlayPause();
      } else if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        toggleMute();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, shorts.length]);

  const handleNext = () => {
    if (currentIndex < shorts.length - 1) {
      playClickSound();
      onIndexChange(currentIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      playClickSound();
      onIndexChange(currentIndex - 1);
    }
  };

  const togglePlayPause = () => {
    const video = videoRef.current;
    if (!video) return;

    if (video.paused) {
      video.play();
      setIsPlaying(true);
    } else {
      video.pause();
      setIsPlaying(false);
    }
    setShowPlayPulse(true);
    setTimeout(() => setShowPlayPulse(false), 500);
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setIsMuted(video.muted);
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;
    setCurrentTime(video.currentTime);
    const dur = video.duration || currentShort?.duration || 1;
    setDuration(dur);
    setProgress((video.currentTime / dur) * 100);
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current;
    if (!video) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    const dur = video.duration || currentShort?.duration || 1;
    video.currentTime = pos * dur;
    setProgress(pos * 100);
  };

  // Like action
  const handleToggleLike = async () => {
    if (!user) {
      openAuthModal();
      return;
    }
    if (!currentShort) return;

    const nextLiked = !isLiked;
    setIsLiked(nextLiked);
    const nextCount = nextLiked ? likesCount + 1 : Math.max(0, likesCount - 1);
    setLikesCount(nextCount);

    if (nextLiked) {
      setShowHeartBurst(true);
      playClickSound();
      setTimeout(() => setShowHeartBurst(false), 800);
    }

    if (onShortUpdated) {
      onShortUpdated({ ...currentShort, isLiked: nextLiked, likesCount: nextCount });
    }

    try {
      await fetch(`/api/shorts/${currentShort.id}/like`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${user.token}` },
      });
    } catch (err) {
      console.error('Failed to like short:', err);
    }
  };

  // Double tap to like on video screen
  let lastTap = 0;
  const handleScreenClick = (e: React.MouseEvent) => {
    const now = Date.now();
    if (now - lastTap < 300) {
      // Double tap detected!
      if (!isLiked) {
        handleToggleLike();
      } else {
        setShowHeartBurst(true);
        setTimeout(() => setShowHeartBurst(false), 800);
      }
    } else {
      togglePlayPause();
    }
    lastTap = now;
  };

  // Save / Bookmark
  const handleToggleSave = async () => {
    if (!user) {
      openAuthModal();
      return;
    }
    if (!currentShort) return;

    playMenuSound();
    const nextSaved = !isSaved;
    setIsSaved(nextSaved);

    if (onShortUpdated) {
      onShortUpdated({ ...currentShort, isSaved: nextSaved });
    }

    try {
      await fetch(`/api/shorts/${currentShort.id}/save`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${user.token}` },
      });
    } catch (err) {
      console.error('Failed to save short:', err);
    }
  };

  // Follow creator
  const handleToggleFollow = async () => {
    if (!user) {
      openAuthModal();
      return;
    }
    if (!currentShort) return;

    playMenuSound();
    const nextFollowing = !isFollowing;
    setIsFollowing(nextFollowing);

    if (onShortUpdated) {
      onShortUpdated({ ...currentShort, isFollowing: nextFollowing });
    }

    try {
      await fetch(`/api/shorts/creator/${currentShort.creatorId}/follow`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${user.token}` },
      });
    } catch (err) {
      console.error('Failed to toggle follow:', err);
    }
  };

  // Share
  const handleShare = async () => {
    if (!currentShort) return;
    playClickSound();

    const url = window.location.origin + `?short=${currentShort.id}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `LOT Short by @${currentShort.creatorUsername}`,
          text: currentShort.caption,
          url,
        });
        return;
      } catch {}
    }

    // Fallback: copy link
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  if (!currentShort) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] text-center text-[#A5A3B8]">
        <Sparkles className="w-10 h-10 text-[#8B5CF6] mb-3 animate-pulse" />
        <h3 className="text-base font-bold text-white mb-1">No Shorts available in this feed</h3>
        <p className="text-xs">Be the first to upload a short or explore other feeds!</p>
      </div>
    );
  }

  return (
    <div className="relative w-full max-w-md mx-auto flex items-center justify-center">
      {/* Vertical 9:16 Video Canvas */}
      <div
        ref={containerRef}
        className="relative w-full aspect-[9/16] max-h-[82vh] sm:max-h-[85vh] bg-black rounded-3xl overflow-hidden shadow-2xl border border-[#302D46] select-none group"
      >
        {currentShort.youtubeVideoId ? (
          <div className="w-full h-full relative bg-black flex items-center justify-center">
            <iframe
              key={currentShort.id}
              src={`https://www.youtube-nocookie.com/embed/${currentShort.youtubeVideoId}?autoplay=1&mute=${isMuted ? 1 : 0}&loop=1&playlist=${currentShort.youtubeVideoId}&playsinline=1&rel=0&modestbranding=1&enablejsapi=1`}
              title={currentShort.caption || 'YouTube Short'}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              className="w-full h-full border-0 object-cover"
            />
          </div>
        ) : (
          <video
            ref={videoRef}
            src={currentShort.videoUrl}
            poster={currentShort.thumbnailUrl}
            loop
            playsInline
            preload="auto"
            muted={isMuted}
            onTimeUpdate={handleTimeUpdate}
            onWaiting={() => setIsBuffering(true)}
            onCanPlay={() => setIsBuffering(false)}
            onCanPlayThrough={() => setIsBuffering(false)}
            onLoadedData={() => setIsBuffering(false)}
            onPlaying={() => {
              setIsBuffering(false);
              setIsPlaying(true);
            }}
            onError={() => {
              setIsBuffering(false);
              setVideoError(true);
            }}
            className="w-full h-full object-cover cursor-pointer"
            onClick={handleScreenClick}
          />
        )}

        {/* Buffering Indicator */}
        {isBuffering && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30 pointer-events-none z-15">
            <div className="w-10 h-10 border-4 border-[#8B5CF6] border-t-transparent rounded-full animate-spin" />
          </div>
        )}

        {/* Playback Error & Tap to Retry */}
        {videoError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 z-25 p-4 text-center">
            <AlertCircle className="w-10 h-10 text-amber-400 mb-2 animate-bounce" />
            <p className="text-white text-xs font-semibold mb-1">Playback interrupted</p>
            <p className="text-[#A5A3B8] text-[11px] mb-3">Unable to stream video track</p>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setVideoError(false);
                setIsBuffering(true);
                const video = videoRef.current;
                if (video && currentShort?.videoUrl) {
                  const sep = currentShort.videoUrl.includes('?') ? '&' : '?';
                  video.src = `${currentShort.videoUrl}${sep}_t=${Date.now()}`;
                  video.load();
                  video.play().catch(() => {
                    video.muted = true;
                    setIsMuted(true);
                    video.play().catch(() => {});
                  });
                }
              }}
              className="px-4 py-1.5 rounded-full bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-bold transition shadow-lg cursor-pointer active:scale-95"
            >
              Tap to Retry
            </button>
          </div>
        )}

        {/* Play / Pause Animated Icon Overlay */}
        {showPlayPulse && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none animate-ping duration-300">
            <div className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white">
              {isPlaying ? <Play className="w-8 h-8 fill-current ml-1" /> : <Pause className="w-8 h-8 fill-current" />}
            </div>
          </div>
        )}

        {/* Double-tap Heart Burst Overlay */}
        {showHeartBurst && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none animate-in zoom-in-50 duration-200">
            <Heart className="w-24 h-24 text-red-500 fill-current drop-shadow-[0_0_25px_rgba(239,68,68,0.8)] animate-bounce" />
          </div>
        )}

        {/* Top Controls Bar */}
        <div className="absolute top-0 inset-x-0 p-4 bg-gradient-to-b from-black/80 via-black/30 to-transparent flex items-center justify-between z-20">
          <div className="flex items-center gap-2">
            {currentShort.youtubeVideoId ? (
              <span className="px-2.5 py-1 rounded-full bg-red-950/85 backdrop-blur-md text-[11px] font-bold text-red-200 border border-red-500/50 flex items-center gap-1.5 shadow-lg">
                <Youtube className="w-3.5 h-3.5 text-red-500" />
                <span>YouTube Short</span>
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-full bg-black/50 backdrop-blur-md text-[11px] font-bold text-white border border-white/10 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
                LOT Shorts
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Mute / Unmute Button */}
            <button
              onClick={toggleMute}
              className="p-2 rounded-full bg-black/60 hover:bg-black/90 backdrop-blur-md text-white transition cursor-pointer"
              aria-label={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-green-400" />}
            </button>

            {/* Options Menu Toggle */}
            <div className="relative">
              <button
                onClick={() => setShowMoreMenu((prev) => !prev)}
                className="p-2 rounded-full bg-black/60 hover:bg-black/90 backdrop-blur-md text-white transition cursor-pointer"
                aria-label="More options"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {showMoreMenu && (
                <div className="absolute right-0 top-10 w-44 bg-[#141428] border border-[#302D46] rounded-xl shadow-2xl py-1 z-30 text-xs">
                  {isCreator && (
                    <>
                      <button
                        onClick={handleOpenEdit}
                        className="w-full px-3 py-2 text-left text-purple-300 hover:bg-[#1E1E38] flex items-center gap-2 transition cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5 text-[#8B5CF6]" />
                        <span className="font-semibold">Edit Short</span>
                      </button>
                      <button
                        onClick={handleOpenDelete}
                        className="w-full px-3 py-2 text-left text-red-400 hover:bg-[#1E1E38] flex items-center gap-2 transition cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span className="font-semibold">Delete Short</span>
                      </button>
                      <div className="my-1 border-t border-[#262640]" />
                    </>
                  )}
                  {!isCreator && (
                    <button
                      onClick={() => {
                        setShowMoreMenu(false);
                        onOpenReport(currentShort);
                      }}
                      className="w-full px-3 py-2 text-left text-red-400 hover:bg-[#1E1E38] flex items-center gap-2 transition"
                    >
                      <Flag className="w-3.5 h-3.5" />
                      <span>Report Short</span>
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setShowMoreMenu(false);
                      handleShare();
                    }}
                    className="w-full px-3 py-2 text-left text-white hover:bg-[#1E1E38] flex items-center gap-2 transition"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Copy Link</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowMoreMenu(false);
                      onOpenCreator(currentShort.creatorUsername);
                    }}
                    className="w-full px-3 py-2 text-left text-white hover:bg-[#1E1E38] flex items-center gap-2 transition"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>View Channel</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Interaction Sidebar (Action Bar) */}
        <div className="absolute right-3 bottom-16 sm:bottom-18 flex flex-col items-center gap-3.5 z-20">
          {/* Creator Avatar & Follow Button */}
          <div className="relative mb-1">
            <button
              onClick={() => onOpenCreator(currentShort.creatorUsername)}
              className="w-11 h-11 rounded-full p-0.5 bg-gradient-to-tr from-[#8B5CF6] to-[#C4B5FD] shadow-lg cursor-pointer hover:scale-105 transition"
            >
              <div className="w-full h-full rounded-full overflow-hidden bg-black flex items-center justify-center font-bold text-xs text-white">
                {currentShort.creatorAvatar ? (
                  <img src={currentShort.creatorAvatar} alt={currentShort.creatorUsername} className="w-full h-full object-cover" />
                ) : (
                  currentShort.creatorUsername.charAt(0).toUpperCase()
                )}
              </div>
            </button>
            {user?.id !== currentShort.creatorId && !isFollowing && (
              <button
                onClick={handleToggleFollow}
                className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-[#8B5CF6] hover:bg-[#7C3AED] text-white flex items-center justify-center shadow-md transition cursor-pointer"
                title="Follow creator"
              >
                <span className="text-xs font-black leading-none">+</span>
              </button>
            )}
          </div>

          {/* Upward Arrow: Scroll Up (Previous Short) */}
          <div className="flex flex-col items-center">
            <button
              onClick={handlePrev}
              disabled={currentIndex === 0}
              className={`w-11 h-11 rounded-full bg-black/75 hover:bg-purple-600 backdrop-blur-md flex items-center justify-center transition-all cursor-pointer shadow-xl active:scale-90 border ${
                currentIndex === 0
                  ? 'opacity-25 cursor-not-allowed text-white/30 border-white/5'
                  : 'text-white border-purple-500/40 hover:border-purple-300 hover:scale-105 shadow-purple-500/20'
              }`}
              aria-label="Scroll Up (Previous Short)"
              title="Scroll Up (Previous Short)"
            >
              <ChevronUp className="w-6 h-6" />
            </button>
            <span className="text-[10px] font-bold text-white drop-shadow-md mt-1">Up</span>
          </div>

          {/* Downward Arrow: Scroll Down (Next Short) */}
          <div className="flex flex-col items-center">
            <button
              onClick={handleNext}
              disabled={currentIndex >= shorts.length - 1}
              className={`w-11 h-11 rounded-full bg-black/75 hover:bg-purple-600 backdrop-blur-md flex items-center justify-center transition-all cursor-pointer shadow-xl active:scale-90 border ${
                currentIndex >= shorts.length - 1
                  ? 'opacity-25 cursor-not-allowed text-white/30 border-white/5'
                  : 'text-white border-purple-500/40 hover:border-purple-300 hover:scale-105 shadow-purple-500/20'
              }`}
              aria-label="Scroll Down (Next Short)"
              title="Scroll Down (Next Short)"
            >
              <ChevronDown className="w-6 h-6" />
            </button>
            <span className="text-[10px] font-bold text-white drop-shadow-md mt-1">Down</span>
          </div>

          {/* Like Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={handleToggleLike}
              className={`w-11 h-11 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md flex items-center justify-center transition cursor-pointer shadow-lg active:scale-90 ${
                isLiked ? 'text-red-500' : 'text-white hover:text-red-400'
              }`}
              aria-label="Like short"
            >
              <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
            </button>
            <span className="text-[11px] font-bold text-white mt-1 drop-shadow-md">
              {formatCompactNumber(likesCount)}
            </span>
          </div>

          {/* Comments Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={() => onOpenComments(currentShort)}
              className="w-11 h-11 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md flex items-center justify-center text-white hover:text-[#C4B5FD] transition cursor-pointer shadow-lg active:scale-90"
              aria-label="View comments"
            >
              <MessageCircle className="w-5 h-5" />
            </button>
            <span className="text-[11px] font-bold text-white mt-1 drop-shadow-md">
              {formatCompactNumber(currentShort.commentsCount)}
            </span>
          </div>

          {/* Save / Bookmark Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={handleToggleSave}
              className={`w-11 h-11 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md flex items-center justify-center transition cursor-pointer shadow-lg active:scale-90 ${
                isSaved ? 'text-yellow-400' : 'text-white hover:text-yellow-400'
              }`}
              aria-label="Bookmark short"
            >
              <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
            </button>
            <span className="text-[10px] font-bold text-white mt-1 drop-shadow-md">
              {isSaved ? 'Saved' : 'Save'}
            </span>
          </div>

          {/* Share Button */}
          <div className="flex flex-col items-center">
            <button
              onClick={handleShare}
              className="w-11 h-11 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md flex items-center justify-center text-white hover:text-purple-300 transition cursor-pointer shadow-lg active:scale-90 relative"
              aria-label="Share short"
            >
              {copiedLink ? <Check className="w-5 h-5 text-green-400" /> : <Share2 className="w-5 h-5" />}
            </button>
            <span className="text-[10px] font-bold text-white mt-1 drop-shadow-md">
              {copiedLink ? 'Copied' : 'Share'}
            </span>
          </div>
        </div>

        {/* Bottom Overlay Info (Caption, Creator, Tags) */}
        <div className="absolute bottom-3 inset-x-0 px-4 pb-2 bg-gradient-to-t from-black/95 via-black/60 to-transparent z-10 flex flex-col justify-end pointer-events-auto">
          {/* Creator @handle & Attribution / Creator Quick Actions */}
          <div className="flex items-center gap-2 mb-1.5 pr-14 flex-wrap">
            {currentShort.youtubeVideoId && currentShort.youtubeChannelTitle ? (
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-sm font-bold text-white flex items-center gap-1 drop-shadow">
                  {currentShort.youtubeChannelTitle}
                </span>
                {currentShort.isAttributionVerified && (
                  <span className="text-[9px] bg-red-950/90 border border-red-500/50 text-red-300 px-1.5 py-0.5 rounded font-black tracking-wider uppercase flex items-center gap-1">
                    <Youtube className="w-2.5 h-2.5 text-red-500" />
                    <span>YouTube Creator</span>
                  </span>
                )}
                {currentShort.publishedByAdminUsername && (
                  <span className="text-[10px] text-purple-300/80 font-medium">
                    (via admin @{currentShort.publishedByAdminUsername})
                  </span>
                )}
              </div>
            ) : (
              <button
                onClick={() => onOpenCreator(currentShort.creatorUsername)}
                className="text-sm font-bold text-white hover:text-[#C4B5FD] transition cursor-pointer truncate drop-shadow"
              >
                @{currentShort.creatorUsername}
              </button>
            )}

            {!currentShort.youtubeVideoId && user?.id !== currentShort.creatorId && !isCreator && (
              <button
                onClick={handleToggleFollow}
                className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full transition cursor-pointer ${
                  isFollowing
                    ? 'bg-white/20 text-white'
                    : 'bg-[#8B5CF6] hover:bg-[#7C3AED] text-white shadow-sm'
                }`}
              >
                {isFollowing ? 'Following' : 'Follow'}
              </button>
            )}

            {/* Creator Quick Actions */}
            {isCreator && (
              <div className="flex items-center gap-1.5 ml-auto">
                <button
                  onClick={handleOpenEdit}
                  className="px-2 py-0.5 rounded-lg bg-[#8B5CF6]/25 hover:bg-[#8B5CF6]/50 text-[#C4B5FD] hover:text-white border border-[#8B5CF6]/50 text-[10px] font-bold flex items-center gap-1 transition cursor-pointer shadow-sm active:scale-95"
                  title="Edit your Short"
                >
                  <Edit3 className="w-2.5 h-2.5" />
                  <span>Edit</span>
                </button>
                <button
                  onClick={handleOpenDelete}
                  className="px-2 py-0.5 rounded-lg bg-red-500/20 hover:bg-red-500/40 text-red-300 hover:text-red-100 border border-red-500/40 text-[10px] font-bold flex items-center gap-1 transition cursor-pointer shadow-sm active:scale-95"
                  title="Delete your Short"
                >
                  <Trash2 className="w-2.5 h-2.5" />
                  <span>Delete</span>
                </button>
              </div>
            )}
          </div>

          {/* Caption & Expandable text */}
          <div className="pr-14 mb-2">
            <p
              className={`text-xs text-[#E8E6F5] leading-relaxed transition-all ${
                captionExpanded ? '' : 'line-clamp-2'
              }`}
            >
              {currentShort.caption}
            </p>
            {currentShort.caption && currentShort.caption.length > 70 && (
              <button
                onClick={() => setCaptionExpanded(!captionExpanded)}
                className="text-[11px] font-semibold text-[#C4B5FD] hover:text-white mt-0.5"
              >
                {captionExpanded ? 'less' : '...more'}
              </button>
            )}
          </div>

          {/* Hashtag tags */}
          {currentShort.hashtags && currentShort.hashtags.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap pr-14 mb-2 text-[11px]">
              {currentShort.hashtags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => onHashtagClick(tag)}
                  className="text-[#C4B5FD] hover:text-white font-medium hover:underline cursor-pointer"
                >
                  {tag}
                </button>
              ))}
            </div>
          )}

          {/* Audio track pill */}
          <div className="flex items-center gap-1.5 text-[10px] text-[#A5A3B8] pr-14">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-ping" />
            <span className="truncate">Original audio - @{currentShort.creatorUsername}</span>
          </div>

          {/* Progress Scrubber Bar */}
          <div
            onClick={handleSeek}
            className="w-full mt-2 h-1.5 bg-white/25 hover:h-2 rounded-full cursor-pointer relative transition-all group/bar"
          >
            <div
              className="h-full bg-gradient-to-r from-[#8B5CF6] to-[#C4B5FD] rounded-full relative"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-white shadow-md opacity-0 group-hover/bar:opacity-100 transition" />
            </div>
          </div>
        </div>
      </div>

      {/* Floating Next & Previous Navigation Buttons for Desktop */}
      <div className="hidden lg:flex flex-col gap-3 absolute -right-16 top-1/2 -translate-y-1/2">
        <button
          onClick={handlePrev}
          disabled={currentIndex === 0}
          className="w-11 h-11 rounded-full bg-[#18182E] hover:bg-[#252545] border border-[#302D46] text-white disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center transition cursor-pointer shadow-lg"
          title="Previous Short (Up Arrow)"
        >
          <ChevronUp className="w-6 h-6" />
        </button>
        <button
          onClick={handleNext}
          disabled={currentIndex === shorts.length - 1}
          className="w-11 h-11 rounded-full bg-[#18182E] hover:bg-[#252545] border border-[#302D46] text-white disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center transition cursor-pointer shadow-lg"
          title="Next Short (Down Arrow)"
        >
          <ChevronDown className="w-6 h-6" />
        </button>
      </div>

      {/* Creator Edit Short Modal */}
      {isEditing && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200"
          onClick={() => !savingEdit && setIsEditing(false)}
        >
          <div
            className="bg-[#121226] border border-[#302D46] rounded-3xl w-full max-w-md p-5 sm:p-6 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#222238] mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 flex items-center justify-center text-[#C4B5FD]">
                  <Edit3 className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-white">Edit Your Short</h3>
              </div>
              <button
                onClick={() => !savingEdit && setIsEditing(false)}
                className="text-[#A5A3B8] hover:text-white p-1 rounded-lg hover:bg-white/10 transition cursor-pointer"
              >
                ✕
              </button>
            </div>

            {editError && (
              <div className="mb-4 p-2.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{editError}</span>
              </div>
            )}

            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#C4B5FD] mb-1.5">
                  Caption & #Hashtags
                </label>
                <textarea
                  value={editCaption}
                  onChange={(e) => setEditCaption(e.target.value)}
                  maxLength={250}
                  rows={3}
                  className="w-full bg-[#181830] border border-[#302D46] focus:border-[#8B5CF6] rounded-xl p-3 text-xs text-white placeholder-[#706E88] focus:outline-none resize-none"
                  placeholder="Update your caption or add #hashtags..."
                />
                <div className="flex items-center justify-between mt-1 text-[11px] text-[#A5A3B8]">
                  <span>Supports #gaming, #lot, #crypto, #vstocks</span>
                  <span>{editCaption.length}/250</span>
                </div>
              </div>

              {/* Quick tags */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {['#lot', '#vpay', '#vstocks', '#gaming', '#crypto'].map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      if (!editCaption.includes(tag)) {
                        setEditCaption((prev) => (prev ? `${prev.trim()} ${tag}` : tag));
                      }
                    }}
                    className="px-2 py-0.5 rounded-lg bg-[#20203D] hover:bg-[#2E2E55] text-[10px] text-[#C4B5FD] transition cursor-pointer"
                  >
                    {tag}
                  </button>
                ))}
              </div>

              {/* Allow Comments Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#181830] border border-[#2B2B44]">
                <div>
                  <p className="text-xs font-semibold text-white">Allow Viewer Comments</p>
                  <p className="text-[10px] text-[#A5A3B8]">Let viewers leave comments on this video</p>
                </div>
                <button
                  type="button"
                  onClick={() => setEditAllowComments(!editAllowComments)}
                  className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                    editAllowComments ? 'bg-[#8B5CF6]' : 'bg-[#302D46]'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                      editAllowComments ? 'left-6' : 'left-1'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  disabled={savingEdit}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-[#A5A3B8] hover:text-white hover:bg-[#1E1E38] transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingEdit}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:brightness-110 text-white text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-lg shadow-purple-500/20 active:scale-95"
                >
                  {savingEdit ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <span>Save Changes</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Creator Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200"
          onClick={() => !deletingShort && setShowDeleteConfirm(false)}
        >
          <div
            className="bg-[#121226] border border-red-500/30 rounded-3xl w-full max-w-sm p-5 sm:p-6 shadow-2xl relative text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/20 text-red-400 mx-auto mb-3 flex items-center justify-center border border-red-500/30">
              <Trash2 className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-white mb-1">Delete This Short?</h3>
            <p className="text-xs text-[#A5A3B8] mb-4 leading-relaxed">
              Are you sure you want to permanently delete this video? All likes, views, and comments will also be removed. This cannot be undone.
            </p>

            {deleteError && (
              <div className="mb-4 p-2 rounded-xl bg-red-950/70 border border-red-500/40 text-red-300 text-xs text-left flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{deleteError}</span>
              </div>
            )}

            <div className="flex items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                disabled={deletingShort}
                className="flex-1 py-2 rounded-xl text-xs font-semibold text-[#A5A3B8] hover:text-white bg-[#1A1A32] hover:bg-[#252545] transition cursor-pointer"
              >
                Keep Video
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={deletingShort}
                className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition cursor-pointer shadow-lg shadow-red-600/30 active:scale-95 flex items-center justify-center gap-1.5"
              >
                {deletingShort ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <span>Delete Video</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
