import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Compass,
  TrendingUp,
  UserCheck,
  Bookmark,
  Plus,
  Search,
  Sparkles,
  Loader2,
  Film,
  Hash,
  X,
  Volume2,
  RefreshCw,
  Share2,
} from 'lucide-react';
import { ShortVideo } from './types';
import { ShortsPlayer } from './ShortsPlayer';
import { CommentsModal } from './CommentsModal';
import { UploadShortModal } from './UploadShortModal';
import { CreatorProfileModal } from './CreatorProfileModal';
import { ReportModal } from './ReportModal';
import { useAuth } from '../../context/AuthContext';
import { playMenuSound, playClickSound } from '../../lib/sounds';

const POPULAR_TOPICS = [
  { label: 'All', tag: null },
  { label: 'Gaming', tag: '#gaming' },
  { label: 'Tech & AI', tag: '#tech' },
  { label: 'Coding', tag: '#coding' },
  { label: 'Memes', tag: '#memes' },
  { label: 'GTA', tag: '#gta' },
  { label: 'Anime', tag: '#anime' },
  { label: 'Marvel', tag: '#marvel' },
  { label: 'Science', tag: '#science' },
  { label: 'Satisfying', tag: '#satisfying' },
  { label: 'Music', tag: '#music' },
  { label: 'Sports', tag: '#sports' },
];

export const LotShorts: React.FC = () => {
  const { user, openAuthModal } = useAuth();

  // Feed tabs: foryou, following, trending, saved
  const [activeFeed, setActiveFeed] = useState<'foryou' | 'following' | 'trending' | 'saved'>('foryou');
  const [shorts, setShorts] = useState<ShortVideo[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Search & Hashtag filters
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTag, setActiveTag] = useState<string | null>(null);

  // Modals state
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [activeCommentsShort, setActiveCommentsShort] = useState<ShortVideo | null>(null);
  const [activeCreatorUsername, setActiveCreatorUsername] = useState<string | null>(null);
  const [reportTarget, setReportTarget] = useState<{
    type: 'short' | 'comment';
    id: string;
    snippet?: string;
  } | null>(null);

  // Load feed items
  const loadFeed = useCallback(
    async (isRefresh = false) => {
      if (isRefresh) setRefreshing(true);
      else setLoading(true);

      try {
        const headers: Record<string, string> = {};
        if (user?.token) {
          headers['Authorization'] = `Bearer ${user.token}`;
        }

        let endpoint = `/api/shorts/feed?feed=${activeFeed}&limit=100`;
        if (activeTag) {
          endpoint += `&tag=${encodeURIComponent(activeTag)}`;
        }
        if (searchQuery.trim()) {
          endpoint += `&search=${encodeURIComponent(searchQuery.trim())}`;
        }

        const res = await fetch(endpoint, { headers });
        if (res.ok) {
          const data = await res.json();
          setShorts(data.shorts || []);
          setCurrentIndex(0);
        }
      } catch (err) {
        console.error('Failed to load shorts feed:', err);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [activeFeed, activeTag, searchQuery, user?.token]
  );

  useEffect(() => {
    loadFeed();
  }, [loadFeed]);

  // Handle wheel navigation with throttle
  const wheelLockRef = useRef(false);
  const handleWheel = (e: React.WheelEvent) => {
    if (wheelLockRef.current) return;
    if (Math.abs(e.deltaY) > 40) {
      wheelLockRef.current = true;
      if (e.deltaY > 0 && currentIndex < shorts.length - 1) {
        setCurrentIndex((i) => i + 1);
        playClickSound();
      } else if (e.deltaY < 0 && currentIndex > 0) {
        setCurrentIndex((i) => i - 1);
        playClickSound();
      }
      setTimeout(() => {
        wheelLockRef.current = false;
      }, 600);
    }
  };

  const handleTabSwitch = (feed: 'foryou' | 'following' | 'trending' | 'saved') => {
    if (feed === 'saved' && !user) {
      openAuthModal();
      return;
    }
    if (feed === 'following' && !user) {
      openAuthModal();
      return;
    }
    playMenuSound();
    setActiveFeed(feed);
    setActiveTag(null);
    setSearchQuery('');
  };

  const handleTagClick = (tag: string) => {
    playClickSound();
    setActiveTag(tag);
  };

  const handleClearFilters = () => {
    setActiveTag(null);
    setSearchQuery('');
  };

  return (
    <div
      onWheel={handleWheel}
      className="flex flex-col items-center justify-start min-h-[calc(100vh-140px)] pb-12 w-full max-w-5xl mx-auto px-2 sm:px-4"
    >
      {/* Top Header & Navigation Bar */}
      <div className="w-full max-w-xl mx-auto mb-4 flex flex-col gap-3">
        {/* Feed tabs & Create button */}
        <div className="flex items-center justify-between gap-2 bg-[#121224] p-1.5 rounded-2xl border border-[#302D46] shadow-lg">
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
            <button
              onClick={() => handleTabSwitch('foryou')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeFeed === 'foryou' && !activeTag
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md shadow-purple-500/20'
                  : 'text-[#A5A3B8] hover:text-white hover:bg-[#1A1A32]'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>For You</span>
            </button>

            <button
              onClick={() => handleTabSwitch('trending')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeFeed === 'trending'
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md shadow-purple-500/20'
                  : 'text-[#A5A3B8] hover:text-white hover:bg-[#1A1A32]'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Trending</span>
            </button>

            <button
              onClick={() => handleTabSwitch('following')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeFeed === 'following'
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md shadow-purple-500/20'
                  : 'text-[#A5A3B8] hover:text-white hover:bg-[#1A1A32]'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Following</span>
            </button>

            <button
              onClick={() => handleTabSwitch('saved')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeFeed === 'saved'
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md shadow-purple-500/20'
                  : 'text-[#A5A3B8] hover:text-white hover:bg-[#1A1A32]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>Saved</span>
            </button>
          </div>

          {/* Upload Button */}
          <button
            onClick={() => {
              if (!user) {
                openAuthModal();
                return;
              }
              playMenuSound();
              setIsUploadOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#C4B5FD] text-[#0B0B14] font-black text-xs hover:brightness-110 shadow-md shadow-purple-500/25 transition cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span className="hidden xs:inline">Upload</span>
          </button>
        </div>

        {/* Search bar & quick filter tags */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#A5A3B8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search shorts, creators, or #topics..."
              className="w-full bg-[#121224] border border-[#2B2B44] rounded-xl pl-9 pr-8 py-2 text-xs text-white placeholder-[#6C6A84] focus:outline-none focus:border-[#8B5CF6]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#6C6A84] hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            onClick={() => loadFeed(true)}
            disabled={refreshing}
            className="p-2 rounded-xl bg-[#121224] border border-[#2B2B44] text-[#A5A3B8] hover:text-white hover:bg-[#1E1E38] transition cursor-pointer"
            title="Refresh Feed"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-[#8B5CF6]' : ''}`} />
          </button>
        </div>

        {/* Quick Topic / Genre Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 w-full">
          {POPULAR_TOPICS.map((topic) => {
            const isSelected = (!activeTag && topic.tag === null) || (activeTag && topic.tag && activeTag.toLowerCase() === topic.tag.toLowerCase());
            return (
              <button
                key={topic.label}
                onClick={() => {
                  playClickSound();
                  setActiveTag(topic.tag);
                  if (topic.tag === null) {
                    setSearchQuery('');
                  }
                }}
                className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer shrink-0 ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md shadow-purple-500/20'
                    : 'bg-[#151528] text-[#A5A3B8] hover:text-white hover:bg-[#1F1F38] border border-[#2B2B44]/80'
                }`}
              >
                {topic.label}
              </button>
            );
          })}
        </div>

        {/* Active Tag Filter chip */}
        {activeTag && (
          <div className="flex items-center gap-2 bg-[#1C1C35] px-3 py-1.5 rounded-xl border border-[#8B5CF6] text-xs text-[#C4B5FD] w-fit">
            <Hash className="w-3.5 h-3.5 text-[#8B5CF6]" />
            <span className="font-semibold">{activeTag}</span>
            <button
              onClick={() => setActiveTag(null)}
              className="p-0.5 rounded hover:bg-white/10 text-white ml-1"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>

      {/* Main Feed Content Area */}
      {loading ? (
        <div className="flex flex-col items-center justify-center h-[65vh] gap-3 text-center">
          <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] to-[#C4B5FD] flex items-center justify-center text-white shadow-xl shadow-purple-500/25">
            <Film className="w-7 h-7 animate-pulse" />
          </div>
          <p className="text-sm font-bold text-white">Loading LOT Shorts...</p>
          <p className="text-xs text-[#A5A3B8]">Streaming the finest vertical video moments</p>
        </div>
      ) : shorts.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-[60vh] text-center max-w-sm mx-auto p-6 bg-[#121224] rounded-3xl border border-[#302D46] shadow-xl">
          <div className="w-16 h-16 rounded-2xl bg-[#1E1E38] flex items-center justify-center text-[#C4B5FD] mb-4">
            <Film className="w-8 h-8" />
          </div>
          <h3 className="text-base font-black text-white mb-1.5">No Shorts Found</h3>
          <p className="text-xs text-[#A5A3B8] leading-relaxed mb-5">
            {activeFeed === 'following'
              ? 'You are not following any creators with published Shorts yet. Discover creators in For You or Trending!'
              : activeFeed === 'saved'
              ? 'You have not saved any Shorts yet. Click the bookmark icon on any short to save it for later.'
              : activeTag || searchQuery
              ? `No matching shorts found for "${activeTag || searchQuery}". Try another search keyword.`
              : 'Be the first creator in the LOT Ecosystem to publish a Short!'}
          </p>
          <div className="flex items-center gap-3">
            {(activeTag || searchQuery) && (
              <button
                onClick={handleClearFilters}
                className="px-4 py-2 rounded-xl bg-[#20203C] hover:bg-[#2C2C52] text-xs font-semibold text-white transition cursor-pointer"
              >
                Clear Search
              </button>
            )}
            <button
              onClick={() => {
                if (!user) openAuthModal();
                else setIsUploadOpen(true);
              }}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white text-xs font-bold shadow-lg shadow-purple-500/25 hover:brightness-110 transition cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Create Short</span>
            </button>
          </div>
        </div>
      ) : (
        <ShortsPlayer
          shorts={shorts}
          currentIndex={currentIndex}
          onIndexChange={(newIndex) => setCurrentIndex(newIndex)}
          onOpenComments={(short) => setActiveCommentsShort(short)}
          onOpenCreator={(creatorUsername) => setActiveCreatorUsername(creatorUsername)}
          onOpenReport={(short) =>
            setReportTarget({
              type: 'short',
              id: short.id,
              snippet: short.caption,
            })
          }
          onHashtagClick={handleTagClick}
          onShortUpdated={(updated) => {
            setShorts((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
          }}
          onShortDeleted={(shortId) => {
            setShorts((prev) => {
              const updated = prev.filter((s) => s.id !== shortId);
              if (currentIndex >= updated.length) {
                setCurrentIndex(Math.max(0, updated.length - 1));
              }
              return updated;
            });
          }}
        />
      )}

      {/* Comments Drawer / Modal */}
      {activeCommentsShort && (
        <CommentsModal
          short={activeCommentsShort}
          isOpen={!!activeCommentsShort}
          onClose={() => setActiveCommentsShort(null)}
          onCommentsCountChange={(count) => {
            setShorts((prev) =>
              prev.map((s) => (s.id === activeCommentsShort.id ? { ...s, commentsCount: count } : s))
            );
          }}
          onOpenReportModal={(commentId, commentSnippet) => {
            setReportTarget({
              type: 'comment',
              id: commentId,
              snippet: commentSnippet,
            });
          }}
        />
      )}

      {/* Upload Short Modal */}
      <UploadShortModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onSuccess={(newShort) => {
          setShorts((prev) => [newShort, ...prev]);
          setCurrentIndex(0);
        }}
      />

      {/* Creator Profile Modal */}
      {activeCreatorUsername && (
        <CreatorProfileModal
          username={activeCreatorUsername}
          isOpen={!!activeCreatorUsername}
          onClose={() => setActiveCreatorUsername(null)}
          onSelectShort={(selectedShort) => {
            const idx = shorts.findIndex((s) => s.id === selectedShort.id);
            if (idx >= 0) {
              setCurrentIndex(idx);
            } else {
              setShorts((prev) => [selectedShort, ...prev]);
              setCurrentIndex(0);
            }
          }}
          onShortDeleted={(shortId) => {
            setShorts((prev) => prev.filter((s) => s.id !== shortId));
          }}
          onShortUpdated={(updated) => {
            setShorts((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
          }}
        />
      )}

      {/* Safety & Moderation Report Modal */}
      {reportTarget && (
        <ReportModal
          targetType={reportTarget.type}
          targetId={reportTarget.id}
          targetSnippet={reportTarget.snippet}
          isOpen={!!reportTarget}
          onClose={() => setReportTarget(null)}
        />
      )}
    </div>
  );
};
