import React, { useState, useEffect } from 'react';
import { Search, Sparkles, Loader2, X } from 'lucide-react';
import { GifItem } from './types';

interface GifPickerProps {
  onSelectGif: (gif: GifItem) => void;
  onClose: () => void;
}

export const GifPicker: React.FC<GifPickerProps> = ({ onSelectGif, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [gifs, setGifs] = useState<GifItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'trending' | 'search'>('trending');
  const [error, setError] = useState<string | null>(null);

  // Fetch trending or search results
  useEffect(() => {
    let isCancelled = false;

    async function fetchGifs() {
      setLoading(true);
      setError(null);
      try {
        let endpoint = '/api/gifs/trending';
        if (searchQuery.trim().length > 0) {
          endpoint = `/api/gifs/search?q=${encodeURIComponent(searchQuery.trim())}`;
          setActiveTab('search');
        } else {
          setActiveTab('trending');
        }

        const res = await fetch(endpoint);
        if (!res.ok) {
          throw new Error('Failed to load GIFs');
        }
        const data = await res.json();
        if (!isCancelled) {
          setGifs(data.gifs || []);
        }
      } catch (err: any) {
        if (!isCancelled) {
          setError('Unable to load GIFs right now');
        }
      } finally {
        if (!isCancelled) {
          setLoading(false);
        }
      }
    }

    const timer = setTimeout(() => {
      fetchGifs();
    }, searchQuery ? 350 : 0);

    return () => {
      isCancelled = true;
      clearTimeout(timer);
    };
  }, [searchQuery]);

  return (
    <div className="bg-[#121222] border border-[#302D46] rounded-2xl shadow-2xl p-3 sm:p-4 w-full max-w-sm sm:max-w-md animate-in fade-in zoom-in-95 duration-150">
      <div className="flex items-center justify-between pb-3 border-b border-[#25253e] mb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#C4B5FD]" />
          <h4 className="text-sm font-bold text-white tracking-wide">Select a GIF</h4>
        </div>
        <button
          onClick={onClose}
          className="text-[#A5A3B8] hover:text-white p-1 rounded-lg hover:bg-[#1E1E38] transition cursor-pointer"
          aria-label="Close GIF Picker"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Search Input */}
      <div className="relative mb-3">
        <Search className="w-4 h-4 text-[#A5A3B8] absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search all GIFs..."
          className="w-full bg-[#18182E] border border-[#302D46] rounded-xl pl-9 pr-8 py-1.5 text-xs text-white placeholder-[#6C6A84] focus:outline-none focus:border-[#8B5CF6]"
          autoFocus
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#6C6A84] hover:text-white text-xs"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Quick Search Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 no-scrollbar text-[11px]">
        {['🔥 Fire', '🚀 Moon', '🎉 GG', '😂 Laugh', '✨ Neon', '🎮 Gamer'].map((tag) => (
          <button
            key={tag}
            onClick={() => setSearchQuery(tag.split(' ')[1].toLowerCase())}
            className="px-2.5 py-1 rounded-lg bg-[#19192F] hover:bg-[#262645] border border-[#2A2A46] text-[#A5A3B8] hover:text-[#F5F3FF] whitespace-nowrap transition cursor-pointer"
          >
            {tag}
          </button>
        ))}
      </div>

      {/* GIFs Grid */}
      <div className="h-64 overflow-y-auto pr-1 grid grid-cols-2 gap-2 custom-scrollbar">
        {loading ? (
          <div className="col-span-2 flex flex-col items-center justify-center h-48 text-[#A5A3B8] text-xs gap-2">
            <Loader2 className="w-6 h-6 animate-spin text-[#8B5CF6]" />
            <span>Finding awesome GIFs...</span>
          </div>
        ) : error ? (
          <div className="col-span-2 text-center py-8 text-xs text-red-400">
            {error}
          </div>
        ) : gifs.length === 0 ? (
          <div className="col-span-2 text-center py-8 text-xs text-[#A5A3B8]">
            No GIFs found for "{searchQuery}". Try another keyword!
          </div>
        ) : (
          gifs.map((gif) => (
            <button
              key={gif.id}
              onClick={() => onSelectGif(gif)}
              className="group relative rounded-xl overflow-hidden bg-[#1A1A32] border border-transparent hover:border-[#8B5CF6] transition-all aspect-video cursor-pointer"
            >
              <img
                src={gif.previewUrl || gif.url}
                alt={gif.title}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-200"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition flex items-end p-1.5">
                <span className="text-[10px] text-white font-medium truncate">{gif.title}</span>
              </div>
            </button>
          ))
        )}
      </div>

      {/* GIPHY / Tenor Attribution */}
      <div className="mt-2 pt-2 border-t border-[#25253e] flex items-center justify-between text-[10px] text-[#6C6A84]">
        <span>Powered by GIPHY API</span>
        <span className="font-semibold text-purple-400">LOT Media Engine</span>
      </div>
    </div>
  );
};
