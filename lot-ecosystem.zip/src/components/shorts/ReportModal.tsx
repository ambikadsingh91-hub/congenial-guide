import React, { useState } from 'react';
import { X, Flag, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { playNotificationSound, playErrorSound } from '../../lib/sounds';

interface ReportModalProps {
  targetType: 'short' | 'comment';
  targetId: string;
  targetSnippet?: string;
  isOpen: boolean;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  targetType,
  targetId,
  targetSnippet,
  isOpen,
  onClose,
}) => {
  const { user, openAuthModal } = useAuth();
  const [reason, setReason] = useState('Inappropriate Content');
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const reasons = [
    'Inappropriate Content',
    'Spam or Misleading',
    'Harassment or Bullying',
    'Hate Speech',
    'Scam or Fraud',
    'Copyright Violation',
    'Other Safety Concern',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal();
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const endpoint =
        targetType === 'short'
          ? `/api/shorts/${targetId}/report`
          : `/api/shorts/comments/${targetId}/report`;

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.token}`,
        },
        body: JSON.stringify({ reason, details }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to submit report');
      }

      playNotificationSound();
      setSubmitted(true);
      setTimeout(() => {
        onClose();
        setSubmitted(false);
        setDetails('');
      }, 1500);
    } catch (err: any) {
      playErrorSound();
      setError(err.message || 'Error submitting report');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div
        className="bg-[#121224] border border-[#302D46] rounded-2xl w-full max-w-md p-5 shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#25253e] mb-4">
          <div className="flex items-center gap-2">
            <Flag className="w-4 h-4 text-red-400" />
            <h3 className="text-sm font-bold text-white tracking-wide">
              Report {targetType === 'short' ? 'Short Video' : 'Comment'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#A5A3B8] hover:text-white hover:bg-[#1E1E38] transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-2">
            <CheckCircle className="w-10 h-10 text-green-400 mx-auto" />
            <h4 className="text-sm font-bold text-white">Report Submitted</h4>
            <p className="text-xs text-[#A5A3B8]">
              Thank you for keeping LOT Ecosystem safe. Our team is reviewing this item.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {targetSnippet && (
              <div className="p-2.5 rounded-xl bg-[#1A1A32] border border-[#2B2B48] text-xs text-[#C4B5FD] line-clamp-2 italic">
                "{targetSnippet}"
              </div>
            )}

            {error && (
              <div className="p-2 rounded-lg bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">
                Reason for reporting
              </label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full bg-[#18182E] border border-[#302D46] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
              >
                {reasons.map((r) => (
                  <option key={r} value={r} className="bg-[#18182E] text-white">
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#A5A3B8] mb-1.5">
                Additional Details (Optional)
              </label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Help us understand the issue..."
                rows={3}
                className="w-full bg-[#18182E] border border-[#302D46] rounded-xl p-2.5 text-xs text-white placeholder-[#6C6A84] focus:outline-none focus:border-[#8B5CF6] resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                disabled={submitting}
                className="px-3.5 py-1.5 rounded-xl text-xs text-[#A5A3B8] hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-4 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition shadow-md flex items-center gap-1.5"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <Flag className="w-3.5 h-3.5" />
                    <span>Submit Report</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
