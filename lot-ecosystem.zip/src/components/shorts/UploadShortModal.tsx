import React, { useState, useRef } from 'react';
import {
  X,
  UploadCloud,
  Film,
  Image as ImageIcon,
  CheckCircle,
  AlertCircle,
  Loader2,
  Clock,
  Sparkles,
  Hash,
  MessageSquare,
  Youtube,
  Link,
  ExternalLink,
  Check,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { ShortVideo } from './types';
import { playPurchaseSound, playErrorSound, playNotificationSound } from '../../lib/sounds';

interface UploadShortModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newShort: ShortVideo) => void;
}

export const UploadShortModal: React.FC<UploadShortModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { user } = useAuth();
  const [activeMode, setActiveMode] = useState<'file' | 'youtube'>('youtube');

  // Video File state
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [videoDuration, setVideoDuration] = useState<number>(0);

  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [thumbnailPreviewUrl, setThumbnailPreviewUrl] = useState<string | null>(null);

  // Common metadata
  const [caption, setCaption] = useState('');
  const [allowComments, setAllowComments] = useState(true);

  // YouTube Short state
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [ytLoading, setYtLoading] = useState(false);
  const [ytPreview, setYtPreview] = useState<{
    videoId: string;
    youtubeUrl: string;
    embedUrl: string;
    title: string;
    channelTitle: string;
    thumbnailUrl: string;
    duration: number;
    isAttributionVerified: boolean;
  } | null>(null);

  // Upload/Publish state
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStep, setUploadStep] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const videoInputRef = useRef<HTMLInputElement>(null);
  const thumbnailInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Handle video selection and duration validation
  const handleVideoSelect = (file: File) => {
    setError(null);

    // Validate size (60MB)
    if (file.size > 60 * 1024 * 1024) {
      setError('Video file is too large. Maximum file size is 60MB.');
      playErrorSound();
      return;
    }

    // Validate type
    const validTypes = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska'];
    if (!validTypes.includes(file.type) && !file.name.match(/\.(mp4|webm|mov|mkv)$/i)) {
      setError('Unsupported video format. Please upload MP4 or WebM.');
      playErrorSound();
      return;
    }

    const previewUrl = URL.createObjectURL(file);
    setVideoPreviewUrl(previewUrl);
    setVideoFile(file);
    setVideoDuration(15);

    // Check duration using temporary off-screen video element
    const tempVideo = document.createElement('video');
    tempVideo.preload = 'metadata';
    tempVideo.src = previewUrl;
    tempVideo.onloadedmetadata = () => {
      let dur = tempVideo.duration;
      if (!isFinite(dur) || isNaN(dur)) {
        tempVideo.currentTime = Number.MAX_SAFE_INTEGER;
        tempVideo.ontimeupdate = () => {
          tempVideo.ontimeupdate = null;
          let calculatedDur = Math.round(tempVideo.duration);
          if (isFinite(calculatedDur) && !isNaN(calculatedDur)) {
            setVideoDuration(calculatedDur);
            if (calculatedDur > 60) {
              setError(`Video is ${calculatedDur}s long. LOT Shorts must be 60 seconds or shorter.`);
              playErrorSound();
            }
          }
        };
        return;
      }
      const roundedDur = Math.round(dur);
      if (isFinite(roundedDur) && !isNaN(roundedDur)) {
        setVideoDuration(roundedDur);
        if (roundedDur > 60) {
          setError(`Video is ${roundedDur}s long. LOT Shorts must be 60 seconds or shorter.`);
          playErrorSound();
        }
      }
    };
  };

  const handleThumbnailSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file for the thumbnail (JPEG, PNG, or WebP).');
      return;
    }
    setThumbnailFile(file);
    setThumbnailPreviewUrl(URL.createObjectURL(file));
  };

  const handleQuickTag = (tag: string) => {
    if (!caption.includes(tag)) {
      setCaption((prev) => (prev ? `${prev.trim()} ${tag}` : tag));
    }
  };

  // Fetch YouTube metadata preview
  const handleFetchYtPreview = async (urlToFetch?: string) => {
    const targetUrl = (urlToFetch || youtubeUrl).trim();
    if (!targetUrl) {
      setError('Please enter a YouTube video or Shorts link.');
      return;
    }

    setError(null);
    setYtLoading(true);

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user?.token && user.token !== 'undefined') {
        headers['Authorization'] = `Bearer ${user.token}`;
      }

      const res = await fetch('/api/shorts/youtube/preview', {
        method: 'POST',
        headers,
        credentials: 'include',
        body: JSON.stringify({ url: targetUrl }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to retrieve YouTube video preview.');
      }

      setYtPreview(data);
      if (!caption.trim()) {
        setCaption(data.title || 'YouTube Short');
      }
      playNotificationSound();
    } catch (err: any) {
      setError(err.message || 'Could not fetch YouTube Short. Please check the URL.');
      playErrorSound();
    } finally {
      setYtLoading(false);
    }
  };

  // Publish YouTube Short
  const handlePublishYouTube = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !ytPreview) {
      setError('Please preview a YouTube Short before publishing.');
      return;
    }

    setUploading(true);
    setError(null);
    setUploadProgress(40);
    setUploadStep('Connecting YouTube player stream...');

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user?.token && user.token !== 'undefined') {
        headers['Authorization'] = `Bearer ${user.token}`;
      }

      const res = await fetch('/api/shorts/youtube/publish', {
        method: 'POST',
        headers,
        credentials: 'include',
        body: JSON.stringify({
          url: ytPreview.youtubeUrl,
          caption: caption.trim() || ytPreview.title,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to publish YouTube Short.');
      }

      setUploadProgress(100);
      setUploadStep('Short published to LOT feed!');
      playPurchaseSound();

      setTimeout(() => {
        onSuccess(data.short);
        onClose();
      }, 500);
    } catch (err: any) {
      playErrorSound();
      setError(err.message || 'Failed to publish YouTube Short.');
      setUploading(false);
    }
  };

  // Publish File Upload
  const handlePublishFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !videoFile) return;

    if (videoDuration > 60) {
      setError('Video duration must be 60 seconds or less.');
      return;
    }

    setUploading(true);
    setError(null);
    setUploadProgress(10);
    setUploadStep('Validating video streams...');

    try {
      const formData = new FormData();
      formData.append('video', videoFile);
      if (thumbnailFile) {
        formData.append('thumbnail', thumbnailFile);
      }
      formData.append('caption', caption.trim() || 'My LOT Short');
      formData.append('duration', String(videoDuration || 15));
      formData.append('allowComments', String(allowComments));

      setUploadProgress(40);
      setUploadStep('Uploading media file to server storage...');

      const interval = setInterval(() => {
        setUploadProgress((p) => (p < 85 ? p + 5 : p));
      }, 300);

      const headers: Record<string, string> = {};
      if (user?.token && user.token !== 'undefined') {
        headers['Authorization'] = `Bearer ${user.token}`;
      }

      const res = await fetch('/api/shorts/upload', {
        method: 'POST',
        headers,
        credentials: 'include',
        body: formData,
      });

      clearInterval(interval);

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'Failed to upload short.');
      }

      setUploadProgress(100);
      setUploadStep('Published successfully!');
      playPurchaseSound();

      const data = await res.json();
      setTimeout(() => {
        onSuccess(data.short);
        onClose();
      }, 500);
    } catch (err: any) {
      playErrorSound();
      setError(err.message || 'An error occurred during upload.');
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div
        className="bg-[#10101F] border border-[#302D46] rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl relative custom-scrollbar"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[#202035] sticky top-0 bg-[#10101F]/90 backdrop-blur-sm z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-white shadow-md shadow-purple-500/20">
              <Film className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-black text-white tracking-wide">Add LOT Short</h3>
              <p className="text-[11px] text-[#A5A3B8]">Import YouTube Shorts or upload vertical video clips</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={uploading}
            className="p-1.5 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-[#1C1C35] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="px-4 sm:px-6 pt-4 pb-1">
          <div className="grid grid-cols-2 gap-2 p-1 bg-[#151528] rounded-2xl border border-[#2B2B48]">
            <button
              type="button"
              onClick={() => {
                setActiveMode('youtube');
                setError(null);
              }}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                activeMode === 'youtube'
                  ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
                  : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              <Youtube className="w-4 h-4" />
              <span>Import YouTube Short</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveMode('file');
                setError(null);
              }}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                activeMode === 'file'
                  ? 'bg-[#8B5CF6] text-white shadow-lg shadow-purple-600/30'
                  : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload Video File</span>
            </button>
          </div>
        </div>

        {/* YOUTUBE SHORT MODE */}
        {activeMode === 'youtube' && (
          <form onSubmit={handlePublishYouTube} className="p-4 sm:p-6 space-y-5">
            {error && (
              <div className="p-3 rounded-xl bg-red-950/50 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* YouTube Link Input */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-white uppercase tracking-wider">
                YouTube Short or Video Link
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#6C6A84]">
                    <Link className="w-4 h-4" />
                  </div>
                  <input
                    type="url"
                    value={youtubeUrl}
                    onChange={(e) => setYoutubeUrl(e.target.value)}
                    placeholder="https://youtube.com/shorts/... or https://youtu.be/..."
                    className="w-full pl-9 pr-3 py-2.5 bg-[#151528] border border-[#302D46] rounded-xl text-xs text-white placeholder-[#6C6A84] focus:outline-none focus:border-red-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => handleFetchYtPreview()}
                  disabled={ytLoading || !youtubeUrl.trim()}
                  className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shrink-0 shadow-md shadow-red-600/20"
                >
                  {ytLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  <span>Fetch Short</span>
                </button>
              </div>
              <p className="text-[11px] text-[#A5A3B8]">
                Supports <code className="text-red-400">youtube.com/shorts/ID</code>, <code className="text-red-400">youtu.be/ID</code>, and standard YouTube watch URLs.
              </p>
            </div>

            {/* Quick Presets for Instant Testing */}
            {!ytPreview && (
              <div className="p-3.5 rounded-2xl bg-[#151528]/80 border border-[#252540] space-y-2">
                <p className="text-[11px] font-bold text-[#A5A3B8] uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" /> Or pick a trending YouTube Short to import:
                </p>
                <div className="flex flex-wrap gap-2">
                  {[
                    { label: '🔥 Python vs C++ Speed', url: 'https://youtube.com/shorts/k1BneeJTDcU' },
                    { label: '⚡ Clean Code Tips', url: 'https://youtube.com/shorts/p7bfOZek9t4' },
                    { label: '✨ 3D Satisfying Physics', url: 'https://youtube.com/shorts/L_LUpnjgPso' },
                    { label: '💻 VS Code Secrets', url: 'https://youtube.com/shorts/s4gBChg6AII' },
                  ].map((preset) => (
                    <button
                      key={preset.url}
                      type="button"
                      onClick={() => {
                        setYoutubeUrl(preset.url);
                        handleFetchYtPreview(preset.url);
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-[#202038] hover:bg-[#2C2C4E] text-white text-xs transition cursor-pointer"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Preview Card */}
            {ytPreview && (
              <div className="p-4 rounded-2xl bg-[#151528] border border-red-500/30 space-y-3">
                <div className="flex items-start gap-4">
                  <div className="relative w-24 h-36 rounded-xl overflow-hidden bg-black shrink-0 border border-[#302D46] shadow-md">
                    <img
                      src={ytPreview.thumbnailUrl}
                      alt={ytPreview.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-red-600 text-white text-[9px] font-bold flex items-center gap-1">
                      <Youtube className="w-2.5 h-2.5" /> Short
                    </div>
                    <div className="absolute bottom-1 right-1 px-1 py-0.5 rounded bg-black/80 text-white text-[9px] font-mono">
                      {ytPreview.duration}s
                    </div>
                  </div>

                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-1.5 text-red-400 text-xs font-semibold">
                      <CheckCircle className="w-3.5 h-3.5 text-green-400" />
                      <span>Verified Embeddable YouTube Short</span>
                    </div>
                    <h4 className="text-sm font-bold text-white line-clamp-2 leading-tight">
                      {ytPreview.title}
                    </h4>
                    <p className="text-xs text-[#C4B5FD] flex items-center gap-1">
                      Original Creator: <span className="font-semibold text-white">{ytPreview.channelTitle}</span>
                    </p>
                    <div className="pt-1 flex items-center gap-2">
                      <a
                        href={ytPreview.youtubeUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-[#A5A3B8] hover:text-white flex items-center gap-1 underline"
                      >
                        <ExternalLink className="w-3 h-3" /> View on YouTube
                      </a>
                    </div>
                  </div>
                </div>

                {/* Caption & Hashtags */}
                <div className="space-y-2 pt-2 border-t border-[#252540]">
                  <label className="block text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
                    <span>Caption on LOT Feed</span>
                    <span className="text-[#6C6A84] font-normal">{caption.length}/300</span>
                  </label>
                  <textarea
                    value={caption}
                    onChange={(e) => setCaption(e.target.value.slice(0, 300))}
                    placeholder="Add custom caption or thoughts..."
                    rows={2}
                    className="w-full bg-[#10101F] border border-[#302D46] rounded-xl p-3 text-xs text-white placeholder-[#6C6A84] focus:outline-none focus:border-red-500 resize-none"
                  />

                  {/* Quick Tags */}
                  <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px]">
                    <span className="text-[#6C6A84] text-xs flex items-center gap-1">
                      <Hash className="w-3.5 h-3.5" /> Tags:
                    </span>
                    {['#lot', '#shorts', '#tech', '#gaming', '#coding', '#viral', '#music'].map((tag) => (
                      <button
                        type="button"
                        key={tag}
                        onClick={() => handleQuickTag(tag)}
                        className="px-2 py-0.5 rounded-md bg-[#1B1B34] hover:bg-[#28284C] text-[#C4B5FD] text-[11px] transition cursor-pointer"
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Upload Progress */}
            {uploading && (
              <div className="p-4 rounded-xl bg-[#17172F] border border-[#302D46] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#C4B5FD] font-semibold flex items-center gap-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-red-500" />
                    {uploadStep}
                  </span>
                  <span className="text-white font-mono">{uploadProgress}%</span>
                </div>
                <div className="w-full bg-[#20203D] rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-red-600 to-red-400 h-2 transition-all duration-300 rounded-full"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#202035]">
              <button
                type="button"
                onClick={onClose}
                disabled={uploading}
                className="px-4 py-2 rounded-xl text-xs font-medium text-[#A5A3B8] hover:text-white hover:bg-[#1E1E38] transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!ytPreview || uploading}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-red-500 text-white text-xs font-bold hover:brightness-110 disabled:opacity-40 transition cursor-pointer shadow-lg shadow-red-600/25 flex items-center gap-2"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Publishing to LOT Shorts...</span>
                  </>
                ) : (
                  <>
                    <Youtube className="w-4 h-4" />
                    <span>Publish to LOT Shorts</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {/* FILE UPLOAD MODE */}
        {activeMode === 'file' && (
          <form onSubmit={handlePublishFile} className="p-4 sm:p-6 space-y-5">
            {error && (
              <div className="p-3 rounded-xl bg-red-950/50 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Upload Dropzone / Video Preview */}
            {!videoPreviewUrl ? (
              <div
                onClick={() => videoInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  if (e.dataTransfer.files?.[0]) {
                    handleVideoSelect(e.dataTransfer.files[0]);
                  }
                }}
                className="border-2 border-dashed border-[#3A3855] hover:border-[#8B5CF6] rounded-2xl p-8 flex flex-col items-center justify-center text-center bg-[#151528] hover:bg-[#181830] transition cursor-pointer group"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#20203B] flex items-center justify-center text-[#C4B5FD] mb-3 group-hover:scale-110 transition">
                  <UploadCloud className="w-7 h-7" />
                </div>
                <h4 className="text-sm font-bold text-white mb-1">Select video file to upload</h4>
                <p className="text-xs text-[#A5A3B8] max-w-sm mb-3">
                  Drag and drop MP4 or WebM video. Max 60 seconds duration (60MB max).
                </p>
                <span className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white text-xs font-semibold shadow-md shadow-purple-500/20">
                  Browse Video
                </span>
                <input
                  ref={videoInputRef}
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      handleVideoSelect(e.target.files[0]);
                    }
                  }}
                />
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#151528] p-4 rounded-2xl border border-[#2B2B48]">
                {/* Vertical Player Preview */}
                <div className="relative aspect-[9/16] max-h-72 mx-auto sm:max-h-80 w-full rounded-xl overflow-hidden bg-black shadow-lg border border-[#302D46]">
                  <video
                    src={videoPreviewUrl}
                    controls
                    playsInline
                    className="w-full h-full object-contain"
                  />
                  <div className="absolute top-2 left-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] text-white flex items-center gap-1 font-semibold">
                    <Clock className="w-3 h-3 text-[#C4B5FD]" />
                    <span>{videoDuration}s</span>
                  </div>
                </div>

                {/* Video Specs & Replace action */}
                <div className="flex flex-col justify-between space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs pb-2 border-b border-[#252540]">
                      <span className="text-[#A5A3B8]">Filename:</span>
                      <span className="text-white font-medium truncate max-w-[160px]">{videoFile?.name}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs pb-2 border-b border-[#252540]">
                      <span className="text-[#A5A3B8]">Duration:</span>
                      <span className={`font-bold ${videoDuration <= 60 ? 'text-green-400' : 'text-red-400'}`}>
                        {videoDuration} seconds {videoDuration <= 60 ? '✓' : '(Too long)'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs pb-2 border-b border-[#252540]">
                      <span className="text-[#A5A3B8]">File Size:</span>
                      <span className="text-white">
                        {videoFile ? (videoFile.size / (1024 * 1024)).toFixed(1) : 0} MB
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setVideoFile(null);
                        setVideoPreviewUrl(null);
                      }}
                      className="w-full py-2 rounded-xl bg-[#202038] hover:bg-[#2B2B4A] text-xs text-[#C4B5FD] font-semibold transition cursor-pointer"
                    >
                      Change Video
                    </button>

                    {/* Optional Custom Thumbnail */}
                    <div className="pt-2">
                      <label className="text-xs font-semibold text-[#A5A3B8] block mb-1">
                        Custom Thumbnail (Optional)
                      </label>
                      <div className="flex items-center gap-3">
                        {thumbnailPreviewUrl ? (
                          <div className="w-12 h-16 rounded-lg overflow-hidden border border-[#8B5CF6] shrink-0">
                            <img src={thumbnailPreviewUrl} alt="Thumbnail preview" className="w-full h-full object-cover" />
                          </div>
                        ) : (
                          <div className="w-12 h-16 rounded-lg bg-[#202038] border border-dashed border-[#3A3855] flex items-center justify-center text-[#6C6A84] shrink-0">
                            <ImageIcon className="w-5 h-5" />
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={() => thumbnailInputRef.current?.click()}
                          className="text-xs px-3 py-1.5 rounded-lg bg-[#202038] hover:bg-[#2C2C4E] text-white transition cursor-pointer"
                        >
                          {thumbnailFile ? 'Change Cover' : 'Upload Cover'}
                        </button>
                        <input
                          ref={thumbnailInputRef}
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files?.[0]) {
                              handleThumbnailSelect(e.target.files[0]);
                            }
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Caption & Hashtags */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
                <span>Caption & Hashtags</span>
                <span className="text-[#6C6A84] font-normal">{caption.length}/300</span>
              </label>
              <textarea
                value={caption}
                onChange={(e) => setCaption(e.target.value.slice(0, 300))}
                placeholder="What's this Short about? Add #lot #metaverse #gaming..."
                rows={3}
                className="w-full bg-[#151528] border border-[#302D46] rounded-xl p-3 text-xs text-white placeholder-[#6C6A84] focus:outline-none focus:border-[#8B5CF6] resize-none"
              />

              {/* Quick Hashtags */}
              <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px]">
                <span className="text-[#6C6A84] text-xs flex items-center gap-1">
                  <Hash className="w-3.5 h-3.5" /> Tags:
                </span>
                {['#lot', '#shorts', '#crypto', '#metaverse', '#gaming', '#vpay', '#vstocks'].map((tag) => (
                  <button
                    type="button"
                    key={tag}
                    onClick={() => handleQuickTag(tag)}
                    className="px-2 py-0.5 rounded-md bg-[#1B1B34] hover:bg-[#28284C] text-[#C4B5FD] text-[11px] transition cursor-pointer"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Settings: Comments Toggle */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#151528] border border-[#2B2B46]">
              <div className="flex items-center gap-2.5">
                <MessageSquare className="w-4 h-4 text-[#8B5CF6]" />
                <div>
                  <p className="text-xs font-bold text-white">Allow Comments</p>
                  <p className="text-[11px] text-[#A5A3B8]">Let viewers post comments and GIFs on this Short</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowComments}
                  onChange={(e) => setAllowComments(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-[#25253e] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#8B5CF6]"></div>
              </label>
            </div>

            {/* Upload Progress Bar */}
            {uploading && (
              <div className="p-4 rounded-xl bg-[#17172F] border border-[#302D46] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#C4B5FD] font-semibold flex items-center gap-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-[#8B5CF6]" />
                    {uploadStep}
                  </span>
                  <span className="text-white font-mono">{uploadProgress}%</span>
                </div>
                <div className="w-full bg-[#20203D] rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-[#8B5CF6] to-[#C4B5FD] h-2 transition-all duration-300 rounded-full"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Publish Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#202035]">
              <button
                type="button"
                onClick={onClose}
                disabled={uploading}
                className="px-4 py-2 rounded-xl text-xs font-medium text-[#A5A3B8] hover:text-white hover:bg-[#1E1E38] transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!videoFile || videoDuration > 60 || uploading}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white text-xs font-bold hover:brightness-110 disabled:opacity-40 transition cursor-pointer shadow-lg shadow-purple-500/25 flex items-center gap-2"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Publishing...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Publish Short</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
