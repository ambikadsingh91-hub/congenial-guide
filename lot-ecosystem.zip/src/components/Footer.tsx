import React from 'react';
import { Coins, ShieldCheck, Heart } from 'lucide-react';

interface FooterProps {
  setCurrentTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentTab }) => {
  return (
    <footer className="w-full bg-[#0B0B14] border-t border-[#302D46] mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 text-xs">
          {/* Brand */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-black border border-[#302D46] flex items-center justify-center overflow-hidden p-0.5">
                <img
                  src="/assets/aistudio/VPay_icon_512_4f9ce408.png"
                  alt="LOT Ecosystem Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <span className="font-bold text-white text-base">LOT ECOSYSTEM</span>
            </div>
            <p className="text-[#A5A3B8] max-w-sm leading-relaxed">
              Unified digital economy combining LOT Shop marketplace, VPay peer transfers, and VStocks trading with an
              authoritative cloud ledger and persistent database storage.
            </p>
            <div className="flex items-center gap-2 text-emerald-400 font-semibold pt-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Cloud Firestore Connected & Authoritative</span>
            </div>
          </div>

          {/* Navigation Links */}
          <div>
            <h4 className="font-bold text-white mb-3 uppercase tracking-wider text-[11px]">Ecosystem Hubs</h4>
            <ul className="space-y-2 text-[#A5A3B8]">
              <li>
                <button onClick={() => setCurrentTab('shop')} className="hover:text-white transition-colors cursor-pointer">
                  LOT Shop Marketplace
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('videos')} className="hover:text-white transition-colors cursor-pointer">
                  LOT Videos & Shorts
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('appstore')} className="hover:text-white transition-colors cursor-pointer">
                  LOT App Store (Android APKs)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('jobs')} className="hover:text-white transition-colors cursor-pointer">
                  Business & Govt Job Manager
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('bank')} className="hover:text-white transition-colors cursor-pointer">
                  LOT Bank & Loan Vault
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('vpay')} className="hover:text-white transition-colors cursor-pointer">
                  VPay Instant Transfers
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('vstocks')} className="hover:text-white transition-colors cursor-pointer">
                  VStocks Trading Exchange
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('games')} className="hover:text-white transition-colors cursor-pointer">
                  Minigames Arcade
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('redeem')} className="hover:text-white transition-colors cursor-pointer">
                  Redeem Promo Codes
                </button>
              </li>
            </ul>
          </div>

          {/* Ledger Compliance */}
          <div>
            <h4 className="font-bold text-white mb-3 uppercase tracking-wider text-[11px]">Integrity & Compliance</h4>
            <p className="text-[#A5A3B8] leading-relaxed mb-3">
              Market prices in VStocks are dynamically simulated. LOT is an authoritative in-game digital currency and does
              not represent fiat money or bank deposits.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-[#C4B5FD]">
              <ShieldCheck className="w-4 h-4 text-[#8B5CF6]" />
              <span>Zero client-side balance manipulation</span>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-[#302D46]/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#A5A3B8]">
          <p>© {new Date().getFullYear()} LOT Ecosystem. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Built for Google Firebase Studio with authoritative cloud persistence.
          </p>
        </div>
      </div>
    </footer>
  );
};
