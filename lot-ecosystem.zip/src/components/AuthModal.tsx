import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { X, Lock, User as UserIcon, ShieldCheck, AlertCircle, Sparkles } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, authModalTab, setAuthModalTab, login, register } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);
    setLoading(true);

    if (authModalTab === 'login') {
      const res = await login(username, password);
      if (!res.success) {
        setError(res.error || 'Incorrect username or password.');
      }
    } else {
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        setLoading(false);
        return;
      }
      const res = await register(username, password, confirmPassword);
      if (!res.success) {
        setError(res.error || 'Registration failed.');
      } else if (res.message) {
        setSuccessMessage(res.message);
      }
    }
    setLoading(false);
  };

  const isViratCandidate = username.trim().toLowerCase() === 'virat';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#19192B] border border-[#302D46] rounded-2xl shadow-2xl overflow-hidden p-6 text-[#F5F3FF]">
        {/* Close Button */}
        <button
          onClick={() => setIsAuthModalOpen(false)}
          className="absolute top-4 right-4 p-2 text-[#A5A3B8] hover:text-white rounded-lg hover:bg-[#202039] transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-black border border-[#302D46] mb-3 shadow-lg shadow-purple-500/20 overflow-hidden p-1">
            <img
              src="/assets/aistudio/VPay_icon_512_4f9ce408.png"
              alt="LOT Ecosystem"
              className="w-full h-full object-contain"
            />
          </div>
          <h2 className="text-2xl font-bold text-white tracking-wide">
            {authModalTab === 'login' ? 'Welcome Back' : 'Create LOT Account'}
          </h2>
          <p className="text-sm text-[#A5A3B8] mt-1">
            {authModalTab === 'login'
              ? 'Access LOT Shop, VPay, and VStocks with one unified login.'
              : 'Join the LOT Ecosystem with one shared account & ledger.'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex bg-[#121222] p-1 rounded-xl mb-6 border border-[#302D46]">
          <button
            type="button"
            onClick={() => {
              setAuthModalTab('login');
              setError(null);
            }}
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
              authModalTab === 'login'
                ? 'bg-[#8B5CF6] text-white shadow-md'
                : 'text-[#A5A3B8] hover:text-white'
            }`}
          >
            Login
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthModalTab('register');
              setError(null);
            }}
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-all ${
              authModalTab === 'register'
                ? 'bg-[#8B5CF6] text-white shadow-md'
                : 'text-[#A5A3B8] hover:text-white'
            }`}
          >
            Register
          </button>
        </div>

        {/* Error or Success notification */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/30 text-red-200 text-sm flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}
        {successMessage && (
          <div className="mb-4 p-3 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-200 text-sm flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-purple-400" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Virat Administrator notice when registering as Virat */}
        {authModalTab === 'register' && isViratCandidate && (
          <div className="mb-4 p-3 rounded-xl bg-gradient-to-r from-purple-900/40 to-indigo-900/40 border border-purple-500/40 text-purple-200 text-xs flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-[#C4B5FD] mt-0.5" />
            <div>
              <span className="font-semibold text-white">Administrator Registration Detected:</span> The username
              "Virat" will be securely established as the authoritative Administrator upon registration.
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#A5A3B8] mb-1.5">Username</label>
            <div className="relative">
              <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A5A3B8]" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                className="w-full pl-10 pr-4 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white placeholder-[#A5A3B8]/60 focus:outline-none focus:border-[#8B5CF6] focus:ring-1 focus:ring-[#8B5CF6] transition-all text-sm"
              />
            </div>
            {authModalTab === 'register' && (
              <p className="text-[11px] text-[#A5A3B8] mt-1">Username is case-insensitive and unique across LOT.</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-[#A5A3B8] mb-1.5">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A5A3B8]" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full pl-10 pr-4 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white placeholder-[#A5A3B8]/60 focus:outline-none focus:border-[#8B5CF6] focus:ring-1 focus:ring-[#8B5CF6] transition-all text-sm"
              />
            </div>
          </div>

          {authModalTab === 'register' && (
            <div>
              <label className="block text-xs font-medium text-[#A5A3B8] mb-1.5">Re-enter Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A5A3B8]" />
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter your password"
                  className="w-full pl-10 pr-4 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white placeholder-[#A5A3B8]/60 focus:outline-none focus:border-[#8B5CF6] focus:ring-1 focus:ring-[#8B5CF6] transition-all text-sm"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 mt-2 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:from-[#7C3AED] hover:to-[#9333EA] text-white font-medium shadow-lg shadow-purple-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : authModalTab === 'login' ? (
              'Sign In to LOT'
            ) : (
              'Create Account'
            )}
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-[#302D46] text-center text-xs text-[#A5A3B8]">
          {authModalTab === 'login' ? (
            <p>
              Don't have an account yet?{' '}
              <button
                type="button"
                onClick={() => {
                  setAuthModalTab('register');
                  setError(null);
                }}
                className="text-[#C4B5FD] hover:underline font-medium cursor-pointer"
              >
                Register now
              </button>
            </p>
          ) : (
            <p>
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setAuthModalTab('login');
                  setError(null);
                }}
                className="text-[#C4B5FD] hover:underline font-medium cursor-pointer"
              >
                Log in
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
