import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import {
  Coins,
  ShoppingBag,
  Send,
  TrendingUp,
  Gamepad2,
  Gift,
  Shield,
  Bell,
  User as UserIcon,
  LogOut,
  Menu,
  X,
  CheckCircle2,
  ExternalLink,
  MoreHorizontal,
  MessageSquare,
  Volume2,
  VolumeX,
  Film,
  Landmark,
  Tv,
  Smartphone,
  Briefcase,
} from 'lucide-react';
import { formatCompactNumber } from '../lib/formatNumber';
import { sounds, playMenuSound, playNotificationSound } from '../lib/sounds';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, setCurrentTab }) => {
  const { user, logout, notifications, unreadCount, markNotificationsRead, openAuthModal } = useAuth();
  const { unreadChatCount } = useSocial();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [soundOn, setSoundOn] = useState(() => sounds.isEnabled());

  React.useEffect(() => {
    const handler = (e: Event) => {
      const customEvent = e as CustomEvent<{ enabled: boolean }>;
      if (customEvent.detail) {
        setSoundOn(customEvent.detail.enabled);
      }
    };
    window.addEventListener('lot-sound-setting-changed', handler);
    return () => window.removeEventListener('lot-sound-setting-changed', handler);
  }, []);

  const navItems = [
    { id: 'shop', label: 'LOT Shop', icon: ShoppingBag },
    { id: 'videos', label: 'LOT Videos', icon: Tv },
    { id: 'shorts', label: 'LOT Shorts', icon: Film },
    { id: 'appstore', label: 'App Store', icon: Smartphone },
    { id: 'bank', label: 'LOT Bank', icon: Landmark },
    { id: 'jobs', label: 'Job Manager', icon: Briefcase },
    { id: 'vpay', label: 'VPay', icon: Send },
    { id: 'vstocks', label: 'VStocks', icon: TrendingUp },
    { id: 'games', label: 'Minigames', icon: Gamepad2 },
    { id: 'redeem', label: 'Redeem', icon: Gift },
    { id: 'messages', label: '•••', icon: MoreHorizontal, title: 'Player Messages & Calls' },
  ];

  if (user?.isAdmin) {
    navItems.push({ id: 'admin', label: 'Admin', icon: Shield });
  }

  const handleTabClick = (tabId: string) => {
    playMenuSound();
    setCurrentTab(tabId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B0B14]/95 backdrop-blur-md border-b border-[#302D46] max-w-full overflow-x-clip">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 sm:h-16 gap-2 min-w-0">
          {/* Brand Logo */}
          <div
            onClick={() => handleTabClick('shop')}
            className="flex items-center gap-2 sm:gap-3 cursor-pointer group shrink-0 min-w-0"
          >
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-black border border-[#302D46] flex items-center justify-center shadow-lg shadow-purple-500/20 group-hover:scale-105 transition-transform shrink-0 overflow-hidden p-1">
              <img
                src="/assets/aistudio/VPay_icon_512_4f9ce408.png"
                alt="LOT Ecosystem Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="flex items-center min-w-0">
              <span className="text-base sm:text-lg font-black text-white tracking-wider">LOT</span>
              <span className="text-base sm:text-lg font-light text-[#C4B5FD] ml-1 hidden xs:inline sm:inline">
                ECOSYSTEM
              </span>
              <span className="hidden lg:inline-block ml-2 px-2 py-0.5 text-[10px] font-semibold bg-[#202039] border border-[#302D46] rounded-md text-[#C4B5FD]">
                STUDIO
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              const isAdminTab = item.id === 'admin';
              const isMessagesTab = item.id === 'messages';
              return (
                <button
                  key={item.id}
                  onClick={() => handleTabClick(item.id)}
                  title={item.id === 'messages' ? 'Player Messaging & Live Calls' : undefined}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs lg:text-sm font-medium transition-all cursor-pointer relative ${
                    isActive
                      ? isAdminTab
                        ? 'bg-gradient-to-r from-red-600 to-purple-600 text-white shadow-md shadow-purple-500/20'
                        : 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-md shadow-purple-500/20'
                      : 'text-[#A5A3B8] hover:text-[#F5F3FF] hover:bg-[#19192B]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {isAdminTab && (
                    <span className="text-[10px] bg-red-950/80 border border-red-500/40 text-red-200 px-1.5 py-0.2 rounded font-bold">
                      ADMIN
                    </span>
                  )}
                  {isMessagesTab && unreadChatCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[9px] font-bold animate-pulse">
                      {unreadChatCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Items */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            {/* LOT Balance pill */}
            {user ? (
              <div
                onClick={() => handleTabClick('account')}
                title={`Click to view ledger and wallet transactions (Exact: ${user.lotBalance.toLocaleString()} LOT)`}
                className={`flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3.5 py-1 sm:py-1.5 rounded-xl cursor-pointer transition-all shadow-inner group shrink-0 border ${
                  user.lotBalance < 0
                    ? 'bg-red-950/70 border-red-500/60 hover:border-red-400'
                    : 'bg-[#19192B] border-[#302D46] hover:border-[#8B5CF6]'
                }`}
              >
                <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-purple-500/20 flex items-center justify-center shrink-0">
                  <Coins className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#C4B5FD]" />
                </div>
                <div className="text-right">
                  <span className={`text-[10px] hidden sm:block leading-none font-medium ${user.lotBalance < 0 ? 'text-red-400 font-bold' : 'text-[#A5A3B8]'}`}>
                    {user.lotBalance < 0 ? 'Overdrawn' : 'Balance'}
                  </span>
                  <span className={`text-xs sm:text-sm font-bold transition-colors leading-tight whitespace-nowrap ${user.lotBalance < 0 ? 'text-red-400' : 'text-white group-hover:text-[#C4B5FD]'}`}>
                    {formatCompactNumber(user.lotBalance)} <span className={`text-[10px] sm:text-xs ${user.lotBalance < 0 ? 'text-red-300' : 'text-[#8B5CF6]'}`}>LOT</span>
                  </span>
                </div>
              </div>
            ) : null}

            {/* Sound Effects Toggle Button */}
            <button
              onClick={() => {
                const next = sounds.toggle();
                setSoundOn(next);
              }}
              className="relative p-1.5 sm:p-2 text-[#A5A3B8] hover:text-white rounded-xl bg-[#19192B] border border-[#302D46] hover:border-[#8B5CF6] transition-all cursor-pointer shrink-0"
              aria-label={soundOn ? 'Mute sound effects' : 'Enable sound effects'}
              title={soundOn ? 'Sound effects enabled (Click to mute)' : 'Sound effects muted (Click to unmute)'}
            >
              {soundOn ? (
                <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-[#C4B5FD]" />
              ) : (
                <VolumeX className="w-4 h-4 sm:w-5 sm:h-5 text-[#A5A3B8]" />
              )}
            </button>

            {/* Notification Bell */}
            {user && (
              <div className="relative shrink-0">
                <button
                  onClick={() => {
                    const nextOpen = !showNotifications;
                    if (nextOpen) {
                      playNotificationSound();
                    }
                    setShowNotifications(nextOpen);
                    setShowUserMenu(false);
                  }}
                  className="relative p-1.5 sm:p-2 text-[#A5A3B8] hover:text-white rounded-xl bg-[#19192B] border border-[#302D46] hover:border-[#8B5CF6] transition-all cursor-pointer"
                  aria-label="Notifications"
                >
                  <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 bg-gradient-to-r from-red-500 to-[#A855F7] text-white text-[9px] sm:text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-[#0B0B14]">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown - mobile viewport safe */}
                {showNotifications && (
                  <div className="fixed sm:absolute left-2 right-2 sm:left-auto sm:right-0 top-16 sm:top-full mt-1 sm:w-80 md:w-96 bg-[#19192B] border border-[#302D46] rounded-2xl shadow-2xl p-4 text-[#F5F3FF] z-50 animate-fadeIn max-h-[75vh] flex flex-col">
                    <div className="flex items-center justify-between pb-3 border-b border-[#302D46] shrink-0">
                      <div className="flex items-center gap-2">
                        <Bell className="w-4 h-4 text-[#8B5CF6]" />
                        <h4 className="font-semibold text-sm">Notifications</h4>
                        {unreadCount > 0 && (
                          <span className="text-xs bg-purple-950 text-purple-300 border border-purple-800 px-2 py-0.5 rounded-full">
                            {unreadCount} new
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {unreadCount > 0 && (
                          <button
                            onClick={() => markNotificationsRead()}
                            className="text-xs text-[#C4B5FD] hover:underline cursor-pointer"
                          >
                            Mark read
                          </button>
                        )}
                        <button
                          onClick={() => setShowNotifications(false)}
                          className="sm:hidden text-[#A5A3B8] hover:text-white p-1"
                          aria-label="Close"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="mt-2 overflow-y-auto space-y-2 flex-1">
                      {notifications.length === 0 ? (
                        <div className="text-center py-8 text-xs text-[#A5A3B8]">
                          No notifications yet. Activity in LOT Shop, VPay, and VStocks will appear here.
                        </div>
                      ) : (
                        notifications.map((notif) => (
                          <div
                            key={notif.id}
                            onClick={() => {
                              if (!notif.read) markNotificationsRead(notif.id);
                            }}
                            className={`p-3 rounded-xl border transition-all text-xs cursor-pointer ${
                              notif.read
                                ? 'bg-[#121222]/60 border-[#302D46]/60 text-[#A5A3B8]'
                                : 'bg-[#202039] border-[#8B5CF6]/40 text-[#F5F3FF] shadow-sm'
                            }`}
                          >
                            <div className="flex items-center justify-between font-semibold text-white mb-1">
                              <span className="truncate">{notif.title}</span>
                              <span className="text-[10px] text-[#A5A3B8] shrink-0 ml-2">
                                {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="line-clamp-2">{notif.message}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* User Profile Menu / Auth buttons */}
            {user ? (
              <div className="relative shrink-0">
                <button
                  onClick={() => {
                    setShowUserMenu(!showUserMenu);
                    setShowNotifications(false);
                  }}
                  className="flex items-center gap-1.5 sm:gap-2 p-1 sm:p-1.5 pl-1.5 sm:pl-2.5 bg-[#19192B] border border-[#302D46] hover:border-[#8B5CF6] rounded-xl text-xs sm:text-sm font-medium text-white transition-all cursor-pointer"
                >
                  <span className="hidden sm:inline max-w-[80px] truncate text-xs font-semibold">@{user.username}</span>
                  {user.isAdmin && (
                    <span className="bg-red-950 text-red-300 border border-red-500/40 text-[9px] px-1 py-0.2 rounded font-bold hidden xs:inline">
                      ADMIN
                    </span>
                  )}
                  {user.vipBadge && (
                    <span className="bg-purple-950 text-purple-200 border border-purple-500/40 text-[9px] px-1 py-0.2 rounded font-semibold hidden md:inline">
                      {user.vipBadge}
                    </span>
                  )}
                  <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-[10px] sm:text-xs font-bold text-white shadow shrink-0 overflow-hidden">
                    {user.avatarUrl ? (
                      <img src={user.avatarUrl} alt={user.username} className="w-full h-full object-cover" />
                    ) : (
                      user.username.charAt(0).toUpperCase()
                    )}
                  </div>
                </button>

                {showUserMenu && (
                  <div className="fixed sm:absolute left-2 right-2 sm:left-auto sm:right-0 top-16 sm:top-full mt-1 sm:w-64 bg-[#19192B] border border-[#302D46] rounded-2xl shadow-2xl p-2 z-50 text-sm">
                    <div className="p-3 border-b border-[#302D46] mb-1 flex items-start justify-between">
                      <div className="flex items-center gap-2.5 truncate">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-sm font-bold text-white shadow shrink-0 overflow-hidden">
                          {user.avatarUrl ? (
                            <img src={user.avatarUrl} alt={user.username} className="w-full h-full object-cover" />
                          ) : (
                            user.username.charAt(0).toUpperCase()
                          )}
                        </div>
                        <div className="truncate">
                          <p className="text-[11px] text-[#A5A3B8]">Signed in as</p>
                          <p className="font-bold text-white truncate">@{user.username}</p>
                          {user.vipBadge && (
                            <span className="inline-block mt-0.5 text-[9px] bg-purple-900/60 text-purple-200 px-1.5 py-0.2 rounded font-semibold">
                              {user.vipBadge}
                            </span>
                          )}
                          <p className="text-[11px] text-[#C4B5FD] mt-0.5 font-semibold">
                            {user.lotBalance.toLocaleString()} LOT
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => setShowUserMenu(false)}
                        className="sm:hidden text-[#A5A3B8] hover:text-white p-1"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <button
                      onClick={() => {
                        handleTabClick('account');
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs rounded-xl hover:bg-[#202039] text-white transition-colors cursor-pointer"
                    >
                      <UserIcon className="w-4 h-4 text-[#8B5CF6]" />
                      <span>My Dashboard & Ledger</span>
                    </button>

                    <button
                      onClick={() => {
                        handleTabClick('messages');
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center justify-between px-3 py-2 text-xs rounded-xl hover:bg-[#202039] text-white transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <MoreHorizontal className="w-4 h-4 text-[#C4B5FD]" />
                        <span>Player Messages & Calls</span>
                      </div>
                      {unreadChatCount > 0 && (
                        <span className="px-1.5 py-0.2 bg-purple-600 text-white rounded-full text-[9px] font-bold">
                          {unreadChatCount}
                        </span>
                      )}
                    </button>

                    {user.isAdmin && (
                      <button
                        onClick={() => {
                          handleTabClick('admin');
                          setShowUserMenu(false);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs rounded-xl hover:bg-[#202039] text-red-300 transition-colors cursor-pointer"
                      >
                        <Shield className="w-4 h-4 text-red-400" />
                        <span>Admin Console & Tools</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        logout();
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs rounded-xl hover:bg-red-950/40 text-red-400 transition-colors cursor-pointer mt-1 border-t border-[#302D46]/60 pt-2"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                <button
                  onClick={() => openAuthModal('login')}
                  className="px-2.5 sm:px-3.5 py-1.5 rounded-xl text-xs font-semibold text-[#A5A3B8] hover:text-white bg-[#19192B] border border-[#302D46] hover:border-[#8B5CF6] transition-all cursor-pointer"
                >
                  Login
                </button>
                <button
                  onClick={() => openAuthModal('register')}
                  className="px-2.5 sm:px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:from-[#7C3AED] hover:to-[#9333EA] shadow-md shadow-purple-500/20 transition-all cursor-pointer"
                >
                  Register
                </button>
              </div>
            )}

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => {
                setMobileMenuOpen(!mobileMenuOpen);
                setShowNotifications(false);
                setShowUserMenu(false);
              }}
              className="md:hidden p-1.5 sm:p-2 text-[#A5A3B8] hover:text-white rounded-xl bg-[#19192B] border border-[#302D46] shrink-0"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-4 h-4 sm:w-5 sm:h-5" /> : <Menu className="w-4 h-4 sm:w-5 sm:h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#121222] border-b border-[#302D46] px-4 pt-3 pb-5 space-y-1 animate-fadeIn max-h-[80vh] overflow-y-auto">
          {user && (
            <div className="mb-3 p-3 rounded-2xl bg-[#19192B] border border-[#302D46] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-sm font-bold text-white shadow shrink-0 overflow-hidden">
                  {user.avatarUrl ? (
                    <img src={user.avatarUrl} alt={user.username} className="w-full h-full object-cover" />
                  ) : (
                    user.username.charAt(0).toUpperCase()
                  )}
                </div>
                <div>
                  <span className="text-[11px] text-[#A5A3B8] block">Wallet Balance</span>
                  <span className="text-base font-black text-white">{user.lotBalance.toLocaleString()} LOT</span>
                </div>
              </div>
              <span className="text-xs px-2.5 py-1 bg-[#202039] border border-[#302D46] rounded-xl text-[#C4B5FD] font-semibold">
                @{user.username}
              </span>
            </div>
          )}

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-medium ${
                  isActive
                    ? item.id === 'admin'
                      ? 'bg-gradient-to-r from-red-600 to-purple-600 text-white shadow'
                      : 'bg-[#8B5CF6] text-white shadow'
                    : 'text-[#A5A3B8] hover:bg-[#19192B] hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-4 h-4" />
                  <span>
                    {item.id === 'messages'
                      ? '••• Player Messages & Calls'
                      : item.id === 'jobs'
                      ? 'Business & Govt Job Manager'
                      : item.label}
                  </span>
                </div>
                {item.id === 'admin' && (
                  <span className="text-[10px] bg-red-900 text-red-200 px-1.5 py-0.5 rounded font-bold">
                    ADMIN
                  </span>
                )}
                {item.id === 'messages' && unreadChatCount > 0 && (
                  <span className="text-[10px] bg-red-600 text-white px-2 py-0.5 rounded-full font-bold">
                    {unreadChatCount} new
                  </span>
                )}
              </button>
            );
          })}

          {user && (
            <>
              <button
                onClick={() => handleTabClick('account')}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium ${
                  currentTab === 'account' ? 'bg-[#8B5CF6] text-white' : 'text-[#A5A3B8] hover:bg-[#19192B] hover:text-white'
                }`}
              >
                <UserIcon className="w-4 h-4 text-[#8B5CF6]" />
                <span>My Account & Ledger</span>
              </button>
              <button
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium text-red-400 hover:bg-red-950/40 mt-2 border-t border-[#302D46]/60 pt-3"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </>
          )}
        </div>
      )}
    </header>
  );
};
