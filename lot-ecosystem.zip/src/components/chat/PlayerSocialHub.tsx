import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useSocial } from '../../context/SocialContext';
import { Conversation, DirectMessage, PlayerSummary, FriendRecord, BlockRecord } from '../../types';
import {
  Search,
  Send,
  Phone,
  Video,
  UserPlus,
  UserCheck,
  UserX,
  ShieldAlert,
  ShieldCheck,
  MoreVertical,
  Coins,
  Clock,
  Sparkles,
  MessageSquare,
  Users,
  Ban,
  Check,
  CheckCheck,
  Smile,
  Trash2,
  AlertCircle,
  RefreshCw,
  X,
  Circle,
  Paperclip,
  Image as ImageIcon,
  Download,
  Eye,
} from 'lucide-react';
import { formatCompactNumber } from '../../lib/formatNumber';

export const PlayerSocialHub: React.FC = () => {
  const { user } = useAuth();
  const {
    initiateCall,
    acceptCall,
    joinCall,
    declineCall,
    activeCall,
    incomingCall,
    callStatus,
    onlineUserIds,
    targetChatUser,
    setTargetChatUser,
    refreshUnreadCount,
    socket,
  } = useSocial();

  // Active view tabs
  const [activeTab, setActiveTab] = useState<'chats' | 'friends' | 'blocked' | 'directory'>('chats');

  // Search input to message players by name
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<PlayerSummary[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchDebounce, setSearchDebounce] = useState<any>(null);

  // Conversations list
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [convLoading, setConvLoading] = useState(false);

  // Active Selected Conversation
  const [selectedPartner, setSelectedPartner] = useState<PlayerSummary | null>(null);
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [messageInput, setMessageInput] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);

  // Live call state with selected partner
  const [partnerActiveCall, setPartnerActiveCall] = useState<any | null>(null);

  // Friends & Blocks lists
  const [friendsList, setFriendsList] = useState<FriendRecord[]>([]);
  const [blocksList, setBlocksList] = useState<BlockRecord[]>([]);
  const [friendsLoading, setFriendsLoading] = useState(false);
  const [blocksLoading, setBlocksLoading] = useState(false);

  // Media attachments & Native Keyboard GIF support
  const [pendingAttachment, setPendingAttachment] = useState<{
    file: File;
    previewUrl: string;
    mimeType: string;
    isGif: boolean;
    name: string;
    size: number;
  } | null>(null);
  const [uploadingAttachment, setUploadingAttachment] = useState(false);
  const [lightboxMedia, setLightboxMedia] = useState<{
    url: string;
    fileName?: string;
    isGif?: boolean;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Partner options dropdown menu
  const [showOptionsMenu, setShowOptionsMenu] = useState(false);

  // Chat scroll anchor
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const getAuthHeaders = (): Record<string, string> => {
    const token = localStorage.getItem('lot_session_token') || user?.token || '';
    return {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    };
  };

  // 1. Fetch Conversations
  const fetchConversations = async () => {
    if (!user) return;
    try {
      setConvLoading(true);
      const res = await fetch('/api/chat/conversations', {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setConversations(data.conversations || []);
      }
    } catch {
      // non-critical
    } finally {
      setConvLoading(false);
    }
  };

  // 2. Fetch Friends
  const fetchFriends = async () => {
    if (!user) return;
    try {
      setFriendsLoading(true);
      const res = await fetch('/api/friends', {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setFriendsList(data.friends || []);
      }
    } catch {}
    finally {
      setFriendsLoading(false);
    }
  };

  // 3. Fetch Blocks
  const fetchBlocks = async () => {
    if (!user) return;
    try {
      setBlocksLoading(true);
      const res = await fetch('/api/blocks', {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setBlocksList(data.blocks || []);
      }
    } catch {}
    finally {
      setBlocksLoading(false);
    }
  };

  // Check active call with current partner
  const checkActiveCallWithPartner = async (partnerId: string) => {
    try {
      const res = await fetch(`/api/call/with/${partnerId}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setPartnerActiveCall(data.activeCall || null);
      }
    } catch {}
  };

  // 4. Initial Load
  useEffect(() => {
    fetchConversations();
    fetchFriends();
    fetchBlocks();
  }, [user?.id]);

  // Handle incoming real-time messages & call events for currently active chat
  useEffect(() => {
    // 1. Listen via WebSocket message
    if (socket) {
      const handleMessage = (event: MessageEvent) => {
        try {
          const data = JSON.parse(event.data);
          if (data.event === 'chat:message' && data.message) {
            const newMsg: DirectMessage = data.message;
            if (
              selectedPartner &&
              (newMsg.senderId === selectedPartner.id || newMsg.recipientId === selectedPartner.id)
            ) {
              setMessages((prev) => {
                if (prev.some((m) => m.id === newMsg.id)) return prev;
                return [...prev, newMsg];
              });
              setTimeout(scrollToBottom, 50);
              fetch(`/api/chat/read/${selectedPartner.id}`, { method: 'POST', headers: getAuthHeaders() }).catch(() => {});
              if (newMsg.type === 'call') {
                checkActiveCallWithPartner(selectedPartner.id);
              }
            }
            fetchConversations();
          } else if (data.event === 'chat:read') {
            setMessages((prev) => prev.map((m) => ({ ...m, read: true })));
          } else if (data.event === 'chat:call_status_update') {
            const { callId, status } = data;
            setMessages((prev) =>
              prev.map((m) => (m.callId === callId ? { ...m, callStatus: status } : m))
            );
            if (selectedPartner) {
              checkActiveCallWithPartner(selectedPartner.id);
            }
          } else if (data.event === 'friend:update' || data.event === 'block:update') {
            fetchFriends();
            fetchBlocks();
            if (selectedPartner) {
              loadPlayerByUsername(selectedPartner.username);
            }
          }
        } catch {}
      };

      socket.addEventListener('message', handleMessage);
      return () => {
        socket.removeEventListener('message', handleMessage);
      };
    }
  }, [socket, selectedPartner?.id]);

  // Listen to Window CustomEvents dispatched by SocialContext
  useEffect(() => {
    const handleWinMessage = (e: any) => {
      const newMsg: DirectMessage = e.detail;
      if (!newMsg) return;
      if (
        selectedPartner &&
        (newMsg.senderId === selectedPartner.id || newMsg.recipientId === selectedPartner.id)
      ) {
        setMessages((prev) => {
          if (prev.some((m) => m.id === newMsg.id)) return prev;
          return [...prev, newMsg];
        });
        setTimeout(scrollToBottom, 50);
        fetch(`/api/chat/read/${selectedPartner.id}`, { method: 'POST', headers: getAuthHeaders() }).catch(() => {});
        if (newMsg.type === 'call') {
          checkActiveCallWithPartner(selectedPartner.id);
        }
      }
      fetchConversations();
    };

    const handleWinCallUpdate = (e: any) => {
      const { callId, status } = e.detail || {};
      if (callId) {
        setMessages((prev) =>
          prev.map((m) => (m.callId === callId ? { ...m, callStatus: status } : m))
        );
        if (selectedPartner) {
          checkActiveCallWithPartner(selectedPartner.id);
        }
      }
    };

    const handleWinIncomingCall = (e: any) => {
      const call = e.detail;
      if (call && selectedPartner && (call.callerId === selectedPartner.id || call.recipientId === selectedPartner.id)) {
        setPartnerActiveCall(call);
      }
    };

    window.addEventListener('lot:chat_message', handleWinMessage);
    window.addEventListener('lot:chat_call_update', handleWinCallUpdate);
    window.addEventListener('lot:call_incoming', handleWinIncomingCall);

    return () => {
      window.removeEventListener('lot:chat_message', handleWinMessage);
      window.removeEventListener('lot:chat_call_update', handleWinCallUpdate);
      window.removeEventListener('lot:call_incoming', handleWinIncomingCall);
    };
  }, [selectedPartner?.id]);

  // Background 2.5s Polling for open chat: guarantees messages and call status appear without reloading
  useEffect(() => {
    if (!selectedPartner?.id) return;
    checkActiveCallWithPartner(selectedPartner.id);

    const timer = setInterval(() => {
      loadMessages(selectedPartner.id, true);
      checkActiveCallWithPartner(selectedPartner.id);
    }, 2500);

    return () => clearInterval(timer);
  }, [selectedPartner?.id]);

  // Sync partnerActiveCall with global incomingCall and activeCall
  useEffect(() => {
    if (!selectedPartner) return;
    if (incomingCall && incomingCall.callerId === selectedPartner.id) {
      setPartnerActiveCall(incomingCall);
    } else if (activeCall && (activeCall.callerId === selectedPartner.id || activeCall.recipientId === selectedPartner.id)) {
      setPartnerActiveCall(activeCall);
    }
  }, [incomingCall, activeCall, selectedPartner?.id]);

  // 5. If `targetChatUser` was set globally, automatically open chat with them
  useEffect(() => {
    if (targetChatUser) {
      loadPlayerByUsername(targetChatUser);
      setTargetChatUser(null);
    }
  }, [targetChatUser]);

  // Load player profile and open conversation
  const loadPlayerByUsername = async (username: string) => {
    try {
      setMessagesLoading(true);
      setChatError(null);
      const res = await fetch(`/api/players/lookup/${encodeURIComponent(username)}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedPartner(data.player);
        await loadMessages(data.player.id);
        await checkActiveCallWithPartner(data.player.id);
      } else {
        setChatError(`Could not find player "@${username}"`);
      }
    } catch {
      setChatError('Failed to load player dossier');
    } finally {
      setMessagesLoading(false);
    }
  };

  // Load messages for a partner (quiet mode suppresses loading spinner for smooth live polling)
  const loadMessages = async (partnerId: string, quiet = false) => {
    try {
      if (!quiet) setMessagesLoading(true);
      const res = await fetch(`/api/chat/messages/${partnerId}`, {
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        const incoming: DirectMessage[] = data.messages || [];
        setMessages((prev) => {
          if (incoming.length !== prev.length || JSON.stringify(incoming) !== JSON.stringify(prev)) {
            setTimeout(scrollToBottom, 50);
            return incoming;
          }
          return prev;
        });
        refreshUnreadCount();
      }
    } catch {}
    finally {
      if (!quiet) setMessagesLoading(false);
    }
  };

  // Select conversation from list
  const handleSelectConversation = (conv: Conversation) => {
    const partner: PlayerSummary = {
      id: conv.partnerId,
      username: conv.partnerUsername,
      avatarUrl: conv.partnerAvatarUrl,
      lotBalance: conv.partnerBalance || 0,
      vipBadge: conv.partnerVipBadge,
      isFriend: conv.isFriend,
      isBlocked: conv.isBlocked,
      hasBlockedMe: conv.hasBlockedMe,
      isOnline: conv.isOnline,
    };
    setSelectedPartner(partner);
    setChatError(null);
    loadMessages(conv.partnerId);
    checkActiveCallWithPartner(conv.partnerId);
  };

  // Player Search autocomplete
  const handleSearchChange = (val: string) => {
    setSearchQuery(val);
    if (searchDebounce) clearTimeout(searchDebounce);

    if (!val.trim()) {
      setSearchResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        setSearchLoading(true);
        const res = await fetch(`/api/players/search?q=${encodeURIComponent(val.trim())}`, {
          headers: getAuthHeaders(),
        });
        if (res.ok) {
          const data = await res.json();
          setSearchResults(data.players || []);
        }
      } catch {}
      finally {
        setSearchLoading(false);
      }
    }, 250);

    setSearchDebounce(timer);
  };

  // Handle file attachment selection (images, photos, GIFs)
  const handleFileSelect = (file: File) => {
    setChatError(null);
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    const isGif = file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif');

    if (!allowed.includes(file.type) && !isGif && !file.type.startsWith('image/')) {
      setChatError('Please select a valid photo (JPG, PNG, WEBP) or animated GIF.');
      return;
    }

    if (file.size > 20 * 1024 * 1024) {
      setChatError('File size exceeds 20MB limit. Please choose a smaller image.');
      return;
    }

    if (pendingAttachment?.previewUrl) {
      URL.revokeObjectURL(pendingAttachment.previewUrl);
    }

    const previewUrl = URL.createObjectURL(file);
    setPendingAttachment({
      file,
      previewUrl,
      mimeType: file.type || (isGif ? 'image/gif' : 'image/jpeg'),
      isGif,
      name: file.name,
      size: file.size,
    });
  };

  // Handle native keyboard GIFs (Gboard, iOS, desktop clipboard paste)
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const items = e.clipboardData?.items;
    if (!items || items.length === 0) return;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.type.indexOf('image') !== -1) {
        const file = item.getAsFile();
        if (file) {
          e.preventDefault();
          handleFileSelect(file);
          return;
        }
      }
    }
  };

  const handleRemoveAttachment = () => {
    if (pendingAttachment?.previewUrl) {
      URL.revokeObjectURL(pendingAttachment.previewUrl);
    }
    setPendingAttachment(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Send Direct Message (supports text, photo attachment, and animated native keyboard GIFs)
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedPartner || sendingMessage || uploadingAttachment) return;

    const content = messageInput.trim();
    if (!content && !pendingAttachment) return;

    setMessageInput('');
    setSendingMessage(true);
    setChatError(null);

    let attachmentUrl = '';
    let mediaType: 'image' | 'gif' | undefined;
    let fileName = '';
    let fileSize = 0;

    try {
      // 1. Upload attachment if present
      if (pendingAttachment) {
        setUploadingAttachment(true);
        const formData = new FormData();
        formData.append('file', pendingAttachment.file);

        const token = localStorage.getItem('lot_session_token') || user?.token || '';
        const uploadRes = await fetch('/api/media/upload', {
          method: 'POST',
          headers: token ? { Authorization: `Bearer ${token}` } : {},
          body: formData,
        });

        if (!uploadRes.ok) {
          const errData = await uploadRes.json().catch(() => ({}));
          throw new Error(errData.error || 'Failed to upload attachment');
        }

        const uploadData = await uploadRes.json();
        attachmentUrl = uploadData.url;
        mediaType = pendingAttachment.isGif ? 'gif' : 'image';
        fileName = pendingAttachment.name;
        fileSize = pendingAttachment.size;
        setUploadingAttachment(false);
      }

      // 2. Dispatch direct message
      const res = await fetch('/api/chat/messages', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          recipientId: selectedPartner.id,
          recipientUsername: selectedPartner.username,
          content,
          attachmentUrl: attachmentUrl || undefined,
          mediaType: mediaType || undefined,
          fileName: fileName || undefined,
          fileSize: fileSize || undefined,
          type: mediaType || 'text',
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setChatError(data.error || 'Failed to send message');
        setMessageInput(content); // restore input
      } else {
        handleRemoveAttachment();
        setMessages((prev) => [...prev, data.message]);
        setTimeout(scrollToBottom, 50);
        fetchConversations();
      }
    } catch (err: any) {
      setChatError(err.message || 'Network error while sending');
      setMessageInput(content);
    } finally {
      setSendingMessage(false);
      setUploadingAttachment(false);
    }
  };

  // Friend / Unfriend Toggle
  const handleToggleFriend = async (targetId: string) => {
    try {
      const res = await fetch('/api/friends/toggle', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ targetUserId: targetId }),
      });
      if (res.ok) {
        const data = await res.json();
        if (selectedPartner && selectedPartner.id === targetId) {
          setSelectedPartner({ ...selectedPartner, isFriend: data.isFriend });
        }
        fetchFriends();
        fetchConversations();
      }
    } catch {}
  };

  // Block / Unblock Toggle
  const handleToggleBlock = async (targetId: string) => {
    try {
      const res = await fetch('/api/blocks/toggle', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ targetUserId: targetId }),
      });
      if (res.ok) {
        const data = await res.json();
        if (selectedPartner && selectedPartner.id === targetId) {
          setSelectedPartner({ ...selectedPartner, isBlocked: data.isBlocked });
        }
        fetchBlocks();
        fetchConversations();
        setShowOptionsMenu(false);
      }
    } catch {}
  };

  // Clear Chat History
  const handleClearChat = async () => {
    if (!selectedPartner) return;
    if (!window.confirm(`Clear all messages with @${selectedPartner.username}?`)) return;

    try {
      const res = await fetch(`/api/chat/clear/${selectedPartner.id}`, {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        setMessages([]);
        fetchConversations();
        setShowOptionsMenu(false);
      }
    } catch {}
  };

  // Quick Call Buttons
  const handleStartCall = async (type: 'audio' | 'video') => {
    if (!selectedPartner) return;
    const res = await initiateCall({
      recipientId: selectedPartner.id,
      recipientUsername: selectedPartner.username,
      type,
    });
    if (!res.success) {
      setChatError(res.error || 'Failed to place call');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-16">
      {/* ---------------------------------------------------- */}
      {/* SOCIAL HUB HERO HEADER & INSTANT PLAYER LOOKUP */}
      {/* ---------------------------------------------------- */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#121222] via-[#19192B] to-[#202039] border border-[#302D46] p-6 sm:p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 border border-purple-500/40 text-[10px] font-bold text-purple-300 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-purple-400" />
                ••• Player Social & Communication Studio
              </span>
              <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold px-2 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                {onlineUserIds.size + 1} Players Live
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">Player Messages & Live Calls</h1>
            <p className="text-xs sm:text-sm text-[#A5A3B8] max-w-xl mt-1">
              Connect with any player by username. Send direct messages, place real-time audio/video calls, manage friendships, and customize your social network.
            </p>
          </div>

          {/* Quick Player Lookup Bar: Message Any Player */}
          <div className="w-full md:w-80 relative shrink-0">
            <span className="text-[11px] font-bold text-purple-200 block mb-1.5 flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5 text-purple-400" />
              <span>Find & Message Player by Name:</span>
            </span>
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => handleSearchChange(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && searchQuery.trim()) {
                    loadPlayerByUsername(searchQuery.trim());
                    setSearchResults([]);
                  }
                }}
                placeholder="Type player username..."
                className="w-full pl-9 pr-20 py-2.5 bg-[#121222] border border-[#302D46] focus:border-purple-500 rounded-2xl text-xs text-white placeholder-[#706E88] focus:outline-none transition-all shadow-inner"
              />
              <Search className="w-4 h-4 text-[#A5A3B8] absolute left-3 top-3 pointer-events-none" />

              <button
                type="button"
                onClick={() => {
                  if (searchQuery.trim()) {
                    loadPlayerByUsername(searchQuery.trim());
                    setSearchResults([]);
                  }
                }}
                className="absolute right-1.5 top-1.5 px-3 py-1 bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:brightness-110 text-white text-[11px] font-bold rounded-xl shadow cursor-pointer transition-all"
              >
                Chat
              </button>
            </div>

            {/* Live Autocomplete Dropdown */}
            {searchResults.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-[#19192B] border border-[#302D46] rounded-2xl shadow-2xl p-2 z-50 max-h-72 overflow-y-auto space-y-1">
                <span className="text-[10px] text-[#A5A3B8] uppercase font-bold px-2 py-1 block">
                  Found Players ({searchResults.length})
                </span>
                {searchResults.map((player) => (
                  <div
                    key={player.id}
                    onClick={() => {
                      setSelectedPartner(player);
                      loadMessages(player.id);
                      setSearchResults([]);
                      setSearchQuery('');
                    }}
                    className="p-2 rounded-xl hover:bg-[#202039] flex items-center justify-between gap-2.5 cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="relative w-8 h-8 rounded-xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-xs font-bold text-white overflow-hidden shrink-0">
                        {player.avatarUrl ? (
                          <img src={player.avatarUrl} alt={player.username} className="w-full h-full object-cover" />
                        ) : (
                          player.username.charAt(0).toUpperCase()
                        )}
                        {onlineUserIds.has(player.id) && (
                          <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-[#19192B]" />
                        )}
                      </div>
                      <div className="truncate">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-xs text-white group-hover:text-purple-300 transition-colors truncate">
                            @{player.username}
                          </span>
                          {player.vipBadge && (
                            <span className="text-[9px] bg-purple-950 text-purple-200 px-1 py-0.2 rounded font-semibold">
                              {player.vipBadge}
                            </span>
                          )}
                        </div>
                        <span
                          className="text-[10px] text-[#A5A3B8] flex items-center gap-1"
                          title={`${player.lotBalance.toLocaleString()} LOT`}
                        >
                          <Coins className="w-2.5 h-2.5 text-[#C4B5FD]" />
                          {formatCompactNumber(player.lotBalance)} LOT
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <span className="px-2 py-0.5 rounded-lg bg-purple-500/20 text-purple-300 text-[10px] font-bold">
                        Message
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ---------------------------------------------------- */}
      {/* MAIN TWO-COLUMN SPLIT STUDIO */}
      {/* ---------------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[640px]">
        {/* ==================================================== */}
        {/* LEFT COLUMN: CONVERSATIONS, FRIENDS, BLOCKS (4 COLS) */}
        {/* ==================================================== */}
        <div className="lg:col-span-4 bg-[#121222] border border-[#302D46] rounded-3xl p-4 flex flex-col shadow-xl overflow-hidden">
          {/* Sub Navigation Pills */}
          <div className="flex bg-[#19192B] p-1 rounded-2xl border border-[#302D46] mb-4 shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('chats')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'chats'
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow'
                  : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Chats</span>
              {conversations.some((c) => c.unreadCount > 0) && (
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('friends')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'friends'
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow'
                  : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Friends ({friendsList.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('blocked')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'blocked'
                  ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow'
                  : 'text-[#A5A3B8] hover:text-white'
              }`}
            >
              <Ban className="w-3.5 h-3.5" />
              <span>Blocked ({blocksList.length})</span>
            </button>
          </div>

          {/* LIST VIEW BASED ON TAB */}
          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {/* 1. CHATS LIST */}
            {activeTab === 'chats' && (
              <>
                {convLoading ? (
                  <div className="p-8 text-center text-xs text-[#A5A3B8] flex items-center justify-center gap-2">
                    <RefreshCw className="w-4 h-4 animate-spin text-purple-400" />
                    <span>Loading conversations...</span>
                  </div>
                ) : conversations.length === 0 ? (
                  <div className="p-8 text-center rounded-2xl bg-[#19192B]/50 border border-dashed border-[#302D46]">
                    <MessageSquare className="w-8 h-8 text-[#706E88] mx-auto mb-2 opacity-50" />
                    <p className="text-xs font-bold text-white mb-1">No active conversations yet</p>
                    <p className="text-[11px] text-[#A5A3B8] mb-3">
                      Search any player name above to start chatting or place a call!
                    </p>
                  </div>
                ) : (
                  conversations.map((conv) => {
                    const isSelected = selectedPartner?.id === conv.partnerId;
                    const isOnline = onlineUserIds.has(conv.partnerId);

                    return (
                      <div
                        key={conv.id}
                        onClick={() => handleSelectConversation(conv)}
                        className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center gap-3 relative ${
                          isSelected
                            ? 'bg-gradient-to-r from-purple-900/40 to-indigo-900/30 border-purple-500/60 shadow-md'
                            : 'bg-[#19192B]/70 hover:bg-[#19192B] border-[#302D46] hover:border-purple-500/30'
                        }`}
                      >
                        {/* Profile Picture with Online Status Dot */}
                        <div className="relative shrink-0">
                          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-sm font-bold text-white overflow-hidden shadow-md">
                            {conv.partnerAvatarUrl ? (
                              <img src={conv.partnerAvatarUrl} alt={conv.partnerUsername} className="w-full h-full object-cover" />
                            ) : (
                              conv.partnerUsername.charAt(0).toUpperCase()
                            )}
                          </div>
                          {isOnline ? (
                            <span
                              className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#121222]"
                              title="Online"
                            />
                          ) : (
                            <span
                              className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-gray-500 border-2 border-[#121222]"
                              title="Offline"
                            />
                          )}
                        </div>

                        {/* Middle info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1">
                            <span className="font-bold text-xs text-white truncate flex items-center gap-1.5">
                              @{conv.partnerUsername}
                              {conv.isFriend && (
                                <span className="text-[9px] bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 px-1 py-0.2 rounded font-semibold">
                                  Friend
                                </span>
                              )}
                              {conv.isBlocked && (
                                <span className="text-[9px] bg-red-950/80 border border-red-500/40 text-red-300 px-1 py-0.2 rounded font-semibold">
                                  Blocked
                                </span>
                              )}
                            </span>
                            <span className="text-[10px] text-[#706E88] shrink-0">
                              {new Date(conv.lastMessageTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>

                          <p className="text-[11px] text-[#A5A3B8] truncate mt-0.5">
                            {conv.lastMessage}
                          </p>
                        </div>

                        {/* Unread badge */}
                        {conv.unreadCount > 0 && (
                          <span className="w-5 h-5 rounded-full bg-gradient-to-r from-red-500 to-purple-600 text-white text-[10px] font-bold flex items-center justify-center shadow-lg shrink-0">
                            {conv.unreadCount}
                          </span>
                        )}
                      </div>
                    );
                  })
                )}
              </>
            )}

            {/* 2. FRIENDS LIST */}
            {activeTab === 'friends' && (
              <>
                {friendsLoading ? (
                  <div className="p-8 text-center text-xs text-[#A5A3B8] flex items-center justify-center gap-2">
                    <RefreshCw className="w-4 h-4 animate-spin text-purple-400" />
                    <span>Loading friends...</span>
                  </div>
                ) : friendsList.length === 0 ? (
                  <div className="p-8 text-center rounded-2xl bg-[#19192B]/50 border border-dashed border-[#302D46]">
                    <Users className="w-8 h-8 text-[#706E88] mx-auto mb-2 opacity-50" />
                    <p className="text-xs font-bold text-white mb-1">No friends added yet</p>
                    <p className="text-[11px] text-[#A5A3B8]">
                      Search any player above and click &quot;Add Friend&quot; to stay connected!
                    </p>
                  </div>
                ) : (
                  friendsList.map((fr) => {
                    const isOnline = onlineUserIds.has(fr.friendId);
                    return (
                      <div
                        key={fr.id}
                        className="p-3 rounded-2xl bg-[#19192B] border border-[#302D46] flex items-center justify-between gap-3 hover:border-purple-500/40 transition-colors"
                      >
                        <div
                          onClick={() => loadPlayerByUsername(fr.friendUsername)}
                          className="flex items-center gap-2.5 min-w-0 cursor-pointer flex-1"
                        >
                          <div className="relative shrink-0">
                            <div className="w-10 h-10 rounded-2xl bg-purple-600 flex items-center justify-center text-xs font-bold text-white overflow-hidden shadow">
                              {fr.friendAvatarUrl ? (
                                <img src={fr.friendAvatarUrl} alt={fr.friendUsername} className="w-full h-full object-cover" />
                              ) : (
                                fr.friendUsername.charAt(0).toUpperCase()
                              )}
                            </div>
                            {isOnline && (
                              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border border-[#19192B]" />
                            )}
                          </div>

                          <div className="truncate">
                            <p className="font-bold text-xs text-white truncate">@{fr.friendUsername}</p>
                            <span className="text-[10px] text-emerald-400 font-medium">
                              {isOnline ? 'Online now' : 'Offline'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => loadPlayerByUsername(fr.friendUsername)}
                            className="p-2 rounded-xl bg-[#202039] hover:bg-purple-600/30 text-purple-300 hover:text-white transition-colors cursor-pointer"
                            title="Message"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              loadPlayerByUsername(fr.friendUsername);
                              initiateCall({ recipientId: fr.friendId, recipientUsername: fr.friendUsername, type: 'audio' });
                            }}
                            className="p-2 rounded-xl bg-[#202039] hover:bg-emerald-600/30 text-emerald-300 hover:text-white transition-colors cursor-pointer"
                            title="Audio Call"
                          >
                            <Phone className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleToggleFriend(fr.friendId)}
                            className="p-2 rounded-xl bg-[#202039] hover:bg-red-600/30 text-[#A5A3B8] hover:text-red-300 transition-colors cursor-pointer"
                            title="Unfriend"
                          >
                            <UserX className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </>
            )}

            {/* 3. BLOCKED PLAYERS LIST */}
            {activeTab === 'blocked' && (
              <>
                {blocksLoading ? (
                  <div className="p-8 text-center text-xs text-[#A5A3B8] flex items-center justify-center gap-2">
                    <RefreshCw className="w-4 h-4 animate-spin text-purple-400" />
                    <span>Loading blocked list...</span>
                  </div>
                ) : blocksList.length === 0 ? (
                  <div className="p-8 text-center rounded-2xl bg-[#19192B]/50 border border-dashed border-[#302D46]">
                    <ShieldCheck className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-60" />
                    <p className="text-xs font-bold text-white mb-1">No blocked players</p>
                    <p className="text-[11px] text-[#A5A3B8]">
                      You have not blocked any players.
                    </p>
                  </div>
                ) : (
                  blocksList.map((bl) => (
                    <div
                      key={bl.id}
                      className="p-3 rounded-2xl bg-[#19192B] border border-red-900/30 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-red-950 border border-red-800 flex items-center justify-center text-xs font-bold text-red-200 overflow-hidden shrink-0">
                          {bl.blockedAvatarUrl ? (
                            <img src={bl.blockedAvatarUrl} alt={bl.blockedUsername} className="w-full h-full object-cover" />
                          ) : (
                            bl.blockedUsername.charAt(0).toUpperCase()
                          )}
                        </div>
                        <div className="truncate">
                          <p className="font-bold text-xs text-white truncate">@{bl.blockedUsername}</p>
                          <span className="text-[10px] text-red-400">Blocked</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleToggleBlock(bl.blockedUserId)}
                        className="px-3 py-1.5 rounded-xl bg-red-950 hover:bg-red-900 border border-red-500/40 text-red-200 hover:text-white text-xs font-bold cursor-pointer transition-colors shadow-sm"
                      >
                        Unblock
                      </button>
                    </div>
                  ))
                )}
              </>
            )}
          </div>
        </div>

        {/* ==================================================== */}
        {/* RIGHT COLUMN: ACTIVE CONVERSATION & CALL HUB (8 COLS) */}
        {/* ==================================================== */}
        <div className="lg:col-span-8 bg-[#121222] border border-[#302D46] rounded-3xl flex flex-col shadow-xl overflow-hidden min-h-[500px]">
          {selectedPartner ? (
            <>
              {/* Active Conversation Header */}
              <div className="p-4 sm:p-5 border-b border-[#302D46] bg-[#19192B]/80 backdrop-blur-sm flex items-center justify-between gap-3 shrink-0">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] via-[#A855F7] to-[#C4B5FD] flex items-center justify-center text-base font-bold text-white shadow-lg overflow-hidden border border-purple-400/40">
                      {selectedPartner.avatarUrl ? (
                        <img src={selectedPartner.avatarUrl} alt={selectedPartner.username} className="w-full h-full object-cover" />
                      ) : (
                        selectedPartner.username.charAt(0).toUpperCase()
                      )}
                    </div>
                    {onlineUserIds.has(selectedPartner.id) && (
                      <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#19192B]" />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-black text-base text-white truncate">@{selectedPartner.username}</h3>
                      {selectedPartner.vipBadge && (
                        <span className="text-[10px] bg-purple-950 border border-purple-800 text-purple-200 px-1.5 py-0.2 rounded font-semibold">
                          {selectedPartner.vipBadge}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[#A5A3B8]">
                      <span
                        className="flex items-center gap-1 font-mono text-[#C4B5FD]"
                        title={`${selectedPartner.lotBalance.toLocaleString()} LOT`}
                      >
                        <Coins className="w-3 h-3 text-[#8B5CF6]" />
                        {formatCompactNumber(selectedPartner.lotBalance)} LOT
                      </span>
                      <span>•</span>
                      <span className={onlineUserIds.has(selectedPartner.id) ? 'text-emerald-400 font-semibold' : 'text-[#706E88]'}>
                        {onlineUserIds.has(selectedPartner.id) ? 'Online' : 'Offline'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Header Action Buttons: Voice Call, Video Call, Friend Toggle, Block, Menu */}
                <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                  {/* Start Voice Call */}
                  <button
                    type="button"
                    onClick={() => handleStartCall('audio')}
                    disabled={selectedPartner.isBlocked || selectedPartner.hasBlockedMe}
                    className="p-2.5 rounded-xl bg-[#202039] hover:bg-emerald-600/30 text-emerald-300 hover:text-white border border-[#302D46] hover:border-emerald-500/50 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
                    title="Start Audio Call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>

                  {/* Start Video Call */}
                  <button
                    type="button"
                    onClick={() => handleStartCall('video')}
                    disabled={selectedPartner.isBlocked || selectedPartner.hasBlockedMe}
                    className="p-2.5 rounded-xl bg-[#202039] hover:bg-purple-600/30 text-purple-300 hover:text-white border border-[#302D46] hover:border-purple-500/50 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
                    title="Start Video Call"
                  >
                    <Video className="w-4 h-4" />
                  </button>

                  {/* Friend / Unfriend Toggle */}
                  <button
                    type="button"
                    onClick={() => handleToggleFriend(selectedPartner.id)}
                    className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border ${
                      selectedPartner.isFriend
                        ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-200 hover:bg-red-950 hover:text-red-200 hover:border-red-500/40'
                        : 'bg-[#202039] hover:bg-[#302D46] border-[#302D46] text-purple-200 hover:text-white'
                    }`}
                  >
                    {selectedPartner.isFriend ? (
                      <>
                        <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="hidden sm:inline">Friends</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5 text-purple-400" />
                        <span className="hidden sm:inline">Add Friend</span>
                      </>
                    )}
                  </button>

                  {/* 3-Dot Options Dropdown */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setShowOptionsMenu(!showOptionsMenu)}
                      className="p-2 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-[#202039] transition-colors cursor-pointer"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {showOptionsMenu && (
                      <div className="absolute right-0 top-full mt-1.5 w-48 bg-[#19192B] border border-[#302D46] rounded-2xl shadow-2xl p-1.5 z-40 text-xs">
                        <button
                          type="button"
                          onClick={() => handleToggleBlock(selectedPartner.id)}
                          className={`w-full text-left px-3 py-2 rounded-xl flex items-center gap-2 cursor-pointer transition-colors ${
                            selectedPartner.isBlocked
                              ? 'text-emerald-300 hover:bg-emerald-950/40'
                              : 'text-red-300 hover:bg-red-950/40'
                          }`}
                        >
                          {selectedPartner.isBlocked ? (
                            <>
                              <ShieldCheck className="w-4 h-4" />
                              <span>Unblock Player</span>
                            </>
                          ) : (
                            <>
                              <ShieldAlert className="w-4 h-4" />
                              <span>Block Player</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={handleClearChat}
                          className="w-full text-left px-3 py-2 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-[#202039] flex items-center gap-2 cursor-pointer transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-gray-400" />
                          <span>Clear Chat History</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Interactive In-Chat Call Alert Banner */}
              {partnerActiveCall && (partnerActiveCall.status === 'ringing' || partnerActiveCall.status === 'connected') && partnerActiveCall.callerId === selectedPartner.id && callStatus !== 'connected' && (
                <div className="p-3.5 bg-gradient-to-r from-emerald-950 via-purple-950 to-[#19192B] border-b border-emerald-500/50 flex flex-wrap items-center justify-between gap-3 shadow-lg animate-fadeIn shrink-0">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
                      <Phone className="w-5 h-5 animate-bounce" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-bold text-white">
                          @{selectedPartner.username} has started a {partnerActiveCall.type || 'voice'} call!
                        </p>
                        <span className="text-[9px] bg-emerald-500 text-black px-1.5 py-0.5 rounded-full font-black tracking-wider uppercase animate-pulse">
                          Live Call
                        </span>
                      </div>
                      <p className="text-[11px] text-emerald-200/90 mt-0.5">
                        Do you want to join this call?
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => joinCall(partnerActiveCall.id, partnerActiveCall.type)}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-400 hover:to-green-400 text-black font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/30 cursor-pointer transition-all hover:scale-105"
                    >
                      <Phone className="w-3.5 h-3.5 fill-current" />
                      <span>Join Call</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        declineCall(partnerActiveCall.id);
                        setPartnerActiveCall(null);
                      }}
                      className="px-3 py-2 rounded-xl bg-red-950/80 hover:bg-red-900 border border-red-500/40 text-red-300 font-semibold text-xs cursor-pointer transition-colors"
                    >
                      Decline
                    </button>
                  </div>
                </div>
              )}

              {/* Block Alert Banner if any block active */}
              {(selectedPartner.isBlocked || selectedPartner.hasBlockedMe) && (
                <div className="p-3 bg-red-950/80 border-b border-red-500/40 text-red-200 text-xs flex items-center justify-between gap-2 shrink-0 animate-fadeIn">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
                    <span>
                      {selectedPartner.isBlocked
                        ? 'You have blocked this player. Unblock them to exchange messages or place calls.'
                        : 'This player has blocked you. Messages and calls are restricted.'}
                    </span>
                  </div>
                  {selectedPartner.isBlocked && (
                    <button
                      type="button"
                      onClick={() => handleToggleBlock(selectedPartner.id)}
                      className="px-2.5 py-1 rounded-lg bg-red-900 hover:bg-red-800 text-white font-bold text-[11px] cursor-pointer"
                    >
                      Unblock
                    </button>
                  )}
                </div>
              )}

              {/* Error notice */}
              {chatError && (
                <div className="p-3 bg-red-950/70 border-b border-red-500/30 text-red-200 text-xs flex items-center gap-2 shrink-0">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span>{chatError}</span>
                </div>
              )}

              {/* Message Feed Viewport */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
                {messagesLoading ? (
                  <div className="py-20 text-center text-xs text-[#A5A3B8] flex items-center justify-center gap-2">
                    <RefreshCw className="w-4 h-4 animate-spin text-purple-400" />
                    <span>Loading messages...</span>
                  </div>
                ) : messages.length === 0 ? (
                  <div className="py-20 text-center text-[#A5A3B8]">
                    <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-[#8B5CF6]/20 to-[#A855F7]/20 border border-purple-500/30 flex items-center justify-center mx-auto mb-3 text-purple-300">
                      <Sparkles className="w-8 h-8" />
                    </div>
                    <h4 className="font-bold text-white text-base">Direct Conversation with @{selectedPartner.username}</h4>
                    <p className="text-xs text-[#A5A3B8] max-w-sm mx-auto mt-1">
                      Say hello or send a trade proposal! Messages are delivered in real time across the LOT Network.
                    </p>
                  </div>
                ) : (
                  messages.map((msg) => {
                    if (msg.type === 'call') {
                      const isMe = msg.senderId === user?.id;
                      const isRinging = msg.callStatus === 'ringing';
                      const isConnected = msg.callStatus === 'connected';

                      return (
                        <div key={msg.id} className="flex justify-center my-3 animate-fadeIn">
                          <div className={`w-full max-w-md rounded-2xl p-4 border shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                            isRinging
                              ? 'bg-gradient-to-r from-emerald-950/80 via-purple-950/60 to-[#19192B] border-emerald-500/40 shadow-emerald-950/30'
                              : isConnected
                              ? 'bg-gradient-to-r from-purple-950/80 to-[#19192B] border-purple-500/40'
                              : 'bg-[#19192B]/80 border-[#302D46] text-[#A5A3B8]'
                          }`}>
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${
                                isRinging
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                                  : isConnected
                                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                                  : 'bg-[#202039] text-gray-400'
                              }`}>
                                {msg.callType === 'video' ? <Video className="w-5 h-5" /> : <Phone className="w-5 h-5" />}
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-xs text-white">
                                    {isMe ? 'You' : `@${msg.senderUsername}`} started a {msg.callType || 'voice'} call
                                  </span>
                                  <span className={`text-[9px] px-1.5 py-0.5 rounded font-black uppercase ${
                                    isRinging
                                      ? 'bg-emerald-500 text-black animate-pulse'
                                      : isConnected
                                      ? 'bg-purple-500 text-white'
                                      : 'bg-gray-800 text-gray-400'
                                  }`}>
                                    {msg.callStatus || 'call'}
                                  </span>
                                </div>
                                <p className="text-[11px] text-[#A5A3B8] mt-0.5">
                                  {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </p>
                              </div>
                            </div>

                            {/* Join Call button inside feed if ringing or active */}
                            {isRinging && callStatus !== 'connected' && (
                              <button
                                type="button"
                                onClick={() => joinCall(msg.callId || msg.id.replace('msg_call_', ''), msg.callType)}
                                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-400 hover:to-green-400 text-black font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 cursor-pointer transition-all hover:scale-105 shrink-0"
                              >
                                <Phone className="w-3.5 h-3.5 fill-current" />
                                <span>Join Call</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    }

                    const isMe = msg.senderId === user?.id;

                    return (
                      <div
                        key={msg.id}
                        className={`flex items-end gap-2.5 ${isMe ? 'justify-end' : 'justify-start'}`}
                      >
                        {/* Partner Avatar for received messages */}
                        {!isMe && (
                          <div className="w-8 h-8 rounded-xl bg-purple-600 flex items-center justify-center text-xs font-bold text-white overflow-hidden shrink-0 shadow">
                            {selectedPartner.avatarUrl ? (
                              <img src={selectedPartner.avatarUrl} alt={selectedPartner.username} className="w-full h-full object-cover" />
                            ) : (
                              selectedPartner.username.charAt(0).toUpperCase()
                            )}
                          </div>
                        )}

                        <div className={`max-w-[85%] sm:max-w-[72%] rounded-2xl p-3 shadow-md ${
                          isMe
                            ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white rounded-br-none'
                            : 'bg-[#19192B] border border-[#302D46] text-[#F5F3FF] rounded-bl-none'
                        }`}>
                          {/* Attachment (Photo or animated GIF) */}
                          {msg.attachmentUrl && (
                            <div className="mb-2 relative rounded-xl overflow-hidden group cursor-pointer border border-white/10 bg-black/20">
                              <img
                                src={msg.attachmentUrl}
                                alt={msg.fileName || 'Media attachment'}
                                className="w-full max-h-72 object-cover rounded-xl transition-transform group-hover:scale-[1.02]"
                                loading="lazy"
                                onClick={() =>
                                  setLightboxMedia({
                                    url: msg.attachmentUrl!,
                                    fileName: msg.fileName,
                                    isGif: msg.mediaType === 'gif' || msg.type === 'gif',
                                  })
                                }
                              />
                              {(msg.mediaType === 'gif' || msg.type === 'gif') && (
                                <span className="absolute top-2 left-2 px-1.5 py-0.5 rounded-md bg-purple-900/90 text-purple-200 border border-purple-400/50 text-[10px] font-black tracking-wider uppercase backdrop-blur-sm pointer-events-none">
                                  GIF
                                </span>
                              )}
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 pointer-events-none">
                                <span className="p-2 rounded-xl bg-black/70 text-white backdrop-blur-sm flex items-center gap-1.5 text-xs font-semibold">
                                  <Eye className="w-3.5 h-3.5" />
                                  <span>View</span>
                                </span>
                              </div>
                            </div>
                          )}

                          {msg.content && (
                            <p className="text-xs sm:text-sm whitespace-pre-wrap break-words leading-relaxed font-sans">
                              {msg.content}
                            </p>
                          )}

                          <div className={`flex items-center gap-1.5 mt-1 text-[10px] ${isMe ? 'text-purple-200 justify-end' : 'text-[#706E88] justify-start'}`}>
                            <span>
                              {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                            {isMe && (
                              <span>
                                {msg.read ? <CheckCheck className="w-3.5 h-3.5 text-white" /> : <Check className="w-3.5 h-3.5 text-purple-300" />}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Attachment Preview Banner before sending */}
              {pendingAttachment && (
                <div className="px-4 py-2.5 bg-[#121222] border-t border-[#302D46] flex items-center justify-between gap-3 animate-fadeIn shrink-0">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="relative w-12 h-12 rounded-xl overflow-hidden border border-purple-500/50 shrink-0 bg-black/30">
                      <img
                        src={pendingAttachment.previewUrl}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                      {pendingAttachment.isGif && (
                        <span className="absolute bottom-0 inset-x-0 bg-purple-900/90 text-[8px] font-black text-center text-purple-200 uppercase py-0.5">
                          GIF
                        </span>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white truncate max-w-[200px]">
                          {pendingAttachment.name}
                        </span>
                        {pendingAttachment.isGif && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/30 text-purple-300 font-bold uppercase">
                            Native GIF
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-[#A5A3B8]">
                        {(pendingAttachment.size / (1024 * 1024)).toFixed(2)} MB • Ready to send
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleRemoveAttachment}
                    className="p-1.5 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-[#202039] transition-colors cursor-pointer"
                    title="Remove attachment"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Message Input Form */}
              <div className="p-3 sm:p-4 border-t border-[#302D46] bg-[#19192B]/60 shrink-0">
                <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                  {/* Hidden File Picker Input */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/jpeg,image/png,image/webp,image/gif"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileSelect(file);
                    }}
                  />

                  {/* Attachment Button */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={selectedPartner.isBlocked || selectedPartner.hasBlockedMe || sendingMessage}
                    className="p-3 rounded-2xl bg-[#121222] hover:bg-[#202039] text-[#A5A3B8] hover:text-purple-300 border border-[#302D46] transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
                    title="Attach photo or GIF (or paste directly from keyboard)"
                  >
                    <Paperclip className="w-4 h-4" />
                  </button>

                  <input
                    type="text"
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onPaste={handlePaste}
                    disabled={selectedPartner.isBlocked || selectedPartner.hasBlockedMe || sendingMessage}
                    placeholder={
                      selectedPartner.isBlocked || selectedPartner.hasBlockedMe
                        ? 'Messaging disabled due to block restrictions'
                        : pendingAttachment
                        ? `Add a caption (optional)...`
                        : `Message @${selectedPartner.username}... (Paste GIFs directly or press Enter)`
                    }
                    className="flex-1 px-4 py-3 bg-[#121222] border border-[#302D46] focus:border-purple-500 rounded-2xl text-xs sm:text-sm text-white placeholder-[#706E88] focus:outline-none transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-inner"
                  />

                  {/* Send Button */}
                  <button
                    type="submit"
                    disabled={(!messageInput.trim() && !pendingAttachment) || selectedPartner.isBlocked || selectedPartner.hasBlockedMe || sendingMessage || uploadingAttachment}
                    className="p-3 rounded-2xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:brightness-110 text-white transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-purple-500/20 shrink-0 flex items-center justify-center min-w-[44px]"
                    title="Send message"
                  >
                    {uploadingAttachment ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </button>
                </form>
              </div>
            </>
          ) : (
            /* Empty State when no partner selected */
            <div className="my-auto p-12 text-center text-[#A5A3B8]">
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-[#8B5CF6]/20 to-[#A855F7]/20 border border-purple-500/30 flex items-center justify-center mx-auto mb-4 text-purple-300">
                <MessageSquare className="w-10 h-10" />
              </div>
              <h3 className="font-black text-xl text-white mb-2">Select a Conversation or Search a Player</h3>
              <p className="text-xs sm:text-sm text-[#A5A3B8] max-w-md mx-auto mb-6">
                Type any player&apos;s username in the search bar above to start a live conversation or make an audio/video call!
              </p>

              {friendsList.length > 0 && (
                <div className="max-w-sm mx-auto p-4 rounded-2xl bg-[#19192B]/80 border border-[#302D46]">
                  <span className="text-[11px] font-bold text-purple-300 block mb-2">Quick Chat with Friends:</span>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {friendsList.slice(0, 5).map((fr) => (
                      <button
                        key={fr.id}
                        type="button"
                        onClick={() => loadPlayerByUsername(fr.friendUsername)}
                        className="px-3 py-1.5 rounded-xl bg-[#202039] hover:bg-purple-600/30 border border-[#302D46] hover:border-purple-500 text-xs font-semibold text-white flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <span>@{fr.friendUsername}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {/* Lightbox High-Resolution Media Modal */}
      {lightboxMedia && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-4 animate-fadeIn"
          onClick={() => setLightboxMedia(null)}
        >
          <div
            className="relative max-w-4xl max-h-[90vh] flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header / Actions */}
            <div className="w-full flex items-center justify-between pb-3 text-white">
              <div className="flex items-center gap-2">
                <span className="text-xs sm:text-sm font-bold truncate max-w-xs sm:max-w-md">
                  {lightboxMedia.fileName || (lightboxMedia.isGif ? 'Animated GIF' : 'Photo Attachment')}
                </span>
                {lightboxMedia.isGif && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-600 font-black uppercase tracking-wider">
                    GIF
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={lightboxMedia.url}
                  download={lightboxMedia.fileName || (lightboxMedia.isGif ? 'media.gif' : 'media.png')}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#A5A3B8] hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
                  title="Download image"
                >
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">Download</span>
                </a>

                <button
                  type="button"
                  onClick={() => setLightboxMedia(null)}
                  className="p-2 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#A5A3B8] hover:text-white transition-colors cursor-pointer"
                  title="Close preview"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Media Display */}
            <div className="relative rounded-2xl overflow-hidden border border-[#302D46] bg-black shadow-2xl max-h-[80vh] flex items-center justify-center">
              <img
                src={lightboxMedia.url}
                alt={lightboxMedia.fileName || 'Enlarged media'}
                className="max-h-[80vh] max-w-full object-contain"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
