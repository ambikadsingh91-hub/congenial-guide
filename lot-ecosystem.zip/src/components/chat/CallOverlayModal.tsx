import React, { useState, useRef, useEffect } from 'react';
import { useSocial } from '../../context/SocialContext';
import { useAuth } from '../../context/AuthContext';
import {
  Phone,
  PhoneOff,
  Video,
  VideoOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Minimize2,
  Maximize2,
  Sparkles,
  SwitchCamera,
  AlertTriangle,
  Radio,
  Activity,
} from 'lucide-react';

export const CallOverlayModal: React.FC = () => {
  const { user } = useAuth();
  const {
    activeCall,
    incomingCall,
    callStatus,
    callError,
    isMuted,
    isVideoEnabled,
    isSpeakerOn,
    callDuration,
    localStream,
    remoteStream,
    acceptCall,
    declineCall,
    endCall,
    toggleMute,
    toggleVideo,
    toggleSpeaker,
    switchCamera,
  } = useSocial();

  const [isMinimized, setIsMinimized] = useState(false);
  const [remoteAudioUnlocked, setRemoteAudioUnlocked] = useState(false);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const remoteAudioRef = useRef<HTMLAudioElement>(null);

  // Web Audio direct playback pipeline to ensure voice is ALWAYS emitted without browser autoplay blocks
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Setup Web Audio playback for incoming remote audio stream
  useEffect(() => {
    if (!remoteStream) {
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        try {
          audioContextRef.current.close();
        } catch {}
        audioContextRef.current = null;
      }
      return;
    }

    const audioTracks = remoteStream.getAudioTracks();
    console.log('[CallOverlay] Remote audio tracks count:', audioTracks.length);

    if (audioTracks.length > 0) {
      audioTracks.forEach((t) => (t.enabled = true));

      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          audioContextRef.current = ctx;

          if (ctx.state === 'suspended') {
            ctx.resume().catch(() => {});
          }

          const source = ctx.createMediaStreamSource(remoteStream);
          mediaStreamSourceRef.current = source;

          const gain = ctx.createGain();
          gain.gain.setValueAtTime(isSpeakerOn ? 1.0 : 0.0, ctx.currentTime);
          gainNodeRef.current = gain;

          source.connect(gain);
          gain.connect(ctx.destination);
          setRemoteAudioUnlocked(true);
          console.log('[CallOverlay] Web Audio route connected to speakers successfully');
        }
      } catch (err) {
        console.warn('[CallOverlay] Web Audio route initialization warning:', err);
      }
    }

    return () => {
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        try {
          audioContextRef.current.close();
        } catch {}
        audioContextRef.current = null;
      }
    };
  }, [remoteStream]);

  // Adjust speaker volume gain when user toggles speaker button
  useEffect(() => {
    if (gainNodeRef.current && audioContextRef.current) {
      try {
        gainNodeRef.current.gain.setValueAtTime(
          isSpeakerOn ? 1.0 : 0.0,
          audioContextRef.current.currentTime
        );
      } catch {}
    }
  }, [isSpeakerOn]);

  // Attach local stream to preview video element
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
      localVideoRef.current.play().catch(() => {});
    }
  }, [localStream, isVideoEnabled]);

  // Attach remote stream to HTML5 video & audio elements
  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
      remoteVideoRef.current.play().catch((err) => {
        console.warn('[CallOverlay] Remote video play note:', err);
      });
    }

    if (remoteAudioRef.current && remoteStream) {
      remoteAudioRef.current.srcObject = remoteStream;
      remoteAudioRef.current.muted = !isSpeakerOn;
      remoteAudioRef.current.play().catch((err) => {
        console.log('[CallOverlay] HTML5 audio waiting for user interaction:', err);
      });
    }
  }, [remoteStream, isSpeakerOn]);

  // Global user gesture click to unlock audio if browser initially paused it
  const handleUserInteractionUnlock = () => {
    if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume().then(() => {
        setRemoteAudioUnlocked(true);
      }).catch(() => {});
    }
    if (remoteAudioRef.current) {
      remoteAudioRef.current.play().catch(() => {});
    }
    if (remoteVideoRef.current) {
      remoteVideoRef.current.play().catch(() => {});
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Determine partner profile
  const isCaller = activeCall ? activeCall.callerId === user?.id : false;
  const partnerUsername = activeCall
    ? isCaller
      ? activeCall.recipientUsername
      : activeCall.callerUsername
    : '';
  const partnerAvatar = activeCall
    ? isCaller
      ? activeCall.recipientAvatarUrl
      : activeCall.callerAvatarUrl
    : '';

  const isVideoCall = activeCall?.type === 'video';
  const remoteVideoTracks = remoteStream ? remoteStream.getVideoTracks() : [];
  const hasRemoteVideo = isVideoCall && remoteVideoTracks.length > 0 && remoteVideoTracks.some((t) => t.enabled);

  return (
    <div onClick={handleUserInteractionUnlock}>
      {/* Hidden remote audio element as secondary fallback audio path */}
      <audio ref={remoteAudioRef} autoPlay playsInline muted={!isSpeakerOn} />

      {/* ---------------------------------------------------- */}
      {/* INCOMING CALL ALERT (Global notification) */}
      {/* ---------------------------------------------------- */}
      {incomingCall && (
        <div className="fixed top-5 right-5 sm:top-8 sm:right-8 z-50 animate-bounce duration-1000 max-w-sm w-full">
          <div className="p-4 sm:p-5 rounded-3xl bg-[#19192B]/95 border-2 border-purple-500 shadow-2xl backdrop-blur-xl text-white flex flex-col gap-3">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] flex items-center justify-center text-xl font-bold text-white shadow-lg overflow-hidden shrink-0 border border-purple-400">
                  {incomingCall.callerAvatarUrl ? (
                    <img
                      src={incomingCall.callerAvatarUrl}
                      alt={incomingCall.callerUsername}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    incomingCall.callerUsername.charAt(0).toUpperCase()
                  )}
                </div>
                <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-[#19192B] flex items-center justify-center">
                  {incomingCall.type === 'video' ? (
                    <Video className="w-2.5 h-2.5 text-white" />
                  ) : (
                    <Phone className="w-2.5 h-2.5 text-white" />
                  )}
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <p className="text-[11px] text-[#A5A3B8] font-medium flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                  Incoming {incomingCall.type === 'video' ? 'Video' : 'Voice'} Call...
                </p>
                <h4 className="font-black text-base text-white truncate">@{incomingCall.callerUsername}</h4>
                <span className="text-[10px] text-purple-300">LOT WebRTC Network</span>
              </div>
            </div>

            {/* Action buttons: Accept or Decline */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => declineCall(incomingCall.id)}
                className="py-2.5 px-3 rounded-xl bg-red-950/80 hover:bg-red-900 border border-red-500/50 text-red-200 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-sm"
              >
                <PhoneOff className="w-4 h-4 text-red-400" />
                <span>Decline</span>
              </button>

              <button
                type="button"
                onClick={() => acceptCall(incomingCall.id)}
                className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg shadow-emerald-500/20"
              >
                <Phone className="w-4 h-4 text-white animate-bounce" />
                <span>Accept</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* ACTIVE CALL SCREEN / OVERLAY */}
      {/* ---------------------------------------------------- */}
      {activeCall && (
        <>
          {/* Minimized View */}
          {isMinimized ? (
            <div className="fixed bottom-6 right-6 z-50 animate-fadeIn">
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-[#19192B]/95 border border-[#8B5CF6] shadow-2xl backdrop-blur-md text-white">
                <div className="relative">
                  <div className="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-sm font-bold text-white overflow-hidden shrink-0">
                    {partnerAvatar ? (
                      <img src={partnerAvatar} alt={partnerUsername} className="w-full h-full object-cover" />
                    ) : (
                      partnerUsername.charAt(0).toUpperCase()
                    )}
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border border-[#19192B]" />
                </div>

                <div>
                  <p className="text-xs font-bold text-white truncate max-w-[120px]">@{partnerUsername}</p>
                  <p className="text-[10px] text-emerald-400 font-medium">
                    {callStatus === 'connected' ? formatDuration(callDuration) : callStatus}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 ml-2">
                  <button
                    type="button"
                    onClick={toggleMute}
                    className={`p-2 rounded-lg cursor-pointer ${
                      isMuted ? 'bg-red-500/20 text-red-400' : 'bg-white/10 text-white'
                    }`}
                  >
                    {isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsMinimized(false)}
                    className="p-2 rounded-lg bg-white/10 text-white hover:bg-white/20 cursor-pointer"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={endCall}
                    className="p-2 rounded-lg bg-red-600 hover:bg-red-500 text-white cursor-pointer"
                  >
                    <PhoneOff className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Full Glass Call Overlay */
            <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-xl animate-fadeIn">
              <div className="relative w-full max-w-2xl bg-gradient-to-b from-[#19192B] via-[#121222] to-[#0B0B14] border border-[#302D46] rounded-3xl shadow-2xl p-4 sm:p-6 text-white flex flex-col items-center justify-between min-h-[520px] sm:min-h-[580px] overflow-hidden">
                {/* Background Ambient Glow */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

                {/* Top Header Bar */}
                <div className="w-full flex items-center justify-between z-20">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/40 text-[11px] font-bold text-purple-300 flex items-center gap-1.5 shadow-sm">
                      <Radio className="w-3 h-3 text-purple-400 animate-pulse" />
                      LOT WebRTC Real-Time {isVideoCall ? 'Video' : 'Voice'} Call
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsMinimized(true)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#A5A3B8] hover:text-white transition-colors cursor-pointer"
                    title="Minimize call"
                  >
                    <Minimize2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Error Banner if any */}
                {callError && (
                  <div className="w-full mt-2 p-2.5 rounded-xl bg-red-950/80 border border-red-500/50 text-red-200 text-xs flex items-center gap-2 z-20 animate-fadeIn">
                    <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                    <span>{callError}</span>
                  </div>
                )}

                {/* Center Video/Audio Area */}
                <div className="relative w-full flex-1 flex flex-col items-center justify-center my-3 z-10 min-h-0">
                  {/* Video Call Mode */}
                  {isVideoCall && (
                    <div className="relative w-full h-full max-h-[400px] aspect-video rounded-2xl overflow-hidden bg-black/60 border border-[#302D46] flex items-center justify-center shadow-2xl">
                      {/* Remote Video Stream */}
                      <video
                        ref={remoteVideoRef}
                        autoPlay
                        playsInline
                        className="w-full h-full object-cover"
                      />

                      {/* Remote Video Placeholder (if remote camera is off or negotiating) */}
                      {!hasRemoteVideo && (
                        <div className="absolute inset-0 bg-[#121222]/90 flex flex-col items-center justify-center p-6 text-center z-10">
                          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#8B5CF6] to-[#C4B5FD] p-1 mb-3 shadow-xl">
                            <div className="w-full h-full rounded-full overflow-hidden bg-[#151528] flex items-center justify-center text-3xl font-black text-white">
                              {partnerAvatar ? (
                                <img
                                  src={partnerAvatar}
                                  alt={partnerUsername}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                partnerUsername.charAt(0).toUpperCase()
                              )}
                            </div>
                          </div>
                          <p className="text-sm font-bold text-white">@{partnerUsername}</p>
                          <p className="text-xs text-[#A5A3B8] mt-1">
                            {callStatus === 'connected' ? 'Voice connected • Camera is off' : 'Connecting media stream...'}
                          </p>
                        </div>
                      )}

                      {/* Local Video Stream Picture-in-Picture Box */}
                      {isVideoEnabled && localStream && (
                        <div className="absolute bottom-3 right-3 w-28 sm:w-36 aspect-[4/3] rounded-xl overflow-hidden border-2 border-purple-500/60 bg-black shadow-2xl z-20">
                          <video
                            ref={localVideoRef}
                            autoPlay
                            muted
                            playsInline
                            className="w-full h-full object-cover -scale-x-100"
                          />
                          <div className="absolute bottom-1 left-1.5 flex items-center gap-1 bg-black/70 px-1.5 py-0.5 rounded text-[9px] text-white font-mono">
                            <span>You</span>
                            {isMuted && <MicOff className="w-2.5 h-2.5 text-red-400" />}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Audio-only Call Mode */}
                  {!isVideoCall && (
                    <div className="flex flex-col items-center justify-center text-center py-4">
                      <div className="relative mb-5">
                        {/* Animated Ripple Waves */}
                        <div className="absolute inset-0 rounded-full bg-purple-500/20 animate-ping opacity-60" />
                        <div className="absolute -inset-3 rounded-full bg-purple-500/10 animate-pulse" />

                        {/* Main Avatar Container */}
                        <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#8B5CF6] via-[#A855F7] to-[#C4B5FD] p-1 shadow-2xl shadow-purple-500/30">
                          <div className="w-full h-full rounded-[22px] overflow-hidden bg-[#121222] flex items-center justify-center text-3xl font-black text-white">
                            {partnerAvatar ? (
                              <img
                                src={partnerAvatar}
                                alt={partnerUsername}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              partnerUsername.charAt(0).toUpperCase()
                            )}
                          </div>
                        </div>

                        {/* Audio Call Badge */}
                        <div className="absolute -bottom-2 right-1/2 translate-x-1/2 px-3 py-0.5 rounded-full bg-[#19192B] border border-purple-500 text-[10px] font-bold text-purple-200 shadow">
                          VOICE CALL
                        </div>
                      </div>

                      <h3 className="text-2xl font-black text-white">@{partnerUsername}</h3>

                      {/* Live Voice Activity Indicator */}
                      {callStatus === 'connected' && (
                        <div className="flex items-center gap-1.5 mt-2 px-3 py-1 rounded-full bg-purple-900/40 border border-purple-500/30 text-purple-200 text-xs">
                          <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                          <span>Voice stream active</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Call State & Duration */}
                  <div className="mt-3 flex items-center gap-2">
                    {callStatus === 'ringing' && (
                      <p className="text-xs text-purple-300 font-semibold animate-pulse">
                        Ringing @{partnerUsername}...
                      </p>
                    )}
                    {callStatus === 'connecting' && (
                      <p className="text-xs text-purple-300 font-semibold animate-pulse">
                        Connecting WebRTC audio channels...
                      </p>
                    )}
                    {callStatus === 'connected' && (
                      <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/30">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                        <span className="text-xs font-mono font-bold text-emerald-400">
                          {formatDuration(callDuration)}
                        </span>
                      </div>
                    )}
                    {callStatus === 'ended' && (
                      <p className="text-xs text-red-400 font-bold">Call Ended</p>
                    )}
                    {callStatus === 'declined' && (
                      <p className="text-xs text-red-400 font-bold">Call Declined</p>
                    )}
                  </div>
                </div>

                {/* Bottom Call Action Control Bar */}
                <div className="w-full flex items-center justify-center gap-3 sm:gap-4 p-3 rounded-2xl bg-white/5 border border-white/10 z-20">
                  {/* Microphone Mute Toggle */}
                  <button
                    type="button"
                    onClick={toggleMute}
                    className={`p-3.5 rounded-2xl flex items-center justify-center transition-all cursor-pointer ${
                      isMuted
                        ? 'bg-red-600/80 hover:bg-red-600 text-white shadow-lg shadow-red-500/20'
                        : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                    title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
                  >
                    {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>

                  {/* Video Camera Toggle */}
                  {isVideoCall && (
                    <>
                      <button
                        type="button"
                        onClick={toggleVideo}
                        className={`p-3.5 rounded-2xl flex items-center justify-center transition-all cursor-pointer ${
                          !isVideoEnabled
                            ? 'bg-red-600/80 hover:bg-red-600 text-white shadow-lg shadow-red-500/20'
                            : 'bg-white/10 hover:bg-white/20 text-white'
                        }`}
                        title={isVideoEnabled ? 'Turn Off Camera' : 'Turn On Camera'}
                      >
                        {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                      </button>

                      <button
                        type="button"
                        onClick={switchCamera}
                        className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
                        title="Switch Camera (Front/Rear)"
                      >
                        <SwitchCamera className="w-5 h-5" />
                      </button>
                    </>
                  )}

                  {/* Speaker Output Toggle */}
                  <button
                    type="button"
                    onClick={toggleSpeaker}
                    className={`p-3.5 rounded-2xl flex items-center justify-center transition-all cursor-pointer ${
                      !isSpeakerOn
                        ? 'bg-red-600/80 hover:bg-red-600 text-white shadow-lg shadow-red-500/20'
                        : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                    title={isSpeakerOn ? 'Mute Speaker' : 'Unmute Speaker'}
                  >
                    {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                  </button>

                  {/* End Call Button */}
                  <button
                    type="button"
                    onClick={endCall}
                    className="p-3.5 px-6 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold flex items-center justify-center gap-2 shadow-xl shadow-red-600/30 transition-all cursor-pointer hover:scale-105 active:scale-95"
                    title="End Call"
                  >
                    <PhoneOff className="w-5 h-5" />
                    <span className="text-xs hidden sm:inline">End Call</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
