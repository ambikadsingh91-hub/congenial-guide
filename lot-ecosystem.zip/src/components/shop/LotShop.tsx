import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Listing, ProductCategory, Order, OrderStatus } from '../../types';
import {
  ShoppingBag,
  Search,
  PlusCircle,
  Package,
  Clock,
  CheckCircle,
  Truck,
  ExternalLink,
  Coins,
  Sparkles,
  AlertCircle,
  X,
  Tag,
  ShieldCheck,
  BellRing,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatCompactNumber } from '../../lib/formatNumber';
import { playPurchaseSound, playErrorSound } from '../../lib/sounds';

const CATEGORIES: ('All' | ProductCategory)[] = ['All', 'Weapons', 'Collectibles', 'Clothing', 'Other'];

const SAMPLE_IMAGE_PRESETS = [
  { name: 'Plasma Katana', url: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80' },
  { name: 'Cybernetic Visor', url: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=600&q=80' },
  { name: 'Quantum Core Relic', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80' },
  { name: 'Stealth Exosuit', url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80' },
];

export const LotShop: React.FC = () => {
  const { user, openAuthModal, refreshUser } = useAuth();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<'All' | ProductCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [selectedListing, setSelectedListing] = useState<Listing | null>(null);
  const [purchaseQuantity, setPurchaseQuantity] = useState(1);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isOrdersModalOpen, setIsOrdersModalOpen] = useState(false);
  const [isWebhookModalOpen, setIsWebhookModalOpen] = useState(false);

  // Listing creation form state
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState<ProductCategory>('Weapons');
  const [newPrice, setNewPrice] = useState('150');
  const [newStock, setNewStock] = useState('5');
  const [newImageUrl, setNewImageUrl] = useState(SAMPLE_IMAGE_PRESETS[0].url);
  const [createLoading, setCreateLoading] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // Orders state
  const [purchases, setPurchases] = useState<Order[]>([]);
  const [sales, setSales] = useState<Order[]>([]);
  const [ordersTab, setOrdersTab] = useState<'purchases' | 'sales'>('purchases');
  const [ordersLoading, setOrdersLoading] = useState(false);

  // Webhook state
  const [webhookUrl, setWebhookUrl] = useState('');
  const [webhookSaved, setWebhookSaved] = useState(false);
  const [webhookLoading, setWebhookLoading] = useState(false);

  const fetchListings = async () => {
    try {
      setLoading(true);
      const url = new URL('/api/shop/listings', window.location.origin);
      if (selectedCategory !== 'All') url.searchParams.set('category', selectedCategory);
      if (searchQuery.trim()) url.searchParams.set('search', searchQuery.trim());

      const res = await fetch(url.toString());
      if (res.ok) {
        const data = await res.json();
        setListings(data.listings || []);
      }
    } catch {
      // non-critical
    } finally {
      setLoading(false);
    }
  };

  const fetchOrders = async () => {
    if (!user) return;
    try {
      setOrdersLoading(true);
      const res = await fetch('/api/shop/orders');
      if (res.ok) {
        const data = await res.json();
        setPurchases(data.purchases || []);
        setSales(data.sales || []);
      }
    } catch {
      // ignore
    } finally {
      setOrdersLoading(false);
    }
  };

  const fetchWebhook = async () => {
    if (!user) return;
    try {
      const res = await fetch('/api/shop/seller/webhook');
      if (res.ok) {
        const data = await res.json();
        setWebhookUrl(data.webhookUrl || '');
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetchListings();
  }, [selectedCategory]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchListings();
  };

  const handleBuyItem = async () => {
    if (!user) {
      openAuthModal('login');
      return;
    }
    if (!selectedListing) return;

    setIsPurchasing(true);
    setPurchaseError(null);

    try {
      const res = await fetch('/api/shop/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          listingId: selectedListing.id,
          quantity: purchaseQuantity,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        playErrorSound();
        setPurchaseError(data.error || 'Failed to complete purchase.');
        setIsPurchasing(false);
        return;
      }

      playPurchaseSound();
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#8B5CF6', '#A855F7', '#C4B5FD', '#10B981'],
      });

      setSelectedListing(null);
      setPurchaseQuantity(1);
      await refreshUser();
      await fetchListings();
    } catch {
      playErrorSound();
      setPurchaseError('Network error during purchase.');
    } finally {
      setIsPurchasing(false);
    }
  };

  const handleCreateListing = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal('login');
      return;
    }

    setCreateLoading(true);
    setCreateError(null);

    try {
      const res = await fetch('/api/shop/listings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle,
          description: newDesc,
          category: newCategory,
          priceLot: Number(newPrice),
          stock: Number(newStock),
          images: [newImageUrl || SAMPLE_IMAGE_PRESETS[0].url],
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setCreateError(data.error || 'Failed to publish listing.');
        setCreateLoading(false);
        return;
      }

      setIsCreateModalOpen(false);
      setNewTitle('');
      setNewDesc('');
      setNewPrice('150');
      setNewStock('5');
      await fetchListings();
    } catch {
      setCreateError('Network error occurred.');
    } finally {
      setCreateLoading(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus) => {
    try {
      const res = await fetch(`/api/shop/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        await fetchOrders();
      }
    } catch {
      // ignore
    }
  };

  const handleSaveWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    setWebhookLoading(true);
    try {
      const res = await fetch('/api/shop/seller/webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ webhookUrl }),
      });
      if (res.ok) {
        setWebhookSaved(true);
        setTimeout(() => setWebhookSaved(false), 3000);
      }
    } catch {
      // ignore
    } finally {
      setWebhookLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* Hero Banner — Exact Required Headline: Buy. Sell. Earn LOT. */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#121222] via-[#19192B] to-[#202039] border border-[#302D46] p-8 sm:p-12 shadow-2xl">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-[#8B5CF6]/15 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-80 h-80 rounded-full bg-[#A855F7]/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#202039] border border-[#8B5CF6]/40 text-[#C4B5FD] text-xs font-semibold mb-4">
            <Sparkles className="w-3.5 h-3.5 text-[#A855F7]" />
            Authoritative LOT Marketplace
          </div>
          <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-none mb-4">
            Buy. Sell. Earn LOT.
          </h1>
          <p className="text-base sm:text-lg text-[#A5A3B8] leading-relaxed mb-6">
            Explore premium gaming weapons, rare artifacts, and virtual clothing with instantaneous atomic settlement
            and cross-platform delivery tracking.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => {
                if (!user) openAuthModal('login');
                else setIsCreateModalOpen(true);
              }}
              className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:from-[#7C3AED] hover:to-[#9333EA] text-white font-semibold text-sm shadow-lg shadow-purple-500/25 transition-all cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>List Item for Sale</span>
            </button>

            {user && (
              <>
                <button
                  onClick={() => {
                    fetchOrders();
                    setIsOrdersModalOpen(true);
                  }}
                  className="flex items-center gap-2 px-4 py-3 rounded-xl bg-[#202039] hover:bg-[#302D46] text-white text-sm font-medium border border-[#302D46] transition-all cursor-pointer"
                >
                  <Package className="w-4 h-4 text-[#8B5CF6]" />
                  <span>My Orders & Sales</span>
                </button>

                <button
                  onClick={() => {
                    fetchWebhook();
                    setIsWebhookModalOpen(true);
                  }}
                  className="flex items-center gap-2 px-4 py-3 rounded-xl bg-[#202039] hover:bg-[#302D46] text-[#A5A3B8] hover:text-white text-sm font-medium border border-[#302D46] transition-all cursor-pointer"
                  title="Configure Discord webhook for real-time sale alerts"
                >
                  <BellRing className="w-4 h-4 text-[#C4B5FD]" />
                  <span>Discord Alert</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Quick Highlights Banner */}
        <div className="mt-8 pt-6 border-t border-[#302D46]/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <span className="text-[#A5A3B8] block">Settlement Currency</span>
            <span className="font-bold text-white text-sm flex items-center gap-1 mt-0.5">
              <Coins className="w-3.5 h-3.5 text-[#8B5CF6]" /> 100% LOT Authoritative
            </span>
          </div>
          <div>
            <span className="text-[#A5A3B8] block">Atomic Guarantees</span>
            <span className="font-bold text-emerald-400 text-sm flex items-center gap-1 mt-0.5">
              <ShieldCheck className="w-3.5 h-3.5" /> No Negative Balance
            </span>
          </div>
          <div>
            <span className="text-[#A5A3B8] block">Order Tracking</span>
            <span className="font-bold text-white text-sm flex items-center gap-1 mt-0.5">
              <Truck className="w-3.5 h-3.5 text-[#C4B5FD]" /> Placed → Delivered
            </span>
          </div>
          <div>
            <span className="text-[#A5A3B8] block">Seller Webhooks</span>
            <span className="font-bold text-indigo-400 text-sm flex items-center gap-1 mt-0.5">
              <BellRing className="w-3.5 h-3.5" /> Discord Bot Ready
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        {/* Categories */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#8B5CF6] text-white shadow-md shadow-purple-500/20'
                  : 'bg-[#19192B] border border-[#302D46] text-[#A5A3B8] hover:text-white hover:border-[#8B5CF6]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <form onSubmit={handleSearchSubmit} className="relative sm:w-72">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A5A3B8]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search weapons, items..."
            className="w-full pl-10 pr-4 py-2 bg-[#19192B] border border-[#302D46] rounded-xl text-white placeholder-[#A5A3B8]/60 focus:outline-none focus:border-[#8B5CF6] text-xs transition-all"
          />
        </form>
      </div>

      {/* Product Listings Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-72 rounded-2xl bg-[#19192B] animate-pulse border border-[#302D46]" />
          ))}
        </div>
      ) : listings.length === 0 ? (
        <div className="text-center py-16 bg-[#19192B] border border-[#302D46] rounded-2xl p-8">
          <ShoppingBag className="w-12 h-12 text-[#A5A3B8] mx-auto mb-3 opacity-60" />
          <h3 className="text-lg font-bold text-white mb-1">No items found</h3>
          <p className="text-xs text-[#A5A3B8] max-w-sm mx-auto mb-4">
            Be the first seller to list a legendary weapon or collectible in LOT Shop!
          </p>
          <button
            onClick={() => {
              if (!user) openAuthModal('login');
              else setIsCreateModalOpen(true);
            }}
            className="px-4 py-2 bg-[#8B5CF6] text-white text-xs font-semibold rounded-xl hover:bg-[#7C3AED] transition-colors cursor-pointer"
          >
            Create First Listing
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {listings.map((item) => (
            <div
              key={item.id}
              className="group bg-[#19192B] border border-[#302D46] hover:border-[#8B5CF6] rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-purple-900/10 flex flex-col justify-between"
            >
              <div>
                <div className="relative aspect-video w-full overflow-hidden bg-[#121222]">
                  <img
                    src={item.images[0] || SAMPLE_IMAGE_PRESETS[0].url}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded-lg bg-[#0B0B14]/80 backdrop-blur-md border border-[#302D46] text-[10px] font-semibold text-[#C4B5FD]">
                    {item.category}
                  </div>
                  {item.stock <= 0 && (
                    <div className="absolute inset-0 bg-black/70 backdrop-blur-[2px] flex items-center justify-center text-red-400 font-bold text-xs uppercase tracking-wider">
                      Sold Out
                    </div>
                  )}
                </div>

                <div className="p-4">
                  <div className="flex items-center justify-between text-[11px] text-[#A5A3B8] mb-1">
                    <span>Seller: @{item.sellerUsername}</span>
                    <span className={item.stock > 0 ? 'text-emerald-400 font-medium' : 'text-red-400'}>
                      {item.stock > 0 ? `${item.stock} in stock` : 'Out of stock'}
                    </span>
                  </div>

                  <h3 className="font-bold text-white text-base truncate group-hover:text-[#C4B5FD] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-[#A5A3B8] line-clamp-2 mt-1 leading-relaxed">
                    {item.description || 'Premium in-game equipment verified in LOT ledger.'}
                  </p>
                </div>
              </div>

              <div className="p-4 pt-0">
                <div className="flex items-center justify-between pt-3 border-t border-[#302D46]">
                  <div>
                    <span className="text-[10px] text-[#A5A3B8] block leading-none">Price</span>
                    <span
                      className="text-lg font-black text-white flex items-center gap-1"
                      title={`${item.priceLot.toLocaleString()} LOT`}
                    >
                      {formatCompactNumber(item.priceLot)} <span className="text-xs text-[#8B5CF6]">LOT</span>
                    </span>
                  </div>

                  <button
                    disabled={item.stock <= 0}
                    onClick={() => {
                      setSelectedListing(item);
                      setPurchaseQuantity(1);
                      setPurchaseError(null);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:bg-[#202039] disabled:text-[#A5A3B8] text-white text-xs font-semibold shadow-md shadow-purple-500/20 transition-all cursor-pointer"
                  >
                    {item.stock <= 0 ? 'Sold Out' : 'Buy Now'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Product Details & Purchase Modal */}
      {selectedListing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-lg bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl overflow-hidden p-6 text-[#F5F3FF]">
            <button
              onClick={() => setSelectedListing(null)}
              className="absolute top-4 right-4 p-2 text-[#A5A3B8] hover:text-white rounded-lg hover:bg-[#202039] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="aspect-video w-full rounded-2xl overflow-hidden bg-[#121222] mb-4">
              <img
                src={selectedListing.images[0] || SAMPLE_IMAGE_PRESETS[0].url}
                alt={selectedListing.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-lg bg-[#202039] border border-[#302D46] text-xs font-semibold text-[#C4B5FD]">
                {selectedListing.category}
              </span>
              <span className="text-xs text-[#A5A3B8]">Sold by @{selectedListing.sellerUsername}</span>
            </div>

            <h2 className="text-2xl font-bold text-white mb-2">{selectedListing.title}</h2>
            <p className="text-xs text-[#A5A3B8] leading-relaxed mb-4">
              {selectedListing.description || 'Verified authentic item registered in the LOT Ecosystem ledger.'}
            </p>

            {/* Price & Quantity Selector */}
            <div className="bg-[#121222] p-4 rounded-2xl border border-[#302D46] space-y-3 mb-4">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#A5A3B8]">Unit Price:</span>
                <span className="font-bold text-white" title={`${selectedListing.priceLot.toLocaleString()} LOT`}>
                  {formatCompactNumber(selectedListing.priceLot)} LOT
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#A5A3B8]">Stock Available:</span>
                <span className="font-bold text-emerald-400">{selectedListing.stock} units</span>
              </div>
              <div className="flex items-center justify-between text-xs pt-2 border-t border-[#302D46]">
                <span className="text-[#A5A3B8]">Select Quantity:</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPurchaseQuantity(Math.max(1, purchaseQuantity - 1))}
                    className="w-7 h-7 rounded-lg bg-[#202039] hover:bg-[#302D46] text-white flex items-center justify-center font-bold"
                  >
                    -
                  </button>
                  <span className="font-bold text-white px-2">{purchaseQuantity}</span>
                  <button
                    onClick={() => setPurchaseQuantity(Math.min(selectedListing.stock, purchaseQuantity + 1))}
                    className="w-7 h-7 rounded-lg bg-[#202039] hover:bg-[#302D46] text-white flex items-center justify-center font-bold"
                  >
                    +
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm pt-2 border-t border-[#302D46] font-bold">
                <span className="text-white">Total Amount:</span>
                <span
                  className="text-[#C4B5FD] text-lg font-black"
                  title={`${(selectedListing.priceLot * purchaseQuantity).toLocaleString()} LOT`}
                >
                  {formatCompactNumber(selectedListing.priceLot * purchaseQuantity)} LOT
                </span>
              </div>
            </div>

            {user && (
              <div className="flex items-center justify-between text-xs text-[#A5A3B8] mb-4 px-1">
                <span>Your Available Balance:</span>
                <span className="font-bold text-white" title={`${user.lotBalance.toLocaleString()} LOT`}>
                  {formatCompactNumber(user.lotBalance)} LOT
                </span>
              </div>
            )}

            {purchaseError && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/30 text-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{purchaseError}</span>
              </div>
            )}

            <button
              onClick={handleBuyItem}
              disabled={isPurchasing || !!(user && user.lotBalance < selectedListing.priceLot * purchaseQuantity)}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:from-[#7C3AED] hover:to-[#9333EA] text-white font-semibold text-sm shadow-lg shadow-purple-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
            >
              {isPurchasing ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : user && user.lotBalance < selectedListing.priceLot * purchaseQuantity ? (
                'Insufficient LOT Balance'
              ) : (
                `Confirm Purchase for ${formatCompactNumber(selectedListing.priceLot * purchaseQuantity)} LOT`
              )}
            </button>
          </div>
        </div>
      )}

      {/* Create Listing Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-lg bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl overflow-hidden p-6 text-[#F5F3FF]">
            <button
              onClick={() => setIsCreateModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-[#A5A3B8] hover:text-white rounded-lg hover:bg-[#202039] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-1">Create Marketplace Listing</h2>
            <p className="text-xs text-[#A5A3B8] mb-4">Sell gaming weapons, collectibles, or gear in exchange for authoritative LOT.</p>

            {createError && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/30 text-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{createError}</span>
              </div>
            )}

            <form onSubmit={handleCreateListing} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-[#A5A3B8] mb-1">Item Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Mythic Void Blade +9"
                  className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#A5A3B8] mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as ProductCategory)}
                    className="w-full px-3 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                  >
                    <option value="Weapons">Weapons</option>
                    <option value="Collectibles">Collectibles</option>
                    <option value="Clothing">Clothing</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#A5A3B8] mb-1">Price (LOT)</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#A5A3B8] mb-1">Stock Quantity</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={newStock}
                  onChange={(e) => setNewStock(e.target.value)}
                  className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#A5A3B8] mb-1">Description</label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Describe rarity, in-game stats, or lore..."
                  className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#A5A3B8] mb-1">Image URL / Select Preset</label>
                <input
                  type="url"
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                  className="w-full px-3.5 py-2 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6] mb-2"
                />
                <div className="flex gap-2">
                  {SAMPLE_IMAGE_PRESETS.map((p) => (
                    <button
                      type="button"
                      key={p.name}
                      onClick={() => setNewImageUrl(p.url)}
                      className={`px-2 py-1 text-[10px] rounded-lg border transition-all ${
                        newImageUrl === p.url ? 'bg-[#8B5CF6] text-white border-[#8B5CF6]' : 'bg-[#202039] text-[#A5A3B8] border-[#302D46]'
                      }`}
                    >
                      {p.name}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={createLoading}
                className="w-full py-3 mt-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white font-semibold text-xs shadow-lg shadow-purple-500/25 transition-all cursor-pointer"
              >
                {createLoading ? 'Publishing...' : 'Publish Listing'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Orders & Tracking Modal */}
      {isOrdersModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-2xl bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl overflow-hidden p-6 text-[#F5F3FF]">
            <button
              onClick={() => setIsOrdersModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-[#A5A3B8] hover:text-white rounded-lg hover:bg-[#202039] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-bold text-white mb-2">Marketplace Orders & Tracking</h2>

            <div className="flex bg-[#121222] p-1 rounded-xl mb-4 border border-[#302D46]">
              <button
                onClick={() => setOrdersTab('purchases')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  ordersTab === 'purchases' ? 'bg-[#8B5CF6] text-white' : 'text-[#A5A3B8] hover:text-white'
                }`}
              >
                My Purchases ({purchases.length})
              </button>
              <button
                onClick={() => setOrdersTab('sales')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  ordersTab === 'sales' ? 'bg-[#8B5CF6] text-white' : 'text-[#A5A3B8] hover:text-white'
                }`}
              >
                My Sales ({sales.length})
              </button>
            </div>

            <div className="max-h-96 overflow-y-auto space-y-3">
              {ordersLoading ? (
                <div className="text-center py-8 text-xs text-[#A5A3B8]">Loading orders...</div>
              ) : (ordersTab === 'purchases' ? purchases : sales).length === 0 ? (
                <div className="text-center py-8 text-xs text-[#A5A3B8]">
                  No {ordersTab} recorded yet.
                </div>
              ) : (
                (ordersTab === 'purchases' ? purchases : sales).map((ord) => (
                  <div key={ord.id} className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-sm">{ord.listingTitle}</span>
                      <span
                        className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                          ord.status === 'Delivered'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : ord.status === 'Processing'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-purple-950 text-purple-300 border border-purple-800'
                        }`}
                      >
                        {ord.status}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center justify-between text-[#A5A3B8]">
                      <span>
                        {ordersTab === 'purchases' ? `Seller: @${ord.sellerUsername}` : `Buyer: @${ord.buyerUsername}`}
                      </span>
                      <span>
                        Total:{' '}
                        <strong className="text-white" title={`${ord.totalLot.toLocaleString()} LOT`}>
                          {formatCompactNumber(ord.totalLot)} LOT
                        </strong>{' '}
                        ({ord.quantity}x @ {formatCompactNumber(ord.priceLot)} LOT)
                      </span>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-[#302D46]/80 text-[11px]">
                      <span className="text-[#A5A3B8]">Ordered: {new Date(ord.createdAt).toLocaleString()}</span>

                      {/* Status changer for seller */}
                      {ordersTab === 'sales' && ord.status !== 'Delivered' && (
                        <div className="flex items-center gap-1.5">
                          {ord.status === 'Placed' && (
                            <button
                              onClick={() => handleUpdateOrderStatus(ord.id, 'Processing')}
                              className="px-2 py-1 rounded bg-amber-600/30 text-amber-300 border border-amber-500/40 hover:bg-amber-600/50 text-[10px]"
                            >
                              Mark Processing
                            </button>
                          )}
                          <button
                            onClick={() => handleUpdateOrderStatus(ord.id, 'Delivered')}
                            className="px-2 py-1 rounded bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/50 text-[10px]"
                          >
                            Mark Delivered
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Discord Webhook Modal */}
      {isWebhookModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-[#19192B] border border-[#302D46] rounded-3xl shadow-2xl overflow-hidden p-6 text-[#F5F3FF]">
            <button
              onClick={() => setIsWebhookModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-[#A5A3B8] hover:text-white rounded-lg hover:bg-[#202039] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-2">
              <BellRing className="w-5 h-5 text-[#8B5CF6]" />
              <h2 className="text-lg font-bold text-white">Seller Discord Webhook</h2>
            </div>
            <p className="text-xs text-[#A5A3B8] mb-4">
              Receive automated instant Discord notifications whenever a user purchases one of your listings.
            </p>

            {webhookSaved && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>Discord webhook saved securely on backend!</span>
              </div>
            )}

            <form onSubmit={handleSaveWebhook} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#A5A3B8] mb-1">Webhook URL</label>
                <input
                  type="url"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  placeholder="https://discord.com/api/webhooks/..."
                  className="w-full px-3.5 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                />
                <span className="text-[10px] text-[#A5A3B8] mt-1 block">
                  Stored securely on the server and never revealed to buyers.
                </span>
              </div>

              <button
                type="submit"
                disabled={webhookLoading}
                className="w-full py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                {webhookLoading ? 'Saving...' : 'Save Webhook'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
