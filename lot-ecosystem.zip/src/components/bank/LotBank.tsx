import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext';
import { BankAccount, BankLoan, BankTransaction } from '../../types';
import { formatCompactNumber, formatLOT } from '../../lib/formatNumber';
import { sounds } from '../../lib/sounds';
import confetti from 'canvas-confetti';
import {
  Landmark,
  PiggyBank,
  CreditCard,
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  ShieldCheck,
  Percent,
  RefreshCw,
  Coins,
  History,
  Info,
  Calendar,
  Sparkles,
  Zap,
} from 'lucide-react';

export const LotBank: React.FC = () => {
  const { user, refreshUser, openAuthModal } = useAuth();

  const [activeTab, setActiveTab] = useState<'vault' | 'loans' | 'history'>('vault');
  const [account, setAccount] = useState<BankAccount | null>(null);
  const [activeLoan, setActiveLoan] = useState<BankLoan | null>(null);
  const [pastLoans, setPastLoans] = useState<BankLoan[]>([]);
  const [transactions, setTransactions] = useState<BankTransaction[]>([]);
  const [bankAuthority, setBankAuthority] = useState<{
    id: string;
    username: string;
    displayName: string;
    reserveBalance: number;
    vaultReserves: number;
    creditRating: string;
    status: string;
    verified: boolean;
  } | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Vault form state
  const [vaultAction, setVaultAction] = useState<'deposit' | 'withdraw'>('deposit');
  const [vaultAmount, setVaultAmount] = useState<string>('');

  // Loan application form state
  const [loanAmount, setLoanAmount] = useState<number>(1000);
  const [repayAmount, setRepayAmount] = useState<string>('');
  const [isCustomRepay, setIsCustomRepay] = useState<boolean>(false);

  // History filter
  const [historyFilter, setHistoryFilter] = useState<string>('all');

  // Live countdown state for active loan
  const [timeLeftStr, setTimeLeftStr] = useState<string>('');
  const [isUrgent, setIsUrgent] = useState<boolean>(false);
  const [timeProgressPercent, setTimeProgressPercent] = useState<number>(0);

  const getStoredToken = () => {
    try {
      return localStorage.getItem('lot_session_token') || user?.token || '';
    } catch {
      return user?.token || '';
    }
  };

  const fetchBankData = useCallback(async (quiet = false) => {
    if (!quiet) setLoading(true);
    try {
      const token = getStoredToken();
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/bank/account', {
        headers,
        credentials: 'include',
      });

      if (res.ok) {
        const data = await res.json();
        setAccount(data.account);
        setActiveLoan(data.activeLoan);
        setPastLoans(data.pastLoans || []);
        setTransactions(data.recentTransactions || []);
        setBankAuthority(data.bankAuthority || null);
        // Also refresh user balance in auth context
        await refreshUser();
      }
    } catch (err) {
      console.error('Failed to load bank data:', err);
    } finally {
      if (!quiet) setLoading(false);
    }
  }, [user?.token, refreshUser]);

  useEffect(() => {
    if (user) {
      fetchBankData();
    } else {
      setLoading(false);
    }
  }, [user?.id, fetchBankData]);

  // Live loan countdown tick
  useEffect(() => {
    if (!activeLoan || activeLoan.status !== 'active') {
      setTimeLeftStr('');
      return;
    }

    const updateTimer = () => {
      const now = Date.now();
      const due = new Date(activeLoan.dueDate).getTime();
      const created = new Date(activeLoan.createdAt).getTime();
      const diff = due - now;

      if (diff <= 0) {
        setTimeLeftStr('OVERDUE - Automatic Deduction Incurred');
        setIsUrgent(true);
        setTimeProgressPercent(100);
        // Trigger auto check
        fetchBankData(true);
        return;
      }

      const totalDuration = due - created;
      const elapsed = now - created;
      const progress = Math.min(100, Math.max(0, (elapsed / totalDuration) * 100));
      setTimeProgressPercent(progress);

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const seconds = Math.floor((diff / 1000) % 60);

      setIsUrgent(diff < 24 * 60 * 60 * 1000); // Less than 24 hours
      setTimeLeftStr(`${days}d ${hours}h ${minutes}m ${seconds}s`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [activeLoan, fetchBankData]);

  const showSuccessFeedback = (text: string) => {
    setFeedback({ type: 'success', text });
    setTimeout(() => setFeedback(null), 6000);
  };

  const showErrorFeedback = (text: string) => {
    setFeedback({ type: 'error', text });
    setTimeout(() => setFeedback(null), 6000);
  };

  // Vault Deposit / Withdraw Action
  const handleVaultSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal();
      return;
    }

    const amount = Number(vaultAmount);
    if (isNaN(amount) || amount <= 0) {
      showErrorFeedback('Please enter a valid amount.');
      return;
    }

    setSubmitting(true);
    setFeedback(null);

    try {
      const token = getStoredToken();
      const endpoint = vaultAction === 'deposit' ? '/api/bank/deposit' : '/api/bank/withdraw';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        credentials: 'include',
        body: JSON.stringify({ amount }),
      });

      const data = await res.json();
      if (!res.ok) {
        sounds.playError();
        showErrorFeedback(data.error || 'Transaction failed');
      } else {
        sounds.playPayment();
        showSuccessFeedback(data.message);
        setVaultAmount('');
        if (vaultAction === 'deposit') {
          confetti({
            particleCount: 40,
            spread: 50,
            origin: { y: 0.6 },
          });
        }
        await fetchBankData(true);
      }
    } catch {
      sounds.playError();
      showErrorFeedback('Failed to process transaction. Check network.');
    } finally {
      setSubmitting(false);
    }
  };

  // Claim Accrued Vault Interest
  const handleClaimInterest = async () => {
    if (!user) return;
    setSubmitting(true);
    try {
      const token = getStoredToken();
      const res = await fetch('/api/bank/interest/claim', {
        method: 'POST',
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        credentials: 'include',
      });
      if (res.ok) {
        sounds.playTransaction();
        showSuccessFeedback('Vault interest updated & compounded successfully!');
        await fetchBankData(true);
      }
    } catch {
      showErrorFeedback('Failed to update interest');
    } finally {
      setSubmitting(false);
    }
  };

  // Apply for Loan
  const handleApplyLoan = async () => {
    if (!user) {
      openAuthModal();
      return;
    }

    if (loanAmount < 500 || loanAmount > 10000) {
      showErrorFeedback('Loan amount must be between 500 and 10,000 LOT.');
      return;
    }

    setSubmitting(true);
    setFeedback(null);

    try {
      const token = getStoredToken();
      const res = await fetch('/api/bank/loan/apply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        credentials: 'include',
        body: JSON.stringify({ amount: loanAmount }),
      });

      const data = await res.json();
      if (!res.ok) {
        sounds.playError();
        showErrorFeedback(data.error || 'Failed to apply for loan');
      } else {
        sounds.playPurchase();
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.5 },
        });
        showSuccessFeedback(data.message);
        await fetchBankData(true);
      }
    } catch {
      sounds.playError();
      showErrorFeedback('Failed to disburse loan. Try again.');
    } finally {
      setSubmitting(false);
    }
  };

  // Repay Active Loan
  const handleRepayLoan = async (fullRepayment: boolean = true) => {
    if (!user || !activeLoan) return;

    const amountToRepay = fullRepayment ? activeLoan.remainingDue : Number(repayAmount);
    if (!fullRepayment && (isNaN(amountToRepay) || amountToRepay <= 0)) {
      showErrorFeedback('Please enter a valid repayment amount.');
      return;
    }

    setSubmitting(true);
    setFeedback(null);

    try {
      const token = getStoredToken();
      const res = await fetch('/api/bank/loan/repay', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        credentials: 'include',
        body: JSON.stringify({
          loanId: activeLoan.id,
          amount: amountToRepay,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        sounds.playError();
        showErrorFeedback(data.error || 'Repayment failed');
      } else {
        sounds.playPurchase();
        if (data.isFullyPaid) {
          confetti({
            particleCount: 80,
            spread: 90,
            origin: { y: 0.4 },
          });
        }
        showSuccessFeedback(data.message);
        setRepayAmount('');
        setIsCustomRepay(false);
        await fetchBankData(true);
      }
    } catch {
      sounds.playError();
      showErrorFeedback('Failed to process loan repayment');
    } finally {
      setSubmitting(false);
    }
  };

  const getCreditScoreTier = (score: number) => {
    if (score >= 780) return { label: 'Excellent', color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/30' };
    if (score >= 680) return { label: 'Good', color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/30' };
    if (score >= 580) return { label: 'Fair', color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/30' };
    return { label: 'High Risk', color: 'text-rose-400', bg: 'bg-rose-500/10 border-rose-500/30' };
  };

  const filteredTransactions = transactions.filter((tx) => {
    if (historyFilter === 'all') return true;
    if (historyFilter === 'vault') return tx.type === 'deposit' || tx.type === 'withdraw' || tx.type === 'interest_payout';
    if (historyFilter === 'loans') return tx.type === 'loan_disbursed' || tx.type === 'loan_repayment' || tx.type === 'loan_auto_deducted';
    return true;
  });

  return (
    <div className="space-y-6 pb-16 animate-fadeIn">
      {/* Top Banner & Overview */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1E1B4B] via-[#12122A] to-[#0A0A16] border border-[#3A3366] p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-80 h-80 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-semibold">
                <Landmark className="w-3.5 h-3.5 text-purple-400" />
                <span>LOT Reserve Central Bank</span>
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 text-xs font-bold shadow-sm">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Official Reserve: @Bank_Of_Lotus</span>
                <span className="text-[10px] bg-emerald-500/20 px-1.5 py-0.2 rounded text-emerald-200">VERIFIED</span>
              </div>
            </div>
            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight flex items-center gap-3">
              LOT Bank & Loan Vault
            </h1>
            <p className="text-sm sm:text-base text-purple-200/80 mt-2 max-w-2xl">
              Backed by <span className="text-emerald-300 font-bold">@{bankAuthority?.username || 'Bank_Of_Lotus'}</span> with over <span className="text-purple-300 font-semibold">{bankAuthority ? formatCompactNumber(bankAuthority.reserveBalance) : '45T'} LOT in Sovereign Reserves</span>. Store your wealth safely with <span className="text-purple-300 font-semibold">4.5% APY yield</span>, or borrow up to <span className="text-purple-300 font-semibold">10,000 LOT</span> with 7-day terms.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => fetchBankData(false)}
              disabled={loading}
              className="p-2.5 rounded-2xl bg-[#201C38] border border-[#3A3366] text-purple-300 hover:text-white hover:border-purple-500 transition-all cursor-pointer"
              title="Refresh Bank Balances"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Global Financial Metrics Bar */}
        {user && (
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Wallet Balance Card */}
            <div className={`p-4 rounded-2xl border backdrop-blur-md transition-all ${
              user.lotBalance < 0
                ? 'bg-red-950/40 border-red-500/50 shadow-lg shadow-red-900/20'
                : 'bg-[#151426]/80 border-[#302D46]'
            }`}>
              <div className="flex items-center justify-between text-xs text-[#A5A3B8] mb-1">
                <span>Wallet Balance</span>
                <Coins className="w-4 h-4 text-purple-400" />
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className={`text-xl sm:text-2xl font-black tracking-tight ${
                  user.lotBalance < 0 ? 'text-red-400' : 'text-white'
                }`}>
                  {user.lotBalance < 0 ? '-' : ''}{Math.abs(user.lotBalance).toLocaleString()}
                </span>
                <span className="text-xs font-bold text-purple-400">LOT</span>
              </div>
              {user.lotBalance < 0 ? (
                <div className="mt-1 flex items-center gap-1 text-[11px] font-bold text-red-300 animate-pulse">
                  <AlertTriangle className="w-3 h-3 text-red-400 shrink-0" />
                  <span>Account Overdrawn (Debt)</span>
                </div>
              ) : (
                <div className="mt-1 text-[11px] text-[#A5A3B8]">
                  Available for immediate spend or deposit
                </div>
              )}
            </div>

            {/* Savings Vault Balance Card */}
            <div className="p-4 rounded-2xl bg-[#151426]/80 border border-[#302D46] backdrop-blur-md">
              <div className="flex items-center justify-between text-xs text-[#A5A3B8] mb-1">
                <span>Bank Vault Savings</span>
                <PiggyBank className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  {(account?.savingsBalance || 0).toLocaleString()}
                </span>
                <span className="text-xs font-bold text-emerald-400">LOT</span>
              </div>
              <div className="mt-1 flex items-center justify-between text-[11px] text-emerald-300/80">
                <span>Yield: 4.5% APY</span>
                {account && account.savingsBalance > 0 && (
                  <button
                    onClick={handleClaimInterest}
                    disabled={submitting}
                    className="underline hover:text-emerald-200 cursor-pointer text-[10px]"
                  >
                    Accrue Yield
                  </button>
                )}
              </div>
            </div>

            {/* Active Loan Status Card */}
            <div className={`p-4 rounded-2xl border backdrop-blur-md ${
              activeLoan
                ? isUrgent
                  ? 'bg-amber-950/40 border-amber-500/50'
                  : 'bg-purple-950/40 border-purple-500/40'
                : 'bg-[#151426]/80 border-[#302D46]'
            }`}>
              <div className="flex items-center justify-between text-xs text-[#A5A3B8] mb-1">
                <span>Active 7-Day Loan</span>
                <CreditCard className="w-4 h-4 text-purple-400" />
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className={`text-xl sm:text-2xl font-black tracking-tight ${
                  activeLoan ? (isUrgent ? 'text-amber-300' : 'text-purple-200') : 'text-white'
                }`}>
                  {activeLoan ? activeLoan.remainingDue.toLocaleString() : '0'}
                </span>
                <span className="text-xs font-bold text-purple-400">LOT Due</span>
              </div>
              <div className="mt-1 text-[11px] truncate">
                {activeLoan ? (
                  <span className={`font-semibold ${isUrgent ? 'text-amber-400' : 'text-purple-300'}`}>
                    ⏳ {timeLeftStr || 'Due in 7 days'}
                  </span>
                ) : (
                  <span className="text-emerald-400/90 font-medium">No outstanding loans</span>
                )}
              </div>
            </div>

            {/* Credit Score Card */}
            {account && (
              <div className="p-4 rounded-2xl bg-[#151426]/80 border border-[#302D46] backdrop-blur-md">
                <div className="flex items-center justify-between text-xs text-[#A5A3B8] mb-1">
                  <span>Borrower Credit Rating</span>
                  <ShieldCheck className="w-4 h-4 text-blue-400" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    {account.creditScore || 720}
                  </span>
                  <span className="text-xs text-[#A5A3B8]">/ 850</span>
                  <span className={`ml-auto text-[11px] font-bold px-2 py-0.5 rounded-full ${getCreditScoreTier(account.creditScore || 720).bg} ${getCreditScoreTier(account.creditScore || 720).color}`}>
                    {getCreditScoreTier(account.creditScore || 720).label}
                  </span>
                </div>
                <div className="mt-1 text-[11px] text-[#A5A3B8]">
                  {account.creditScore >= 700 ? '+15 on on-time loan payment' : 'Pay on time to restore rating'}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Negative Balance Alert Notice if user is overdrawn */}
      {user && user.lotBalance < 0 && (
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-red-950/80 via-red-900/60 to-purple-950/60 border border-red-500/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/40 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Account Balance Negative (Overdrawn: -{Math.abs(user.lotBalance).toLocaleString()} LOT)</span>
              </h4>
              <p className="text-xs text-red-200/80 mt-0.5">
                Your loan reached its 7-day term and was automatically deducted from your account. You can clear this negative balance by withdrawing from your Vault Savings, receiving VPay, or redeeming promotional codes.
              </p>
            </div>
          </div>
          {account && account.savingsBalance > 0 && (
            <button
              onClick={() => {
                setActiveTab('vault');
                setVaultAction('withdraw');
                setVaultAmount(String(Math.min(account.savingsBalance, Math.abs(user.lotBalance))));
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-white text-red-950 hover:bg-red-100 transition-all shadow shrink-0 cursor-pointer"
            >
              Transfer From Vault
            </button>
          )}
        </div>
      )}

      {/* Feedback Alert */}
      {feedback && (
        <div
          className={`p-4 rounded-2xl border flex items-center gap-3 animate-slideDown ${
            feedback.type === 'success'
              ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
              : 'bg-red-950/80 border-red-500/50 text-red-200'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
          )}
          <span className="text-sm font-medium">{feedback.text}</span>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center border-b border-[#302D46] gap-2 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('vault')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'vault'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-lg shadow-purple-500/20'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <PiggyBank className="w-4 h-4" />
          <span>Savings Vault (Deposit & Withdraw)</span>
        </button>

        <button
          onClick={() => setActiveTab('loans')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-sm font-semibold transition-all cursor-pointer whitespace-nowrap relative ${
            activeTab === 'loans'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-lg shadow-purple-500/20'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>7-Day Loan Center</span>
          {activeLoan && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'history'
              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white shadow-lg shadow-purple-500/20'
              : 'text-[#A5A3B8] hover:text-white hover:bg-[#19192B]'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Bank Ledger & History</span>
        </button>
      </div>

      {/* TAB 1: SAVINGS VAULT (DEPOSIT & WITHDRAW) */}
      {activeTab === 'vault' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Vault Action Panel */}
          <div className="lg:col-span-2 bg-[#121222] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="flex items-center justify-between pb-6 border-b border-[#252438]">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <PiggyBank className="w-5 h-5 text-purple-400" />
                  <span>LOT Bank Vault Terminal</span>
                </h3>
                <p className="text-xs text-[#A5A3B8] mt-1">
                  Store funds securely away from daily spending while earning high-yield interest.
                </p>
              </div>

              {/* Action Toggle */}
              <div className="flex p-1 rounded-2xl bg-[#1A1A2E] border border-[#302D46]">
                <button
                  type="button"
                  onClick={() => {
                    setVaultAction('deposit');
                    setVaultAmount('');
                  }}
                  className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    vaultAction === 'deposit'
                      ? 'bg-[#8B5CF6] text-white shadow'
                      : 'text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  Deposit
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setVaultAction('withdraw');
                    setVaultAmount('');
                  }}
                  className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    vaultAction === 'withdraw'
                      ? 'bg-[#8B5CF6] text-white shadow'
                      : 'text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  Withdraw
                </button>
              </div>
            </div>

            <form onSubmit={handleVaultSubmit} className="mt-6 space-y-6">
              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <label className="font-semibold text-purple-200">
                    {vaultAction === 'deposit' ? 'Amount to Deposit into Vault' : 'Amount to Withdraw to Wallet'}
                  </label>
                  <span className="text-[#A5A3B8]">
                    {vaultAction === 'deposit'
                      ? `Wallet Balance: ${(user?.lotBalance || 0).toLocaleString()} LOT`
                      : `Vault Stored: ${(account?.savingsBalance || 0).toLocaleString()} LOT`}
                  </span>
                </div>

                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={vaultAmount}
                    onChange={(e) => setVaultAmount(e.target.value)}
                    placeholder="0"
                    className="w-full bg-[#18172E] border border-[#3A3366] rounded-2xl px-4 py-4 text-2xl font-black text-white focus:outline-none focus:border-[#8B5CF6] transition-all pr-20"
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-bold text-purple-400">
                    LOT
                  </div>
                </div>

                {/* Quick Presets */}
                <div className="flex items-center gap-2 mt-3">
                  <span className="text-[11px] text-[#A5A3B8] mr-1">Presets:</span>
                  {[25, 50, 75, 100].map((pct) => {
                    const maxVal = vaultAction === 'deposit' ? Math.max(0, user?.lotBalance || 0) : account?.savingsBalance || 0;
                    const calculated = Math.floor((maxVal * pct) / 100);
                    return (
                      <button
                        key={pct}
                        type="button"
                        onClick={() => setVaultAmount(String(calculated))}
                        disabled={maxVal <= 0}
                        className="px-2.5 py-1 rounded-xl text-xs font-bold bg-[#1C1B33] border border-[#302D46] text-purple-300 hover:text-white hover:border-purple-500 transition-all cursor-pointer disabled:opacity-40"
                      >
                        {pct === 100 ? 'Max' : `${pct}%`}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Transaction Preview Card */}
              <div className="p-4 rounded-2xl bg-[#16152B] border border-[#2B2945] space-y-2 text-xs">
                <div className="flex justify-between text-[#A5A3B8]">
                  <span>Operation:</span>
                  <span className="font-semibold text-white uppercase">{vaultAction}</span>
                </div>
                <div className="flex justify-between text-[#A5A3B8]">
                  <span>Processing Fee:</span>
                  <span className="font-semibold text-emerald-400">0 LOT (100% Free)</span>
                </div>
                <div className="flex justify-between text-[#A5A3B8]">
                  <span>Annual Yield (APY):</span>
                  <span className="font-semibold text-purple-300">4.50% Compounding</span>
                </div>
                <div className="border-t border-[#252438] pt-2 flex justify-between text-sm font-bold text-white">
                  <span>New Vault Balance:</span>
                  <span className="text-purple-300">
                    {vaultAction === 'deposit'
                      ? ((account?.savingsBalance || 0) + (Number(vaultAmount) || 0)).toLocaleString()
                      : Math.max(0, (account?.savingsBalance || 0) - (Number(vaultAmount) || 0)).toLocaleString()}{' '}
                    LOT
                  </span>
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting || !vaultAmount || Number(vaultAmount) <= 0}
                className="w-full py-4 rounded-2xl text-sm font-black text-white bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#C4B5FD] hover:from-[#7C3AED] hover:to-[#9333EA] shadow-xl shadow-purple-500/25 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {vaultAction === 'deposit' ? (
                  <>
                    <ArrowDownLeft className="w-5 h-5" />
                    <span>Confirm Deposit to Vault</span>
                  </>
                ) : (
                  <>
                    <ArrowUpRight className="w-5 h-5" />
                    <span>Confirm Withdrawal to Wallet</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Vault Info & Yield Calculator Side Card */}
          <div className="space-y-6">
            <div className="bg-[#121222] border border-[#302D46] rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex items-center gap-2 text-purple-300 font-bold text-sm">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>Vault High-Yield Savings</span>
              </div>
              <p className="text-xs text-[#A5A3B8] leading-relaxed">
                By storing your LOT in the Vault, your funds are safely insulated against accidental transfers and market fluctuations, while passively generating compound interest every second.
              </p>

              <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-950/40 to-indigo-950/30 border border-purple-500/20 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-[#A5A3B8]">Total Lifetime Yield</span>
                  <span className="text-sm font-bold text-emerald-400">
                    +{(account?.interestEarned || 0).toLocaleString()} LOT
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-[#A5A3B8]">Current Vault APY</span>
                  <span className="text-sm font-bold text-purple-300">4.50%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-[#A5A3B8]">Est. Monthly on Stored</span>
                  <span className="text-sm font-bold text-white">
                    +{Math.floor(((account?.savingsBalance || 0) * 0.045) / 12).toLocaleString()} LOT
                  </span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#16152B] border border-[#2B2945] flex items-center gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <span className="text-xs text-purple-200">
                  Vault funds can be withdrawn at any time with zero lockups or withdrawal penalties.
                </span>
              </div>
            </div>

            {/* Quick Stat Pill */}
            <div className="bg-[#121222] border border-[#302D46] rounded-3xl p-6 shadow-xl">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Lifetime Vault Statistics</h4>
              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between text-[#A5A3B8]">
                  <span>Total Deposited:</span>
                  <span className="font-semibold text-white">{(account?.totalDeposited || 0).toLocaleString()} LOT</span>
                </div>
                <div className="flex justify-between text-[#A5A3B8]">
                  <span>Total Withdrawn:</span>
                  <span className="font-semibold text-white">{(account?.totalWithdrawn || 0).toLocaleString()} LOT</span>
                </div>
                <div className="flex justify-between text-[#A5A3B8]">
                  <span>Account Created:</span>
                  <span className="font-semibold text-purple-300">
                    {account ? new Date(account.createdAt).toLocaleDateString() : 'N/A'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: 7-DAY LOAN CENTER */}
      {activeTab === 'loans' && (
        <div className="space-y-6">
          {/* Active Loan Section if user has one */}
          {activeLoan ? (
            <div className="bg-[#121222] border-2 border-purple-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-[#252438]">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs font-bold mb-2">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Active 7-Day Loan in Progress</span>
                  </div>
                  <h3 className="text-2xl font-black text-white">
                    Loan ID: #{activeLoan.id.slice(-8).toUpperCase()}
                  </h3>
                  <p className="text-xs text-[#A5A3B8] mt-1">
                    Disbursed on {new Date(activeLoan.createdAt).toLocaleDateString()} at{' '}
                    {new Date(activeLoan.createdAt).toLocaleTimeString()}
                  </p>
                </div>

                {/* Countdown pill */}
                <div className={`px-4 py-3 rounded-2xl border text-center ${
                  isUrgent
                    ? 'bg-red-950/60 border-red-500/60 text-red-200 animate-pulse'
                    : 'bg-purple-950/60 border-purple-500/40 text-purple-200'
                }`}>
                  <span className="text-[10px] uppercase font-bold tracking-wider block text-white/70">
                    Time Remaining
                  </span>
                  <span className="text-lg font-black tracking-tight">{timeLeftStr}</span>
                </div>
              </div>

              {/* 7-Day Term Progress Bar */}
              <div className="mt-6 space-y-2">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-[#A5A3B8]">Loan Duration Progress (7 Days Term)</span>
                  <span className={isUrgent ? 'text-amber-400 font-bold' : 'text-purple-300'}>
                    Due: {new Date(activeLoan.dueDate).toLocaleDateString()} ({Math.round(timeProgressPercent)}% elapsed)
                  </span>
                </div>
                <div className="h-3 w-full bg-[#1C1B33] rounded-full overflow-hidden p-0.5 border border-[#302D46]">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isUrgent
                        ? 'bg-gradient-to-r from-amber-500 to-red-500'
                        : 'bg-gradient-to-r from-purple-500 to-indigo-500'
                    }`}
                    style={{ width: `${Math.min(100, Math.max(5, timeProgressPercent))}%` }}
                  />
                </div>
              </div>

              {/* Loan Details Grid */}
              <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-[#16152B] border border-[#2B2945]">
                  <span className="text-xs text-[#A5A3B8] block">Principal Borrowed</span>
                  <span className="text-lg font-black text-white mt-0.5 block">
                    {activeLoan.principal.toLocaleString()} LOT
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-[#16152B] border border-[#2B2945]">
                  <span className="text-xs text-[#A5A3B8] block">Fixed Fee (5%)</span>
                  <span className="text-lg font-black text-purple-300 mt-0.5 block">
                    +{activeLoan.interestAmount.toLocaleString()} LOT
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-[#16152B] border border-[#2B2945]">
                  <span className="text-xs text-[#A5A3B8] block">Amount Repaid</span>
                  <span className="text-lg font-black text-emerald-400 mt-0.5 block">
                    {activeLoan.amountRepaid.toLocaleString()} LOT
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-950/60 to-indigo-950/60 border border-purple-500/40">
                  <span className="text-xs text-purple-200 block">Total Remaining Due</span>
                  <span className="text-xl font-black text-white mt-0.5 block">
                    {activeLoan.remainingDue.toLocaleString()} LOT
                  </span>
                </div>
              </div>

              {/* Auto-Deduction Warning Notice */}
              <div className="mt-6 p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 flex items-start gap-3 text-xs text-amber-200/90">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-amber-300">Automatic Deduction Terms: </span>
                  If this loan is not settled within 7 days (by {new Date(activeLoan.dueDate).toLocaleString()}), the outstanding balance of {activeLoan.remainingDue.toLocaleString()} LOT will automatically be deducted from your account. If your balance is lower than the amount due, your account balance will go into <span className="underline font-bold text-white">MINUS (negative debt)</span>.
                </div>
              </div>

              {/* Repayment Controls */}
              <div className="mt-8 pt-6 border-t border-[#252438] space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Coins className="w-4 h-4 text-purple-400" />
                    <span>Repay Your Loan</span>
                  </h4>
                  <span className="text-xs text-[#A5A3B8]">
                    Your Wallet Balance:{' '}
                    <strong className="text-white">{(user?.lotBalance || 0).toLocaleString()} LOT</strong>
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-3">
                  {/* Primary Pay Full Button */}
                  <button
                    onClick={() => handleRepayLoan(true)}
                    disabled={submitting || (user?.lotBalance || 0) < activeLoan.remainingDue}
                    className="w-full sm:w-auto px-6 py-3.5 rounded-2xl text-xs sm:text-sm font-black text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Repay Full Balance ({activeLoan.remainingDue.toLocaleString()} LOT)</span>
                  </button>

                  {/* Toggle Custom Partial Repayment */}
                  <button
                    type="button"
                    onClick={() => setIsCustomRepay(!isCustomRepay)}
                    className="w-full sm:w-auto px-4 py-3 rounded-2xl text-xs font-semibold bg-[#1C1B33] border border-[#302D46] text-purple-300 hover:text-white transition-all cursor-pointer"
                  >
                    {isCustomRepay ? 'Cancel Partial Repay' : 'Make Partial Payment'}
                  </button>
                </div>

                {isCustomRepay && (
                  <div className="p-4 rounded-2xl bg-[#16152B] border border-[#2B2945] flex flex-col sm:flex-row items-center gap-3">
                    <input
                      type="number"
                      min="1"
                      max={activeLoan.remainingDue}
                      value={repayAmount}
                      onChange={(e) => setRepayAmount(e.target.value)}
                      placeholder={`Partial amount (Max ${activeLoan.remainingDue})`}
                      className="w-full sm:w-64 bg-[#1C1B33] border border-[#302D46] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-purple-500"
                    />
                    <button
                      onClick={() => handleRepayLoan(false)}
                      disabled={submitting || !repayAmount || Number(repayAmount) <= 0}
                      className="w-full sm:w-auto px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-500 transition-all cursor-pointer disabled:opacity-50"
                    >
                      Confirm Partial Payment
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* Loan Application Panel when user has NO active loan */
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-[#121222] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
                <div className="pb-6 border-b border-[#252438]">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-2">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Eligible for Instant Disbursement</span>
                  </div>
                  <h3 className="text-xl font-black text-white flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-purple-400" />
                    <span>Apply for a 7-Day LOT Loan</span>
                  </h3>
                  <p className="text-xs text-[#A5A3B8] mt-1">
                    Receive funds immediately in your wallet. Fixed 5% fee with exactly 7 days to repay.
                  </p>
                </div>

                <div className="mt-6 space-y-6">
                  {/* Amount Selector */}
                  <div>
                    <div className="flex items-center justify-between text-xs mb-2">
                      <label className="font-semibold text-purple-200">Select Loan Amount</label>
                      <span className="text-purple-300 font-bold text-sm">
                        {loanAmount.toLocaleString()} LOT
                      </span>
                    </div>

                    <input
                      type="range"
                      min="500"
                      max="10000"
                      step="100"
                      value={loanAmount}
                      onChange={(e) => setLoanAmount(Number(e.target.value))}
                      className="w-full h-2.5 bg-[#1C1B33] rounded-lg appearance-none cursor-pointer accent-[#8B5CF6]"
                    />

                    <div className="flex justify-between text-[11px] text-[#A5A3B8] mt-1.5 font-medium">
                      <span>Min: 500 LOT</span>
                      <span>Max: 10,000 LOT</span>
                    </div>

                    {/* Quick Amount Buttons */}
                    <div className="grid grid-cols-4 gap-2 mt-4">
                      {[500, 2500, 5000, 10000].map((amt) => (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => setLoanAmount(amt)}
                          className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                            loanAmount === amt
                              ? 'bg-purple-600/30 border-purple-500 text-white'
                              : 'bg-[#18172E] border-[#302D46] text-[#A5A3B8] hover:text-white'
                          }`}
                        >
                          {amt === 10000 ? '10K (Max)' : `${amt.toLocaleString()} LOT`}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Loan Term Breakdown */}
                  <div className="p-5 rounded-2xl bg-[#16152B] border border-[#2B2945] space-y-3 text-xs">
                    <div className="flex justify-between text-[#A5A3B8]">
                      <span>Principal Amount:</span>
                      <span className="font-bold text-white">{loanAmount.toLocaleString()} LOT</span>
                    </div>
                    <div className="flex justify-between text-[#A5A3B8]">
                      <span>Fixed 7-Day Fee (5%):</span>
                      <span className="font-bold text-purple-300">
                        +{Math.round(loanAmount * 0.05).toLocaleString()} LOT
                      </span>
                    </div>
                    <div className="flex justify-between text-[#A5A3B8]">
                      <span>Repayment Term:</span>
                      <span className="font-bold text-white">Exactly 7 Days (168 Hours)</span>
                    </div>
                    <div className="flex justify-between text-[#A5A3B8]">
                      <span>Repayment Due Date:</span>
                      <span className="font-bold text-purple-300">
                        {new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="border-t border-[#252438] pt-3 flex justify-between text-sm font-black text-white">
                      <span>Total Due to Repay:</span>
                      <span className="text-xl text-emerald-400">
                        {Math.round(loanAmount * 1.05).toLocaleString()} LOT
                      </span>
                    </div>
                  </div>

                  {/* Strict User Requirement Warning */}
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-red-950/40 to-amber-950/40 border border-amber-500/40 text-xs text-amber-200/90 space-y-1">
                    <div className="font-bold flex items-center gap-1.5 text-amber-300">
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>Notice on Overdue Loans & Negative Balance:</span>
                    </div>
                    <p className="leading-relaxed">
                      You must repay this loan within 7 days. If not repaid, the full remaining amount will be{' '}
                      <span className="font-bold text-white">automatically deducted</span> from your account. If your account does not have sufficient balance, your account balance will{' '}
                      <span className="font-bold text-red-300 underline">go into MINUS (negative debt)</span>.
                    </p>
                  </div>

                  <button
                    onClick={handleApplyLoan}
                    disabled={submitting}
                    className="w-full py-4 rounded-2xl text-sm font-black text-white bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#C4B5FD] hover:from-[#7C3AED] hover:to-[#9333EA] shadow-xl shadow-purple-500/25 transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <Zap className="w-5 h-5 text-amber-300" />
                    <span>Accept Terms & Receive {loanAmount.toLocaleString()} LOT Now</span>
                  </button>
                </div>
              </div>

              {/* Loan Policy & Borrower Information */}
              <div className="space-y-6">
                <div className="bg-[#121222] border border-[#302D46] rounded-3xl p-6 shadow-xl space-y-4">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Info className="w-4 h-4 text-purple-400" />
                    <span>Real-Life Loan Rules</span>
                  </h4>
                  <ul className="space-y-3 text-xs text-[#A5A3B8]">
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5 shrink-0" />
                      <span>
                        <strong className="text-white">Minimum:</strong> 500 LOT.
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5 shrink-0" />
                      <span>
                        <strong className="text-white">Maximum:</strong> 10,000 LOT per loan.
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5 shrink-0" />
                      <span>
                        <strong className="text-white">7-Day Term:</strong> Exact countdown from issuance.
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5 shrink-0" />
                      <span>
                        <strong className="text-white">Auto-Deduction:</strong> At day 7, unpaid debt auto-debits wallet into negative.
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5 shrink-0" />
                      <span>
                        <strong className="text-white">Credit Score:</strong> Repaying on time awards +20 credit score boost.
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Past Loans History Table */}
          {pastLoans.length > 0 && (
            <div className="bg-[#121222] border border-[#302D46] rounded-3xl p-6 shadow-xl">
              <h4 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <History className="w-4 h-4 text-purple-400" />
                <span>Your Loan History</span>
              </h4>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-[#252438] text-[#A5A3B8]">
                      <th className="pb-3 font-semibold">Loan ID</th>
                      <th className="pb-3 font-semibold">Principal</th>
                      <th className="pb-3 font-semibold">Total Due</th>
                      <th className="pb-3 font-semibold">Date Issued</th>
                      <th className="pb-3 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1F1E33]">
                    {pastLoans.map((loan) => (
                      <tr key={loan.id} className="hover:bg-[#16152B]">
                        <td className="py-3 font-mono text-purple-300">#{loan.id.slice(-8).toUpperCase()}</td>
                        <td className="py-3 font-bold text-white">{loan.principal.toLocaleString()} LOT</td>
                        <td className="py-3 text-[#A5A3B8]">{loan.totalDue.toLocaleString()} LOT</td>
                        <td className="py-3 text-[#A5A3B8]">{new Date(loan.createdAt).toLocaleDateString()}</td>
                        <td className="py-3">
                          {loan.status === 'repaid' && (
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
                              Repaid Full
                            </span>
                          )}
                          {loan.status === 'overdue_deducted' && (
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-red-500/15 border border-red-500/30 text-red-400">
                              Auto-Deducted (Overdue)
                            </span>
                          )}
                          {loan.status === 'active' && (
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/15 border border-amber-500/30 text-amber-400 animate-pulse">
                              Active (In Progress)
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: BANK LEDGER & HISTORY */}
      {activeTab === 'history' && (
        <div className="bg-[#121222] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-[#252438]">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <History className="w-5 h-5 text-purple-400" />
                <span>Bank Statement & Ledger</span>
              </h3>
              <p className="text-xs text-[#A5A3B8] mt-1">
                Authoritative record of all deposits, withdrawals, loan payouts, repayments, and yields.
              </p>
            </div>

            {/* Filter Buttons */}
            <div className="flex gap-2">
              {[
                { id: 'all', label: 'All Records' },
                { id: 'vault', label: 'Vault Only' },
                { id: 'loans', label: 'Loans Only' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setHistoryFilter(f.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    historyFilter === f.id
                      ? 'bg-purple-600 text-white'
                      : 'bg-[#1A1A2E] border border-[#302D46] text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-6">
            {filteredTransactions.length === 0 ? (
              <div className="text-center py-12 text-[#A5A3B8]">
                <Landmark className="w-12 h-12 text-[#302D46] mx-auto mb-3" />
                <p className="text-sm font-semibold">No bank transactions recorded yet.</p>
                <p className="text-xs text-[#6E6A8A] mt-1">
                  Make your first deposit to the Vault or request a loan to start your ledger.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-[#252438] text-[#A5A3B8]">
                      <th className="pb-3 font-semibold">Timestamp</th>
                      <th className="pb-3 font-semibold">Type</th>
                      <th className="pb-3 font-semibold">Description</th>
                      <th className="pb-3 font-semibold text-right">Amount</th>
                      <th className="pb-3 font-semibold text-right">Wallet Balance After</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1F1E33]">
                    {filteredTransactions.map((tx) => {
                      const isPositive =
                        tx.type === 'withdraw' ||
                        tx.type === 'loan_disbursed' ||
                        tx.type === 'interest_payout';

                      return (
                        <tr key={tx.id} className="hover:bg-[#16152B] transition-colors">
                          <td className="py-3.5 text-[#A5A3B8] whitespace-nowrap">
                            {new Date(tx.createdAt).toLocaleDateString()}{' '}
                            <span className="text-[10px] text-[#6E6A8A]">
                              {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </td>
                          <td className="py-3.5">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                                tx.type === 'deposit'
                                  ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                                  : tx.type === 'withdraw'
                                  ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                                  : tx.type === 'loan_disbursed'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : tx.type === 'loan_repayment'
                                  ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20'
                                  : tx.type === 'loan_auto_deducted'
                                  ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                                  : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              }`}
                            >
                              {tx.type.replace('_', ' ')}
                            </span>
                          </td>
                          <td className="py-3.5 text-purple-100 max-w-xs sm:max-w-md truncate">
                            {tx.description}
                          </td>
                          <td
                            className={`py-3.5 text-right font-black whitespace-nowrap ${
                              isPositive ? 'text-emerald-400' : 'text-purple-300'
                            }`}
                          >
                            {isPositive ? '+' : '-'}{tx.amount.toLocaleString()} LOT
                          </td>
                          <td className="py-3.5 text-right font-bold text-white whitespace-nowrap">
                            <span className={tx.walletBalanceAfter < 0 ? 'text-red-400' : 'text-white'}>
                              {tx.walletBalanceAfter.toLocaleString()} LOT
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
