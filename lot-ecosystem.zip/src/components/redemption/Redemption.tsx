import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { RedemptionClaim } from '../../types';
import { Gift, Sparkles, CheckCircle2, AlertCircle, Clock, ShieldCheck, Coins } from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatCompactNumber } from '../../lib/formatNumber';
import { playRedeemSound, playErrorSound } from '../../lib/sounds';

export const Redemption: React.FC = () => {
  const { user, openAuthModal, refreshUser } = useAuth();
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [claims, setClaims] = useState<RedemptionClaim[]>([]);
  const [claimsLoading, setClaimsLoading] = useState(false);

  const fetchClaims = async () => {
    if (!user) return;
    try {
      setClaimsLoading(true);
      const res = await fetch('/api/redemption/my-claims');
      if (res.ok) {
        const data = await res.json();
        setClaims(data.claims || []);
      }
    } catch {
      // non-critical
    } finally {
      setClaimsLoading(false);
    }
  };

  useEffect(() => {
    fetchClaims();
  }, [user?.id]);

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!user) {
      openAuthModal('login');
      return;
    }

    if (!code.trim()) {
      playErrorSound();
      setError('Please enter a redemption code.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/redemption/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: code.trim() }),
      });

      const data = await res.json();
      if (!res.ok) {
        playErrorSound();
        setError(data.error || 'Failed to redeem code.');
        setLoading(false);
        return;
      }

      playRedeemSound();
      confetti({
        particleCount: 110,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#8B5CF6', '#A855F7', '#C4B5FD', '#10B981'],
      });

      setSuccess(`Congratulations! Code applied: +${formatCompactNumber(data.rewardLot)} LOT added to your balance.`);
      setCode('');
      await refreshUser();
      await fetchClaims();
    } catch {
      playErrorSound();
      setError('Network error during redemption.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-16 max-w-3xl mx-auto">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#121222] via-[#19192B] to-[#202039] border border-[#302D46] p-8 sm:p-10 shadow-2xl text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#8B5CF6] to-[#A855F7] mb-4 shadow-lg shadow-purple-500/20">
          <Gift className="w-7 h-7 text-white" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
          Redeem Promo Codes
        </h1>
        <p className="text-sm text-[#A5A3B8] max-w-md mx-auto mt-2 leading-relaxed">
          Enter promotional gift codes created by administrator Virat to claim free LOT currency directly into your wallet.
        </p>
      </div>

      {/* Code Input Card */}
      <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
        {error && (
          <div className="mb-4 p-3.5 rounded-xl bg-red-950/60 border border-red-500/30 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-4 p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleRedeem} className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            required
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="ENTER-CODE-HERE"
            className="flex-1 px-4 py-3 bg-[#121222] border border-[#302D46] rounded-xl text-white font-mono font-bold tracking-wider placeholder-[#A5A3B8]/40 text-sm focus:outline-none focus:border-[#8B5CF6]"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-8 py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:from-[#7C3AED] hover:to-[#9333EA] text-white font-bold text-xs shadow-lg shadow-purple-500/25 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            {loading ? 'Validating...' : 'Claim LOT'}
          </button>
        </form>

        <div className="mt-4 flex items-center gap-2 text-[11px] text-[#A5A3B8]">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Each code can be claimed once per user account. All claims are validated atomically.</span>
        </div>
      </div>

      {/* User's Claim History */}
      <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#8B5CF6]" />
            <h3 className="font-bold text-white text-sm">Your Redeemed Codes</h3>
          </div>
          <span className="text-xs text-[#A5A3B8]">{claims.length} claimed</span>
        </div>

        {claimsLoading ? (
          <div className="text-center py-6 text-xs text-[#A5A3B8]">Loading claims...</div>
        ) : !user ? (
          <div className="text-center py-6 text-xs text-[#A5A3B8]">Sign in to view your redemption history.</div>
        ) : claims.length === 0 ? (
          <div className="text-center py-6 text-xs text-[#A5A3B8]">
            You have not redeemed any codes yet. Keep an eye on global announcements for promo drops!
          </div>
        ) : (
          <div className="space-y-2">
            {claims.map((claim) => (
              <div
                key={claim.id}
                className="flex items-center justify-between p-3 rounded-xl bg-[#121222] border border-[#302D46] text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <span className="font-mono font-bold text-white text-sm">{claim.code}</span>
                  <span className="text-[10px] text-[#A5A3B8]">
                    {new Date(claim.claimedAt).toLocaleDateString()}
                  </span>
                </div>
                <span
                  className="font-bold text-emerald-400 flex items-center gap-1"
                  title={`+${claim.rewardLot.toLocaleString()} LOT`}
                >
                  <Coins className="w-3.5 h-3.5" /> +{formatCompactNumber(claim.rewardLot)} LOT
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
