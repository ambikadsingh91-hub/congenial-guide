import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { StockInstrument, UserPortfolio, StockTrade } from '../../types';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  DollarSign,
  PieChart,
  History,
  AlertCircle,
  Coins,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  Info,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatCompactNumber } from '../../lib/formatNumber';
import { playTransactionSound, playErrorSound } from '../../lib/sounds';

export const VStocks: React.FC = () => {
  const { user, openAuthModal, refreshUser } = useAuth();
  const [stocks, setStocks] = useState<StockInstrument[]>([]);
  const [selectedStock, setSelectedStock] = useState<StockInstrument | null>(null);
  const [tradeType, setTradeType] = useState<'BUY' | 'SELL'>('BUY');
  const [quantity, setQuantity] = useState('1');
  const [timeframe, setTimeframe] = useState<'1D' | '1W' | '1M' | 'ALL'>('1D');

  // Portfolio state
  const [holdings, setHoldings] = useState<any[]>([]);
  const [totalPortfolioValue, setTotalPortfolioValue] = useState(0);
  const [totalInvested, setTotalInvested] = useState(0);
  const [totalPnl, setTotalPnl] = useState(0);
  const [totalPnlPercent, setTotalPnlPercent] = useState(0);

  // Trade History
  const [trades, setTrades] = useState<StockTrade[]>([]);
  const [activeTab, setActiveTab] = useState<'trade' | 'portfolio' | 'history'>('trade');

  // Loading & error
  const [isTrading, setIsTrading] = useState(false);
  const [tradeError, setTradeError] = useState<string | null>(null);
  const [tradeSuccess, setTradeSuccess] = useState<string | null>(null);

  const fetchMarket = async () => {
    try {
      const res = await fetch('/api/stocks/market');
      if (res.ok) {
        const data = await res.json();
        setStocks(data.stocks || []);
        if (!selectedStock && data.stocks?.length > 0) {
          setSelectedStock(data.stocks[0]);
        } else if (selectedStock && data.stocks?.length > 0) {
          const updated = data.stocks.find((s: StockInstrument) => s.symbol === selectedStock.symbol);
          if (updated) setSelectedStock(updated);
        }
      }
    } catch {
      // ignore
    }
  };

  const fetchPortfolio = async () => {
    if (!user) return;
    try {
      const res = await fetch('/api/stocks/portfolio');
      if (res.ok) {
        const data = await res.json();
        setHoldings(data.holdings || []);
        setTotalPortfolioValue(data.totalPortfolioValue || 0);
        setTotalInvested(data.totalInvested || 0);
        setTotalPnl(data.totalPnl || 0);
        setTotalPnlPercent(data.totalPnlPercent || 0);
      }
    } catch {
      // ignore
    }
  };

  const fetchTrades = async () => {
    if (!user) return;
    try {
      const res = await fetch('/api/stocks/trades');
      if (res.ok) {
        const data = await res.json();
        setTrades(data.trades || []);
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    fetchMarket();
    const interval = setInterval(fetchMarket, 4000); // live updates
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (user) {
      fetchPortfolio();
      fetchTrades();
    }
  }, [user?.id]);

  const handleExecuteTrade = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal('login');
      return;
    }
    if (!selectedStock) return;

    setIsTrading(true);
    setTradeError(null);
    setTradeSuccess(null);

    const qty = Math.floor(Number(quantity));
    if (!qty || qty <= 0) {
      playErrorSound();
      setTradeError('Please enter a valid share quantity of 1 or more.');
      setIsTrading(false);
      return;
    }

    try {
      const res = await fetch('/api/stocks/trade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol: selectedStock.symbol,
          type: tradeType,
          quantity: qty,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        playErrorSound();
        setTradeError(data.error || 'Trade failed.');
        setIsTrading(false);
        return;
      }

      playTransactionSound();
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#8B5CF6', '#A855F7', '#C4B5FD', '#10B981'],
      });

      setTradeSuccess(`Executed ${tradeType} order: ${qty}x ${selectedStock.symbol} at ${formatCompactNumber(selectedStock.currentPrice)} LOT.`);
      setQuantity('1');
      await refreshUser();
      await fetchPortfolio();
      await fetchTrades();
    } catch {
      playErrorSound();
      setTradeError('Network error executing trade.');
    } finally {
      setIsTrading(false);
    }
  };

  // Find user holding for selected stock
  const currentHolding = holdings.find((h) => h.symbol === selectedStock?.symbol);
  const userHoldingQty = currentHolding ? currentHolding.quantity : 0;

  // Chart SVG generator based on sparkline data
  const renderChart = (points: number[] = []) => {
    if (points.length < 2) return null;
    const min = Math.min(...points) * 0.98;
    const max = Math.max(...points) * 1.02;
    const range = max - min || 1;
    const width = 600;
    const height = 220;

    const coords = points.map((val, idx) => {
      const x = (idx / (points.length - 1)) * width;
      const y = height - ((val - min) / range) * (height - 30) - 15;
      return `${x},${y}`;
    });

    const isUp = points[points.length - 1] >= points[0];
    const strokeColor = isUp ? '#10B981' : '#EF4444';
    const gradientId = `chartGrad_${selectedStock?.symbol || 'main'}`;

    return (
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-56 overflow-visible">
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={strokeColor} stopOpacity="0.3" />
            <stop offset="100%" stopColor={strokeColor} stopOpacity="0.0" />
          </linearGradient>
        </defs>
        <polygon
          points={`0,${height} ${coords.join(' ')} ${width},${height}`}
          fill={`url(#${gradientId})`}
        />
        <polyline
          fill="none"
          stroke={strokeColor}
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={coords.join(' ')}
        />
        {/* Draw latest price dot */}
        {points.length > 0 && (
          <circle
            cx={coords[coords.length - 1].split(',')[0]}
            cy={coords[coords.length - 1].split(',')[1]}
            r="4.5"
            fill={strokeColor}
            className="animate-ping"
          />
        )}
      </svg>
    );
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* VStocks Header & Simulated Disclosure */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#121222] via-[#19192B] to-[#202039] border border-[#302D46] p-8 sm:p-10 shadow-2xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#202039] border border-[#8B5CF6]/40 text-[#C4B5FD] text-xs font-semibold mb-3">
              <Sparkles className="w-3.5 h-3.5 text-[#8B5CF6]" />
              VStocks Digital Exchange
            </div>
            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
              Trade Ecosystem Stocks
            </h1>
            <p className="text-sm text-[#A5A3B8] max-w-xl mt-2 leading-relaxed">
              Invest your LOT currency in virtual gaming equities, tech labs, and weapon foundries with live micro-volatility
              and instant ledger settlement.
            </p>
          </div>

          {/* Honest Simulation Badge per prompt */}
          <div className="bg-[#121222]/90 border border-purple-500/30 p-4 rounded-2xl min-w-[240px] shadow-xl">
            <span className="text-[10px] font-bold text-[#8B5CF6] uppercase tracking-wider block">
              Market Classification
            </span>
            <span className="text-sm font-bold text-white flex items-center gap-2 mt-1">
              <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
              Simulated Market Data
            </span>
            <p className="text-[11px] text-[#A5A3B8] mt-1.5 leading-snug">
              Market quotes are dynamically simulated 24/7 on the server. Backed by authoritative LOT ledger balances.
            </p>
          </div>
        </div>

        {/* Portfolio Stats Strip if user is logged in */}
        {user && (
          <div className="mt-8 pt-6 border-t border-[#302D46]/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div>
              <span className="text-[#A5A3B8] block">Portfolio Value</span>
              <span className="font-bold text-white text-base mt-0.5 block" title={`${totalPortfolioValue.toLocaleString()} LOT`}>
                {formatCompactNumber(totalPortfolioValue)} LOT
              </span>
            </div>
            <div>
              <span className="text-[#A5A3B8] block">Total Invested</span>
              <span className="font-bold text-white text-base mt-0.5 block" title={`${totalInvested.toLocaleString()} LOT`}>
                {formatCompactNumber(totalInvested)} LOT
              </span>
            </div>
            <div>
              <span className="text-[#A5A3B8] block">Unrealized P&L</span>
              <span
                className={`font-bold text-base mt-0.5 flex items-center gap-1 ${
                  totalPnl >= 0 ? 'text-emerald-400' : 'text-red-400'
                }`}
                title={`${totalPnl >= 0 ? '+' : ''}${totalPnl.toLocaleString()} LOT`}
              >
                {totalPnl >= 0 ? '+' : ''}{formatCompactNumber(totalPnl)} LOT ({totalPnlPercent}%)
              </span>
            </div>
            <div>
              <span className="text-[#A5A3B8] block">Available Cash</span>
              <span className="font-bold text-[#C4B5FD] text-base mt-0.5 block" title={`${user.lotBalance.toLocaleString()} LOT`}>
                {formatCompactNumber(user.lotBalance)} LOT
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Stock Tickers Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {stocks.map((stock) => {
          const isSelected = selectedStock?.symbol === stock.symbol;
          const isUp = stock.change24h >= 0;
          return (
            <div
              key={stock.symbol}
              onClick={() => setSelectedStock(stock)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#202039] border-[#8B5CF6] shadow-lg shadow-purple-900/20'
                  : 'bg-[#19192B] border-[#302D46] hover:border-[#8B5CF6]/50'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-black text-white text-sm">{stock.symbol}</span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5 ${
                    isUp ? 'bg-emerald-950 text-emerald-300' : 'bg-red-950 text-red-300'
                  }`}
                >
                  {isUp ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
                  {isUp ? '+' : ''}{stock.change24h}%
                </span>
              </div>
              <p className="text-[11px] text-[#A5A3B8] truncate">{stock.name}</p>
              <div className="mt-2 text-base font-black text-white flex items-center gap-1">
                {stock.currentPrice} <span className="text-[11px] font-semibold text-[#8B5CF6]">LOT</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Trading and Chart Workspace */}
      {selectedStock && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Chart & Instrument Details (8 Cols) */}
          <div className="lg:col-span-8 bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-2xl font-black text-white">{selectedStock.name}</h2>
                  <span className="px-2.5 py-0.5 rounded-lg bg-[#202039] border border-[#302D46] text-xs font-bold text-[#C4B5FD]">
                    {selectedStock.symbol}
                  </span>
                </div>
                <p className="text-xs text-[#A5A3B8] mt-1">Sector: {selectedStock.category}</p>
              </div>

              {/* Timeframe Controls */}
              <div className="flex bg-[#121222] p-1 rounded-xl border border-[#302D46] self-start">
                {(['1D', '1W', '1M', 'ALL'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setTimeframe(tf)}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                      timeframe === tf ? 'bg-[#8B5CF6] text-white shadow' : 'text-[#A5A3B8] hover:text-white'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* Current Price Banner */}
            <div className="flex items-baseline gap-3 mb-6">
              <span className="text-3xl sm:text-4xl font-black text-white">
                {selectedStock.currentPrice} <span className="text-lg text-[#8B5CF6]">LOT</span>
              </span>
              <span
                className={`text-sm font-bold flex items-center gap-1 ${
                  selectedStock.change24h >= 0 ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                {selectedStock.change24h >= 0 ? '+' : ''}{selectedStock.change24h}% (24h)
              </span>
            </div>

            {/* Price Chart SVG */}
            <div className="w-full bg-[#121222] p-4 rounded-2xl border border-[#302D46] mb-6">
              {renderChart(selectedStock.sparkline)}
            </div>

            {/* Market High / Low / Volume */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#302D46] text-xs">
              <div>
                <span className="text-[#A5A3B8] block">Day High</span>
                <span className="font-bold text-white text-sm mt-0.5 block">{formatCompactNumber(selectedStock.dayHigh)} LOT</span>
              </div>
              <div>
                <span className="text-[#A5A3B8] block">Day Low</span>
                <span className="font-bold text-white text-sm mt-0.5 block">{formatCompactNumber(selectedStock.dayLow)} LOT</span>
              </div>
              <div>
                <span className="text-[#A5A3B8] block">24h Traded Volume</span>
                <span className="font-bold text-white text-sm mt-0.5 block" title={`${selectedStock.volume24h.toLocaleString()} shares`}>
                  {formatCompactNumber(selectedStock.volume24h)} shares
                </span>
              </div>
            </div>
          </div>

          {/* Trade Execution Panel (4 Cols) */}
          <div className="lg:col-span-4 bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col justify-between">
            <div>
              {/* Buy / Sell Toggle Tabs */}
              <div className="flex bg-[#121222] p-1 rounded-xl mb-6 border border-[#302D46]">
                <button
                  type="button"
                  onClick={() => setTradeType('BUY')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                    tradeType === 'BUY'
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  Buy {selectedStock.symbol}
                </button>
                <button
                  type="button"
                  onClick={() => setTradeType('SELL')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                    tradeType === 'SELL'
                      ? 'bg-red-600 text-white shadow-md'
                      : 'text-[#A5A3B8] hover:text-white'
                  }`}
                >
                  Sell {selectedStock.symbol}
                </button>
              </div>

              {tradeError && (
                <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/30 text-red-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{tradeError}</span>
                </div>
              )}

              {tradeSuccess && (
                <div className="mb-4 p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{tradeSuccess}</span>
                </div>
              )}

              <form onSubmit={handleExecuteTrade} className="space-y-4">
                <div>
                  <div className="flex justify-between items-center text-xs text-[#A5A3B8] mb-1.5">
                    <span>Quantity (Shares)</span>
                    {tradeType === 'SELL' && (
                      <button
                        type="button"
                        onClick={() => setQuantity(String(userHoldingQty))}
                        className="text-[#C4B5FD] hover:underline"
                      >
                        Sell Max ({userHoldingQty})
                      </button>
                    )}
                  </div>
                  <input
                    type="number"
                    min="1"
                    required
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    className="w-full px-4 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-bold text-sm focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>

                {/* Calculation Summary */}
                <div className="bg-[#121222] p-4 rounded-2xl border border-[#302D46] space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#A5A3B8]">Unit Price:</span>
                    <span className="font-bold text-white">{formatCompactNumber(selectedStock.currentPrice)} LOT</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#A5A3B8]">You currently hold:</span>
                    <span className="font-bold text-white">{userHoldingQty} shares</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-[#302D46] text-sm font-bold">
                    <span className="text-white">Estimated Total:</span>
                    <span
                      className="text-[#C4B5FD]"
                      title={`${+(Number(quantity) * selectedStock.currentPrice).toFixed(2)} LOT`}
                    >
                      {formatCompactNumber(+(Number(quantity) * selectedStock.currentPrice).toFixed(2))} LOT
                    </span>
                  </div>
                </div>

                {user && (
                  <div className="flex justify-between text-xs text-[#A5A3B8] px-1">
                    <span>Cash Balance:</span>
                    <span className="font-bold text-white" title={`${user.lotBalance.toLocaleString()} LOT`}>
                      {formatCompactNumber(user.lotBalance)} LOT
                    </span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isTrading}
                  className={`w-full py-3.5 mt-2 rounded-xl text-white font-bold text-xs shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2 ${
                    tradeType === 'BUY'
                      ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/25'
                      : 'bg-red-600 hover:bg-red-500 shadow-red-600/25'
                  }`}
                >
                  {isTrading
                    ? 'Transacting...'
                    : `${tradeType === 'BUY' ? 'Buy' : 'Sell'} ${quantity || '1'} ${selectedStock.symbol}`}
                </button>
              </form>
            </div>

            <div className="mt-6 pt-4 border-t border-[#302D46] text-[11px] text-[#A5A3B8] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Trades are validated server-side. Overselling and balance exploits are prevented.</span>
            </div>
          </div>
        </div>
      )}

      {/* Tabs: Portfolio Holdings & Trade History */}
      <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex bg-[#121222] p-1 rounded-xl mb-6 max-w-sm border border-[#302D46]">
          <button
            onClick={() => setActiveTab('portfolio')}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'portfolio' ? 'bg-[#8B5CF6] text-white shadow' : 'text-[#A5A3B8] hover:text-white'
            }`}
          >
            My Holdings ({holdings.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'history' ? 'bg-[#8B5CF6] text-white shadow' : 'text-[#A5A3B8] hover:text-white'
            }`}
          >
            Trade History ({trades.length})
          </button>
        </div>

        {activeTab === 'portfolio' ? (
          <div>
            {!user ? (
              <div className="text-center py-8 text-xs text-[#A5A3B8]">Sign in to view your stock portfolio.</div>
            ) : holdings.length === 0 ? (
              <div className="text-center py-8 text-xs text-[#A5A3B8]">
                You don't own any stocks yet. Pick a stock above and click Buy!
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-[#302D46] text-[#A5A3B8]">
                      <th className="pb-3">Symbol</th>
                      <th className="pb-3">Shares</th>
                      <th className="pb-3">Avg Cost</th>
                      <th className="pb-3">Current Price</th>
                      <th className="pb-3">Market Value</th>
                      <th className="pb-3 text-right">Unrealized P&L</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#302D46]/60">
                    {holdings.map((h) => {
                      const isUp = h.pnl >= 0;
                      return (
                        <tr key={h.symbol} className="hover:bg-[#121222]/40 transition-colors">
                          <td className="py-3 font-bold text-white">{h.symbol}</td>
                          <td className="py-3 text-white">{h.quantity}</td>
                          <td className="py-3 text-[#A5A3B8]" title={`${h.averageBuyPrice.toLocaleString()} LOT`}>
                            {formatCompactNumber(h.averageBuyPrice)} LOT
                          </td>
                          <td className="py-3 font-semibold text-white" title={`${h.currentPrice.toLocaleString()} LOT`}>
                            {formatCompactNumber(h.currentPrice)} LOT
                          </td>
                          <td className="py-3 font-bold text-white" title={`${h.currentValue.toLocaleString()} LOT`}>
                            {formatCompactNumber(h.currentValue)} LOT
                          </td>
                          <td
                            className={`py-3 text-right font-bold ${isUp ? 'text-emerald-400' : 'text-red-400'}`}
                            title={`${isUp ? '+' : ''}${h.pnl.toLocaleString()} LOT`}
                          >
                            {isUp ? '+' : ''}{formatCompactNumber(h.pnl)} LOT ({h.pnlPercent}%)
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ) : (
          <div>
            {!user ? (
              <div className="text-center py-8 text-xs text-[#A5A3B8]">Sign in to view trade history.</div>
            ) : trades.length === 0 ? (
              <div className="text-center py-8 text-xs text-[#A5A3B8]">No executed trades yet.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-[#302D46] text-[#A5A3B8]">
                      <th className="pb-3">Order Side</th>
                      <th className="pb-3">Symbol</th>
                      <th className="pb-3">Quantity</th>
                      <th className="pb-3">Price / Unit</th>
                      <th className="pb-3">Total Value</th>
                      <th className="pb-3 text-right">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#302D46]/60">
                    {trades.map((t) => (
                      <tr key={t.id} className="hover:bg-[#121222]/40 transition-colors">
                        <td className="py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              t.type === 'BUY'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                : 'bg-red-950 text-red-300 border border-red-800'
                            }`}
                          >
                            {t.type}
                          </span>
                        </td>
                        <td className="py-3 font-bold text-white">{t.symbol}</td>
                        <td className="py-3 text-white">{t.quantity}</td>
                        <td className="py-3 text-[#A5A3B8]" title={`${t.pricePerUnit.toLocaleString()} LOT`}>
                          {formatCompactNumber(t.pricePerUnit)} LOT
                        </td>
                        <td className="py-3 font-bold text-white" title={`${t.totalLot.toLocaleString()} LOT`}>
                          {formatCompactNumber(t.totalLot)} LOT
                        </td>
                        <td className="py-3 text-right text-[#A5A3B8]">
                          {new Date(t.createdAt).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
