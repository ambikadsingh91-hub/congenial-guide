import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Lock,
  Unlock,
  Coins,
  ThumbsUp,
  ThumbsDown,
  Bookmark,
  Share2,
  UserPlus,
  UserCheck,
  RotateCcw,
  Sparkles,
  MessageSquare,
  Settings,
  Tv,
  Subtitles,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { LotVideo, VideoComment } from './types';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';
import { GifPicker } from '../shorts/GifPicker';

interface VideoPlayerModalProps {
  video: LotVideo;
  onClose: () => void;
  onVideoUpdated: (updated: LotVideo) => void;
  onOpenPlaylist?: (video: LotVideo) => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  video,
  onClose,
  onVideoUpdated,
  onOpenPlaylist,
}) => {
  const { user, refreshUser } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Player controls state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(video.continueTime || 0);
  const [duration, setDuration] = useState<number>(video.duration || 0);
  const [volume, setVolume] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showSubtitles, setShowSubtitles] = useState<boolean>(false);
  const [quality, setQuality] = useState<string>('Auto (1080p)');
  const [controlsVisible, setControlsVisible] = useState<boolean>(true);
  const controlsTimeoutRef = useRef<any>(null);

  // Engagement state
  const [isUnlocked, setIsUnlocked] = useState<boolean>(Boolean(video.isUnlocked));
  const [purchasing, setPurchasing] = useState<boolean>(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);
  const [purchaseSuccess, setPurchaseSuccess] = useState<string | null>(null);

  const [hasLiked, setHasLiked] = useState<boolean>(Boolean(video.hasLiked));
  const [hasDisliked, setHasDisliked] = useState<boolean>(Boolean(video.hasDisliked));
  const [hasSaved, setHasSaved] = useState<boolean>(Boolean(video.hasSaved));
  const [isFollowing, setIsFollowing] = useState<boolean>(Boolean(video.isFollowing));
  const [likesCount, setLikesCount] = useState<number>(video.likesCount || 0);
  const [showShareToast, setShowShareToast] = useState<boolean>(false);

  // Comments state
  const [comments, setComments] = useState<VideoComment[]>([]);
  const [loadingComments, setLoadingComments] = useState<boolean>(false);
  const [commentText, setCommentText] = useState<string>('');
  const [submittingComment, setSubmittingComment] = useState<boolean>(false);
  const [showGifPicker, setShowGifPicker] = useState<boolean>(false);

  // Hide controls after inactivity
  const handleMouseMove = () => {
    setControlsVisible(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setControlsVisible(false);
    }, 3000);
  };

  // Keyboard shortcuts (Space = Play/Pause, M = Mute, F = Fullscreen)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;
      if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'm' || e.key === 'M') {
        toggleMute();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      } else if (e.key === 'Escape' && !isFullscreen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isFullscreen, isMuted]);

  // Load comments
  useEffect(() => {
    const fetchComments = async () => {
      try {
        setLoadingComments(true);
        const res = await fetch(`/api/shorts/${video.id}/comments`);
        if (res.ok) {
          const data = await res.json();
          setComments(data.comments || []);
        }
      } catch (e) {
        console.error('Failed to load comments:', e);
      } finally {
        setLoadingComments(false);
      }
    };
    fetchComments();
  }, [video.id]);

  // Track watch progress periodically (every 5 seconds)
  useEffect(() => {
    if (!isPlaying || !isUnlocked) return;
    const interval = setInterval(async () => {
      if (videoRef.current && user) {
        const time = videoRef.current.currentTime;
        const dur = videoRef.current.duration || duration;
        try {
          await fetch(`/api/videos/${video.id}/progress`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ currentTime: time, duration: dur }),
          });
        } catch {}
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [isPlaying, isUnlocked, video.id, duration, user]);

  const togglePlay = () => {
    if (!videoRef.current || !isUnlocked) return;
    if (videoRef.current.paused) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    const nextMute = !isMuted;
    videoRef.current.muted = nextMute;
    setIsMuted(nextMute);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
      setIsMuted(val === 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setCurrentTime(val);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
    }
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackRate(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
    setShowSettings(false);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const togglePiP = async () => {
    if (!videoRef.current) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else {
        await videoRef.current.requestPictureInPicture();
      }
    } catch (e) {
      console.warn('PiP not supported or disallowed:', e);
    }
  };

  // Format seconds to mm:ss or hh:mm:ss
  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = Math.floor(secs % 60);
    if (h > 0) {
      return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  // Purchase Paid Video with LOT balance
  const handlePurchase = async () => {
    if (!user) {
      setPurchaseError('Please sign in to unlock this video.');
      return;
    }
    setPurchasing(true);
    setPurchaseError(null);

    try {
      const res = await fetch(`/api/videos/${video.id}/purchase`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to complete purchase');
      }

      setIsUnlocked(true);
      setPurchaseSuccess(`Video unlocked permanently! £${video.priceLot} LOT deducted.`);
      refreshUser();

      const updated = { ...video, isUnlocked: true, isPurchased: true };
      onVideoUpdated(updated);

      // Auto start playback after unlock
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
        }
      }, 300);
    } catch (err: any) {
      setPurchaseError(err.message || 'Purchase error');
    } finally {
      setPurchasing(false);
    }
  };

  // Like Video
  const handleLike = async () => {
    if (!user) return;
    const nextLiked = !hasLiked;
    setHasLiked(nextLiked);
    if (nextLiked && hasDisliked) setHasDisliked(false);
    setLikesCount((prev) => (nextLiked ? prev + 1 : Math.max(0, prev - 1)));

    try {
      await fetch(`/api/shorts/${video.id}/like`, { method: 'POST' });
      onVideoUpdated({ ...video, hasLiked: nextLiked, likesCount: nextLiked ? likesCount + 1 : likesCount - 1 });
    } catch {}
  };

  // Dislike Video
  const handleDislike = async () => {
    if (!user) return;
    const nextDisliked = !hasDisliked;
    setHasDisliked(nextDisliked);
    if (nextDisliked && hasLiked) {
      setHasLiked(false);
      setLikesCount((prev) => Math.max(0, prev - 1));
    }
    try {
      await fetch(`/api/videos/${video.id}/dislike`, { method: 'POST' });
    } catch {}
  };

  // Save / Bookmark
  const handleSave = async () => {
    if (!user) return;
    const nextSaved = !hasSaved;
    setHasSaved(nextSaved);
    try {
      await fetch(`/api/shorts/${video.id}/save`, { method: 'POST' });
    } catch {}
  };

  // Follow / Subscribe Creator
  const handleFollow = async () => {
    if (!user) return;
    const nextFollow = !isFollowing;
    setIsFollowing(nextFollow);
    try {
      await fetch(`/api/shorts/creators/${video.creatorId}/follow`, { method: 'POST' });
    } catch {}
  };

  // Share
  const handleShare = () => {
    const url = `${window.location.origin}/?tab=videos&v=${video.id}`;
    navigator.clipboard.writeText(url).then(() => {
      setShowShareToast(true);
      setTimeout(() => setShowShareToast(false), 2500);
    });
  };

  // Submit comment
  const handleAddComment = async (e?: React.FormEvent, gif?: { url: string; title: string }) => {
    if (e) e.preventDefault();
    if (!user) return;
    if (!commentText.trim() && !gif) return;

    setSubmittingComment(true);
    try {
      const res = await fetch(`/api/shorts/${video.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: commentText.trim(),
          gifUrl: gif?.url,
          gifTitle: gif?.title,
          mediaType: gif ? 'gif' : undefined,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setComments((prev) => [data.comment, ...prev]);
        setCommentText('');
        setShowGifPicker(false);
      }
    } catch (e) {
      console.error('Comment error:', e);
    } finally {
      setSubmittingComment(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-[#10101F] border border-[#2D2B44] rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[96vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#151528] border-b border-[#2D2B44] shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider bg-purple-900/60 text-purple-300 border border-purple-500/40">
              {video.type === 'short' ? 'LOT Short' : 'LOT Video'}
            </span>
            <span className="text-xs text-[#A5A3B8] hidden sm:inline">• {video.category}</span>
            {video.isPaid && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1 font-bold">
                <Coins className="w-3 h-3 text-amber-400" />
                £{video.priceLot} LOT
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#A5A3B8] hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Box */}
        <div
          ref={containerRef}
          onMouseMove={handleMouseMove}
          className="relative w-full bg-black aspect-video flex items-center justify-center overflow-hidden group select-none shrink-0"
        >
          {isUnlocked ? (
            <>
              {video.source === 'youtube' && video.youtubeVideoId ? (
                <iframe
                  src={`https://www.youtube-nocookie.com/embed/${video.youtubeVideoId}?autoplay=1&rel=0&modestbranding=1`}
                  title={video.title}
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <>
                  <video
                    ref={videoRef}
                    src={video.videoUrl}
                    poster={video.thumbnailUrl}
                    onClick={togglePlay}
                    onTimeUpdate={() => {
                      if (videoRef.current) setCurrentTime(videoRef.current.currentTime);
                    }}
                    onLoadedMetadata={() => {
                      if (videoRef.current) {
                        setDuration(videoRef.current.duration);
                        if (video.continueTime && video.continueTime > 5) {
                          videoRef.current.currentTime = video.continueTime;
                        }
                      }
                    }}
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    className="w-full h-full object-contain cursor-pointer"
                  />

                  {/* Subtitles Overlay if enabled */}
                  {showSubtitles && (
                    <div className="absolute bottom-16 left-1/2 -translate-x-1/2 bg-black/80 px-4 py-1.5 rounded-md text-white text-sm sm:text-base font-semibold pointer-events-none drop-shadow">
                      {video.title}
                    </div>
                  )}

                  {/* Centered Play/Pause Watermark on Pause */}
                  {!isPlaying && (
                    <button
                      onClick={togglePlay}
                      className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-purple-600/80 hover:bg-purple-600 text-white flex items-center justify-center backdrop-blur-sm transition-transform hover:scale-110 shadow-xl"
                    >
                      <Play className="w-8 h-8 ml-1 fill-white" />
                    </button>
                  )}

                  {/* Video Controls Bar */}
                  <div
                    className={`absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-3 sm:p-4 transition-opacity duration-300 ${
                      controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
                    }`}
                  >
                    {/* Scrub Seek Bar */}
                    <div className="flex items-center gap-2 mb-2">
                      <input
                        type="range"
                        min={0}
                        max={duration || 100}
                        step={0.1}
                        value={currentTime}
                        onChange={handleSeek}
                        className="w-full h-1.5 bg-white/20 hover:bg-white/30 rounded-lg appearance-none cursor-pointer accent-purple-500 transition-all"
                      />
                    </div>

                    <div className="flex items-center justify-between text-white text-xs sm:text-sm">
                      {/* Left: Play/Pause, Volume, Time */}
                      <div className="flex items-center gap-3">
                        <button onClick={togglePlay} className="hover:text-purple-400 transition-colors">
                          {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
                        </button>

                        <div className="flex items-center gap-1.5 group/vol">
                          <button onClick={toggleMute} className="hover:text-purple-400">
                            {isMuted || volume === 0 ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                          </button>
                          <input
                            type="range"
                            min={0}
                            max={1}
                            step={0.05}
                            value={isMuted ? 0 : volume}
                            onChange={handleVolumeChange}
                            className="w-16 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer accent-purple-500"
                          />
                        </div>

                        <span className="text-[11px] sm:text-xs text-[#A5A3B8]">
                          {formatTime(currentTime)} / {formatTime(duration)}
                        </span>
                      </div>

                      {/* Right: Subtitles, Settings, PiP, Fullscreen */}
                      <div className="flex items-center gap-3 relative">
                        <button
                          onClick={() => setShowSubtitles((p) => !p)}
                          className={`p-1 rounded transition-colors ${showSubtitles ? 'text-purple-400 font-bold' : 'text-white/80 hover:text-white'}`}
                          title="Subtitles / Captions"
                        >
                          <Subtitles className="w-4 h-4" />
                        </button>

                        {/* Settings Popup (Speed, Quality) */}
                        <div className="relative">
                          <button
                            onClick={() => setShowSettings((p) => !p)}
                            className="p-1 text-white/80 hover:text-white transition-colors"
                            title="Playback Settings"
                          >
                            <Settings className="w-4 h-4" />
                          </button>

                          {showSettings && (
                            <div className="absolute right-0 bottom-8 w-44 bg-[#19192C] border border-[#302D46] rounded-xl shadow-2xl p-2 text-xs z-30">
                              <div className="font-semibold text-purple-300 pb-1 mb-1 border-b border-[#302D46]">
                                Speed ({playbackRate}x)
                              </div>
                              <div className="grid grid-cols-4 gap-1 mb-2">
                                {[0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((s) => (
                                  <button
                                    key={s}
                                    onClick={() => handleSpeedChange(s)}
                                    className={`py-1 rounded text-center ${
                                      playbackRate === s
                                        ? 'bg-purple-600 text-white font-bold'
                                        : 'bg-[#25253E] hover:bg-[#302D46] text-[#A5A3B8]'
                                    }`}
                                  >
                                    {s}x
                                  </button>
                                ))}
                              </div>
                              <div className="font-semibold text-purple-300 pb-1 mb-1 border-b border-[#302D46]">
                                Resolution
                              </div>
                              <div className="space-y-1">
                                {['Auto (1080p)', '720p HD', '480p SD', '360p Data Saver'].map((q) => (
                                  <button
                                    key={q}
                                    onClick={() => {
                                      setQuality(q);
                                      setShowSettings(false);
                                    }}
                                    className={`w-full text-left px-2 py-1 rounded ${
                                      quality === q ? 'bg-purple-600/30 text-purple-300 font-bold' : 'hover:bg-[#25253E] text-[#A5A3B8]'
                                    }`}
                                  >
                                    {q}
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>

                        <button
                          onClick={togglePiP}
                          className="p-1 text-white/80 hover:text-white transition-colors hidden sm:block"
                          title="Picture in Picture"
                        >
                          <Tv className="w-4 h-4" />
                        </button>

                        <button onClick={toggleFullscreen} className="p-1 text-white/80 hover:text-white transition-colors">
                          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </>
          ) : (
            /* Locked Video Preview Overlay */
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-b from-[#15152A] to-[#0A0A14] overflow-hidden">
              {/* Blurred Poster Background */}
              {video.thumbnailUrl && (
                <img
                  src={video.thumbnailUrl}
                  alt={video.title}
                  className="absolute inset-0 w-full h-full object-cover blur-xl opacity-25 scale-105 pointer-events-none"
                />
              )}

              <div className="relative z-10 max-w-md w-full flex flex-col items-center">
                <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-4 shadow-lg shadow-amber-500/10">
                  <Lock className="w-8 h-8 animate-pulse" />
                </div>

                <span className="text-xs uppercase font-extrabold tracking-widest text-amber-400 mb-1">
                  Premium Paid Video
                </span>
                <h3 className="text-xl font-bold text-white mb-2 line-clamp-2">{video.title}</h3>
                <p className="text-xs text-[#A5A3B8] mb-4 line-clamp-2">
                  {video.description || 'Unlock lifetime access to stream this high-definition video in full.'}
                </p>

                {/* Pricing & Balance Box */}
                <div className="w-full bg-[#18182E] border border-[#2D2B44] rounded-xl p-3 mb-4 flex items-center justify-between">
                  <div className="text-left">
                    <span className="text-[10px] text-[#A5A3B8] block">Price to Unlock</span>
                    <span className="text-base font-black text-amber-400 flex items-center gap-1">
                      <Coins className="w-4 h-4 text-amber-400" />
                      £{video.priceLot.toLocaleString()} LOT
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-[#A5A3B8] block">Your Balance</span>
                    <span className="text-base font-bold text-purple-300">
                      £{(user?.lotBalance || 0).toLocaleString()} LOT
                    </span>
                  </div>
                </div>

                {purchaseError && (
                  <div className="w-full bg-red-950/60 border border-red-500/40 text-red-300 text-xs p-2.5 rounded-xl mb-3 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                    <span>{purchaseError}</span>
                  </div>
                )}

                {purchaseSuccess && (
                  <div className="w-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs p-2.5 rounded-xl mb-3 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span>{purchaseSuccess}</span>
                  </div>
                )}

                <button
                  onClick={handlePurchase}
                  disabled={purchasing}
                  className="w-full py-3 px-6 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 to-purple-600 hover:from-amber-400 hover:to-purple-500 text-white shadow-lg shadow-purple-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Unlock className="w-4 h-4" />
                  {purchasing
                    ? 'Processing LOT Transaction...'
                    : `Unlock Permanently for £${video.priceLot} LOT`}
                </button>
                <span className="text-[10px] text-[#A5A3B8] mt-2">
                  One-time charge. Never billed again. Added to your Purchased Videos.
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Scrollable Video Details & Comments Section */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
          {/* Main Info Header */}
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
            <div className="space-y-1 max-w-2xl">
              <h1 className="text-lg sm:text-2xl font-black text-white">{video.title}</h1>
              <div className="flex items-center gap-3 text-xs text-[#A5A3B8]">
                <span>{formatCompactNumber(video.viewsCount || 0)} views</span>
                <span>•</span>
                <span>{new Date(video.createdAt).toLocaleDateString()}</span>
                {video.isPaid && (
                  <>
                    <span>•</span>
                    <span className="text-amber-400 font-bold">
                      {video.purchasesCount || 0} purchases (£{video.totalRevenueLot || 0} LOT earned)
                    </span>
                  </>
                )}
              </div>
            </div>

            {/* Action Buttons (Like, Dislike, Share, Save) */}
            <div className="flex items-center gap-2 flex-wrap shrink-0">
              <div className="flex items-center bg-[#18182E] border border-[#2D2B44] rounded-xl overflow-hidden">
                <button
                  onClick={handleLike}
                  className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold hover:bg-white/5 transition-colors ${
                    hasLiked ? 'text-purple-400' : 'text-[#A5A3B8]'
                  }`}
                >
                  <ThumbsUp className={`w-4 h-4 ${hasLiked ? 'fill-purple-400' : ''}`} />
                  <span>{formatCompactNumber(likesCount)}</span>
                </button>
                <div className="w-[1px] h-4 bg-[#2D2B44]" />
                <button
                  onClick={handleDislike}
                  className={`px-3 py-2 text-xs hover:bg-white/5 transition-colors ${
                    hasDisliked ? 'text-red-400' : 'text-[#A5A3B8]'
                  }`}
                >
                  <ThumbsDown className={`w-4 h-4 ${hasDisliked ? 'fill-red-400' : ''}`} />
                </button>
              </div>

              <button
                onClick={handleSave}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-[#18182E] border border-[#2D2B44] hover:bg-white/5 transition-colors ${
                  hasSaved ? 'text-purple-400' : 'text-[#A5A3B8]'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${hasSaved ? 'fill-purple-400' : ''}`} />
                <span className="hidden sm:inline">Save</span>
              </button>

              <button
                onClick={handleShare}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-[#18182E] border border-[#2D2B44] text-[#A5A3B8] hover:text-white hover:bg-white/5 transition-colors relative"
              >
                <Share2 className="w-4 h-4" />
                <span>Share</span>
                {showShareToast && (
                  <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-[10px] px-2 py-0.5 rounded shadow whitespace-nowrap">
                    Link Copied!
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Creator Profile Bar */}
          <div className="flex items-center justify-between p-3.5 bg-[#16162A] border border-[#2A2840] rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white font-bold text-sm shrink-0 overflow-hidden ring-2 ring-purple-500/20">
                {video.creatorAvatar ? (
                  <img src={video.creatorAvatar} alt={video.creatorUsername} className="w-full h-full object-cover" />
                ) : (
                  video.creatorUsername.charAt(0).toUpperCase()
                )}
              </div>
              <div>
                <div className="text-sm font-bold text-white flex items-center gap-1.5">
                  @{video.creatorUsername}
                  <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                </div>
                <div className="text-[11px] text-[#A5A3B8]">Creator on LOT Ecosystem</div>
              </div>
            </div>

            {user?.id !== video.creatorId && (
              <button
                onClick={handleFollow}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  isFollowing
                    ? 'bg-[#25253E] text-[#A5A3B8] border border-[#302D46]'
                    : 'bg-purple-600 hover:bg-purple-500 text-white shadow-md shadow-purple-500/20'
                }`}
              >
                {isFollowing ? (
                  <>
                    <UserCheck className="w-3.5 h-3.5" />
                    Subscribed
                  </>
                ) : (
                  <>
                    <UserPlus className="w-3.5 h-3.5" />
                    Subscribe
                  </>
                )}
              </button>
            )}
          </div>

          {/* Video Description Box */}
          <div className="bg-[#141424] border border-[#27253D] rounded-xl p-4 text-xs text-[#D1D0E4] space-y-2">
            <p className="whitespace-pre-line leading-relaxed">{video.description || video.caption}</p>
            {video.hashtags && video.hashtags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-2 border-t border-[#27253D]">
                {video.hashtags.map((tag, idx) => (
                  <span key={idx} className="text-purple-400 hover:underline cursor-pointer">
                    {tag.startsWith('#') ? tag : `#${tag}`}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Comments Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-purple-400" />
                Comments ({comments.length})
              </h3>
            </div>

            {/* Post comment input */}
            {user ? (
              <div className="space-y-2">
                <form onSubmit={handleAddComment} className="flex gap-2">
                  <input
                    type="text"
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Add a public comment or send a GIF..."
                    className="flex-1 bg-[#16162A] border border-[#2A2840] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-[#787693] focus:outline-none focus:border-purple-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowGifPicker((p) => !p)}
                    className="px-3 py-2 rounded-xl text-xs font-bold bg-[#202038] hover:bg-[#2B2B4A] text-purple-300 border border-purple-500/30"
                  >
                    GIF
                  </button>
                  <button
                    type="submit"
                    disabled={!commentText.trim() || submittingComment}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white disabled:opacity-40"
                  >
                    Post
                  </button>
                </form>

                {showGifPicker && (
                  <div className="p-2 bg-[#17172E] border border-[#2F2D4A] rounded-xl max-h-56 overflow-y-auto">
                    <GifPicker
                      onSelectGif={(gif) => handleAddComment(undefined, gif)}
                      onClose={() => setShowGifPicker(false)}
                    />
                  </div>
                )}
              </div>
            ) : (
              <div className="text-xs text-[#A5A3B8] p-3 bg-[#16162A] rounded-xl border border-[#2A2840]">
                Sign in to post comments and join the community discussion.
              </div>
            )}

            {/* Comments List */}
            <div className="space-y-3">
              {loadingComments ? (
                <div className="text-center py-4 text-xs text-[#A5A3B8]">Loading comments...</div>
              ) : comments.length === 0 ? (
                <div className="text-center py-6 text-xs text-[#787693]">
                  No comments yet. Be the first to start the conversation!
                </div>
              ) : (
                comments.map((c) => (
                  <div key={c.id} className="p-3 bg-[#131322] border border-[#252538] rounded-xl flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-900/60 text-purple-200 text-xs font-bold flex items-center justify-center shrink-0">
                      {c.userAvatar ? (
                        <img src={c.userAvatar} alt={c.username} className="w-full h-full rounded-full object-cover" />
                      ) : (
                        c.username.charAt(0).toUpperCase()
                      )}
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">@{c.username}</span>
                        <span className="text-[10px] text-[#787693]">
                          {new Date(c.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      {c.text && <p className="text-xs text-[#D1D0E4] leading-relaxed">{c.text}</p>}
                      {c.gifUrl && (
                        <img
                          src={c.gifUrl}
                          alt={c.gifTitle || 'GIF'}
                          className="max-w-[200px] rounded-lg mt-1 border border-purple-500/20"
                        />
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
