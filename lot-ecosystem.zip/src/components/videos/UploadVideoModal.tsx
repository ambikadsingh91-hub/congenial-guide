import React, { useState } from 'react';
import {
  X,
  Upload,
  Film,
  Image as ImageIcon,
  Coins,
  Lock,
  Unlock,
  Sparkles,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { LotVideo } from './types';

interface UploadVideoModalProps {
  onClose: () => void;
  onSuccess: (newVideo: LotVideo) => void;
}

const CATEGORIES = [
  'Entertainment',
  'Gaming',
  'Technology',
  'Music',
  'Education',
  'Comedy',
  'News',
  'Finance & Crypto',
  'Sports',
  'Tutorials & How-To',
  'Creative Arts',
];

export const UploadVideoModal: React.FC<UploadVideoModalProps> = ({ onClose, onSuccess }) => {
  const { user } = useAuth();
  const [videoType, setVideoType] = useState<'video' | 'short'>('video');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Entertainment');
  const [tags, setTags] = useState('');
  const [isPaid, setIsPaid] = useState(false);
  const [priceLot, setPriceLot] = useState('10');
  const [allowComments, setAllowComments] = useState(true);

  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [thumbFile, setThumbFile] = useState<File | null>(null);
  const [thumbPreviewUrl, setThumbPreviewUrl] = useState<string | null>(null);

  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setVideoFile(file);
      setVideoPreviewUrl(URL.createObjectURL(file));
      setError(null);
    }
  };

  const handleThumbSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setThumbFile(file);
      setThumbPreviewUrl(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoFile) {
      setError('Please select a video file to upload.');
      return;
    }
    if (!title.trim()) {
      setError('Video title is required.');
      return;
    }
    if (isPaid && (parseFloat(priceLot) <= 0 || isNaN(parseFloat(priceLot)))) {
      setError('Please specify a valid LOT price (minimum £1 LOT) for paid videos.');
      return;
    }

    setUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('video', videoFile);
      if (thumbFile) formData.append('thumbnail', thumbFile);
      formData.append('title', title.trim());
      formData.append('caption', title.trim());
      formData.append('description', description.trim());
      formData.append('category', category);
      formData.append('tags', tags);
      formData.append('type', videoType);
      formData.append('isPaid', String(isPaid));
      formData.append('priceLot', isPaid ? priceLot : '0');
      formData.append('allowComments', String(allowComments));

      const res = await fetch('/api/videos/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to upload video');
      }

      onSuccess(data.video);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#111122] border border-[#2D2B44] rounded-2xl shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#16162D] border-b border-[#2D2B44]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-purple-600/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Upload to LOT Videos</h2>
              <p className="text-[11px] text-[#A5A3B8]">Publish horizontal long videos or vertical Shorts</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#A5A3B8] hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Video Type Selector */}
          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1.5">Video Format</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setVideoType('video')}
                className={`p-3 rounded-xl border text-left transition-all flex items-center gap-3 ${
                  videoType === 'video'
                    ? 'bg-purple-600/20 border-purple-500 text-white shadow-md shadow-purple-500/10'
                    : 'bg-[#18182E] border-[#2D2B44] text-[#A5A3B8] hover:text-white hover:bg-[#20203C]'
                }`}
              >
                <Film className="w-5 h-5 text-purple-400 shrink-0" />
                <div>
                  <div className="text-xs font-bold">LOT Video (Long-Form)</div>
                  <div className="text-[10px] text-[#A5A3B8]">Horizontal 16:9 widescreen</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setVideoType('short')}
                className={`p-3 rounded-xl border text-left transition-all flex items-center gap-3 ${
                  videoType === 'short'
                    ? 'bg-purple-600/20 border-purple-500 text-white shadow-md shadow-purple-500/10'
                    : 'bg-[#18182E] border-[#2D2B44] text-[#A5A3B8] hover:text-white hover:bg-[#20203C]'
                }`}
              >
                <Film className="w-5 h-5 text-purple-400 shrink-0 rotate-90" />
                <div>
                  <div className="text-xs font-bold">LOT Short (Vertical)</div>
                  <div className="text-[10px] text-[#A5A3B8]">Vertical 9:16 mobile format</div>
                </div>
              </button>
            </div>
          </div>

          {/* Video File Picker */}
          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1.5">
              Select Video File <span className="text-red-400">*</span>
            </label>
            <div className="relative border-2 border-dashed border-[#302D46] hover:border-purple-500/60 rounded-xl p-4 bg-[#141426] text-center transition-colors">
              <input
                type="file"
                accept="video/mp4,video/webm,video/quicktime"
                onChange={handleVideoSelect}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              {videoPreviewUrl ? (
                <div className="flex items-center justify-center gap-3">
                  <Film className="w-6 h-6 text-purple-400" />
                  <div className="text-left">
                    <span className="text-xs font-bold text-white block truncate max-w-xs">
                      {videoFile?.name}
                    </span>
                    <span className="text-[10px] text-purple-300">
                      {((videoFile?.size || 0) / (1024 * 1024)).toFixed(1)} MB • Tap to replace
                    </span>
                  </div>
                </div>
              ) : (
                <div className="space-y-1">
                  <Upload className="w-7 h-7 mx-auto text-purple-400 animate-pulse" />
                  <div className="text-xs font-semibold text-white">Click or drag video file here</div>
                  <div className="text-[10px] text-[#787693]">MP4, WebM, MOV supported (up to 60MB)</div>
                </div>
              )}
            </div>
          </div>

          {/* Custom Thumbnail Picker */}
          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1.5">
              Custom Video Thumbnail (Optional)
            </label>
            <div className="relative border border-[#302D46] rounded-xl p-3 bg-[#141426] flex items-center justify-between">
              <div className="flex items-center gap-3">
                {thumbPreviewUrl ? (
                  <img
                    src={thumbPreviewUrl}
                    alt="Thumbnail preview"
                    className="w-16 h-10 object-cover rounded-lg border border-purple-500/30"
                  />
                ) : (
                  <div className="w-16 h-10 bg-[#1D1D34] rounded-lg border border-[#302D46] flex items-center justify-center text-[#787693]">
                    <ImageIcon className="w-4 h-4" />
                  </div>
                )}
                <div>
                  <span className="text-xs font-semibold text-white block">
                    {thumbFile ? thumbFile.name : 'Upload custom cover image'}
                  </span>
                  <span className="text-[10px] text-[#787693]">16:9 recommended (JPG, PNG, WEBP)</span>
                </div>
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={handleThumbSelect}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <span className="text-xs text-purple-400 font-bold px-3 py-1 bg-purple-950/50 rounded-lg border border-purple-500/20">
                Browse
              </span>
            </div>
          </div>

          {/* Title & Description */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">
                Title <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Give your video a catchy title..."
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-500"
                maxLength={100}
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What is this video about? Add details, links, or context..."
                rows={3}
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500 resize-none"
              />
            </div>
          </div>

          {/* Category & Tags */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c} className="bg-[#10101F]">
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Tags (comma separated)</label>
              <input
                type="text"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="gaming, crypto, review, tips"
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Paid Video Monetization Option */}
          <div className="p-4 bg-gradient-to-r from-[#17162E] to-[#1E1933] border border-amber-500/30 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  {isPaid ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    Paid Video Monetization
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-extrabold">
                      LOT EARNINGS
                    </span>
                  </div>
                  <div className="text-[10px] text-[#A5A3B8]">
                    Require viewers to pay £ LOT currency to unlock and watch
                  </div>
                </div>
              </div>

              {/* Toggle switch */}
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={isPaid}
                  onChange={(e) => setIsPaid(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-10 h-5 bg-[#25253E] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
              </label>
            </div>

            {isPaid && (
              <div className="pt-2 border-t border-amber-500/20 flex items-center justify-between gap-4">
                <div className="text-[11px] text-[#D1D0E4]">
                  Unlock Price (credited directly to your LOT account on each purchase):
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-amber-400">£</span>
                  <input
                    type="number"
                    min="1"
                    max="10000"
                    value={priceLot}
                    onChange={(e) => setPriceLot(e.target.value)}
                    className="w-24 bg-[#10101F] border border-amber-500/40 rounded-lg px-2.5 py-1 text-xs font-bold text-amber-300 focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-xs font-bold text-amber-400">LOT</span>
                </div>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-[#A5A3B8] hover:bg-white/5"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={uploading || !videoFile}
              className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/20 disabled:opacity-50 flex items-center gap-2 cursor-pointer"
            >
              {uploading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Publishing Video...
                </>
              ) : (
                <>
                  <Upload className="w-3.5 h-3.5" />
                  Publish Video
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
