export interface LotVideo {
  id: string;
  type: 'video' | 'short';
  title: string;
  caption?: string;
  description: string;
  category: string;
  hashtags: string[];
  creatorId: string;
  creatorUsername: string;
  creatorAvatar?: string;
  videoUrl: string;
  thumbnailUrl?: string;
  duration: number; // in seconds
  isPaid: boolean;
  priceLot: number;
  likesCount: number;
  viewsCount: number;
  commentsCount: number;
  purchasesCount?: number;
  totalRevenueLot?: number;
  allowComments: boolean;
  status: 'active' | 'hidden' | 'deleted';
  createdAt: string;
  updatedAt?: string;

  // Viewer engagement state
  isUnlocked?: boolean;
  isPurchased?: boolean;
  isOwner?: boolean;
  hasLiked?: boolean;
  hasDisliked?: boolean;
  hasSaved?: boolean;
  isFollowing?: boolean;
  continueTime?: number;
  continueProgress?: number;

  // Optional YouTube integration
  source?: 'upload' | 'youtube';
  youtubeVideoId?: string;
  youtubeChannelTitle?: string;
}

export interface VideoPlaylist {
  id: string;
  name: string;
  description: string;
  userId: string;
  username: string;
  videoIds: string[];
  createdAt: string;
}

export interface VideoComment {
  id: string;
  shortId: string;
  userId: string;
  username: string;
  userAvatar?: string;
  text: string;
  gifUrl?: string;
  gifTitle?: string;
  mediaType?: 'gif' | 'image';
  likesCount: number;
  isLiked?: boolean;
  replyToCommentId?: string | null;
  replyToUsername?: string | null;
  createdAt: string;
  replies?: VideoComment[];
}

export interface CreatorStudioStats {
  totalVideos: number;
  totalViews: number;
  totalLikes: number;
  totalComments: number;
  totalPurchases: number;
  totalRevenueLot: number;
}
