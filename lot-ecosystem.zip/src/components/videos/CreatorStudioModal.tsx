import React, { useState, useEffect } from 'react';
import {
  X,
  Tv,
  Coins,
  Eye,
  ThumbsUp,
  MessageSquare,
  ShoppingBag,
  Edit2,
  Trash2,
  Lock,
  Unlock,
  Check,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';
import { LotVideo, CreatorStudioStats } from './types';

interface CreatorStudioModalProps {
  onClose: () => void;
  onVideoChanged?: () => void;
}

export const CreatorStudioModal: React.FC<CreatorStudioModalProps> = ({ onClose, onVideoChanged }) => {
  const { user } = useAuth();
  const [videos, setVideos] = useState<LotVideo[]>([]);
  const [analytics, setAnalytics] = useState<CreatorStudioStats>({
    totalVideos: 0,
    totalViews: 0,
    totalLikes: 0,
    totalComments: 0,
    totalPurchases: 0,
    totalRevenueLot: 0,
  });
  const [loading, setLoading] = useState(true);

  // Edit State
  const [editingVideo, setEditingVideo] = useState<LotVideo | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editIsPaid, setEditIsPaid] = useState(false);
  const [editPriceLot, setEditPriceLot] = useState('0');
  const [savingEdit, setSavingEdit] = useState(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const fetchStudioData = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/creator/studio');
      if (res.ok) {
        const data = await res.json();
        setVideos(data.videos || []);
        if (data.analytics) setAnalytics(data.analytics);
      }
    } catch (e) {
      console.error('Failed to load creator studio data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudioData();
  }, []);

  const handleStartEdit = (video: LotVideo) => {
    setEditingVideo(video);
    setEditTitle(video.title);
    setEditDescription(video.description || '');
    setEditIsPaid(video.isPaid);
    setEditPriceLot(String(video.priceLot || 10));
    setActionMessage(null);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVideo) return;
    setSavingEdit(true);

    try {
      const res = await fetch(`/api/creator/videos/${editingVideo.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: editTitle,
          description: editDescription,
          isPaid: editIsPaid,
          priceLot: editIsPaid ? parseFloat(editPriceLot) : 0,
        }),
      });

      if (res.ok) {
        setActionMessage('Video updated successfully!');
        setEditingVideo(null);
        fetchStudioData();
        if (onVideoChanged) onVideoChanged();
      }
    } catch (e) {
      console.error('Failed to save video:', e);
    } finally {
      setSavingEdit(false);
    }
  };

  const handleDelete = async (videoId: string) => {
    if (!confirm('Are you sure you want to delete this video? This cannot be undone.')) return;

    try {
      const res = await fetch(`/api/shorts/${videoId}`, { method: 'DELETE' });
      if (res.ok) {
        setVideos((prev) => prev.filter((v) => v.id !== videoId));
        setActionMessage('Video deleted.');
        if (onVideoChanged) onVideoChanged();
      }
    } catch (e) {
      console.error('Delete error:', e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#10101F] border border-[#2D2B44] rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#15152B] border-b border-[#2D2B44] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
              <Tv className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">LOT Creator Studio</h2>
              <p className="text-[11px] text-[#A5A3B8]">Manage your videos, monetization, and audience reach</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-[#A5A3B8] hover:text-white hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {actionMessage && (
            <div className="p-3 bg-purple-950/60 border border-purple-500/40 rounded-xl text-purple-200 text-xs">
              {actionMessage}
            </div>
          )}

          {/* Metric KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            <div className="p-3.5 bg-[#16162D] border border-[#28263E] rounded-xl space-y-1">
              <div className="flex items-center justify-between text-[#A5A3B8] text-[11px]">
                <span>Total Videos</span>
                <Tv className="w-3.5 h-3.5 text-purple-400" />
              </div>
              <div className="text-xl font-black text-white">{analytics.totalVideos}</div>
            </div>

            <div className="p-3.5 bg-[#16162D] border border-[#28263E] rounded-xl space-y-1">
              <div className="flex items-center justify-between text-[#A5A3B8] text-[11px]">
                <span>Total Views</span>
                <Eye className="w-3.5 h-3.5 text-blue-400" />
              </div>
              <div className="text-xl font-black text-white">{formatCompactNumber(analytics.totalViews)}</div>
            </div>

            <div className="p-3.5 bg-[#16162D] border border-[#28263E] rounded-xl space-y-1">
              <div className="flex items-center justify-between text-[#A5A3B8] text-[11px]">
                <span>Likes</span>
                <ThumbsUp className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="text-xl font-black text-white">{formatCompactNumber(analytics.totalLikes)}</div>
            </div>

            <div className="p-3.5 bg-[#16162D] border border-[#28263E] rounded-xl space-y-1">
              <div className="flex items-center justify-between text-[#A5A3B8] text-[11px]">
                <span>Paid Unlocks</span>
                <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div className="text-xl font-black text-white">{analytics.totalPurchases}</div>
            </div>

            <div className="p-3.5 bg-gradient-to-br from-[#1C1833] to-[#261E40] border border-amber-500/30 rounded-xl space-y-1 col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between text-amber-300 text-[11px] font-semibold">
                <span>Total Revenue</span>
                <Coins className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div className="text-xl font-black text-amber-400">
                £{analytics.totalRevenueLot.toLocaleString()} LOT
              </div>
            </div>
          </div>

          {/* Edit Video Drawer / Modal */}
          {editingVideo && (
            <div className="p-4 bg-[#181830] border border-purple-500/40 rounded-xl space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                  <Edit2 className="w-3.5 h-3.5" />
                  Editing Video: {editingVideo.title}
                </span>
                <button
                  onClick={() => setEditingVideo(null)}
                  className="text-xs text-[#A5A3B8] hover:text-white"
                >
                  Cancel
                </button>
              </div>

              <form onSubmit={handleSaveEdit} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#D1D0E4] mb-1">Title</label>
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full bg-[#111122] border border-[#2D2B44] rounded-lg px-3 py-1.5 text-xs text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#D1D0E4] mb-1">Description</label>
                  <textarea
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                    rows={2}
                    className="w-full bg-[#111122] border border-[#2D2B44] rounded-lg px-3 py-1.5 text-xs text-white resize-none"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#2D2B44]">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-white font-medium">
                    <input
                      type="checkbox"
                      checked={editIsPaid}
                      onChange={(e) => setEditIsPaid(e.target.checked)}
                      className="rounded text-purple-600 focus:ring-0"
                    />
                    Paid Video (Pay LOT to Watch)
                  </label>

                  {editIsPaid && (
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-amber-400 font-bold">Price: £</span>
                      <input
                        type="number"
                        min="1"
                        max="10000"
                        value={editPriceLot}
                        onChange={(e) => setEditPriceLot(e.target.value)}
                        className="w-20 bg-[#111122] border border-amber-500/40 rounded px-2 py-0.5 text-xs text-amber-300"
                      />
                      <span className="text-xs text-amber-400 font-bold">LOT</span>
                    </div>
                  )}
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="submit"
                    disabled={savingEdit}
                    className="px-4 py-1.5 rounded-lg text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white disabled:opacity-50"
                  >
                    {savingEdit ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Video Table List */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#A5A3B8]">Your Uploaded Content</h3>

            {loading ? (
              <div className="text-center py-8 text-xs text-[#A5A3B8]">Loading studio content...</div>
            ) : videos.length === 0 ? (
              <div className="text-center py-12 text-xs text-[#787693] bg-[#141426] rounded-xl border border-[#25253C]">
                You haven't uploaded any videos yet. Click "Upload Video" to start sharing!
              </div>
            ) : (
              <div className="space-y-2">
                {videos.map((v) => (
                  <div
                    key={v.id}
                    className="p-3 bg-[#141426] border border-[#25253C] rounded-xl flex items-center justify-between gap-3 hover:border-[#383556] transition-colors"
                  >
                    {/* Thumbnail & Title */}
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-16 h-10 bg-[#1C1C30] rounded-lg overflow-hidden shrink-0 relative">
                        {v.thumbnailUrl ? (
                          <img src={v.thumbnailUrl} alt={v.title} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-purple-400">
                            <Tv className="w-4 h-4" />
                          </div>
                        )}
                        <span className="absolute bottom-0.5 right-0.5 text-[9px] bg-black/80 text-white px-1 rounded">
                          {v.type === 'short' ? 'SHORT' : 'VIDEO'}
                        </span>
                      </div>

                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white truncate max-w-sm">{v.title}</div>
                        <div className="flex items-center gap-2 text-[10px] text-[#A5A3B8] mt-0.5">
                          <span>{formatCompactNumber(v.viewsCount || 0)} views</span>
                          <span>•</span>
                          <span>{v.likesCount || 0} likes</span>
                          <span>•</span>
                          {v.isPaid ? (
                            <span className="text-amber-400 font-bold flex items-center gap-0.5">
                              <Lock className="w-2.5 h-2.5" />
                              £{v.priceLot} LOT ({v.purchasesCount || 0} sold)
                            </span>
                          ) : (
                            <span className="text-emerald-400">Free</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => handleStartEdit(v)}
                        className="p-2 rounded-lg bg-[#1F1F38] hover:bg-[#2B2B4A] text-purple-300 hover:text-white transition-colors"
                        title="Edit Details & Price"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(v.id)}
                        className="p-2 rounded-lg bg-red-950/40 hover:bg-red-950 text-red-400 hover:text-red-200 transition-colors"
                        title="Delete Video"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
