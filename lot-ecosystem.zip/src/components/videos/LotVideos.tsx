import React, { useState, useEffect } from 'react';
import {
  Search,
  Upload,
  Tv,
  Film,
  TrendingUp,
  Clock,
  Bookmark,
  Users,
  Coins,
  Lock,
  Unlock,
  Play,
  Sparkles,
  Filter,
  CheckCircle2,
  RefreshCw,
  FolderHeart,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';
import { LotVideo } from './types';
import { VideoPlayerModal } from './VideoPlayerModal';
import { UploadVideoModal } from './UploadVideoModal';
import { CreatorStudioModal } from './CreatorStudioModal';
import { LotShorts } from '../shorts/LotShorts';

const CATEGORIES = [
  'All',
  'Gaming',
  'Technology',
  'Music',
  'Education',
  'Entertainment',
  'Comedy',
  'News',
  'Finance & Crypto',
  'Sports',
  'Tutorials & How-To',
];

export const LotVideos: React.FC = () => {
  const { user, openAuthModal } = useAuth();
  const [section, setSection] = useState<string>('all'); // all, long, shorts, trending, subscriptions, history, purchased
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [videos, setVideos] = useState<LotVideo[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Modals
  const [activeVideo, setActiveVideo] = useState<LotVideo | null>(null);
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [showStudioModal, setShowStudioModal] = useState<boolean>(false);

  // Fetch videos feed based on active section and category
  const fetchVideos = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (section !== 'all') params.set('section', section);
      if (selectedCategory !== 'All') params.set('category', selectedCategory);
      if (searchQuery.trim()) params.set('search', searchQuery.trim());

      const res = await fetch(`/api/videos/feed?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setVideos(data.videos || []);
      }
    } catch (e) {
      console.error('Failed to fetch videos:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVideos();
  }, [section, selectedCategory]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchVideos();
  };

  const formatDuration = (secs: number) => {
    if (!secs || isNaN(secs)) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const handleVideoCardClick = (video: LotVideo) => {
    setActiveVideo(video);
  };

  const handleVideoUpdated = (updated: LotVideo) => {
    setVideos((prev) => prev.map((v) => (v.id === updated.id ? updated : v)));
    if (activeVideo && activeVideo.id === updated.id) {
      setActiveVideo(updated);
    }
  };

  const handleVideoUploaded = (newVideo: LotVideo) => {
    setVideos((prev) => [newVideo, ...prev]);
    setActiveVideo(newVideo);
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Top Banner / Actions Bar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-[#121124] via-[#1A1833] to-[#121124] border border-[#2F2D48] rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <Tv className="w-4 h-4" />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-wide">LOT Videos</h1>
            <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-md bg-purple-900/60 text-purple-300 border border-purple-500/30">
              HUB
            </span>
          </div>
          <p className="text-xs text-[#A5A3B8]">
            Discover long-form videos, LOT Shorts, and monetize exclusive content with £ LOT currency.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
          <button
            onClick={() => {
              if (!user) {
                openAuthModal();
                return;
              }
              setShowStudioModal(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#1C1C33] border border-[#302D46] text-[#C4B5FD] hover:bg-[#252542] hover:text-white transition-all cursor-pointer shadow-sm"
          >
            <Tv className="w-4 h-4 text-purple-400" />
            <span>Creator Studio</span>
          </button>

          <button
            onClick={() => {
              if (!user) {
                openAuthModal();
                return;
              }
              setShowUploadModal(true);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/20 transition-all cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>Upload Video</span>
          </button>
        </div>
      </div>

      {/* Navigation Sections & Search Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        {/* Section Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'all', label: 'All Content', icon: Tv },
            { id: 'long', label: 'Long Videos', icon: Film },
            { id: 'shorts', label: 'Shorts', icon: Sparkles },
            { id: 'trending', label: 'Trending', icon: TrendingUp },
            { id: 'subscriptions', label: 'Subscriptions', icon: Users },
            { id: 'purchased', label: 'Purchased Videos', icon: Coins },
            { id: 'history', label: 'History', icon: Clock },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = section === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setSection(item.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-500/20'
                    : 'bg-[#151528] text-[#A5A3B8] border border-[#28263E] hover:text-white hover:bg-[#1C1C33]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearchSubmit} className="relative w-full lg:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search videos, creators, tags..."
            className="w-full bg-[#151528] border border-[#28263E] rounded-xl pl-9 pr-8 py-2 text-xs text-white placeholder-[#787693] focus:outline-none focus:border-purple-500"
          />
          <Search className="w-4 h-4 text-[#787693] absolute left-3 top-2.5" />
          {searchQuery && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setTimeout(fetchVideos, 50);
              }}
              className="text-xs text-[#A5A3B8] hover:text-white absolute right-3 top-2"
            >
              ×
            </button>
          )}
        </form>
      </div>

      {/* Conditional: For Shorts section, render the single-item vertical player with scroll buttons; for long videos, keep the grid as it is */}
      {section === 'shorts' ? (
        <div className="w-full pt-1">
          <LotShorts />
        </div>
      ) : (
        <>
          {/* Category Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-gradient-to-r from-purple-700 to-indigo-700 text-white border border-purple-400/40 shadow-sm'
                    : 'bg-[#141426] text-[#A5A3B8] border border-[#24233A] hover:bg-[#1B1B30] hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Video Content Grid for Long Videos */}
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 text-[#A5A3B8] space-y-3">
              <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
              <span className="text-xs">Loading LOT Videos...</span>
            </div>
          ) : videos.length === 0 ? (
        <div className="p-12 text-center bg-[#111122] border border-[#27253D] rounded-2xl space-y-3">
          <Tv className="w-10 h-10 mx-auto text-[#6A6882]" />
          <h3 className="text-base font-bold text-white">No videos found</h3>
          <p className="text-xs text-[#A5A3B8] max-w-sm mx-auto">
            {section === 'purchased'
              ? 'You have not purchased any paid videos yet. Browse videos to find premium content!'
              : section === 'history'
              ? 'You have no watch history yet. Start watching videos to keep track of your progress.'
              : 'Try selecting a different category, clearing search, or be the first to upload a video!'}
          </p>
          <button
            onClick={() => {
              setSection('all');
              setSelectedCategory('All');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
          {videos.map((video) => {
            const isShort = video.type === 'short';
            const isPaid = video.isPaid;
            const isUnlocked = video.isUnlocked;

            return (
              <div
                key={video.id}
                onClick={() => handleVideoCardClick(video)}
                className="group bg-[#121224] border border-[#26243C] hover:border-purple-500/50 rounded-2xl overflow-hidden cursor-pointer transition-all hover:scale-[1.02] hover:shadow-xl hover:shadow-purple-500/10 flex flex-col"
              >
                {/* Thumbnail Container */}
                <div
                  className={`relative w-full bg-black overflow-hidden ${
                    isShort ? 'aspect-[9/14]' : 'aspect-video'
                  }`}
                >
                  {video.thumbnailUrl ? (
                    <img
                      src={video.thumbnailUrl}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : video.source === 'youtube' && video.youtubeVideoId ? (
                    <img
                      src={`https://img.youtube.com/vi/${video.youtubeVideoId}/hqdefault.jpg`}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[#1A1830] to-[#0F0E1F] text-purple-400">
                      <Tv className="w-10 h-10 opacity-40" />
                    </div>
                  )}

                  {/* Play Hover Overlay */}
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <div className="w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center shadow-lg">
                      <Play className="w-5 h-5 ml-0.5 fill-white" />
                    </div>
                  </div>

                  {/* Format & Duration Badge */}
                  <div className="absolute bottom-2 right-2 flex items-center gap-1.5">
                    {isShort && (
                      <span className="bg-purple-900/90 text-purple-200 text-[10px] font-bold px-1.5 py-0.5 rounded shadow">
                        SHORT
                      </span>
                    )}
                    <span className="bg-black/80 backdrop-blur-sm text-white text-[11px] font-medium px-2 py-0.5 rounded shadow">
                      {formatDuration(video.duration)}
                    </span>
                  </div>

                  {/* Paid / Unlocked Badge */}
                  {isPaid && (
                    <div className="absolute top-2 left-2">
                      {isUnlocked ? (
                        <span className="flex items-center gap-1 bg-emerald-950/90 border border-emerald-500/50 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full shadow-md backdrop-blur-sm">
                          <Unlock className="w-3 h-3 text-emerald-400" />
                          UNLOCKED
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 bg-amber-950/90 border border-amber-500/50 text-amber-300 text-[10px] font-extrabold px-2 py-0.5 rounded-full shadow-md backdrop-blur-sm animate-pulse">
                          <Lock className="w-3 h-3 text-amber-400" />
                          £{video.priceLot} LOT
                        </span>
                      )}
                    </div>
                  )}

                  {/* Continue Watching Progress Bar */}
                  {video.continueProgress && video.continueProgress > 0 && (
                    <div className="absolute bottom-0 inset-x-0 h-1 bg-white/20">
                      <div
                        className="h-full bg-purple-500 transition-all"
                        style={{ width: `${video.continueProgress}%` }}
                      />
                    </div>
                  )}
                </div>

                {/* Video Card Details */}
                <div className="p-3.5 flex gap-3 flex-1">
                  {/* Creator Avatar */}
                  <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white font-bold text-xs shrink-0 overflow-hidden ring-1 ring-purple-500/30">
                    {video.creatorAvatar ? (
                      <img
                        src={video.creatorAvatar}
                        alt={video.creatorUsername}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      video.creatorUsername.charAt(0).toUpperCase()
                    )}
                  </div>

                  {/* Text Details */}
                  <div className="flex-1 min-w-0 space-y-1">
                    <h3 className="text-xs font-bold text-white line-clamp-2 leading-snug group-hover:text-purple-300 transition-colors">
                      {video.title}
                    </h3>

                    <div className="text-[11px] text-[#A5A3B8] flex items-center gap-1">
                      <span className="truncate">@{video.creatorUsername}</span>
                      <CheckCircle2 className="w-3 h-3 text-purple-400 shrink-0" />
                    </div>

                    <div className="flex items-center gap-2 text-[10px] text-[#787693]">
                      <span>{formatCompactNumber(video.viewsCount || 0)} views</span>
                      <span>•</span>
                      <span>{new Date(video.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  )}

      {/* Video Player Modal */}
      {activeVideo && (
        <VideoPlayerModal
          video={activeVideo}
          onClose={() => setActiveVideo(null)}
          onVideoUpdated={handleVideoUpdated}
        />
      )}

      {/* Video Upload Modal */}
      {showUploadModal && (
        <UploadVideoModal
          onClose={() => setShowUploadModal(false)}
          onSuccess={handleVideoUploaded}
        />
      )}

      {/* Creator Studio Modal */}
      {showStudioModal && (
        <CreatorStudioModal
          onClose={() => setShowStudioModal(false)}
          onVideoChanged={fetchVideos}
        />
      )}
    </div>
  );
};
