import React, { useState } from 'react';
import {
  X,
  Upload,
  Smartphone,
  Image as ImageIcon,
  Coins,
  Lock,
  Unlock,
  AlertCircle,
  FileCode,
  Info,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { AppRecord } from './types';

interface PublishAppModalProps {
  onClose: () => void;
  onSuccess: (newApp: AppRecord) => void;
}

const CATEGORIES = [
  'Games',
  'Productivity',
  'Finance',
  'Tools',
  'Social',
  'Entertainment',
  'Utilities',
  'Education',
  'Lifestyle',
];

export const PublishAppModal: React.FC<PublishAppModalProps> = ({ onClose, onSuccess }) => {
  const { user } = useAuth();
  const [name, setName] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Games');
  const [version, setVersion] = useState('1.0.0');
  const [isPaid, setIsPaid] = useState(false);
  const [priceLot, setPriceLot] = useState('10');

  const [packageFile, setPackageFile] = useState<File | null>(null);
  const [isAab, setIsAab] = useState(false);
  const [iconFile, setIconFile] = useState<File | null>(null);
  const [iconPreview, setIconPreview] = useState<string | null>(null);
  const [screenshotFiles, setScreenshotFiles] = useState<File[]>([]);

  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePackageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPackageFile(file);
      setIsAab(file.name.toLowerCase().endsWith('.aab'));
      setError(null);
    }
  };

  const handleIconSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setIconFile(file);
      setIconPreview(URL.createObjectURL(file));
    }
  };

  const handleScreenshotsSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setScreenshotFiles(Array.from(e.target.files).slice(0, 5));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('App display name is required.');
      return;
    }
    if (!packageFile) {
      setError('APK or AAB application package file is required.');
      return;
    }
    if (!description.trim()) {
      setError('App description is required.');
      return;
    }
    if (isPaid && (parseFloat(priceLot) <= 0 || isNaN(parseFloat(priceLot)))) {
      setError('Please specify a valid price in LOT (minimum £1 LOT).');
      return;
    }

    setPublishing(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('name', name.trim());
      formData.append('description', description.trim());
      formData.append('shortDescription', shortDescription.trim());
      formData.append('category', category);
      formData.append('version', version.trim());
      formData.append('isPaid', String(isPaid));
      formData.append('priceLot', isPaid ? priceLot : '0');
      formData.append('package', packageFile);
      if (iconFile) formData.append('icon', iconFile);
      screenshotFiles.forEach((file) => formData.append('screenshots', file));

      const res = await fetch('/api/apps/publish', {
        method: 'POST',
        headers: user?.token ? { Authorization: `Bearer ${user.token}` } : {},
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to publish application');
      }

      onSuccess(data.app);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Publishing failed');
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#111122] border border-[#2D2B44] rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#16162D] border-b border-[#2D2B44] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-600/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Publish Android App</h2>
              <p className="text-[11px] text-[#A5A3B8]">Distribute your APK to LOT Ecosystem users worldwide</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-[#A5A3B8] hover:text-white hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-xl text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* App Name & Developer Info */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">
                App Display Name <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. LOT Pixel Runner 3D"
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Version Number</label>
              <input
                type="text"
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                placeholder="1.0.0"
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                required
              />
            </div>
          </div>

          {/* Developer attribution note */}
          <div className="p-2.5 bg-[#141426] border border-[#27253D] rounded-xl flex items-center justify-between text-xs text-[#A5A3B8]">
            <span>Published as Developer:</span>
            <span className="font-bold text-purple-300">@{user?.username}</span>
          </div>

          {/* Upload Package (APK / AAB) */}
          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1">
              Android Package File (APK or AAB) <span className="text-red-400">*</span>
            </label>
            <div className="relative border-2 border-dashed border-[#302D46] hover:border-purple-500/60 rounded-xl p-4 bg-[#141426] text-center transition-colors">
              <input
                type="file"
                accept=".apk,.aab"
                onChange={handlePackageSelect}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              {packageFile ? (
                <div className="flex items-center justify-center gap-3">
                  <FileCode className="w-6 h-6 text-purple-400" />
                  <div className="text-left">
                    <span className="text-xs font-bold text-white block">{packageFile.name}</span>
                    <span className="text-[10px] text-purple-300">
                      {((packageFile.size || 0) / (1024 * 1024)).toFixed(1)} MB • {isAab ? 'Android App Bundle' : 'Direct APK'}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="space-y-1">
                  <Smartphone className="w-7 h-7 mx-auto text-purple-400" />
                  <div className="text-xs font-semibold text-white">Click or drag your APK / AAB package</div>
                  <div className="text-[10px] text-[#787693]">
                    APK is directly installable on Android devices. AAB is supported as publishing format.
                  </div>
                </div>
              )}
            </div>

            {isAab && (
              <div className="mt-2 p-2.5 bg-amber-950/40 border border-amber-500/30 rounded-xl text-[11px] text-amber-300 flex items-start gap-2">
                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                <span>
                  Notice: AAB format requires building into an APK for direct device installation. Users downloading this file may need bundletool or compatible package installer.
                </span>
              </div>
            )}
          </div>

          {/* App Icon Upload */}
          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1">App Icon / Logo</label>
            <div className="relative border border-[#2D2B44] rounded-xl p-3 bg-[#141426] flex items-center justify-between">
              <div className="flex items-center gap-3">
                {iconPreview ? (
                  <img src={iconPreview} alt="App logo preview" className="w-12 h-12 object-contain rounded-xl bg-black border border-purple-500/30" />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-[#1D1D34] border border-[#2D2B44] flex items-center justify-center text-[#787693]">
                    <ImageIcon className="w-5 h-5" />
                  </div>
                )}
                <div>
                  <span className="text-xs font-semibold text-white block">
                    {iconFile ? iconFile.name : 'Square 512x512 logo recommended'}
                  </span>
                  <span className="text-[10px] text-[#787693]">PNG or JPG format</span>
                </div>
              </div>
              <input type="file" accept="image/*" onChange={handleIconSelect} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
              <span className="text-xs text-purple-400 font-bold px-3 py-1 bg-purple-950/50 rounded-lg border border-purple-500/20">
                Browse
              </span>
            </div>
          </div>

          {/* Category & Short Description */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c} className="bg-[#10101F]">
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#D1D0E4] mb-1">Short Tagline</label>
              <input
                type="text"
                value={shortDescription}
                onChange={(e) => setShortDescription(e.target.value)}
                placeholder="Quick 1-sentence summary"
                className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                maxLength={90}
              />
            </div>
          </div>

          {/* Full Description */}
          <div>
            <label className="block text-xs font-bold text-[#D1D0E4] mb-1">
              Full App Description <span className="text-red-400">*</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Detail your application features, gameplay, requirements, and update changelog..."
              rows={3}
              className="w-full bg-[#16162A] border border-[#2D2B44] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-purple-500 resize-none"
              required
            />
          </div>

          {/* Monetization: Free or Paid */}
          <div className="p-4 bg-gradient-to-r from-[#17162E] to-[#1E1933] border border-amber-500/30 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  {isPaid ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    Paid Android Application
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-extrabold">
                      LOT EARNINGS
                    </span>
                  </div>
                  <div className="text-[10px] text-[#A5A3B8]">
                    Users pay once in £ LOT currency for permanent lifetime download access
                  </div>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={isPaid}
                  onChange={(e) => setIsPaid(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-10 h-5 bg-[#25253E] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
              </label>
            </div>

            {isPaid && (
              <div className="pt-2 border-t border-amber-500/20 flex items-center justify-between gap-4">
                <div className="text-[11px] text-[#D1D0E4]">
                  Price to Download (credited directly to your LOT account on each purchase):
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-amber-400">£</span>
                  <input
                    type="number"
                    min="1"
                    max="10000"
                    value={priceLot}
                    onChange={(e) => setPriceLot(e.target.value)}
                    className="w-24 bg-[#10101F] border border-amber-500/40 rounded-lg px-2.5 py-1 text-xs font-bold text-amber-300 focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-xs font-bold text-amber-400">LOT</span>
                </div>
              </div>
            )}
          </div>

          {/* Submit Actions */}
          <div className="pt-3 flex items-center justify-end gap-3 border-t border-[#252538]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-[#A5A3B8] hover:bg-white/5"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={publishing || !packageFile || !name.trim()}
              className="px-6 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/20 disabled:opacity-50 flex items-center gap-2 cursor-pointer"
            >
              {publishing ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Publishing Application...
                </>
              ) : (
                <>
                  <Upload className="w-3.5 h-3.5" />
                  Publish to App Store
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
