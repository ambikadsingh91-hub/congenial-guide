import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  Coins,
  Download,
  Star,
  Edit2,
  Trash2,
  Upload,
  CheckCircle2,
  AlertCircle,
  FileCode,
  Layers,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';
import { AppRecord, DeveloperStats } from './types';

interface DeveloperDashboardModalProps {
  onClose: () => void;
  onAppChanged?: () => void;
}

export const DeveloperDashboardModal: React.FC<DeveloperDashboardModalProps> = ({
  onClose,
  onAppChanged,
}) => {
  const { user } = useAuth();
  const [apps, setApps] = useState<AppRecord[]>([]);
  const [analytics, setAnalytics] = useState<DeveloperStats>({
    totalApps: 0,
    totalDownloads: 0,
    totalEarnedLot: 0,
  });
  const [loading, setLoading] = useState(true);

  // Edit App State
  const [editingApp, setEditingApp] = useState<AppRecord | null>(null);
  const [editName, setEditName] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editIsPaid, setEditIsPaid] = useState(false);
  const [editPriceLot, setEditPriceLot] = useState('0');
  const [savingEdit, setSavingEdit] = useState(false);

  // Version Update State
  const [versioningApp, setVersioningApp] = useState<AppRecord | null>(null);
  const [newVersion, setNewVersion] = useState('');
  const [changelog, setChangelog] = useState('');
  const [versionFile, setVersionFile] = useState<File | null>(null);
  const [uploadingVersion, setUploadingVersion] = useState(false);

  const [message, setMessage] = useState<string | null>(null);

  const fetchDeveloperApps = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/developer/apps');
      if (res.ok) {
        const data = await res.json();
        setApps(data.apps || []);
        if (data.analytics) setAnalytics(data.analytics);
      }
    } catch (e) {
      console.error('Failed to load developer apps:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDeveloperApps();
  }, []);

  const handleStartEdit = (app: AppRecord) => {
    setEditingApp(app);
    setEditName(app.name);
    setEditDescription(app.description);
    setEditIsPaid(app.isPaid);
    setEditPriceLot(String(app.priceLot || 10));
    setMessage(null);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingApp) return;
    setSavingEdit(true);

    try {
      const res = await fetch(`/api/developer/apps/${editingApp.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editName,
          description: editDescription,
          isPaid: editIsPaid,
          priceLot: editIsPaid ? parseFloat(editPriceLot) : 0,
        }),
      });

      if (res.ok) {
        setMessage('Application updated successfully!');
        setEditingApp(null);
        fetchDeveloperApps();
        if (onAppChanged) onAppChanged();
      }
    } catch (e) {
      console.error('Edit error:', e);
    } finally {
      setSavingEdit(false);
    }
  };

  const handleUploadVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!versioningApp || !versionFile || !newVersion.trim()) return;
    setUploadingVersion(true);

    try {
      const formData = new FormData();
      formData.append('package', versionFile);
      formData.append('version', newVersion.trim());
      formData.append('changelog', changelog.trim());

      const res = await fetch(`/api/developer/apps/${versioningApp.id}/version`, {
        method: 'POST',
        body: formData,
      });

      if (res.ok) {
        setMessage(`Updated to version ${newVersion}! All existing owners receive this update automatically.`);
        setVersioningApp(null);
        setVersionFile(null);
        fetchDeveloperApps();
        if (onAppChanged) onAppChanged();
      }
    } catch (e) {
      console.error('Version upload error:', e);
    } finally {
      setUploadingVersion(false);
    }
  };

  const handleDelete = async (appId: string) => {
    if (!confirm('Are you sure you want to unpublish this application?')) return;

    try {
      const res = await fetch(`/api/developer/apps/${appId}`, { method: 'DELETE' });
      if (res.ok) {
        setApps((prev) => prev.filter((a) => a.id !== appId));
        setMessage('Application unpublished from LOT App Store.');
        if (onAppChanged) onAppChanged();
      }
    } catch (e) {
      console.error('Delete error:', e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#10101F] border border-[#2D2B44] rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#15152B] border-b border-[#2D2B44] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">LOT Developer Dashboard</h2>
              <p className="text-[11px] text-[#A5A3B8]">Manage your published APKs, updates, and earnings</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-[#A5A3B8] hover:text-white hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {message && (
            <div className="p-3 bg-purple-950/60 border border-purple-500/40 rounded-xl text-purple-200 text-xs">
              {message}
            </div>
          )}

          {/* Metric KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 bg-[#16162D] border border-[#28263E] rounded-xl space-y-1">
              <div className="flex items-center justify-between text-[#A5A3B8] text-xs">
                <span>Published Apps</span>
                <Smartphone className="w-4 h-4 text-purple-400" />
              </div>
              <div className="text-2xl font-black text-white">{analytics.totalApps}</div>
            </div>

            <div className="p-4 bg-[#16162D] border border-[#28263E] rounded-xl space-y-1">
              <div className="flex items-center justify-between text-[#A5A3B8] text-xs">
                <span>Total Downloads</span>
                <Download className="w-4 h-4 text-blue-400" />
              </div>
              <div className="text-2xl font-black text-white">{formatCompactNumber(analytics.totalDownloads)}</div>
            </div>

            <div className="p-4 bg-gradient-to-br from-[#1C1833] to-[#261E40] border border-amber-500/30 rounded-xl space-y-1">
              <div className="flex items-center justify-between text-amber-300 text-xs font-semibold">
                <span>Total LOT Earnings</span>
                <Coins className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-amber-400">
                £{analytics.totalEarnedLot.toLocaleString()} LOT
              </div>
            </div>
          </div>

          {/* Edit Details Drawer */}
          {editingApp && (
            <div className="p-4 bg-[#181830] border border-purple-500/40 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                  <Edit2 className="w-3.5 h-3.5" />
                  Edit Application Details: {editingApp.name}
                </span>
                <button onClick={() => setEditingApp(null)} className="text-xs text-[#A5A3B8] hover:text-white">
                  Cancel
                </button>
              </div>

              <form onSubmit={handleSaveEdit} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold text-[#D1D0E4] mb-1">App Name</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-[#111122] border border-[#2D2B44] rounded-lg px-3 py-1.5 text-xs text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#D1D0E4] mb-1">Description</label>
                  <textarea
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                    rows={2}
                    className="w-full bg-[#111122] border border-[#2D2B44] rounded-lg px-3 py-1.5 text-xs text-white resize-none"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#2D2B44]">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-white font-medium">
                    <input
                      type="checkbox"
                      checked={editIsPaid}
                      onChange={(e) => setEditIsPaid(e.target.checked)}
                      className="rounded text-purple-600 focus:ring-0"
                    />
                    Paid Application
                  </label>

                  {editIsPaid && (
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-amber-400 font-bold">Price: £</span>
                      <input
                        type="number"
                        min="1"
                        max="10000"
                        value={editPriceLot}
                        onChange={(e) => setEditPriceLot(e.target.value)}
                        className="w-20 bg-[#111122] border border-amber-500/40 rounded px-2 py-0.5 text-xs text-amber-300"
                      />
                      <span className="text-xs text-amber-400 font-bold">LOT</span>
                    </div>
                  )}
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="submit"
                    disabled={savingEdit}
                    className="px-4 py-1.5 rounded-lg text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white disabled:opacity-50"
                  >
                    {savingEdit ? 'Saving...' : 'Save Details'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* New APK Version Drawer */}
          {versioningApp && (
            <div className="p-4 bg-[#181830] border border-purple-500/40 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                  <Upload className="w-3.5 h-3.5" />
                  Upload New Version for {versioningApp.name} (Current: v{versioningApp.version})
                </span>
                <button onClick={() => setVersioningApp(null)} className="text-xs text-[#A5A3B8] hover:text-white">
                  Cancel
                </button>
              </div>

              <form onSubmit={handleUploadVersion} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-[#D1D0E4] mb-1">New Version String</label>
                    <input
                      type="text"
                      value={newVersion}
                      onChange={(e) => setNewVersion(e.target.value)}
                      placeholder="e.g. 1.1.0"
                      className="w-full bg-[#111122] border border-[#2D2B44] rounded-lg px-3 py-1.5 text-xs text-white"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-[#D1D0E4] mb-1">Select New APK / AAB</label>
                    <input
                      type="file"
                      accept=".apk,.aab"
                      onChange={(e) => setVersionFile(e.target.files ? e.target.files[0] : null)}
                      className="w-full text-xs text-[#A5A3B8]"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#D1D0E4] mb-1">Changelog / What's New</label>
                  <input
                    type="text"
                    value={changelog}
                    onChange={(e) => setChangelog(e.target.value)}
                    placeholder="Bug fixes, performance improvements, new features..."
                    className="w-full bg-[#111122] border border-[#2D2B44] rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="submit"
                    disabled={uploadingVersion || !versionFile || !newVersion}
                    className="px-4 py-1.5 rounded-lg text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white disabled:opacity-50"
                  >
                    {uploadingVersion ? 'Uploading...' : 'Publish Update'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Apps Table List */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#A5A3B8]">Your Published Apps</h3>

            {loading ? (
              <div className="text-center py-8 text-xs text-[#A5A3B8]">Loading apps...</div>
            ) : apps.length === 0 ? (
              <div className="text-center py-12 text-xs text-[#787693] bg-[#141426] rounded-xl border border-[#25253C]">
                You haven't published any Android applications yet. Click "Publish App" in the store to distribute your first APK!
              </div>
            ) : (
              <div className="space-y-2">
                {apps.map((a) => (
                  <div
                    key={a.id}
                    className="p-3 bg-[#141426] border border-[#25253C] rounded-xl flex items-center justify-between gap-3 hover:border-[#383556] transition-colors"
                  >
                    {/* App Info */}
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-12 h-12 bg-black rounded-xl border border-[#302D46] p-1 shrink-0 overflow-hidden">
                        <img src={a.iconUrl} alt={a.name} className="w-full h-full object-contain rounded-lg" />
                      </div>

                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white truncate max-w-sm flex items-center gap-2">
                          <span>{a.name}</span>
                          <span className="text-[10px] text-purple-300 bg-purple-950/60 px-1.5 py-0.2 rounded border border-purple-500/30">
                            v{a.version}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-[#A5A3B8] mt-0.5">
                          <span>{formatCompactNumber(a.downloadsCount || 0)} downloads</span>
                          <span>•</span>
                          <span className="flex items-center gap-0.5 text-amber-400">
                            <Star className="w-3 h-3 fill-amber-400" />
                            {a.rating?.toFixed(1) || '5.0'}
                          </span>
                          <span>•</span>
                          {a.isPaid ? (
                            <span className="text-amber-400 font-bold">£{a.priceLot} LOT</span>
                          ) : (
                            <span className="text-emerald-400">Free</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => {
                          setVersioningApp(a);
                          setNewVersion('');
                          setChangelog('');
                          setVersionFile(null);
                        }}
                        className="px-2.5 py-1.5 rounded-lg bg-purple-950/40 hover:bg-purple-900/60 text-purple-300 border border-purple-500/30 text-[11px] font-bold transition-colors flex items-center gap-1"
                        title="Upload New Version"
                      >
                        <Upload className="w-3 h-3" />
                        <span>Update APK</span>
                      </button>

                      <button
                        onClick={() => handleStartEdit(a)}
                        className="p-2 rounded-lg bg-[#1F1F38] hover:bg-[#2B2B4A] text-purple-300 hover:text-white transition-colors"
                        title="Edit Details & Price"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleDelete(a.id)}
                        className="p-2 rounded-lg bg-red-950/40 hover:bg-red-950 text-red-400 hover:text-red-200 transition-colors"
                        title="Unpublish Application"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
