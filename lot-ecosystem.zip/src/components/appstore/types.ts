export interface AppRecord {
  id: string;
  name: string;
  developerId: string;
  developerUsername: string;
  developerAvatar?: string;
  iconUrl: string;
  description: string;
  shortDescription?: string;
  category: string;
  version: string;
  fileUrl: string;
  fileName: string;
  fileSize: number; // in bytes
  fileType: 'apk' | 'aab';
  screenshots: string[];
  isPaid: boolean;
  priceLot: number;
  downloadsCount: number;
  rating: number; // 1.0 - 5.0
  ratingsCount: number;
  isFeatured: boolean;
  status: 'active' | 'suspended' | 'pending' | 'deleted';
  installInstructions?: string;
  createdAt: string;
  updatedAt: string;
  isPurchased?: boolean;
  isDeveloper?: boolean;
}

export interface AppReview {
  id: string;
  appId: string;
  userId: string;
  username: string;
  userAvatar?: string;
  rating: number; // 1-5
  comment: string;
  developerReply?: string;
  developerRepliedAt?: string;
  createdAt: string;
}

export interface DeveloperStats {
  totalApps: number;
  totalDownloads: number;
  totalEarnedLot: number;
}
