import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  Star,
  CheckCircle2,
  Coins,
  Lock,
  Unlock,
  Smartphone,
  Info,
  ShieldCheck,
  Calendar,
  Layers,
  MessageSquare,
  AlertCircle,
  HelpCircle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { AppRecord, AppReview } from './types';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';

interface AppDetailsModalProps {
  app: AppRecord;
  onClose: () => void;
  onAppUpdated: (updated: AppRecord) => void;
}

export const AppDetailsModal: React.FC<AppDetailsModalProps> = ({ app, onClose, onAppUpdated }) => {
  const { user, refreshUser, openAuthModal } = useAuth();
  const [reviews, setReviews] = useState<AppReview[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(true);

  // Purchase State
  const [purchasing, setPurchasing] = useState(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);
  const [purchaseSuccess, setPurchaseSuccess] = useState<string | null>(null);
  const [showPurchaseConfirm, setShowPurchaseConfirm] = useState(false);
  const [downloading, setDownloading] = useState(false);

  // Review Form
  const [myRating, setMyRating] = useState(5);
  const [myComment, setMyComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [showInstallGuide, setShowInstallGuide] = useState(true);

  const fetchAppDetails = async () => {
    try {
      setLoadingReviews(true);
      const res = await fetch(`/api/apps/${app.id}`);
      if (res.ok) {
        const data = await res.json();
        if (data.app) onAppUpdated(data.app);
        if (data.reviews) setReviews(data.reviews);
      }
    } catch (e) {
      console.error('Failed to load app reviews:', e);
    } finally {
      setLoadingReviews(false);
    }
  };

  useEffect(() => {
    fetchAppDetails();
  }, [app.id]);

  const handleDownload = () => {
    setDownloading(true);
    // Direct browser APK download endpoint
    const link = document.createElement('a');
    link.href = `/api/apps/${app.id}/download`;
    link.setAttribute('download', app.fileName || `${app.name}.apk`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setDownloading(false);
      onAppUpdated({ ...app, downloadsCount: (app.downloadsCount || 0) + 1 });
    }, 1500);
  };

  const handlePurchase = async () => {
    if (!user) {
      openAuthModal();
      return;
    }

    setPurchasing(true);
    setPurchaseError(null);

    try {
      const res = await fetch(`/api/apps/${app.id}/purchase`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to complete purchase.');
      }

      setPurchaseSuccess(data.message || 'App purchased successfully!');
      setShowPurchaseConfirm(false);
      refreshUser();

      const updated = { ...app, isPurchased: true };
      onAppUpdated(updated);

      // Auto start download after purchase
      setTimeout(() => {
        handleDownload();
      }, 500);
    } catch (err: any) {
      setPurchaseError(err.message || 'Purchase error');
    } finally {
      setPurchasing(false);
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      openAuthModal();
      return;
    }
    if (!myComment.trim()) return;

    setSubmittingReview(true);
    try {
      const res = await fetch(`/api/apps/${app.id}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating: myRating, comment: myComment.trim() }),
      });

      if (res.ok) {
        const data = await res.json();
        setReviews((prev) => [data.review, ...prev.filter((r) => r.userId !== user.id)]);
        setMyComment('');
        if (data.newAverageRating) {
          onAppUpdated({ ...app, rating: data.newAverageRating, ratingsCount: (app.ratingsCount || 0) + 1 });
        }
      }
    } catch (e) {
      console.error('Review submit error:', e);
    } finally {
      setSubmittingReview(false);
    }
  };

  const formatSize = (bytes: number) => {
    if (!bytes || bytes <= 0) return '18.4 MB';
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-[#10101F] border border-[#2D2B44] rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#15152B] border-b border-[#2D2B44] shrink-0">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-purple-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-purple-300">
              LOT Android Marketplace
            </span>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-[#A5A3B8] hover:text-white hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* App Hero / Title Section */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-20 h-20 rounded-2xl bg-black border border-[#302D46] p-1.5 shrink-0 overflow-hidden shadow-lg shadow-purple-500/10">
                <img src={app.iconUrl} alt={app.name} className="w-full h-full object-contain rounded-xl" />
              </div>

              <div className="space-y-1">
                <h1 className="text-xl sm:text-2xl font-black text-white">{app.name}</h1>
                <div className="text-xs text-[#A5A3B8] flex items-center gap-1.5">
                  <span className="font-semibold text-purple-300">@{app.developerUsername}</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                  <span>•</span>
                  <span>{app.category}</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-[#A5A3B8] pt-1">
                  <span className="flex items-center gap-1 text-amber-400 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    {app.rating ? app.rating.toFixed(1) : '5.0'} ({app.ratingsCount || 0})
                  </span>
                  <span>•</span>
                  <span>{formatCompactNumber(app.downloadsCount || 0)} downloads</span>
                  <span>•</span>
                  <span>v{app.version}</span>
                </div>
              </div>
            </div>

            {/* Action CTA Button */}
            <div className="sm:self-center shrink-0">
              {app.isPaid && !app.isPurchased ? (
                <button
                  onClick={() => setShowPurchaseConfirm(true)}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl font-bold text-xs sm:text-sm bg-gradient-to-r from-amber-500 to-purple-600 hover:from-amber-400 hover:to-purple-500 text-white shadow-lg shadow-purple-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all"
                >
                  <Coins className="w-4 h-4 text-amber-300" />
                  <span>Buy for £{app.priceLot} LOT</span>
                </button>
              ) : (
                <button
                  onClick={handleDownload}
                  disabled={downloading}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl font-bold text-xs sm:text-sm bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>
                    {downloading
                      ? 'Downloading APK...'
                      : app.isPaid
                      ? 'Download APK (Purchased)'
                      : 'Download APK (Free)'}
                  </span>
                </button>
              )}
            </div>
          </div>

          {/* Purchase Confirmation Popup / Drawer */}
          {showPurchaseConfirm && (
            <div className="p-4 bg-gradient-to-r from-[#1E1933] to-[#151426] border border-amber-500/40 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-amber-400" />
                  Confirm Application Purchase
                </span>
                <button onClick={() => setShowPurchaseConfirm(false)} className="text-xs text-[#A5A3B8] hover:text-white">
                  Cancel
                </button>
              </div>

              <p className="text-xs text-[#D1D0E4]">
                You are about to purchase a permanent lifetime license for <strong>{app.name}</strong>. You can download and receive all future updates for free.
              </p>

              <div className="bg-[#0E0D1A] p-3 rounded-lg flex items-center justify-between border border-[#2A2844]">
                <div>
                  <span className="text-[10px] text-[#A5A3B8] block">Price</span>
                  <span className="text-sm font-black text-amber-400">£{app.priceLot} LOT</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#A5A3B8] block">Your Balance</span>
                  <span className="text-sm font-bold text-purple-300">
                    £{(user?.lotBalance || 0).toLocaleString()} LOT
                  </span>
                </div>
              </div>

              {purchaseError && (
                <div className="p-2.5 bg-red-950/60 border border-red-500/40 rounded-lg text-red-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{purchaseError}</span>
                </div>
              )}

              <button
                onClick={handlePurchase}
                disabled={purchasing}
                className="w-full py-2.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-black shadow-md cursor-pointer disabled:opacity-50"
              >
                {purchasing ? 'Processing LOT Transaction...' : `Confirm & Deduct £${app.priceLot} LOT`}
              </button>
            </div>
          )}

          {purchaseSuccess && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{purchaseSuccess}</span>
            </div>
          )}

          {/* Quick Info Grid (Size, Version, Package Type, Security) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-[#151528] border border-[#25253C] rounded-xl text-center space-y-0.5">
              <span className="text-[10px] text-[#787693] uppercase font-bold">Package</span>
              <span className="text-xs font-bold text-white block uppercase">{app.fileType || 'APK'}</span>
            </div>
            <div className="p-3 bg-[#151528] border border-[#25253C] rounded-xl text-center space-y-0.5">
              <span className="text-[10px] text-[#787693] uppercase font-bold">File Size</span>
              <span className="text-xs font-bold text-white block">{formatSize(app.fileSize)}</span>
            </div>
            <div className="p-3 bg-[#151528] border border-[#25253C] rounded-xl text-center space-y-0.5">
              <span className="text-[10px] text-[#787693] uppercase font-bold">Updated</span>
              <span className="text-xs font-bold text-white block">
                {new Date(app.updatedAt || app.createdAt).toLocaleDateString()}
              </span>
            </div>
            <div className="p-3 bg-[#151528] border border-[#25253C] rounded-xl text-center space-y-0.5">
              <span className="text-[10px] text-[#787693] uppercase font-bold">Security</span>
              <span className="text-xs font-bold text-emerald-400 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> Verified
              </span>
            </div>
          </div>

          {/* Android Installation Instructions Accordion */}
          <div className="border border-[#2D2B44] bg-[#141424] rounded-xl overflow-hidden">
            <button
              onClick={() => setShowInstallGuide((p) => !p)}
              className="w-full p-3.5 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-bold text-white">How to Install this APK on your Android Device</span>
              </div>
              {showInstallGuide ? <ChevronUp className="w-4 h-4 text-[#A5A3B8]" /> : <ChevronDown className="w-4 h-4 text-[#A5A3B8]" />}
            </button>

            {showInstallGuide && (
              <div className="p-4 pt-0 text-xs text-[#A5A3B8] space-y-2.5 border-t border-[#252538] mt-1">
                <div className="flex gap-2.5 items-start">
                  <div className="w-5 h-5 rounded-full bg-purple-600/30 text-purple-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    1
                  </div>
                  <div>
                    <span className="font-bold text-white">Download APK:</span> Tap the Download APK button above. The file will save directly to your Android device.
                  </div>
                </div>

                <div className="flex gap-2.5 items-start">
                  <div className="w-5 h-5 rounded-full bg-purple-600/30 text-purple-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    2
                  </div>
                  <div>
                    <span className="font-bold text-white">Open the Package:</span> Open the download notification in your notification tray, or open your Android Files app and tap the APK.
                  </div>
                </div>

                <div className="flex gap-2.5 items-start">
                  <div className="w-5 h-5 rounded-full bg-purple-600/30 text-purple-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    3
                  </div>
                  <div>
                    <span className="font-bold text-white">Allow Unknown Apps:</span> If Android shows "Install unknown apps" security prompt, tap Settings and turn on "Allow from this source".
                  </div>
                </div>

                <div className="flex gap-2.5 items-start">
                  <div className="w-5 h-5 rounded-full bg-purple-600/30 text-purple-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    4
                  </div>
                  <div>
                    <span className="font-bold text-white">Tap Install:</span> Tap Install to finish. The app will appear on your Android home screen!
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Screenshots Gallery */}
          {app.screenshots && app.screenshots.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-[#D1D0E4] uppercase tracking-wider">Screenshots</h3>
              <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
                {app.screenshots.map((s, idx) => (
                  <img
                    key={idx}
                    src={s}
                    alt={`Screenshot ${idx + 1}`}
                    className="h-44 sm:h-52 rounded-xl border border-[#2D2B44] object-cover shadow-md shrink-0"
                  />
                ))}
              </div>
            </div>
          )}

          {/* Description */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-[#D1D0E4] uppercase tracking-wider">About This App</h3>
            <p className="text-xs text-[#D1D0E4] whitespace-pre-line leading-relaxed bg-[#131322] p-4 rounded-xl border border-[#252538]">
              {app.description}
            </p>
          </div>

          {/* Reviews & Ratings */}
          <div className="space-y-4 pt-4 border-t border-[#252538]">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5 uppercase tracking-wider">
                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                Ratings & Reviews ({reviews.length})
              </h3>
            </div>

            {/* Submit Review Form */}
            {user ? (
              <form onSubmit={handleReviewSubmit} className="p-3.5 bg-[#151528] border border-[#28263E] rounded-xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-white">Rate this app:</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setMyRating(star)}
                        className="p-1 hover:scale-110 transition-transform"
                      >
                        <Star
                          className={`w-4 h-4 ${
                            star <= myRating ? 'text-amber-400 fill-amber-400' : 'text-[#4A4860]'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={myComment}
                    onChange={(e) => setMyComment(e.target.value)}
                    placeholder="Share your experience with this app..."
                    className="flex-1 bg-[#10101F] border border-[#2D2B44] rounded-lg px-3 py-1.5 text-xs text-white placeholder-[#787693] focus:outline-none focus:border-purple-500"
                  />
                  <button
                    type="submit"
                    disabled={!myComment.trim() || submittingReview}
                    className="px-4 py-1.5 rounded-lg text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white disabled:opacity-40"
                  >
                    Submit
                  </button>
                </div>
              </form>
            ) : (
              <div className="text-xs text-[#A5A3B8] p-3 bg-[#151528] rounded-xl border border-[#25253C]">
                Sign in to post a rating and review for this app.
              </div>
            )}

            {/* Reviews List */}
            <div className="space-y-3">
              {loadingReviews ? (
                <div className="text-center py-4 text-xs text-[#A5A3B8]">Loading reviews...</div>
              ) : reviews.length === 0 ? (
                <div className="text-center py-6 text-xs text-[#787693]">
                  No reviews yet. Be the first to rate this application!
                </div>
              ) : (
                reviews.map((r) => (
                  <div key={r.id} className="p-3 bg-[#131322] border border-[#252538] rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">@{r.username}</span>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-3 h-3 ${
                                s <= r.rating ? 'text-amber-400 fill-amber-400' : 'text-[#4A4860]'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <span className="text-[10px] text-[#787693]">
                        {new Date(r.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <p className="text-xs text-[#D1D0E4] leading-relaxed">{r.comment}</p>

                    {r.developerReply && (
                      <div className="mt-2 p-2.5 bg-[#1B1930] border-l-2 border-purple-500 rounded-r-lg space-y-1 text-xs">
                        <div className="flex items-center gap-1.5 text-purple-300 font-bold text-[11px]">
                          <MessageSquare className="w-3 h-3" />
                          Developer Response
                        </div>
                        <p className="text-[#C4B5FD] text-[11px]">{r.developerReply}</p>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
