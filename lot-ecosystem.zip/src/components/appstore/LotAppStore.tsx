import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Search,
  Upload,
  Coins,
  Download,
  Star,
  Sparkles,
  TrendingUp,
  Clock,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Unlock,
  Gamepad2,
  Briefcase,
  Layers,
  ShoppingBag,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { formatCompactNumber } from '../../lib/formatNumber';
import { AppRecord } from './types';
import { AppDetailsModal } from './AppDetailsModal';
import { PublishAppModal } from './PublishAppModal';
import { DeveloperDashboardModal } from './DeveloperDashboardModal';

const CATEGORIES = [
  'All',
  'Games',
  'Productivity',
  'Finance',
  'Tools',
  'Social',
  'Entertainment',
  'Utilities',
  'Education',
  'Lifestyle',
];

export const LotAppStore: React.FC = () => {
  const { user, openAuthModal } = useAuth();
  const [apps, setApps] = useState<AppRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState<string>('all'); // all, featured, trending, top_free, top_paid, recent, my_purchased
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [selectedApp, setSelectedApp] = useState<AppRecord | null>(null);
  const [showPublishModal, setShowPublishModal] = useState<boolean>(false);
  const [showDeveloperModal, setShowDeveloperModal] = useState<boolean>(false);

  const fetchApps = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (filter !== 'all') params.set('filter', filter);
      if (selectedCategory !== 'All') params.set('category', selectedCategory);
      if (searchQuery.trim()) params.set('search', searchQuery.trim());

      const res = await fetch(`/api/apps?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setApps(data.apps || []);
      }
    } catch (e) {
      console.error('Failed to fetch apps:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApps();
  }, [filter, selectedCategory]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchApps();
  };

  const handleAppUpdated = (updated: AppRecord) => {
    setApps((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
    if (selectedApp && selectedApp.id === updated.id) {
      setSelectedApp(updated);
    }
  };

  const handleAppPublished = (newApp: AppRecord) => {
    setApps((prev) => [newApp, ...prev]);
    setSelectedApp(newApp);
  };

  // Find top featured app for the hero spot
  const featuredHeroApp = apps.find((a) => a.isFeatured) || apps[0];

  return (
    <div className="space-y-6 pb-16">
      {/* Top Banner / Store Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-[#121124] via-[#1A1833] to-[#121124] border border-[#2F2D48] rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <Smartphone className="w-4 h-4" />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-wide">LOT App Store</h1>
            <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-md bg-purple-900/60 text-purple-300 border border-purple-500/30">
              ANDROID MARKETPLACE
            </span>
          </div>
          <p className="text-xs text-[#A5A3B8]">
            Publish and download native Android APK applications. One-time permanent license with £ LOT currency.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
          <button
            onClick={() => {
              if (!user) {
                openAuthModal();
                return;
              }
              setShowDeveloperModal(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-[#1C1C33] border border-[#302D46] text-[#C4B5FD] hover:bg-[#252542] hover:text-white transition-all cursor-pointer shadow-sm"
          >
            <Briefcase className="w-4 h-4 text-purple-400" />
            <span>Developer Dashboard</span>
          </button>

          <button
            onClick={() => {
              if (!user) {
                openAuthModal();
                return;
              }
              setShowPublishModal(true);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/20 transition-all cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>Publish Android App</span>
          </button>
        </div>
      </div>

      {/* Hero Featured App Carousel / Card (if available and in default view) */}
      {featuredHeroApp && filter === 'all' && selectedCategory === 'All' && !searchQuery && (
        <div
          onClick={() => setSelectedApp(featuredHeroApp)}
          className="relative bg-gradient-to-r from-[#191735] via-[#221D42] to-[#151329] border border-purple-500/40 rounded-2xl p-5 sm:p-7 overflow-hidden cursor-pointer group hover:border-purple-400 transition-all shadow-xl shadow-purple-950/20"
        >
          <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-20 pointer-events-none overflow-hidden hidden md:block">
            {featuredHeroApp.screenshots?.[0] && (
              <img
                src={featuredHeroApp.screenshots[0]}
                alt="Featured preview"
                className="w-full h-full object-cover blur-sm transform scale-110"
              />
            )}
          </div>

          <div className="relative z-10 max-w-xl space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-purple-600 text-white shadow">
                ★ FEATURED APPLICATION
              </span>
              <span className="text-xs text-[#A5A3B8]">• {featuredHeroApp.category}</span>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-black border border-[#3A3755] p-1.5 shrink-0 overflow-hidden shadow-lg group-hover:scale-105 transition-transform">
                <img
                  src={featuredHeroApp.iconUrl}
                  alt={featuredHeroApp.name}
                  className="w-full h-full object-contain rounded-xl"
                />
              </div>

              <div>
                <h2 className="text-lg sm:text-2xl font-black text-white group-hover:text-purple-300 transition-colors">
                  {featuredHeroApp.name}
                </h2>
                <div className="text-xs text-purple-300 font-semibold flex items-center gap-1.5">
                  @{featuredHeroApp.developerUsername}
                  <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                  <span className="text-[#A5A3B8] font-normal">v{featuredHeroApp.version}</span>
                </div>
              </div>
            </div>

            <p className="text-xs text-[#D1D0E4] line-clamp-2 leading-relaxed">
              {featuredHeroApp.shortDescription || featuredHeroApp.description}
            </p>

            <div className="flex items-center gap-3 pt-1">
              <span className="flex items-center gap-1 text-amber-400 text-xs font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                {featuredHeroApp.rating?.toFixed(1) || '5.0'}
              </span>
              <span className="text-xs text-[#A5A3B8]">
                {formatCompactNumber(featuredHeroApp.downloadsCount || 0)} downloads
              </span>
              {featuredHeroApp.isPaid ? (
                <span className="text-xs font-bold text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-md border border-amber-500/30">
                  £{featuredHeroApp.priceLot} LOT
                </span>
              ) : (
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-500/30">
                  Free
                </span>
              )}
              <span className="text-xs font-bold text-purple-300 group-hover:underline ml-auto flex items-center gap-1">
                View & Install →
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'all', label: 'All Apps', icon: Layers },
            { id: 'trending', label: 'Trending', icon: TrendingUp },
            { id: 'top_free', label: 'Top Free', icon: Download },
            { id: 'top_paid', label: 'Top Paid', icon: Coins },
            { id: 'recent', label: 'Recent', icon: Clock },
            { id: 'my_purchased', label: 'My Purchased Apps', icon: ShoppingBag },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = filter === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setFilter(item.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-500/20'
                    : 'bg-[#151528] text-[#A5A3B8] border border-[#28263E] hover:text-white hover:bg-[#1C1C33]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearchSubmit} className="relative w-full lg:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search apps, games, tools..."
            className="w-full bg-[#151528] border border-[#28263E] rounded-xl pl-9 pr-8 py-2 text-xs text-white placeholder-[#787693] focus:outline-none focus:border-purple-500"
          />
          <Search className="w-4 h-4 text-[#787693] absolute left-3 top-2.5" />
          {searchQuery && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setTimeout(fetchApps, 50);
              }}
              className="text-xs text-[#A5A3B8] hover:text-white absolute right-3 top-2"
            >
              ×
            </button>
          )}
        </form>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-gradient-to-r from-purple-700 to-indigo-700 text-white border border-purple-400/40 shadow-sm'
                : 'bg-[#141426] text-[#A5A3B8] border border-[#24233A] hover:bg-[#1B1B30] hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Apps Grid */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 text-[#A5A3B8] space-y-3">
          <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-xs">Loading LOT App Store...</span>
        </div>
      ) : apps.length === 0 ? (
        <div className="p-12 text-center bg-[#111122] border border-[#27253D] rounded-2xl space-y-3">
          <Smartphone className="w-10 h-10 mx-auto text-[#6A6882]" />
          <h3 className="text-base font-bold text-white">No applications found</h3>
          <p className="text-xs text-[#A5A3B8] max-w-sm mx-auto">
            {filter === 'my_purchased'
              ? 'You have not purchased any paid apps yet. Discover top apps in the store!'
              : 'Try clearing your search query or selecting a different category.'}
          </p>
          <button
            onClick={() => {
              setFilter('all');
              setSelectedCategory('All');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {apps.map((appItem) => (
            <div
              key={appItem.id}
              onClick={() => setSelectedApp(appItem)}
              className="p-4 bg-[#121224] border border-[#26243C] hover:border-purple-500/50 rounded-2xl cursor-pointer transition-all hover:scale-[1.02] hover:shadow-xl hover:shadow-purple-500/10 flex flex-col justify-between group space-y-3"
            >
              <div className="space-y-3">
                {/* Header: Icon, Name, Category */}
                <div className="flex items-start gap-3">
                  <div className="w-14 h-14 bg-black rounded-2xl border border-[#302D46] p-1 shrink-0 overflow-hidden shadow-md group-hover:scale-105 transition-transform">
                    <img src={appItem.iconUrl} alt={appItem.name} className="w-full h-full object-contain rounded-xl" />
                  </div>

                  <div className="min-w-0 space-y-0.5">
                    <h3 className="text-xs sm:text-sm font-bold text-white truncate group-hover:text-purple-300 transition-colors">
                      {appItem.name}
                    </h3>
                    <div className="text-[11px] text-[#A5A3B8] truncate">@{appItem.developerUsername}</div>
                    <div className="text-[10px] text-purple-400 font-medium">{appItem.category}</div>
                  </div>
                </div>

                {/* Short Description */}
                <p className="text-[11px] text-[#A5A3B8] line-clamp-2 leading-relaxed">
                  {appItem.shortDescription || appItem.description}
                </p>
              </div>

              {/* Footer: Rating, Downloads, Price / Action */}
              <div className="pt-2 border-t border-[#222036] flex items-center justify-between">
                <div className="flex items-center gap-2 text-[10px] text-[#A5A3B8]">
                  <span className="flex items-center gap-0.5 text-amber-400 font-bold">
                    <Star className="w-3 h-3 fill-amber-400" />
                    {appItem.rating ? appItem.rating.toFixed(1) : '5.0'}
                  </span>
                  <span>•</span>
                  <span>{formatCompactNumber(appItem.downloadsCount || 0)} dl</span>
                </div>

                {/* Price / Owned Badge */}
                <div>
                  {appItem.isPaid ? (
                    appItem.isPurchased ? (
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-500/30 flex items-center gap-1">
                        <Unlock className="w-2.5 h-2.5" />
                        Owned
                      </span>
                    ) : (
                      <span className="text-[10px] font-extrabold text-amber-300 bg-amber-950/60 px-2 py-0.5 rounded-md border border-amber-500/30 flex items-center gap-1">
                        <Coins className="w-2.5 h-2.5 text-amber-400" />
                        £{appItem.priceLot} LOT
                      </span>
                    )
                  ) : (
                    <span className="text-[10px] font-bold text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded-md border border-purple-500/30">
                      Free
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* App Details Modal */}
      {selectedApp && (
        <AppDetailsModal
          app={selectedApp}
          onClose={() => setSelectedApp(null)}
          onAppUpdated={handleAppUpdated}
        />
      )}

      {/* Publish App Modal */}
      {showPublishModal && (
        <PublishAppModal
          onClose={() => setShowPublishModal(false)}
          onSuccess={handleAppPublished}
        />
      )}

      {/* Developer Dashboard Modal */}
      {showDeveloperModal && (
        <DeveloperDashboardModal
          onClose={() => setShowDeveloperModal(false)}
          onAppChanged={fetchApps}
        />
      )}
    </div>
  );
};
