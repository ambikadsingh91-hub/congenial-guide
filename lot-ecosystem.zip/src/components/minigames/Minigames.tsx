import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Gamepad2,
  Sparkles,
  Trophy,
  RotateCcw,
  Clock,
  Zap,
  HelpCircle,
  CheckCircle2,
  AlertCircle,
  Coins,
  ShieldCheck,
  Brain,
  Timer,
  Crosshair,
  Calendar,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatCompactNumber } from '../../lib/formatNumber';
import { playRedeemSound, playErrorSound } from '../../lib/sounds';

export const Minigames: React.FC = () => {
  const { user, openAuthModal, refreshUser } = useAuth();
  const [activeGame, setActiveGame] = useState<'guess' | 'memory' | 'reaction' | 'daily'>('guess');

  // Universal reward feedback
  const [rewardMsg, setRewardMsg] = useState<string | null>(null);
  const [rewardError, setRewardError] = useState<string | null>(null);
  const [claiming, setClaiming] = useState(false);

  const claimReward = async (gameType: 'guess' | 'memory' | 'reaction' | 'daily', score: number) => {
    if (!user) {
      openAuthModal('login');
      return;
    }
    setClaiming(true);
    setRewardMsg(null);
    setRewardError(null);

    try {
      const res = await fetch('/api/games/reward', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gameType,
          score,
          clientNonce: Date.now(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        playErrorSound();
        setRewardError(data.error || 'Failed to claim game reward.');
        setClaiming(false);
        return;
      }

      playRedeemSound();
      confetti({
        particleCount: 90,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#8B5CF6', '#A855F7', '#C4B5FD', '#10B981'],
      });

      setRewardMsg(`Victory! Won +${formatCompactNumber(data.rewardLot)} LOT (Added to authoritative ledger).`);
      await refreshUser();
    } catch {
      playErrorSound();
      setRewardError('Network error submitting game reward.');
    } finally {
      setClaiming(false);
    }
  };

  // -----------------------------------------------------------------
  // 1. GAME: Number Guessing (The Oracle's Vault)
  // -----------------------------------------------------------------
  const [guessTarget, setGuessTarget] = useState<number>(() => Math.floor(Math.random() * 100) + 1);
  const [guessInput, setGuessInput] = useState('');
  const [guessFeedback, setGuessFeedback] = useState<string | null>('Enter a number between 1 and 100 to start.');
  const [guessAttempts, setGuessAttempts] = useState(0);
  const [guessWon, setGuessWon] = useState(false);

  const handleGuessSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (guessWon) return;
    const num = parseInt(guessInput, 10);
    if (isNaN(num) || num < 1 || num > 100) {
      setGuessFeedback('Please enter a valid number between 1 and 100.');
      return;
    }

    const nextAttempts = guessAttempts + 1;
    setGuessAttempts(nextAttempts);

    if (num === guessTarget) {
      setGuessWon(true);
      setGuessFeedback(`🎯 Direct Hit! Found the target ${guessTarget} in ${nextAttempts} attempts!`);
      claimReward('guess', nextAttempts);
    } else if (num < guessTarget) {
      setGuessFeedback(`🔼 ${num} is too low! Aim higher.`);
    } else {
      setGuessFeedback(`🔽 ${num} is too high! Aim lower.`);
    }
    setGuessInput('');
  };

  const resetGuessGame = () => {
    setGuessTarget(Math.floor(Math.random() * 100) + 1);
    setGuessInput('');
    setGuessFeedback('Vault target scrambled! Guess between 1 and 100.');
    setGuessAttempts(0);
    setGuessWon(false);
  };

  // -----------------------------------------------------------------
  // 2. GAME: Memory Matching (Cyber Matrix)
  // -----------------------------------------------------------------
  const ICONS = ['⚔️', '🛡️', '💎', '👑', '🚀', '⚡'];
  const [cards, setCards] = useState<{ id: number; symbol: string; flipped: boolean; matched: boolean }[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [memoryMoves, setMemoryMoves] = useState(0);
  const [memoryTime, setMemoryTime] = useState(0);
  const [memoryTimerRunning, setMemoryTimerRunning] = useState(false);
  const [memoryWon, setMemoryWon] = useState(false);

  const initMemoryGame = () => {
    const deck = [...ICONS, ...ICONS]
      .sort(() => Math.random() - 0.5)
      .map((symbol, id) => ({ id, symbol, flipped: false, matched: false }));
    setCards(deck);
    setFlippedIndices([]);
    setMemoryMoves(0);
    setMemoryTime(0);
    setMemoryTimerRunning(false);
    setMemoryWon(false);
  };

  useEffect(() => {
    initMemoryGame();
  }, []);

  useEffect(() => {
    let timer: any = null;
    if (memoryTimerRunning && !memoryWon) {
      timer = setInterval(() => setMemoryTime((t) => t + 1), 1000);
    }
    return () => clearInterval(timer);
  }, [memoryTimerRunning, memoryWon]);

  const handleCardClick = (index: number) => {
    if (memoryWon || cards[index].flipped || cards[index].matched || flippedIndices.length >= 2) return;

    if (!memoryTimerRunning) setMemoryTimerRunning(true);

    const newCards = [...cards];
    newCards[index].flipped = true;
    setCards(newCards);

    const newFlipped = [...flippedIndices, index];
    setFlippedIndices(newFlipped);

    if (newFlipped.length === 2) {
      setMemoryMoves((m) => m + 1);
      const [first, second] = newFlipped;
      if (cards[first].symbol === cards[second].symbol) {
        newCards[first].matched = true;
        newCards[second].matched = true;
        setCards(newCards);
        setFlippedIndices([]);

        // Check if all matched
        if (newCards.every((c) => c.matched)) {
          setMemoryWon(true);
          setMemoryTimerRunning(false);
          claimReward('memory', memoryTime || 20);
        }
      } else {
        setTimeout(() => {
          newCards[first].flipped = false;
          newCards[second].flipped = false;
          setCards([...newCards]);
          setFlippedIndices([]);
        }, 900);
      }
    }
  };

  // -----------------------------------------------------------------
  // 3. GAME: Reaction Time (Reflex Trigger)
  // -----------------------------------------------------------------
  const [reactionState, setReactionState] = useState<'idle' | 'waiting' | 'ready' | 'result' | 'early'>('idle');
  const [readyTime, setReadyTime] = useState(0);
  const [reactionMs, setReactionMs] = useState<number | null>(null);
  const [reactionTimeoutId, setReactionTimeoutId] = useState<any>(null);

  const startReactionTest = () => {
    setReactionState('waiting');
    setReactionMs(null);

    const delay = Math.floor(Math.random() * 2500) + 1500; // 1.5 to 4.0s
    const timeout = setTimeout(() => {
      setReactionState('ready');
      setReadyTime(Date.now());
    }, delay);
    setReactionTimeoutId(timeout);
  };

  const handleReactionClick = () => {
    if (reactionState === 'waiting') {
      clearTimeout(reactionTimeoutId);
      setReactionState('early');
    } else if (reactionState === 'ready') {
      const elapsed = Date.now() - readyTime;
      setReactionMs(elapsed);
      setReactionState('result');
      claimReward('reaction', elapsed);
    }
  };

  // -----------------------------------------------------------------
  // 4. GAME: Daily Challenge
  // -----------------------------------------------------------------
  const [dailyAnswer, setDailyAnswer] = useState('');
  const [dailySubmitted, setDailySubmitted] = useState(false);
  const [dailyError, setDailyError] = useState<string | null>(null);

  const handleDailySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDailyError(null);

    const clean = dailyAnswer.trim().toUpperCase();
    if (clean === 'LOT' || clean === 'LOT ECOSYSTEM') {
      setDailySubmitted(true);
      claimReward('daily', 100);
    } else {
      setDailyError('Incorrect answer. Clue: It is the 3-letter authoritative currency of this website!');
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-16">
      {/* Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#121222] via-[#19192B] to-[#202039] border border-[#302D46] p-8 sm:p-10 shadow-2xl">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#202039] border border-[#8B5CF6]/40 text-[#C4B5FD] text-xs font-semibold mb-3">
          <Sparkles className="w-3.5 h-3.5 text-[#8B5CF6]" />
          Skill & Skill Challenges (1 - 100 LOT)
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          Minigames Arcade
        </h1>
        <p className="text-sm text-[#A5A3B8] max-w-xl mt-2 leading-relaxed">
          Put your mind and reflexes to the test. All rewards are cryptographically validated by the server and credited
          directly into your authoritative LOT wallet.
        </p>

        {/* Global Feedback notification */}
        {rewardMsg && (
          <div className="mt-4 p-3.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
            <Trophy className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-semibold">{rewardMsg}</span>
          </div>
        )}
        {rewardError && (
          <div className="mt-4 p-3.5 rounded-xl bg-red-950/80 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{rewardError}</span>
          </div>
        )}
      </div>

      {/* Game Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { id: 'guess', name: "The Oracle's Vault", icon: Brain, reward: '15 - 50 LOT', desc: 'Number Guessing' },
          { id: 'memory', name: 'Cyber Matrix', icon: Timer, reward: '20 - 60 LOT', desc: 'Memory Matching' },
          { id: 'reaction', name: 'Reflex Trigger', icon: Crosshair, reward: '20 - 75 LOT', desc: 'Speed Challenge' },
          { id: 'daily', name: 'Daily Cipher', icon: Calendar, reward: '100 LOT', desc: 'Daily Quiz' },
        ].map((g) => {
          const Icon = g.icon;
          const isActive = activeGame === g.id;
          return (
            <button
              key={g.id}
              onClick={() => {
                setActiveGame(g.id as any);
                setRewardMsg(null);
                setRewardError(null);
              }}
              className={`p-4 rounded-2xl border text-left transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#202039] border-[#8B5CF6] shadow-lg shadow-purple-900/25'
                  : 'bg-[#19192B] border-[#302D46] hover:border-[#8B5CF6]/50'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-lg bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 flex items-center justify-center text-[#C4B5FD]">
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-800 px-1.5 py-0.5 rounded">
                  {g.reward}
                </span>
              </div>
              <h3 className="font-bold text-white text-sm">{g.name}</h3>
              <p className="text-[11px] text-[#A5A3B8]">{g.desc}</p>
            </button>
          );
        })}
      </div>

      {/* Active Game Container */}
      <div className="bg-[#19192B] border border-[#302D46] rounded-3xl p-6 sm:p-10 shadow-xl max-w-2xl mx-auto">
        {/* GAME 1: GUESSING */}
        {activeGame === 'guess' && (
          <div className="space-y-6 text-center">
            <div>
              <span className="text-xs text-[#8B5CF6] font-bold uppercase tracking-wider">Number Guessing Challenge</span>
              <h2 className="text-2xl font-black text-white mt-1">The Oracle's Vault</h2>
              <p className="text-xs text-[#A5A3B8] max-w-md mx-auto mt-1">
                The vault has generated a secret number between 1 and 100. Find it in as few attempts as possible.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#121222] border border-[#302D46] text-sm">
              <span className="font-semibold text-[#C4B5FD]">{guessFeedback}</span>
              <div className="text-xs text-[#A5A3B8] mt-1">Attempts made: <strong className="text-white">{guessAttempts}</strong></div>
            </div>

            {!guessWon ? (
              <form onSubmit={handleGuessSubmit} className="flex gap-2 max-w-xs mx-auto">
                <input
                  type="number"
                  min="1"
                  max="100"
                  required
                  value={guessInput}
                  onChange={(e) => setGuessInput(e.target.value)}
                  placeholder="1 - 100"
                  className="flex-1 px-4 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-bold text-center text-sm focus:outline-none focus:border-[#8B5CF6]"
                />
                <button
                  type="submit"
                  disabled={claiming}
                  className="px-5 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-xs shadow-md transition-all cursor-pointer"
                >
                  Guess
                </button>
              </form>
            ) : (
              <div className="space-y-3">
                <div className="text-emerald-400 font-bold text-sm">Vault unlocked successfully!</div>
                <button
                  onClick={resetGuessGame}
                  className="px-5 py-2.5 rounded-xl bg-[#202039] hover:bg-[#302D46] border border-[#302D46] text-white text-xs font-semibold cursor-pointer"
                >
                  Play Again
                </button>
              </div>
            )}
          </div>
        )}

        {/* GAME 2: MEMORY */}
        {activeGame === 'memory' && (
          <div className="space-y-6 text-center">
            <div>
              <span className="text-xs text-[#8B5CF6] font-bold uppercase tracking-wider">Memory Matrix Challenge</span>
              <h2 className="text-2xl font-black text-white mt-1">Cyber Memory Matrix</h2>
              <div className="flex items-center justify-center gap-4 text-xs text-[#A5A3B8] mt-2">
                <span>Timer: <strong className="text-white">{memoryTime}s</strong></span>
                <span>•</span>
                <span>Moves: <strong className="text-white">{memoryMoves}</strong></span>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-3 max-w-sm mx-auto">
              {cards.map((card, idx) => (
                <div
                  key={card.id}
                  onClick={() => handleCardClick(idx)}
                  className={`aspect-square rounded-xl border flex items-center justify-center text-2xl font-bold cursor-pointer transition-all duration-300 select-none ${
                    card.matched
                      ? 'bg-emerald-950/60 border-emerald-500/50 shadow-md shadow-emerald-900/20'
                      : card.flipped
                      ? 'bg-[#202039] border-[#8B5CF6]'
                      : 'bg-[#121222] border-[#302D46] hover:border-[#8B5CF6]/60'
                  }`}
                >
                  {card.flipped || card.matched ? card.symbol : '❓'}
                </div>
              ))}
            </div>

            {memoryWon ? (
              <div className="space-y-3">
                <div className="text-emerald-400 font-bold text-sm">Matrix Cleared in {memoryTime}s!</div>
                <button
                  onClick={initMemoryGame}
                  className="px-5 py-2.5 rounded-xl bg-[#202039] hover:bg-[#302D46] border border-[#302D46] text-white text-xs font-semibold cursor-pointer"
                >
                  Shuffle & Restart
                </button>
              </div>
            ) : (
              <button
                onClick={initMemoryGame}
                className="text-xs text-[#A5A3B8] hover:text-white flex items-center justify-center gap-1 mx-auto"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Board</span>
              </button>
            )}
          </div>
        )}

        {/* GAME 3: REACTION */}
        {activeGame === 'reaction' && (
          <div className="space-y-6 text-center">
            <div>
              <span className="text-xs text-[#8B5CF6] font-bold uppercase tracking-wider">Reflex Speed Test</span>
              <h2 className="text-2xl font-black text-white mt-1">Reflex Trigger</h2>
              <p className="text-xs text-[#A5A3B8] mt-1">
                Wait for the screen to turn vivid purple, then click as fast as humanly possible!
              </p>
            </div>

            <div
              onClick={handleReactionClick}
              className={`h-56 rounded-2xl border flex flex-col items-center justify-center cursor-pointer transition-colors p-6 select-none ${
                reactionState === 'idle'
                  ? 'bg-[#121222] border-[#302D46]'
                  : reactionState === 'waiting'
                  ? 'bg-rose-950 border-rose-600'
                  : reactionState === 'ready'
                  ? 'bg-[#8B5CF6] border-white text-white shadow-2xl'
                  : reactionState === 'early'
                  ? 'bg-amber-950 border-amber-600'
                  : 'bg-emerald-950 border-emerald-600'
              }`}
            >
              {reactionState === 'idle' && (
                <div className="space-y-2">
                  <Crosshair className="w-10 h-10 text-[#8B5CF6] mx-auto" />
                  <span className="font-bold text-white block">Click "Start Test" below to begin</span>
                </div>
              )}
              {reactionState === 'waiting' && (
                <div className="space-y-2">
                  <span className="text-lg font-black text-rose-200">WAIT FOR PURPLE...</span>
                  <span className="text-xs text-rose-300 block">Do not click yet!</span>
                </div>
              )}
              {reactionState === 'ready' && (
                <span className="text-3xl font-black text-white animate-pulse">CLICK NOW!</span>
              )}
              {reactionState === 'early' && (
                <div className="space-y-2">
                  <span className="text-base font-bold text-amber-300">Too Early! False Start.</span>
                  <span className="text-xs text-amber-200 block">Click below to retry.</span>
                </div>
              )}
              {reactionState === 'result' && (
                <div className="space-y-1">
                  <span className="text-3xl font-black text-emerald-300">{reactionMs} ms</span>
                  <span className="text-xs text-emerald-200 block">Excellent reflexes!</span>
                </div>
              )}
            </div>

            <div>
              {reactionState !== 'waiting' && reactionState !== 'ready' && (
                <button
                  onClick={startReactionTest}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] text-white font-bold text-xs shadow-lg shadow-purple-500/25 transition-all cursor-pointer"
                >
                  {reactionState === 'idle' ? 'Start Test' : 'Try Again'}
                </button>
              )}
            </div>
          </div>
        )}

        {/* GAME 4: DAILY CIPHER */}
        {activeGame === 'daily' && (
          <div className="space-y-6 text-center">
            <div>
              <span className="text-xs text-[#8B5CF6] font-bold uppercase tracking-wider">24-Hour Ecosystem Challenge</span>
              <h2 className="text-2xl font-black text-white mt-1">Ecosystem Daily Cipher</h2>
              <p className="text-xs text-[#A5A3B8] max-w-md mx-auto mt-1">
                Answer today's platform riddle to earn the maximum single reward of <strong>100 LOT</strong>.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#121222] border border-[#302D46] text-left space-y-3">
              <span className="text-xs text-[#8B5CF6] font-bold">Today's Riddle:</span>
              <p className="text-sm font-semibold text-white leading-relaxed">
                "I am the unified fuel of the marketplace, the peer transfer channel, and the stock exchange.
                What is the authoritative currency of this ecosystem?"
              </p>
            </div>

            {dailyError && (
              <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/30 text-red-200 text-xs">
                {dailyError}
              </div>
            )}

            {!dailySubmitted ? (
              <form onSubmit={handleDailySubmit} className="flex gap-2 max-w-sm mx-auto">
                <input
                  type="text"
                  required
                  value={dailyAnswer}
                  onChange={(e) => setDailyAnswer(e.target.value)}
                  placeholder="Enter answer..."
                  className="flex-1 px-4 py-2.5 bg-[#121222] border border-[#302D46] rounded-xl text-white font-bold text-sm focus:outline-none focus:border-[#8B5CF6]"
                />
                <button
                  type="submit"
                  disabled={claiming}
                  className="px-5 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-xs shadow-md transition-all cursor-pointer"
                >
                  Solve & Claim 100 LOT
                </button>
              </form>
            ) : (
              <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
                ✓ Daily Cipher Completed! 100 LOT credited to your balance.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
