import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Notification, Announcement } from '../types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (username: string, password: string, confirmPassword: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  notifications: Notification[];
  unreadCount: number;
  markNotificationsRead: (notificationId?: string) => Promise<void>;
  announcements: Announcement[];
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authModalTab: 'login' | 'register';
  setAuthModalTab: (tab: 'login' | 'register') => void;
  openAuthModal: (tab?: 'login' | 'register') => void;
  updateAvatar: (avatarUrl: string) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');

  const getStoredToken = () => {
    try {
      return localStorage.getItem('lot_session_token') || '';
    } catch {
      return '';
    }
  };

  const setStoredToken = (tok: string) => {
    try {
      if (tok) {
        localStorage.setItem('lot_session_token', tok);
      } else {
        localStorage.removeItem('lot_session_token');
      }
    } catch {}
  };

  const fetchCurrentUser = async () => {
    const token = getStoredToken();
    try {
      const headers: Record<string, string> = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const res = await fetch('/api/auth/me', {
        headers,
        credentials: 'include',
      });

      if (res.ok) {
        const data = await res.json();
        const activeToken = data.user?.token || token;
        if (activeToken) {
          setStoredToken(activeToken);
        }
        setUser({ ...data.user, token: activeToken });
      } else {
        if (res.status === 401 || res.status === 403) {
          // Token is explicitly invalidated or expired on server
          setStoredToken('');
          setUser(null);
        }
      }
    } catch {
      // Keep existing user or don't wipe token on transient network blip
    } finally {
      setLoading(false);
    }
  };

  const fetchNotifications = async () => {
    const token = getStoredToken() || user?.token;
    if (!token && !user) {
      setNotifications([]);
      return;
    }
    try {
      const headers: Record<string, string> = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const res = await fetch('/api/notifications', {
        headers,
        credentials: 'include',
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
      }
    } catch {
      // non-critical
    }
  };

  const fetchAnnouncements = async () => {
    try {
      const res = await fetch('/api/announcements', { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        setAnnouncements(data.announcements || []);
      }
    } catch {
      // non-critical
    }
  };

  useEffect(() => {
    fetchCurrentUser();
    fetchAnnouncements();
  }, []);

  useEffect(() => {
    if (user) {
      fetchNotifications();
      const interval = setInterval(() => {
        fetchCurrentUser();
        fetchNotifications();
      }, 10000);
      return () => clearInterval(interval);
    }
  }, [user?.id]);

  const login = async (username: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Incorrect username or password.' };
      }
      const token = data.token;
      if (token) {
        setStoredToken(token);
      }
      setUser({ ...data.user, token });
      setIsAuthModalOpen(false);
      fetchNotifications();
      return { success: true };
    } catch {
      return { success: false, error: 'Network error. Please try again.' };
    }
  };

  const register = async (username: string, password: string, confirmPassword: string) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username, password, confirmPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Registration failed.' };
      }
      const token = data.token;
      if (token) {
        setStoredToken(token);
      }
      setUser({ ...data.user, token });
      setIsAuthModalOpen(false);
      fetchNotifications();
      return { success: true, message: data.message };
    } catch {
      return { success: false, error: 'Network error. Please try again.' };
    }
  };

  const logout = async () => {
    const token = getStoredToken() || user?.token;
    try {
      const headers: Record<string, string> = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers,
        credentials: 'include',
      });
    } catch {
      // Ignore
    }
    setStoredToken('');
    setUser(null);
    setNotifications([]);
  };

  const refreshUser = async () => {
    await fetchCurrentUser();
  };

  const markNotificationsRead = async (notificationId?: string) => {
    const token = getStoredToken() || user?.token;
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      await fetch('/api/notifications/mark-read', {
        method: 'POST',
        headers,
        credentials: 'include',
        body: JSON.stringify({ notificationId }),
      });
      if (notificationId) {
        setNotifications((prev) => prev.map((n) => (n.id === notificationId ? { ...n, read: true } : n)));
      } else {
        setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
      }
    } catch {
      // non-critical
    }
  };

  const openAuthModal = (tab: 'login' | 'register' = 'login') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const updateAvatar = async (avatarUrl: string): Promise<{ success: boolean; error?: string }> => {
    const token = getStoredToken() || user?.token;
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const res = await fetch('/api/user/avatar', {
        method: 'POST',
        headers,
        credentials: 'include',
        body: JSON.stringify({ avatarUrl }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to update avatar' };
      }
      if (user) {
        setUser({ ...user, avatarUrl: data.avatarUrl || undefined });
      }
      return { success: true };
    } catch {
      return { success: false, error: 'Network error updating profile picture' };
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        register,
        logout,
        refreshUser,
        notifications,
        unreadCount,
        markNotificationsRead,
        announcements,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authModalTab,
        setAuthModalTab,
        openAuthModal,
        updateAvatar,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
