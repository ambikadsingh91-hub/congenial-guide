import React, { createContext, useContext, useState, useEffect, useRef, ReactNode, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { CallSession, Conversation, DirectMessage, PlayerSummary } from '../types';

interface SocialContextType {
  unreadChatCount: number;
  activeCall: CallSession | null;
  incomingCall: CallSession | null;
  callStatus: 'idle' | 'calling' | 'ringing' | 'connecting' | 'connected' | 'ended' | 'declined' | 'failed';
  callError: string | null;
  isMuted: boolean;
  isVideoEnabled: boolean;
  isSpeakerOn: boolean;
  callDuration: number;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  onlineUserIds: Set<string>;
  initiateCall: (target: { recipientId?: string; recipientUsername?: string; type: 'audio' | 'video' }) => Promise<{ success: boolean; error?: string }>;
  acceptCall: (callId: string) => Promise<void>;
  joinCall: (callId: string, type?: 'audio' | 'video') => Promise<void>;
  declineCall: (callId: string) => Promise<void>;
  endCall: () => Promise<void>;
  toggleMute: () => void;
  toggleVideo: () => void;
  toggleSpeaker: () => void;
  switchCamera: () => Promise<void>;
  targetChatUser: string | null;
  setTargetChatUser: (username: string | null) => void;
  openChatWith: (username: string) => void;
  refreshUnreadCount: () => Promise<void>;
  socket: WebSocket | null;
}

const SocialContext = createContext<SocialContextType | undefined>(undefined);

// Web Audio API Ringtone & Beep Synthesizer
let audioCtxSingleton: AudioContext | null = null;
function getSharedAudioContext(): AudioContext | null {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return null;
    if (!audioCtxSingleton || audioCtxSingleton.state === 'closed') {
      audioCtxSingleton = new AudioCtx();
    }
    if (audioCtxSingleton.state === 'suspended') {
      audioCtxSingleton.resume().catch(() => {});
    }
    return audioCtxSingleton;
  } catch {
    return null;
  }
}

function playCallSound(type: 'ringing' | 'connected' | 'ended' | 'incoming') {
  try {
    const ctx = getSharedAudioContext();
    if (!ctx) return;

    if (type === 'incoming') {
      // Pleasant melodic chime for incoming calls
      const notes = [523.25, 659.25, 783.99, 1046.5];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.12);
        gain.gain.setValueAtTime(0.001, ctx.currentTime + idx * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + idx * 0.12 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.12 + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.12);
        osc.stop(ctx.currentTime + idx * 0.12 + 0.35);
      });
    } else if (type === 'ringing') {
      // Outgoing phone ring tone
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc1.type = 'sine';
      osc2.type = 'sine';
      osc1.frequency.setValueAtTime(440, ctx.currentTime);
      osc2.frequency.setValueAtTime(480, ctx.currentTime);

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.001, ctx.currentTime + 1.2);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      osc1.start(ctx.currentTime);
      osc2.start(ctx.currentTime);
      osc1.stop(ctx.currentTime + 1.2);
      osc2.stop(ctx.currentTime + 1.2);
    } else if (type === 'connected') {
      // Uplifting connection chime
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(659.25, ctx.currentTime + 0.12);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.25);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.4);
    } else if (type === 'ended') {
      // Descending tone for ended or declined call
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(340, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(180, ctx.currentTime + 0.25);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.25);
    }
  } catch {}
}

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
    { urls: ['stun:stun2.l.google.com:19302', 'stun:stun3.l.google.com:19302'] },
    { urls: ['stun:stun.cloudflare.com:3478'] },
    { urls: ['stun:stun.services.mozilla.com:3478'] },
  ],
  iceCandidatePoolSize: 10,
  bundlePolicy: 'max-bundle',
};

export const SocialProvider: React.FC<{ children: ReactNode; onNavigateToChat?: () => void }> = ({
  children,
  onNavigateToChat,
}) => {
  const { user } = useAuth();
  const [unreadChatCount, setUnreadChatCount] = useState<number>(0);
  const [activeCall, setActiveCall] = useState<CallSession | null>(null);
  const [incomingCall, setIncomingCall] = useState<CallSession | null>(null);
  const [callStatus, setCallStatus] = useState<
    'idle' | 'calling' | 'ringing' | 'connecting' | 'connected' | 'ended' | 'declined' | 'failed'
  >('idle');
  const [callError, setCallError] = useState<string | null>(null);

  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');

  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [onlineUserIds, setOnlineUserIds] = useState<Set<string>>(new Set());
  const [targetChatUser, setTargetChatUser] = useState<string | null>(null);
  const [socket, setSocket] = useState<WebSocket | null>(null);

  const socketRef = useRef<WebSocket | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const pendingCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  const pendingOfferRef = useRef<{ from: string; sdp: RTCSessionDescriptionInit } | null>(null);
  const partnerUserIdRef = useRef<string | null>(null);
  const timerRef = useRef<any>(null);
  const ringtoneIntervalRef = useRef<any>(null);
  const callTimeoutRef = useRef<any>(null);

  // Keep a ref of localStream so callbacks can access the current stream without re-triggering connectWs
  const localStreamRef = useRef<MediaStream | null>(null);
  useEffect(() => {
    localStreamRef.current = localStream;
  }, [localStream]);

  // Send signaling packet to recipient over WebSocket
  const sendSignal = useCallback((targetUserId: string, signal: any) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      console.log('[WebRTC Signaling] Sending to', targetUserId, Object.keys(signal));
      socketRef.current.send(
        JSON.stringify({
          type: 'call:signal',
          to: targetUserId,
          signal,
        })
      );
    } else {
      console.warn('[WebRTC Signaling] WebSocket not open when sending signal');
    }
  }, []);

  // Web Audio synthetic silent audio stream fallback if device has no mic
  const createFallbackStream = (): MediaStream | null => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const dest = ctx.createMediaStreamDestination();
        return dest.stream;
      }
    } catch {}
    return null;
  };

  // Helper to obtain media devices reliably across desktop webcams, mobile devices, and browser constraints
  const obtainMedia = async (video: boolean): Promise<MediaStream | null> => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        const fallback = createFallbackStream();
        if (fallback) {
          setLocalStream(fallback);
          return fallback;
        }
        throw new Error('Media devices API not supported by this browser.');
      }

      // Try 1: Standard constraints with optimal audio processing
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
          video: video
            ? {
                width: { ideal: 1280, max: 1920 },
                height: { ideal: 720, max: 1080 },
              }
            : false,
        });

        setLocalStream(stream);
        setIsMuted(false);
        setIsVideoEnabled(video);
        return stream;
      } catch (err1: any) {
        console.warn('[obtainMedia] Stage 1 getUserMedia failed, retrying with flexible constraints:', err1);

        // Try 2: Basic unconstrained media
        if (video) {
          try {
            const stream = await navigator.mediaDevices.getUserMedia({
              audio: true,
              video: true,
            });
            setLocalStream(stream);
            setIsMuted(false);
            setIsVideoEnabled(true);
            return stream;
          } catch (err2) {
            console.warn('[obtainMedia] Video capture unavailable, falling back to voice audio:', err2);
          }
        }

        // Try 3: Audio-only fallback (e.g. webcam in use by another app or no camera detected)
        const audioOnlyStream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: false,
        });

        setLocalStream(audioOnlyStream);
        setIsMuted(false);
        setIsVideoEnabled(false);
        if (video) {
          setCallError('Camera was unavailable or permission denied. Connected via voice audio.');
        }
        return audioOnlyStream;
      }
    } catch (err: any) {
      console.warn('[obtainMedia] All getUserMedia attempts failed:', err);
      const isDenied = err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError';
      const msg = isDenied
        ? 'Microphone / camera access was denied. Please allow microphone access in your browser to speak.'
        : err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError'
        ? 'No microphone detected on this device.'
        : err.message || 'Failed to access audio / video input.';
      setCallError(msg);

      // Return synthetic stream so connection still negotiates
      const fallback = createFallbackStream();
      if (fallback) {
        setLocalStream(fallback);
        setIsMuted(false);
        setIsVideoEnabled(false);
        return fallback;
      }
      return null;
    }
  };

  // Close and cleanup WebRTC connection & local media tracks
  const teardownCallResources = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (ringtoneIntervalRef.current) {
      clearInterval(ringtoneIntervalRef.current);
      ringtoneIntervalRef.current = null;
    }
    if (callTimeoutRef.current) {
      clearTimeout(callTimeoutRef.current);
      callTimeoutRef.current = null;
    }

    if (pcRef.current) {
      try {
        pcRef.current.ontrack = null;
        pcRef.current.onicecandidate = null;
        pcRef.current.oniceconnectionstatechange = null;
        pcRef.current.onconnectionstatechange = null;
        pcRef.current.close();
      } catch {}
      pcRef.current = null;
    }

    pendingCandidatesRef.current = [];
    pendingOfferRef.current = null;
    partnerUserIdRef.current = null;

    setLocalStream((prev) => {
      if (prev) {
        prev.getTracks().forEach((t) => t.stop());
      }
      return null;
    });

    setRemoteStream(null);
  }, []);

  // Initialize RTCPeerConnection with dual transceivers and robust track management
  const initPeerConnection = useCallback(
    (targetUserId: string, mediaStream: MediaStream, isCaller: boolean) => {
      partnerUserIdRef.current = targetUserId;

      if (pcRef.current) {
        try {
          pcRef.current.close();
        } catch {}
        pcRef.current = null;
      }

      const pc = new RTCPeerConnection(RTC_CONFIG);
      pcRef.current = pc;

      // Add transceivers explicitly to guarantee bidirectional channels
      try {
        pc.addTransceiver('audio', { direction: 'sendrecv' });
        pc.addTransceiver('video', { direction: 'sendrecv' });
      } catch (err) {
        console.warn('[WebRTC] addTransceiver note:', err);
      }

      // Add local media tracks
      mediaStream.getTracks().forEach((track) => {
        try {
          pc.addTrack(track, mediaStream);
        } catch (err) {
          console.warn('[WebRTC] addTrack note:', err);
        }
      });

      // Handle remote incoming tracks with track-state synchronization
      pc.ontrack = (event) => {
        console.log('[WebRTC] Remote track arrived:', event.track.kind, 'id:', event.track.id);
        event.track.enabled = true;

        if (event.streams && event.streams[0]) {
          // Fresh MediaStream instance guarantees React re-renders video and audio elements
          const stream = event.streams[0];
          setRemoteStream(new MediaStream(stream.getTracks()));
        } else {
          // Collect all active receivers
          const receiverTracks = pc
            .getReceivers()
            .map((r) => r.track)
            .filter((t): t is MediaStreamTrack => !!t);
          setRemoteStream(new MediaStream(receiverTracks.length > 0 ? receiverTracks : [event.track]));
        }

        // When remote track arrives, transition status to connected
        setCallStatus('connected');
        setCallError(null);
      };

      // Handle ICE candidates
      pc.onicecandidate = (event) => {
        if (event.candidate) {
          sendSignal(targetUserId, { candidate: event.candidate.toJSON() });
        }
      };

      pc.onconnectionstatechange = () => {
        console.log('[WebRTC] Connection state change:', pc.connectionState);
        if (pc.connectionState === 'connected') {
          setCallStatus('connected');
          setCallError(null);
          playCallSound('connected');
        } else if (pc.connectionState === 'failed') {
          console.warn('[WebRTC] Connection failed, attempting ICE restart');
          pc.restartIce();
        }
      };

      pc.oniceconnectionstatechange = () => {
        console.log('[WebRTC] ICE connection state:', pc.iceConnectionState);
        if (pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed') {
          setCallStatus('connected');
        } else if (pc.iceConnectionState === 'failed') {
          pc.restartIce();
        }
      };

      // Process any pending SDP offer that arrived before pc was ready
      if (pendingOfferRef.current) {
        const pending = pendingOfferRef.current;
        pendingOfferRef.current = null;
        console.log('[WebRTC] Processing pending SDP offer for', pending.from);
        pc.setRemoteDescription(new RTCSessionDescription(pending.sdp))
          .then(async () => {
            while (pendingCandidatesRef.current.length > 0) {
              const cand = pendingCandidatesRef.current.shift();
              if (cand) await pc.addIceCandidate(new RTCIceCandidate(cand)).catch(console.warn);
            }
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            sendSignal(pending.from, { sdp: answer });
          })
          .catch((err) => {
            console.error('[WebRTC] Error resolving pending offer:', err);
          });
      }

      return pc;
    },
    [sendSignal]
  );

  // Handle incoming signaling packets over WebSocket
  const handleIncomingSignal = useCallback(
    async (fromUserId: string, signal: any) => {
      const pc = pcRef.current;

      // 1. SDP Offer
      if (signal.sdp && signal.sdp.type === 'offer') {
        console.log('[WebRTC] Processing incoming SDP Offer from', fromUserId);
        if (!pc) {
          console.log('[WebRTC] PC not yet initialized, queueing offer');
          pendingOfferRef.current = { from: fromUserId, sdp: signal.sdp };
          return;
        }

        try {
          await pc.setRemoteDescription(new RTCSessionDescription(signal.sdp));

          // Drain queued candidates
          while (pendingCandidatesRef.current.length > 0) {
            const cand = pendingCandidatesRef.current.shift();
            if (cand) {
              await pc.addIceCandidate(new RTCIceCandidate(cand)).catch(console.warn);
            }
          }

          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          sendSignal(fromUserId, { sdp: answer });
        } catch (err) {
          console.error('[WebRTC] Failed to process incoming offer:', err);
        }
      }

      // 2. SDP Answer
      if (signal.sdp && signal.sdp.type === 'answer') {
        console.log('[WebRTC] Processing incoming SDP Answer from', fromUserId);
        if (!pc) return;

        try {
          await pc.setRemoteDescription(new RTCSessionDescription(signal.sdp));

          // Drain queued candidates
          while (pendingCandidatesRef.current.length > 0) {
            const cand = pendingCandidatesRef.current.shift();
            if (cand) {
              await pc.addIceCandidate(new RTCIceCandidate(cand)).catch(console.warn);
            }
          }
        } catch (err) {
          console.error('[WebRTC] Failed to process incoming answer:', err);
        }
      }

      // 3. ICE Candidate
      if (signal.candidate) {
        if (pc && pc.remoteDescription && pc.remoteDescription.type) {
          try {
            await pc.addIceCandidate(new RTCIceCandidate(signal.candidate));
          } catch (err) {
            console.warn('[WebRTC] addIceCandidate note:', err);
          }
        } else {
          pendingCandidatesRef.current.push(signal.candidate);
        }
      }
    },
    [sendSignal]
  );

  // Poll unread chat count
  const refreshUnreadCount = async () => {
    if (!user) return;
    try {
      const res = await fetch('/api/chat/conversations');
      if (res.ok) {
        const data = await res.json();
        const total = (data.conversations || []).reduce(
          (sum: number, c: Conversation) => sum + (c.unreadCount || 0),
          0
        );
        setUnreadChatCount(total);
      }
    } catch {}
  };

  // Connect WebSocket on user auth
  useEffect(() => {
    if (!user?.id) {
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }
      setSocket(null);
      return;
    }

    let isSubscribed = true;
    let reconnectTimeout: any = null;

    const connectWs = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const storedToken = localStorage.getItem('lot_session_token') || user?.token || '';
      const cookieToken = document.cookie
        .split('; ')
        .find((row) => row.startsWith('lot_session='))
        ?.split('=')[1] || '';
      const token = storedToken || cookieToken;

      const wsUrl = `${protocol}//${window.location.host}/ws?token=${encodeURIComponent(token)}`;

      try {
        const ws = new WebSocket(wsUrl);
        socketRef.current = ws;

        ws.onopen = () => {
          setSocket(ws);
          if (token) {
            ws.send(JSON.stringify({ type: 'auth', token }));
          }
        };

        ws.onmessage = async (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.event === 'chat:message') {
              playCallSound('incoming');
              refreshUnreadCount();
              window.dispatchEvent(new CustomEvent('lot:chat_message', { detail: data.message }));
            } else if (data.event === 'chat:call_status_update') {
              window.dispatchEvent(new CustomEvent('lot:chat_call_update', { detail: data }));
            } else if (data.event === 'presence:update') {
              setOnlineUserIds((prev) => {
                const next = new Set(prev);
                if (data.isOnline) next.add(data.userId);
                else next.delete(data.userId);
                return next;
              });
            } else if (data.event === 'call:incoming') {
              // Prevent conflicting sessions if user is already connected in another call
              if (activeCall && (callStatus === 'connected' || callStatus === 'connecting')) {
                fetch('/api/call/respond', {
                  method: 'POST',
                  headers: getAuthHeaders(),
                  body: JSON.stringify({ callId: data.call.id, action: 'decline' }),
                }).catch(() => {});
                return;
              }

              setIncomingCall(data.call);
              setCallStatus('ringing');
              playCallSound('incoming');

              // Continuous ringing tone while incoming
              if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
              ringtoneIntervalRef.current = setInterval(() => {
                playCallSound('incoming');
              }, 2500);

              window.dispatchEvent(new CustomEvent('lot:call_incoming', { detail: data.call }));

              // Unanswered call timeout (35s)
              if (callTimeoutRef.current) clearTimeout(callTimeoutRef.current);
              callTimeoutRef.current = setTimeout(() => {
                if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
                playCallSound('ended');
                setIncomingCall(null);
                fetch('/api/call/timeout', {
                  method: 'POST',
                  headers: getAuthHeaders(),
                  body: JSON.stringify({ callId: data.call.id }),
                }).catch(() => {});
              }, 35000);
            } else if (data.event === 'call:response') {
              if (callTimeoutRef.current) clearTimeout(callTimeoutRef.current);
              if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);

              if (data.action === 'accept') {
                playCallSound('connected');
                setActiveCall(data.call);
                setCallStatus('connecting');

                // Caller: create peer connection, add stream tracks and emit offer
                const partnerId = data.call.recipientId;
                let currentStream = localStreamRef.current;
                if (!currentStream) {
                  currentStream = await obtainMedia(data.call.type === 'video');
                }

                if (currentStream) {
                  const pc = initPeerConnection(partnerId, currentStream, true);
                  const offer = await pc.createOffer();
                  await pc.setLocalDescription(offer);
                  sendSignal(partnerId, { sdp: offer });
                }
              } else {
                playCallSound('ended');
                setActiveCall((prev) => (prev ? { ...prev, status: 'declined' } : null));
                setCallStatus('declined');
                setTimeout(() => {
                  teardownCallResources();
                  setActiveCall(null);
                  setCallStatus('idle');
                }, 2000);
              }
            } else if (data.event === 'call:signal') {
              handleIncomingSignal(data.from, data.signal);
            } else if (data.event === 'call:ended') {
              if (callTimeoutRef.current) clearTimeout(callTimeoutRef.current);
              if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
              playCallSound('ended');
              setActiveCall((prev) => (prev ? { ...prev, status: 'ended' } : null));
              setCallStatus('ended');
              setIncomingCall(null);
              setTimeout(() => {
                teardownCallResources();
                setActiveCall(null);
                setCallStatus('idle');
                setCallDuration(0);
              }, 1200);
            }
          } catch (err) {
            console.error('[WebSockets] Message processing error:', err);
          }
        };

        ws.onclose = () => {
          setSocket(null);
          if (isSubscribed) {
            reconnectTimeout = setTimeout(connectWs, 3000);
          }
        };

        ws.onerror = () => {
          ws.close();
        };
      } catch {
        if (isSubscribed) {
          reconnectTimeout = setTimeout(connectWs, 5000);
        }
      }
    };

    connectWs();
    refreshUnreadCount();

    const pollInterval = setInterval(() => {
      refreshUnreadCount();
    }, 15000);

    return () => {
      isSubscribed = false;
      clearInterval(pollInterval);
      if (reconnectTimeout) clearTimeout(reconnectTimeout);
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }
    };
  }, [user?.id, handleIncomingSignal, initPeerConnection, sendSignal, teardownCallResources]);

  // Call duration counter
  useEffect(() => {
    if (callStatus === 'connected' || activeCall?.status === 'connected') {
      timerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [callStatus, activeCall?.status]);

  const getAuthHeaders = (): Record<string, string> => {
    const token = localStorage.getItem('lot_session_token') || user?.token || '';
    return {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    };
  };

  // Initiate call
  const initiateCall = async (target: {
    recipientId?: string;
    recipientUsername?: string;
    type: 'audio' | 'video';
  }): Promise<{ success: boolean; error?: string }> => {
    setCallError(null);
    setCallDuration(0);

    // Resume AudioContext on user gesture
    getSharedAudioContext();

    let stream = await obtainMedia(target.type === 'video');
    if (!stream) {
      stream = createFallbackStream();
      if (stream) setLocalStream(stream);
    }

    try {
      setCallStatus('calling');
      const res = await fetch('/api/call/initiate', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(target),
      });

      const data = await res.json();
      if (!res.ok) {
        teardownCallResources();
        setCallStatus('idle');
        return { success: false, error: data.error || 'Failed to initiate call' };
      }

      setActiveCall(data.call);
      setCallStatus('ringing');
      playCallSound('ringing');

      // Continuous ringing loop
      if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
      ringtoneIntervalRef.current = setInterval(() => {
        playCallSound('ringing');
      }, 3000);

      // 35-second unanswered outgoing call timeout
      if (callTimeoutRef.current) clearTimeout(callTimeoutRef.current);
      callTimeoutRef.current = setTimeout(() => {
        if (callStatus === 'ringing') {
          if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
          playCallSound('ended');
          fetch('/api/call/timeout', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({ callId: data.call.id }),
          }).catch(() => {});
          teardownCallResources();
          setActiveCall((prev) => (prev ? { ...prev, status: 'ended' } : null));
          setCallStatus('ended');
          setTimeout(() => setCallStatus('idle'), 1500);
        }
      }, 35000);

      return { success: true };
    } catch (err: any) {
      teardownCallResources();
      setCallStatus('idle');
      return { success: false, error: err.message || 'Call failed' };
    }
  };

  // Accept incoming call
  const acceptCall = async (callId: string) => {
    setCallError(null);
    if (callTimeoutRef.current) clearTimeout(callTimeoutRef.current);
    if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
    playCallSound('connected');

    // Unlock AudioContext on user interaction
    getSharedAudioContext();

    const isVideo = incomingCall?.type === 'video';
    let stream = await obtainMedia(isVideo);
    if (!stream) {
      stream = createFallbackStream();
      if (stream) setLocalStream(stream);
    }

    try {
      const res = await fetch('/api/call/respond', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ callId, action: 'accept' }),
      });

      if (res.ok) {
        const data = await res.json();
        setActiveCall(data.call);
        setIncomingCall(null);
        setCallStatus('connecting');

        // Recipient initializes peer connection and waits for caller's SDP offer
        const callerId = data.call.callerId;
        if (stream) {
          initPeerConnection(callerId, stream, false);
        }
      }
    } catch (err: any) {
      setCallError('Failed to accept call.');
    }
  };

  // Join Call (allows joining a call directly from chat message or chat card)
  const joinCall = async (callId: string, type?: 'audio' | 'video') => {
    setCallError(null);
    getSharedAudioContext();

    const isVideo = type === 'video' || incomingCall?.type === 'video';
    let stream = await obtainMedia(isVideo);
    if (!stream) {
      stream = createFallbackStream();
      if (stream) setLocalStream(stream);
    }

    try {
      const res = await fetch('/api/call/respond', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ callId, action: 'accept' }),
      });

      if (res.ok) {
        const data = await res.json();
        setActiveCall(data.call);
        setIncomingCall(null);
        setCallStatus('connecting');

        const partnerId = data.call.callerId === user?.id ? data.call.recipientId : data.call.callerId;
        if (stream) {
          initPeerConnection(partnerId, stream, false);
        }
      } else {
        const data = await res.json();
        setCallError(data.error || 'Could not join call');
      }
    } catch {
      setCallError('Failed to join call.');
    }
  };

  // Decline call
  const declineCall = async (callId: string) => {
    if (callTimeoutRef.current) clearTimeout(callTimeoutRef.current);
    if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
    playCallSound('ended');

    try {
      await fetch('/api/call/respond', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ callId, action: 'decline' }),
      });
      setIncomingCall(null);
    } catch {}
  };

  // End active call
  const endCall = async () => {
    if (callTimeoutRef.current) clearTimeout(callTimeoutRef.current);
    if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
    playCallSound('ended');

    if (activeCall) {
      try {
        await fetch('/api/call/end', {
          method: 'POST',
          headers: getAuthHeaders(),
          body: JSON.stringify({ callId: activeCall.id }),
        });
      } catch {}
    }

    setCallStatus('ended');
    setActiveCall((prev) => (prev ? { ...prev, status: 'ended' } : null));

    setTimeout(() => {
      teardownCallResources();
      setActiveCall(null);
      setCallStatus('idle');
      setCallDuration(0);
    }, 1000);
  };

  // Toggle microphone mute
  const toggleMute = () => {
    if (localStream) {
      const nextMuted = !isMuted;
      localStream.getAudioTracks().forEach((track) => {
        track.enabled = !nextMuted;
      });
      setIsMuted(nextMuted);
    }
  };

  // Toggle video camera
  const toggleVideo = () => {
    if (localStream) {
      const nextEnabled = !isVideoEnabled;
      localStream.getVideoTracks().forEach((track) => {
        track.enabled = nextEnabled;
      });
      setIsVideoEnabled(nextEnabled);
    }
  };

  // Toggle speaker
  const toggleSpeaker = () => {
    setIsSpeakerOn(!isSpeakerOn);
  };

  // Switch camera between front and back
  const switchCamera = async () => {
    const nextFacing = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(nextFacing);

    if (localStream && isVideoEnabled) {
      try {
        const newStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: nextFacing },
          audio: false,
        });

        const newVideoTrack = newStream.getVideoTracks()[0];
        if (newVideoTrack && pcRef.current) {
          const sender = pcRef.current.getSenders().find((s) => s.track && s.track.kind === 'video');
          if (sender) {
            sender.replaceTrack(newVideoTrack);
          }
          const oldVideoTrack = localStream.getVideoTracks()[0];
          if (oldVideoTrack) oldVideoTrack.stop();
          localStream.removeTrack(oldVideoTrack);
          localStream.addTrack(newVideoTrack);
          setLocalStream(new MediaStream(localStream.getTracks()));
        }
      } catch (err) {
        console.warn('Switch camera error:', err);
      }
    }
  };

  const openChatWith = (username: string) => {
    setTargetChatUser(username);
    if (onNavigateToChat) {
      onNavigateToChat();
    }
  };

  return (
    <SocialContext.Provider
      value={{
        unreadChatCount,
        activeCall,
        incomingCall,
        callStatus,
        callError,
        isMuted,
        isVideoEnabled,
        isSpeakerOn,
        callDuration,
        localStream,
        remoteStream,
        onlineUserIds,
        initiateCall,
        acceptCall,
        joinCall,
        declineCall,
        endCall,
        toggleMute,
        toggleVideo,
        toggleSpeaker,
        switchCamera,
        targetChatUser,
        setTargetChatUser,
        openChatWith,
        refreshUnreadCount,
        socket,
      }}
    >
      {children}
    </SocialContext.Provider>
  );
};

export const useSocial = () => {
  const context = useContext(SocialContext);
  if (!context) {
    throw new Error('useSocial must be used within a SocialProvider');
  }
  return context;
};
