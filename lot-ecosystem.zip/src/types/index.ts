export type ProductCategory = 'Weapons' | 'Collectibles' | 'Clothing' | 'Other';

export interface User {
  id: string;
  username: string;
  usernameLower: string;
  lotBalance: number;
  isAdmin: boolean;
  isBanned: boolean;
  vipBadge?: string;
  avatarUrl?: string;
  token?: string;
  createdAt: string;
  lastLoginAt?: string;
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  category: ProductCategory;
  priceLot: number;
  stock: number;
  sellerId: string;
  sellerUsername: string;
  images: string[];
  status: 'active' | 'sold_out' | 'delisted';
  createdAt: string;
  updatedAt?: string;
}

export type OrderStatus = 'Placed' | 'Processing' | 'Delivered';

export interface Order {
  id: string;
  listingId: string;
  listingTitle: string;
  priceLot: number;
  quantity: number;
  totalLot: number;
  buyerId: string;
  buyerUsername: string;
  sellerId: string;
  sellerUsername: string;
  status: OrderStatus;
  createdAt: string;
  updatedAt?: string;
}

export type TransactionType =
  | 'vpay_send'
  | 'vpay_receive'
  | 'shop_purchase'
  | 'shop_sale'
  | 'stock_buy'
  | 'stock_sell'
  | 'redemption'
  | 'minigame_reward'
  | 'admin_adjustment';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  balanceAfter: number;
  referenceId?: string;
  description: string;
  createdAt: string;
}

export interface VPayTransfer {
  id: string;
  senderId: string;
  senderUsername: string;
  recipientId: string;
  recipientUsername: string;
  amount: number;
  note?: string;
  status: 'completed' | 'failed';
  createdAt: string;
}

export interface StockInstrument {
  id: string;
  symbol: string;
  name: string;
  category: string;
  currentPrice: number;
  previousPrice: number;
  dayHigh: number;
  dayLow: number;
  change24h: number;
  volume24h: number;
  sparkline: number[];
}

export interface UserPortfolio {
  id: string;
  userId: string;
  symbol: string;
  quantity: number;
  averageBuyPrice: number;
  totalInvested: number;
  updatedAt: string;
}

export interface StockTrade {
  id: string;
  userId: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  quantity: number;
  pricePerUnit: number;
  totalLot: number;
  createdAt: string;
}

export interface RedemptionCode {
  id: string;
  code: string;
  rewardLot: number;
  maxClaims: number;
  claimsCount: number;
  isActive: boolean;
  expiresAt?: string;
  createdBy: string;
  createdAt: string;
}

export interface RedemptionClaim {
  id: string;
  codeId: string;
  code: string;
  userId: string;
  username: string;
  rewardLot: number;
  claimedAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'purchase' | 'order' | 'vpay' | 'stock' | 'redemption' | 'game' | 'announcement' | 'admin';
  read: boolean;
  createdAt: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  author: string;
  createdAt: string;
}

export interface AdminAuditLog {
  id: string;
  adminId: string;
  adminUsername: string;
  action: string;
  targetUserId?: string;
  details: string;
  createdAt: string;
}

export interface PlatformStats {
  totalUsers: number;
  circulatingLot: number;
  activeListings: number;
  completedOrders: number;
  totalTrades: number;
  totalTransfers: number;
}

export interface PlayerSummary {
  id: string;
  username: string;
  avatarUrl?: string;
  lotBalance: number;
  vipBadge?: string;
  isAdmin?: boolean;
  isFriend?: boolean;
  isBlocked?: boolean;
  hasBlockedMe?: boolean;
  isOnline?: boolean;
  lastActiveAt?: string;
}

export interface DirectMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderUsername: string;
  senderAvatarUrl?: string;
  recipientId: string;
  recipientUsername: string;
  recipientAvatarUrl?: string;
  content: string;
  read: boolean;
  createdAt: string;
  type?: 'text' | 'call' | 'image' | 'gif';
  callId?: string;
  callType?: 'audio' | 'video';
  callStatus?: 'ringing' | 'connected' | 'ended' | 'declined';
  attachmentUrl?: string;
  mediaType?: 'image' | 'gif';
  fileName?: string;
  fileSize?: number;
}

export interface Conversation {
  id: string;
  partnerId: string;
  partnerUsername: string;
  partnerAvatarUrl?: string;
  partnerBalance?: number;
  partnerVipBadge?: string;
  lastMessage: string;
  lastMessageTime: string;
  lastSenderId: string;
  unreadCount: number;
  isFriend: boolean;
  isBlocked: boolean;
  hasBlockedMe: boolean;
  isOnline?: boolean;
}

export interface FriendRecord {
  id: string;
  userId: string;
  friendId: string;
  friendUsername: string;
  friendAvatarUrl?: string;
  friendBalance?: number;
  createdAt: string;
}

export interface BlockRecord {
  id: string;
  userId: string;
  blockedUserId: string;
  blockedUsername: string;
  blockedAvatarUrl?: string;
  createdAt: string;
}

export interface CallSession {
  id: string;
  callerId: string;
  callerUsername: string;
  callerAvatarUrl?: string;
  recipientId: string;
  recipientUsername: string;
  recipientAvatarUrl?: string;
  type: 'audio' | 'video';
  status: 'ringing' | 'connected' | 'ended' | 'declined' | 'busy';
  startedAt: string;
  connectedAt?: string;
  endedAt?: string;
}

export interface ShortVideo {
  id: string;
  creatorId: string;
  creatorUsername: string;
  creatorAvatar?: string;
  videoUrl: string;
  thumbnailUrl?: string;
  caption: string;
  hashtags: string[];
  duration: number; // in seconds, <= 60
  likesCount: number;
  viewsCount: number;
  commentsCount: number;
  allowComments: boolean;
  status: 'active' | 'removed';
  createdAt: string;
  updatedAt?: string;
  hasLiked?: boolean;
  hasSaved?: boolean;
  isFollowing?: boolean;
  // YouTube Video Publisher Integration
  source?: 'upload' | 'youtube';
  youtubeVideoId?: string;
  youtubeUrl?: string;
  youtubeChannelTitle?: string;
  youtubeChannelId?: string;
  youtubeChannelUrl?: string;
  isAttributionVerified?: boolean;
  publishedByAdminId?: string;
  publishedByAdminUsername?: string;
}

export interface ShortComment {
  id: string;
  shortId: string;
  userId: string;
  username: string;
  userAvatar?: string;
  text?: string;
  gifUrl?: string;
  gifTitle?: string;
  parentCommentId?: string;
  likesCount: number;
  createdAt: string;
  updatedAt?: string;
  hasLiked?: boolean;
  replies?: ShortComment[];
}

export interface GifItem {
  id: string;
  title: string;
  url: string;
  previewUrl: string;
  width?: number;
  height?: number;
}

export interface ShortReport {
  id: string;
  type: 'video' | 'comment';
  targetId: string;
  shortId?: string;
  reporterId: string;
  reporterUsername: string;
  reason: string;
  details?: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
  videoSnapshot?: Partial<ShortVideo>;
  commentSnapshot?: Partial<ShortComment>;
}

// Bank System Types
export interface BankAccount {
  userId: string;
  savingsBalance: number;
  totalDeposited: number;
  totalWithdrawn: number;
  interestEarned: number;
  lastInterestAccrual: string;
  creditScore: number;
  updatedAt: string;
  createdAt: string;
}

export type BankLoanStatus = 'active' | 'repaid' | 'overdue_deducted';

export interface BankLoan {
  id: string;
  userId: string;
  username: string;
  principal: number; // 500 to 10000 LOT
  interestRate: number; // 0.05 (5%)
  interestAmount: number;
  totalDue: number;
  amountRepaid: number;
  remainingDue: number;
  status: BankLoanStatus;
  createdAt: string;
  dueDate: string; // createdAt + 7 days
  repaidAt?: string;
  autoDeductedAt?: string;
  defecitIncurred?: number;
}

export type BankTransactionType =
  | 'deposit'
  | 'withdraw'
  | 'interest_payout'
  | 'loan_disbursed'
  | 'loan_repayment'
  | 'loan_auto_deducted';

export interface BankTransaction {
  id: string;
  userId: string;
  type: BankTransactionType;
  amount: number;
  savingsBalanceAfter?: number;
  walletBalanceAfter: number;
  description: string;
  createdAt: string;
}


