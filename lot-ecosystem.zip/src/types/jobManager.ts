export type EmploymentType =
  | 'Private Company Employee'
  | 'Business or Shop Employee'
  | 'Government Job Employee'
  | 'Self-Employed'
  | 'Contract Worker'
  | 'Temporary Employee'
  | 'Custom Employment Type';

export type SalaryFrequency = 'Monthly' | 'Weekly' | 'Daily' | 'Hourly';

export type EmployeeStatus =
  | 'active'
  | 'on_leave'
  | 'suspended'
  | 'resigned'
  | 'retired'
  | 'terminated';

export type PaymentStatus = 'paid' | 'pending' | 'partially_paid' | 'overdue';

export type PaymentMethod =
  | 'LOT Ecosystem Transfer'
  | 'Bank Transfer / Direct Deposit'
  | 'Cash'
  | 'Cheque'
  | 'Digital Wallet';

export type LeaveType = 'Casual Leave' | 'Sick Leave' | 'Paid Leave' | 'Unpaid Leave' | 'Emergency Leave';
export type LeaveStatus = 'pending' | 'approved' | 'rejected';

export interface SalaryAdjustment {
  id: string;
  type: 'bonus' | 'commission' | 'overtime' | 'reward' | 'deduction' | 'advance' | 'unpaid_leave_penalty';
  label: string;
  amount: number; // positive for bonuses/overtime, negative or deducted for deductions
  reason: string;
  createdAt: string;
}

export interface EmployeeDocument {
  id: string;
  title: string;
  type: 'contract' | 'appointment_letter' | 'identity_document' | 'other';
  fileUrl: string;
  fileName: string;
  fileSize?: number;
  uploadedAt: string;
  uploadedBy: string;
}

export interface PerformanceRecord {
  id: string;
  date: string;
  rating: number; // 1-5
  reviewTitle: string;
  notes: string;
  reviewedBy: string;
}

export interface PromotionRecord {
  id: string;
  date: string;
  previousTitle: string;
  newTitle: string;
  previousSalary: number;
  newSalary: number;
  notes: string;
  authorizedBy: string;
}

export interface Employee {
  id: string; // e.g. emp_uuid
  orgId: string;
  organizationName: string;
  // If linked to LOT account:
  userId?: string | null;
  username?: string | null;
  avatarUrl?: string | null;
  // Employee personal info:
  fullName: string;
  email?: string;
  phone?: string;
  employeeIdNumber: string; // e.g. EMP-2026-001
  department: string;
  jobTitle: string;
  employmentType: EmploymentType;
  customEmploymentType?: string;
  status: EmployeeStatus;
  joiningDate: string; // YYYY-MM-DD
  exitDate?: string | null;
  // Salary configuration:
  salaryFrequency: SalaryFrequency;
  baseSalary: number;
  currency: 'LOT' | 'USD' | 'GBP' | 'EUR';
  // Attendance settings / rates:
  hourlyRate?: number;
  dailyRate?: number;
  totalLeaveAllowance: number; // annual days, e.g. 18
  leaveUsed: number;
  lastPaidDate?: string | null;
  nextExpectedSalaryDate?: string | null;
  autoPayEnabled?: boolean;
  // Performance and Documents:
  performanceRecords?: PerformanceRecord[];
  promotionHistory?: PromotionRecord[];
  documents?: EmployeeDocument[];
  // Metadata:
  managerId: string;
  managerUsername: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SalaryPayment {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeIdNumber: string;
  department: string;
  jobTitle: string;
  orgId: string;
  organizationName: string;
  salaryPeriod: string; // e.g. "November 2026" or "Week 44, 2026"
  salaryFrequency: SalaryFrequency;
  baseAmount: number;
  totalHoursWorked?: number;
  totalDaysWorked?: number;
  adjustments: SalaryAdjustment[];
  totalBonus: number;
  totalDeductions: number;
  netPayableAmount: number;
  paidAmount: number;
  paymentStatus: PaymentStatus;
  paymentDate?: string | null;
  nextExpectedSalaryDate?: string;
  paymentMethod: PaymentMethod;
  transactionReference?: string;
  currency: 'LOT' | 'USD' | 'GBP' | 'EUR';
  notes?: string;
  // Audit details
  recordedBy: string;
  recordedByUsername: string;
  slipGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  orgId: string;
  date: string; // YYYY-MM-DD
  status: 'present' | 'absent' | 'leave' | 'half_day';
  checkInTime?: string; // HH:mm
  checkOutTime?: string; // HH:mm
  hoursWorked: number;
  overtimeHours: number;
  notes?: string;
  markedBy: string;
  createdAt: string;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeIdNumber: string;
  userId?: string | null;
  orgId: string;
  leaveType: LeaveType;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  daysCount: number;
  reason: string;
  status: LeaveStatus;
  reviewedBy?: string;
  reviewNotes?: string;
  reviewedAt?: string;
  createdAt: string;
}

export interface JobAuditLog {
  id: string;
  orgId: string;
  action:
    | 'employee_created'
    | 'employee_updated'
    | 'salary_changed'
    | 'payment_recorded'
    | 'payment_corrected'
    | 'leave_reviewed'
    | 'status_changed'
    | 'document_uploaded';
  targetEmployeeId?: string;
  targetEmployeeName?: string;
  description: string;
  performedBy: string;
  performedByUsername: string;
  timestamp: string;
}

export interface OrganizationProfile {
  id: string;
  name: string;
  type: 'Business' | 'Private Company' | 'Shop' | 'Organization' | 'Government Department';
  departmentList: string[];
  ownerId: string;
  ownerUsername: string;
  defaultCurrency: 'LOT' | 'USD' | 'GBP' | 'EUR';
  createdAt: string;
}
