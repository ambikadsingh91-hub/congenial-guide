import { Request, Response, Express, NextFunction } from 'express';
import crypto from 'crypto';
import {
  Firestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
  runTransaction,
  orderBy,
  limit,
} from 'firebase/firestore';
import { BankAccount, BankLoan, BankTransaction } from '../types';

export interface BankRouterDeps {
  db: Firestore;
  authMiddleware: (req: Request, res: Response, next: NextFunction) => void;
  sendToUser: (userId: string, event: string, payload: any) => boolean;
}

// Fixed Constants according to prompt requirements
const MIN_LOAN_AMOUNT = 500;
const MAX_LOAN_AMOUNT = 10000;
const LOAN_DURATION_MS = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds
const LOAN_INTEREST_RATE = 0.05; // 5% fixed loan interest / service fee
const SAVINGS_APY = 0.045; // 4.5% annual percentage yield on bank vault deposits

export function setupBankRoutes(app: Express, deps: BankRouterDeps) {
  const { db, authMiddleware, sendToUser } = deps;

  // Helper to get or initialize a user's bank account with continuous interest calculation
  async function getOrInitBankAccount(userId: string): Promise<BankAccount> {
    const accountRef = doc(db, 'bank_accounts', userId);
    const snap = await getDoc(accountRef);
    const now = new Date().toISOString();

    if (!snap.exists()) {
      const initialAccount: BankAccount = {
        userId,
        savingsBalance: 0,
        totalDeposited: 0,
        totalWithdrawn: 0,
        interestEarned: 0,
        lastInterestAccrual: now,
        creditScore: 720,
        createdAt: now,
        updatedAt: now,
      };
      await setDoc(accountRef, initialAccount);
      return initialAccount;
    }

    const account = snap.data() as BankAccount;

    // Calculate accrued interest on savings vault balance
    if (account.savingsBalance > 0 && account.lastInterestAccrual) {
      const lastAccrual = new Date(account.lastInterestAccrual).getTime();
      const elapsedSeconds = Math.max(0, (Date.now() - lastAccrual) / 1000);

      // Annual interest compounding rate per second: APY / (365 * 86400)
      const pendingInterest = Math.floor(
        account.savingsBalance * (SAVINGS_APY / (365 * 86400)) * elapsedSeconds * 100
      ) / 100;

      if (pendingInterest >= 1) {
        const newSavingsBalance = Math.round((account.savingsBalance + pendingInterest) * 100) / 100;
        const newInterestEarned = Math.round(((account.interestEarned || 0) + pendingInterest) * 100) / 100;

        await updateDoc(accountRef, {
          savingsBalance: newSavingsBalance,
          interestEarned: newInterestEarned,
          lastInterestAccrual: now,
          updatedAt: now,
        });

        account.savingsBalance = newSavingsBalance;
        account.interestEarned = newInterestEarned;
        account.lastInterestAccrual = now;

        // Record interest transaction
        const txId = `btx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        await setDoc(doc(db, 'bank_transactions', txId), {
          id: txId,
          userId,
          type: 'interest_payout',
          amount: pendingInterest,
          savingsBalanceAfter: newSavingsBalance,
          walletBalanceAfter: 0, // Not wallet
          description: `Accrued Vault Savings Yield (+${pendingInterest.toLocaleString()} LOT)`,
          createdAt: now,
        });
      }
    }

    return account;
  }

  // Core Overdue Loan Auto-Deduction Engine:
  // If a loan reaches 7 days (now >= dueDate), automatically deduct the remaining balance from the user's LOT balance.
  // CRITICAL REQUIREMENT: If the user does not have enough balance, their balance GOES INTO MINUS (negative).
  async function processOverdueLoans(targetUserId?: string): Promise<number> {
    const nowMs = Date.now();
    const nowIso = new Date().toISOString();
    let processedCount = 0;

    try {
      let snapshot;
      if (targetUserId) {
        // Query by single field userId to avoid requiring composite indexes
        const q = query(
          collection(db, 'bank_loans'),
          where('userId', '==', targetUserId)
        );
        snapshot = await getDocs(q);
      } else {
        const q = query(
          collection(db, 'bank_loans'),
          where('status', '==', 'active')
        );
        snapshot = await getDocs(q);
      }

      for (const loanDoc of snapshot.docs) {
        const loan = loanDoc.data() as BankLoan;
        if (loan.status !== 'active') continue;
        const dueDateMs = new Date(loan.dueDate).getTime();

        // Check if 7 days has elapsed
        if (nowMs >= dueDateMs) {
          const loanRef = doc(db, 'bank_loans', loan.id);
          const userRef = doc(db, 'users', loan.userId);
          const accountRef = doc(db, 'bank_accounts', loan.userId);

          await runTransaction(db, async (transaction) => {
            // ALL READS FIRST
            const currentLoanSnap = await transaction.get(loanRef);
            if (!currentLoanSnap.exists()) return;
            const currentLoan = currentLoanSnap.data() as BankLoan;
            if (currentLoan.status !== 'active') return;

            const currentUserSnap = await transaction.get(userRef);
            if (!currentUserSnap.exists()) return;
            const currentUser = currentUserSnap.data();

            const currentAccountSnap = await transaction.get(accountRef);

            const amountToDeduct = currentLoan.remainingDue;
            const currentBalance = currentUser.lotBalance || 0;
            // Balance is explicitly permitted to go negative per user requirement:
            const newBalance = currentBalance - amountToDeduct;
            const deficit = newBalance < 0 ? Math.abs(newBalance) : 0;

            // ALL WRITES AFTER READS
            // 1. Update user's wallet balance (can be negative)
            transaction.update(userRef, {
              lotBalance: newBalance,
              updatedAt: nowIso,
            });

            // 2. Mark loan as overdue_deducted
            transaction.update(loanRef, {
              status: 'overdue_deducted',
              remainingDue: 0,
              autoDeductedAt: nowIso,
              defecitIncurred: deficit,
            });

            // 3. Lower credit score on default (-60 points, floor 300)
            if (currentAccountSnap.exists()) {
              const currentAcc = currentAccountSnap.data() as BankAccount;
              const newScore = Math.max(300, (currentAcc.creditScore || 720) - 60);
              transaction.update(accountRef, {
                creditScore: newScore,
                updatedAt: nowIso,
              });
            }

            // 4. Record Bank Transaction
            const bankTxId = `btx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
            transaction.set(doc(db, 'bank_transactions', bankTxId), {
              id: bankTxId,
              userId: loan.userId,
              type: 'loan_auto_deducted',
              amount: amountToDeduct,
              walletBalanceAfter: newBalance,
              description: `7-Day Loan Overdue Auto-Deduction (-${amountToDeduct.toLocaleString()} LOT)${newBalance < 0 ? ' [Account Overdrawn]' : ''}`,
              createdAt: nowIso,
            });

            // 5. Authoritative Ledger Transaction
            const ledgerTxId = `tx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
            transaction.set(doc(db, 'transactions', ledgerTxId), {
              id: ledgerTxId,
              userId: loan.userId,
              type: 'admin_adjustment',
              amount: -amountToDeduct,
              balanceAfter: newBalance,
              referenceId: loan.id,
              description: `LOT Bank: 7-day loan auto-deducted. Outstanding: ${amountToDeduct.toLocaleString()} LOT.${newBalance < 0 ? ` Balance is negative: ${newBalance.toLocaleString()} LOT.` : ''}`,
              createdAt: nowIso,
            });

            // 6. Push notification to user
            const notifId = `notif_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
            transaction.set(doc(db, 'notifications', notifId), {
              id: notifId,
              userId: loan.userId,
              title: '⚠️ Bank Loan Auto-Deduction',
              message: `Your 7-day loan term of ${loan.principal.toLocaleString()} LOT has expired. ${amountToDeduct.toLocaleString()} LOT was automatically deducted.${newBalance < 0 ? ` Your wallet is currently overdrawn at ${newBalance.toLocaleString()} LOT.` : ` Current balance: ${newBalance.toLocaleString()} LOT.`}`,
              type: 'warning',
              read: false,
              createdAt: nowIso,
            });
          });

          // Live WebSocket alert
          sendToUser(loan.userId, 'bank:loan_autodeducted', {
            loanId: loan.id,
            principal: loan.principal,
            amountDeducted: loan.remainingDue,
            timestamp: nowIso,
          });

          processedCount++;
        }
      }
    } catch (err) {
      console.error('Error processing overdue bank loans:', err);
    }

    return processedCount;
  }

  // Auto-deduction cron: check for overdue loans every 30 seconds
  const autoDeductInterval = setInterval(() => {
    processOverdueLoans().catch((err) => console.error('Cron overdue loan error:', err));
  }, 30000);

  // Clean up timer if needed on hot reload/process termination
  if (process.on) {
    process.on('SIGTERM', () => clearInterval(autoDeductInterval));
  }

  // ----------------------------------------------------------------------
  // ROUTE: GET /api/bank/account
  // Returns user's bank account, savings balance, active loan, recent history
  // ----------------------------------------------------------------------
  app.get('/api/bank/account', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;

      // 1. Process any overdue loans for this user immediately
      await processOverdueLoans(current.id);

      // 2. Fetch or initialize Bank Account with interest accrual
      const account = await getOrInitBankAccount(current.id);

      // 3. Fetch all user loans (single query by userId to avoid requiring composite indexes)
      const loanHistoryQuery = query(
        collection(db, 'bank_loans'),
        where('userId', '==', current.id),
        limit(20)
      );
      const loanHistorySnap = await getDocs(loanHistoryQuery);
      const pastLoans = loanHistorySnap.docs
        .map((d) => d.data() as BankLoan)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      const activeLoan = pastLoans.find((l) => l.status === 'active') || null;

      // 5. Fetch recent bank transactions
      const txQuery = query(
        collection(db, 'bank_transactions'),
        where('userId', '==', current.id),
        limit(30)
      );
      const txSnap = await getDocs(txQuery);
      const recentTransactions = txSnap.docs
        .map((d) => d.data() as BankTransaction)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      // 6. Get updated wallet balance from user doc
      const userSnap = await getDoc(doc(db, 'users', current.id));
      const walletBalance = userSnap.exists() ? userSnap.data().lotBalance || 0 : 0;

      // 7. Get Bank of Lotus Central Reserve Authority info
      const bankUserSnap = await getDoc(doc(db, 'users', 'usr_910d42bb-f85f-4806-a045-0f5780a7581c'));
      const bankAccountSnap = await getDoc(doc(db, 'bank_accounts', 'usr_910d42bb-f85f-4806-a045-0f5780a7581c'));

      const bankAuthority = {
        id: 'usr_910d42bb-f85f-4806-a045-0f5780a7581c',
        username: 'Bank_Of_Lotus',
        displayName: 'Bank of Lotus Central Reserve',
        reserveBalance: bankUserSnap.exists() ? (bankUserSnap.data().lotBalance || 45023378431075) : 45023378431075,
        vaultReserves: bankAccountSnap.exists() ? (bankAccountSnap.data().savingsBalance || 10000000000000) : 10000000000000,
        creditRating: 'AAA+ Sovereign Reserve Tier 1',
        status: 'Official Ecosystem Reserve & Loan Authority',
        verified: true,
      };

      res.json({
        account,
        activeLoan,
        pastLoans,
        recentTransactions,
        walletBalance,
        bankAuthority,
        loanLimits: {
          min: MIN_LOAN_AMOUNT,
          max: MAX_LOAN_AMOUNT,
          durationDays: 7,
          interestRate: LOAN_INTEREST_RATE,
        },
        savingsApy: SAVINGS_APY,
      });
    } catch (err: any) {
      console.error('Error fetching bank account:', err);
      res.status(500).json({ error: 'Failed to load bank account' });
    }
  });

  // ----------------------------------------------------------------------
  // ROUTE: POST /api/bank/deposit
  // Deposit LOT from wallet balance into bank savings vault
  // ----------------------------------------------------------------------
  app.post('/api/bank/deposit', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const rawAmount = Number(req.body.amount);

      if (isNaN(rawAmount) || rawAmount <= 0) {
        return res.status(400).json({ error: 'Please specify a valid deposit amount greater than 0.' });
      }

      const amount = Math.floor(rawAmount);
      const userRef = doc(db, 'users', current.id);
      const accountRef = doc(db, 'bank_accounts', current.id);
      const now = new Date().toISOString();

      await getOrInitBankAccount(current.id);

      const result = await runTransaction(db, async (t) => {
        const userDoc = await t.get(userRef);
        if (!userDoc.exists()) {
          throw new Error('User not found');
        }

        const userData = userDoc.data();
        const currentWalletBalance = userData.lotBalance || 0;

        if (currentWalletBalance < amount) {
          throw new Error(`Insufficient wallet balance. You have ${currentWalletBalance.toLocaleString()} LOT.`);
        }

        const accountDoc = await t.get(accountRef);
        const accountData = accountDoc.data() as BankAccount;

        const newWalletBalance = currentWalletBalance - amount;
        const newSavingsBalance = (accountData.savingsBalance || 0) + amount;
        const newTotalDeposited = (accountData.totalDeposited || 0) + amount;

        // 1. Debit wallet
        t.update(userRef, {
          lotBalance: newWalletBalance,
          updatedAt: now,
        });

        // 2. Credit savings vault
        t.update(accountRef, {
          savingsBalance: newSavingsBalance,
          totalDeposited: newTotalDeposited,
          lastInterestAccrual: now,
          updatedAt: now,
        });

        // 3. Bank transaction log
        const bankTxId = `btx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        t.set(doc(db, 'bank_transactions', bankTxId), {
          id: bankTxId,
          userId: current.id,
          type: 'deposit',
          amount,
          savingsBalanceAfter: newSavingsBalance,
          walletBalanceAfter: newWalletBalance,
          description: `Deposited into Bank Vault (+${amount.toLocaleString()} LOT)`,
          createdAt: now,
        });

        // 4. Main ledger transaction log
        const ledgerTxId = `tx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        t.set(doc(db, 'transactions', ledgerTxId), {
          id: ledgerTxId,
          userId: current.id,
          type: 'vpay_send',
          amount: -amount,
          balanceAfter: newWalletBalance,
          description: `LOT Bank: Stored in Vault (-${amount.toLocaleString()} LOT)`,
          createdAt: now,
        });

        return {
          newWalletBalance,
          newSavingsBalance,
        };
      });

      sendToUser(current.id, 'wallet:balance_update', { lotBalance: result.newWalletBalance });

      res.json({
        success: true,
        message: `Successfully deposited ${amount.toLocaleString()} LOT into your bank savings vault!`,
        ...result,
      });
    } catch (err: any) {
      console.error('Deposit error:', err);
      res.status(400).json({ error: err.message || 'Deposit failed' });
    }
  });

  // ----------------------------------------------------------------------
  // ROUTE: POST /api/bank/withdraw
  // Withdraw LOT from bank savings vault back to wallet balance
  // ----------------------------------------------------------------------
  app.post('/api/bank/withdraw', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const rawAmount = Number(req.body.amount);

      if (isNaN(rawAmount) || rawAmount <= 0) {
        return res.status(400).json({ error: 'Please specify a valid withdrawal amount greater than 0.' });
      }

      const amount = Math.floor(rawAmount);
      const userRef = doc(db, 'users', current.id);
      const accountRef = doc(db, 'bank_accounts', current.id);
      const now = new Date().toISOString();

      await getOrInitBankAccount(current.id);

      const result = await runTransaction(db, async (t) => {
        const accountDoc = await t.get(accountRef);
        if (!accountDoc.exists()) {
          throw new Error('Bank account not initialized');
        }

        const accountData = accountDoc.data() as BankAccount;
        const currentSavings = accountData.savingsBalance || 0;

        if (currentSavings < amount) {
          throw new Error(`Insufficient vault balance. You have ${currentSavings.toLocaleString()} LOT stored.`);
        }

        const userDoc = await t.get(userRef);
        if (!userDoc.exists()) {
          throw new Error('User not found');
        }

        const userData = userDoc.data();
        const currentWalletBalance = userData.lotBalance || 0;

        const newSavingsBalance = currentSavings - amount;
        const newWalletBalance = currentWalletBalance + amount;
        const newTotalWithdrawn = (accountData.totalWithdrawn || 0) + amount;

        // 1. Debit savings vault
        t.update(accountRef, {
          savingsBalance: newSavingsBalance,
          totalWithdrawn: newTotalWithdrawn,
          lastInterestAccrual: now,
          updatedAt: now,
        });

        // 2. Credit wallet
        t.update(userRef, {
          lotBalance: newWalletBalance,
          updatedAt: now,
        });

        // 3. Bank transaction log
        const bankTxId = `btx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        t.set(doc(db, 'bank_transactions', bankTxId), {
          id: bankTxId,
          userId: current.id,
          type: 'withdraw',
          amount,
          savingsBalanceAfter: newSavingsBalance,
          walletBalanceAfter: newWalletBalance,
          description: `Withdrawn from Bank Vault (-${amount.toLocaleString()} LOT)`,
          createdAt: now,
        });

        // 4. Main ledger transaction log
        const ledgerTxId = `tx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        t.set(doc(db, 'transactions', ledgerTxId), {
          id: ledgerTxId,
          userId: current.id,
          type: 'vpay_receive',
          amount,
          balanceAfter: newWalletBalance,
          description: `LOT Bank: Withdrawn from Vault (+${amount.toLocaleString()} LOT)`,
          createdAt: now,
        });

        return {
          newWalletBalance,
          newSavingsBalance,
        };
      });

      sendToUser(current.id, 'wallet:balance_update', { lotBalance: result.newWalletBalance });

      res.json({
        success: true,
        message: `Successfully withdrawn ${amount.toLocaleString()} LOT to your wallet!`,
        ...result,
      });
    } catch (err: any) {
      console.error('Withdraw error:', err);
      res.status(400).json({ error: err.message || 'Withdrawal failed' });
    }
  });

  // ----------------------------------------------------------------------
  // ROUTE: POST /api/bank/loan/apply
  // Apply for a real-life LOT loan:
  // - Minimum: 500 LOT
  // - Maximum: 10,000 LOT
  // - Term: 7 days to repay
  // - Automatic deduction if not repaid in 7 days (balance can go negative)
  // ----------------------------------------------------------------------
  app.post('/api/bank/loan/apply', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const rawAmount = Number(req.body.amount);

      if (isNaN(rawAmount)) {
        return res.status(400).json({ error: 'Invalid loan amount.' });
      }

      const amount = Math.floor(rawAmount);

      // Validate exact user bounds: 500 LOT minimum, 10,000 LOT maximum
      if (amount < MIN_LOAN_AMOUNT || amount > MAX_LOAN_AMOUNT) {
        return res.status(400).json({
          error: `Loan amount must be between ${MIN_LOAN_AMOUNT.toLocaleString()} LOT and ${MAX_LOAN_AMOUNT.toLocaleString()} LOT.`,
        });
      }

      // Check if user already has an active loan (single field query to avoid composite index)
      const userLoansQuery = query(
        collection(db, 'bank_loans'),
        where('userId', '==', current.id)
      );
      const userLoansSnap = await getDocs(userLoansQuery);
      const existing = userLoansSnap.docs
        .map((d) => d.data() as BankLoan)
        .find((l) => l.status === 'active');
      if (existing) {
        return res.status(400).json({
          error: `You already have an active loan of ${existing.principal.toLocaleString()} LOT. You must repay it before taking another.`,
        });
      }

      await getOrInitBankAccount(current.id);

      const now = new Date();
      const nowIso = now.toISOString();
      // Exact 7 days duration
      const dueDateIso = new Date(now.getTime() + LOAN_DURATION_MS).toISOString();

      const interestAmount = Math.round(amount * LOAN_INTEREST_RATE);
      const totalDue = amount + interestAmount;
      const loanId = `loan_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;

      const userRef = doc(db, 'users', current.id);
      const loanRef = doc(db, 'bank_loans', loanId);

      const result = await runTransaction(db, async (t) => {
        const userDoc = await t.get(userRef);
        if (!userDoc.exists()) {
          throw new Error('User not found');
        }

        const userData = userDoc.data();
        const currentWalletBalance = userData.lotBalance || 0;
        const newWalletBalance = currentWalletBalance + amount;

        // 1. Disburse principal into user's wallet
        t.update(userRef, {
          lotBalance: newWalletBalance,
          updatedAt: nowIso,
        });

        // 2. Create Bank Loan Record
        const newLoan: BankLoan = {
          id: loanId,
          userId: current.id,
          username: current.username,
          principal: amount,
          interestRate: LOAN_INTEREST_RATE,
          interestAmount,
          totalDue,
          amountRepaid: 0,
          remainingDue: totalDue,
          status: 'active',
          createdAt: nowIso,
          dueDate: dueDateIso,
        };
        t.set(loanRef, newLoan);

        // 3. Bank transaction log
        const bankTxId = `btx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        t.set(doc(db, 'bank_transactions', bankTxId), {
          id: bankTxId,
          userId: current.id,
          type: 'loan_disbursed',
          amount,
          walletBalanceAfter: newWalletBalance,
          description: `Disbursed 7-Day Loan (+${amount.toLocaleString()} LOT). Repay ${totalDue.toLocaleString()} LOT within 7 days.`,
          createdAt: nowIso,
        });

        // 4. Main ledger transaction log
        const ledgerTxId = `tx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        t.set(doc(db, 'transactions', ledgerTxId), {
          id: ledgerTxId,
          userId: current.id,
          type: 'admin_adjustment',
          amount,
          balanceAfter: newWalletBalance,
          referenceId: loanId,
          description: `LOT Bank: 7-day loan received (+${amount.toLocaleString()} LOT). Due: 7 days.`,
          createdAt: nowIso,
        });

        // 5. Notification
        const notifId = `notif_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        t.set(doc(db, 'notifications', notifId), {
          id: notifId,
          userId: current.id,
          title: '🏦 Loan Approved & Disbursed',
          message: `Your loan of ${amount.toLocaleString()} LOT has been credited to your wallet. You have 7 days (due ${new Date(dueDateIso).toLocaleDateString()}) to repay ${totalDue.toLocaleString()} LOT, or it will be automatically deducted from your account.`,
          type: 'info',
          read: false,
          createdAt: nowIso,
        });

        return {
          loan: newLoan,
          newWalletBalance,
        };
      });

      sendToUser(current.id, 'wallet:balance_update', { lotBalance: result.newWalletBalance });

      res.json({
        success: true,
        message: `Loan of ${amount.toLocaleString()} LOT successfully approved and disbursed to your wallet!`,
        ...result,
      });
    } catch (err: any) {
      console.error('Loan application error:', err);
      res.status(400).json({ error: err.message || 'Loan application failed' });
    }
  });

  // ----------------------------------------------------------------------
  // ROUTE: POST /api/bank/loan/repay
  // Repay active loan (full or partial) from wallet balance
  // ----------------------------------------------------------------------
  app.post('/api/bank/loan/repay', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const { loanId } = req.body;
      const rawAmount = req.body.amount !== undefined ? Number(req.body.amount) : null;

      if (!loanId) {
        return res.status(400).json({ error: 'loanId is required.' });
      }

      const loanRef = doc(db, 'bank_loans', loanId);
      const userRef = doc(db, 'users', current.id);
      const accountRef = doc(db, 'bank_accounts', current.id);
      const now = new Date().toISOString();

      const result = await runTransaction(db, async (t) => {
        const loanDoc = await t.get(loanRef);
        if (!loanDoc.exists()) {
          throw new Error('Loan record not found');
        }

        const loan = loanDoc.data() as BankLoan;
        if (loan.userId !== current.id) {
          throw new Error('Unauthorized to repay this loan');
        }

        if (loan.status !== 'active') {
          throw new Error(`This loan is already ${loan.status}.`);
        }

        const userDoc = await t.get(userRef);
        if (!userDoc.exists()) {
          throw new Error('User not found');
        }

        const accountDoc = await t.get(accountRef);

        const userData = userDoc.data();
        const currentWalletBalance = userData.lotBalance || 0;

        // Determine repayment amount: either specified or remaining total
        let repayAmount = rawAmount !== null ? Math.floor(rawAmount) : loan.remainingDue;
        if (repayAmount <= 0) {
          throw new Error('Repayment amount must be greater than 0.');
        }

        if (repayAmount > loan.remainingDue) {
          repayAmount = loan.remainingDue;
        }

        if (currentWalletBalance < repayAmount) {
          throw new Error(`Insufficient wallet balance. You need ${repayAmount.toLocaleString()} LOT, but only have ${currentWalletBalance.toLocaleString()} LOT.`);
        }

        const newRemaining = loan.remainingDue - repayAmount;
        const newRepaidTotal = loan.amountRepaid + repayAmount;
        const isFullyPaid = newRemaining <= 0;
        const newWalletBalance = currentWalletBalance - repayAmount;

        // 1. Debit user wallet
        t.update(userRef, {
          lotBalance: newWalletBalance,
          updatedAt: now,
        });

        // 2. Update loan
        t.update(loanRef, {
          remainingDue: newRemaining,
          amountRepaid: newRepaidTotal,
          status: isFullyPaid ? 'repaid' : 'active',
          ...(isFullyPaid ? { repaidAt: now } : {}),
        });

        // 3. Reward credit score on successful full repayment (+20 points, max 850)
        if (isFullyPaid && accountDoc.exists()) {
          const acc = accountDoc.data() as BankAccount;
          const newScore = Math.min(850, (acc.creditScore || 720) + 20);
          t.update(accountRef, {
            creditScore: newScore,
            updatedAt: now,
          });
        }

        // 4. Bank transaction log
        const bankTxId = `btx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        t.set(doc(db, 'bank_transactions', bankTxId), {
          id: bankTxId,
          userId: current.id,
          type: 'loan_repayment',
          amount: repayAmount,
          walletBalanceAfter: newWalletBalance,
          description: `Repaid 7-Day Loan (-${repayAmount.toLocaleString()} LOT)${isFullyPaid ? ' [Loan Closed & Settled]' : ''}`,
          createdAt: now,
        });

        // 5. Main ledger transaction log
        const ledgerTxId = `tx_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
        t.set(doc(db, 'transactions', ledgerTxId), {
          id: ledgerTxId,
          userId: current.id,
          type: 'admin_adjustment',
          amount: -repayAmount,
          balanceAfter: newWalletBalance,
          referenceId: loanId,
          description: `LOT Bank: Loan repayment (-${repayAmount.toLocaleString()} LOT). Remaining: ${newRemaining.toLocaleString()} LOT.`,
          createdAt: now,
        });

        // 6. Notification if fully paid
        if (isFullyPaid) {
          const notifId = `notif_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
          t.set(doc(db, 'notifications', notifId), {
            id: notifId,
            userId: current.id,
            title: '🎉 Loan Fully Repaid!',
            message: `You have successfully repaid your loan of ${loan.principal.toLocaleString()} LOT! Your credit score has increased.`,
            type: 'success',
            read: false,
            createdAt: now,
          });
        }

        return {
          repaidAmount: repayAmount,
          remainingDue: newRemaining,
          isFullyPaid,
          newWalletBalance,
        };
      });

      sendToUser(current.id, 'wallet:balance_update', { lotBalance: result.newWalletBalance });

      res.json({
        success: true,
        message: result.isFullyPaid
          ? `Congratulations! Your loan has been fully repaid and settled.`
          : `Repayment of ${result.repaidAmount.toLocaleString()} LOT successful. Remaining due: ${result.remainingDue.toLocaleString()} LOT.`,
        ...result,
      });
    } catch (err: any) {
      console.error('Loan repayment error:', err);
      res.status(400).json({ error: err.message || 'Loan repayment failed' });
    }
  });

  // ----------------------------------------------------------------------
  // ROUTE: POST /api/bank/interest/claim
  // Manually trigger interest accrual and compounding
  // ----------------------------------------------------------------------
  app.post('/api/bank/interest/claim', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const account = await getOrInitBankAccount(current.id);
      res.json({ success: true, account });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to claim interest' });
    }
  });
}
