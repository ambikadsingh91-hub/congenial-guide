import { Firestore, collection, query, where, getDocs } from 'firebase/firestore';

export interface YouTubeMetadataResult {
  videoId: string;
  youtubeUrl: string;
  embedUrl: string;
  title: string;
  channelTitle: string;
  channelId?: string;
  channelUrl?: string;
  thumbnailUrl: string;
  duration: number; // seconds
  isAttributionVerified: boolean;
  isEmbeddable: boolean;
  category?: string;
}

/**
 * Parses and extracts an 11-character YouTube video ID from various YouTube URL formats.
 * Supported formats:
 * - https://www.youtube.com/shorts/{id}
 * - https://youtube.com/shorts/{id}
 * - https://m.youtube.com/shorts/{id}
 * - https://www.youtube.com/watch?v={id}
 * - https://youtu.be/{id}
 * - https://www.youtube.com/embed/{id}
 * - Raw 11-char ID
 */
export function parseYouTubeVideoId(inputUrl: string): string | null {
  if (!inputUrl || typeof inputUrl !== 'string') return null;

  const trimmed = inputUrl.trim();

  // If already a clean 11-char ID
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }

  // Regular expression covering shorts, watch?v=, youtu.be, embed, m.youtube
  const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?|shorts)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i;
  const match = trimmed.match(regex);
  if (match && match[1]) {
    return match[1];
  }

  return null;
}

/**
 * Parses ISO 8601 duration (e.g., PT59S, PT1M15S) into integer seconds.
 */
function parseISO8601Duration(durationStr: string): number {
  if (!durationStr) return 60;
  const match = durationStr.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return 60;
  const hours = parseInt(match[1] || '0', 10);
  const minutes = parseInt(match[2] || '0', 10);
  const seconds = parseInt(match[3] || '0', 10);
  return hours * 3600 + minutes * 60 + seconds;
}

// In-memory cache for fast response times
const metadataCache = new Map<string, YouTubeMetadataResult>();

/**
 * Fetches authoritative YouTube video metadata using:
 * 1. Cache
 * 2. Official YouTube Data API v3 (if key present)
 * 3. Official YouTube oEmbed API
 */
export async function fetchYouTubeVideoMetadata(
  videoId: string,
  fallbackAdminUsername?: string
): Promise<YouTubeMetadataResult> {
  const cleanId = parseYouTubeVideoId(videoId);
  if (!cleanId) {
    throw new Error('Invalid YouTube video link or ID format. Please provide a valid YouTube Shorts or video URL.');
  }

  if (metadataCache.has(cleanId)) {
    return metadataCache.get(cleanId)!;
  }

  const standardUrl = `https://www.youtube.com/watch?v=${cleanId}`;
  const embedUrl = `https://www.youtube-nocookie.com/embed/${cleanId}`;
  const fallbackThumb = `https://i.ytimg.com/vi/${cleanId}/hqdefault.jpg`;

  const apiKey = process.env.YOUTUBE_API_KEY;

  // 1. Try YouTube Data API v3 if API key is present
  if (apiKey) {
    try {
      const apiUrl = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,status&id=${cleanId}&key=${apiKey}`;
      const response = await fetch(apiUrl);
      if (response.ok) {
        const data = await response.json();
        const item = data.items?.[0];

        if (item) {
          if (item.status && item.status.embeddable === false) {
            throw new Error('The creator of this YouTube video has disabled third-party embedding.');
          }

          if (item.status && item.status.privacyStatus === 'private') {
            throw new Error('This YouTube video is set to Private and cannot be accessed.');
          }

          const snippet = item.snippet || {};
          const contentDetails = item.contentDetails || {};
          const duration = Math.min(60, parseISO8601Duration(contentDetails.duration) || 60);

          const thumbnails = snippet.thumbnails || {};
          const thumbnailUrl =
            thumbnails.maxres?.url ||
            thumbnails.standard?.url ||
            thumbnails.high?.url ||
            thumbnails.medium?.url ||
            thumbnails.default?.url ||
            fallbackThumb;

          const channelTitle = (snippet.channelTitle || '').trim();

          const result: YouTubeMetadataResult = {
            videoId: cleanId,
            youtubeUrl: standardUrl,
            embedUrl,
            title: snippet.title || 'YouTube Short',
            channelTitle: channelTitle || fallbackAdminUsername || 'YouTube Creator',
            channelId: snippet.channelId || undefined,
            channelUrl: snippet.channelId ? `https://www.youtube.com/channel/${snippet.channelId}` : undefined,
            thumbnailUrl,
            duration,
            isAttributionVerified: !!channelTitle,
            isEmbeddable: true,
          };

          metadataCache.set(cleanId, result);
          return result;
        }
      }
    } catch (err: any) {
      if (err.message && err.message.includes('embedding')) {
        throw err;
      }
    }
  }

  // 2. Fetch using official YouTube oEmbed API
  const oEmbedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${cleanId}&format=json`;

  try {
    const oEmbedRes = await fetch(oEmbedUrl);

    if (oEmbedRes.status === 404) {
      throw new Error('YouTube video not found. It may be deleted, invalid, or private.');
    }

    if (oEmbedRes.status === 401 || oEmbedRes.status === 403) {
      throw new Error('This YouTube video is restricted or embedding has been disabled by the creator.');
    }

    if (!oEmbedRes.ok) {
      // Fallback result if oEmbed fails temporarily
      const fallbackResult: YouTubeMetadataResult = {
        videoId: cleanId,
        youtubeUrl: standardUrl,
        embedUrl,
        title: `YouTube Short #${cleanId.slice(0, 6)}`,
        channelTitle: fallbackAdminUsername || 'YouTube Creator',
        thumbnailUrl: fallbackThumb,
        duration: 60,
        isAttributionVerified: false,
        isEmbeddable: true,
      };
      metadataCache.set(cleanId, fallbackResult);
      return fallbackResult;
    }

    const oEmbedData = await oEmbedRes.json();

    const title = (oEmbedData.title || '').trim() || 'YouTube Short';
    const authorName = (oEmbedData.author_name || '').trim();
    const authorUrl = (oEmbedData.author_url || '').trim();
    const thumbnailUrl = oEmbedData.thumbnail_url || fallbackThumb;

    const result: YouTubeMetadataResult = {
      videoId: cleanId,
      youtubeUrl: standardUrl,
      embedUrl,
      title,
      channelTitle: authorName || fallbackAdminUsername || 'YouTube Creator',
      channelUrl: authorUrl || undefined,
      thumbnailUrl,
      duration: 60,
      isAttributionVerified: !!authorName,
      isEmbeddable: true,
    };

    metadataCache.set(cleanId, result);
    return result;
  } catch (err: any) {
    if (err.message && (err.message.includes('not found') || err.message.includes('restricted') || err.message.includes('embedding'))) {
      throw err;
    }
    // Safe fallback for live video playback
    return {
      videoId: cleanId,
      youtubeUrl: standardUrl,
      embedUrl,
      title: 'YouTube Short',
      channelTitle: fallbackAdminUsername || 'YouTube Creator',
      thumbnailUrl: fallbackThumb,
      duration: 60,
      isAttributionVerified: false,
      isEmbeddable: true,
    };
  }
}

/**
 * Checks if a YouTube video has already been published to LOT Shorts.
 */
export async function checkYouTubeVideoAlreadyPublished(
  db: Firestore,
  videoId: string
): Promise<{ alreadyPublished: boolean; existingShortId?: string }> {
  try {
    const q = query(collection(db, 'shorts'), where('youtubeVideoId', '==', videoId));
    const snap = await getDocs(q);
    if (!snap.empty) {
      return { alreadyPublished: true, existingShortId: snap.docs[0].id };
    }
    return { alreadyPublished: false };
  } catch (err) {
    console.error('Error checking duplicate YouTube short:', err);
    return { alreadyPublished: false };
  }
}

// -----------------------------------------------------------------------------
// Curated YouTube Shorts Library across popular categories
// -----------------------------------------------------------------------------
export interface CuratedShortItem {
  videoId: string;
  title: string;
  channelTitle: string;
  category: string;
  hashtags: string[];
}

export const CURATED_YOUTUBE_CATALOG: CuratedShortItem[] = [
  // Trending & Viral
  { videoId: '6t-6ha1EVyA', title: 'POV: Bro thought he was him 🗿 #viral #shorts', channelTitle: 'ViralZone', category: 'trending', hashtags: ['#viral', '#trending', '#shorts'] },
  { videoId: 'CRHrFJJQ4CY', title: 'Satisfying physics test in real life #satisfying #shorts', channelTitle: 'LabWonders', category: 'trending', hashtags: ['#satisfying', '#shorts', '#viral'] },
  { videoId: 'GqD2P2BvBS8', title: "I'm Not Tony Stark… 🗿 | Iron Man Edit | Funk Mada (Slowed)", channelTitle: 'AS EDITSZX', category: 'trending', hashtags: ['#ironman', '#marvel', '#edit'] },
  { videoId: 'u57UqUBLJnw', title: 'How much Aura did I gain 😭🙏 #funny #memes', channelTitle: 'AuraMeme', category: 'trending', hashtags: ['#aura', '#memes', '#shorts'] },
  { videoId: 'hd2hiquQZVw', title: 'Insane trick shot on the first try #tricks #viral', channelTitle: 'TrickLegends', category: 'trending', hashtags: ['#tricks', '#viral', '#shorts'] },
  { videoId: '5AtAO7G3iLo', title: 'World Record attempt that shocked everyone #record #shorts', channelTitle: 'WorldRecordsHQ', category: 'trending', hashtags: ['#record', '#viral', '#shorts'] },

  // Gaming (Minecraft, Roblox, GTA, COD)
  { videoId: 'JAxsbmESYjU', title: 'Minecraft clutch save at 1 HP #minecraft #gaming #shorts', channelTitle: 'CraftMaster', category: 'gaming', hashtags: ['#minecraft', '#gaming', '#shorts'] },
  { videoId: 'GfmQeRSafZo', title: 'Minecraft building tricks you didnt know #minecraftbuilds', channelTitle: 'MineArchitect', category: 'gaming', hashtags: ['#minecraft', '#building', '#shorts'] },
  { videoId: 'ymRCIJC1-yc', title: 'Roblox impossible obby completed in 10 seconds #roblox', channelTitle: 'BloxPro', category: 'gaming', hashtags: ['#roblox', '#gaming', '#shorts'] },
  { videoId: 'dhhr3EczegI', title: 'Minecraft Redstone Trap vs Pro Players #redstone', channelTitle: 'RedstoneEngineer', category: 'gaming', hashtags: ['#minecraft', '#redstone', '#gaming'] },
  { videoId: '5ln8Q1vZSzg', title: "POV: You're playing against a 9 year old sniper #roblox #shorts", channelTitle: 'PixelGaming', category: 'gaming', hashtags: ['#roblox', '#sniper', '#gaming'] },
  { videoId: 'vebc_DX2sZo', title: "Can't touch the ground challenge #roblox #trending", channelTitle: 'RobloxFun', category: 'gaming', hashtags: ['#roblox', '#trending', '#shorts'] },

  // GTA 5 & 6
  { videoId: 'M_4mMpnHuKQ', title: 'Delay was really worth it. #gta6 #rockstargames #shorts', channelTitle: 'GTAViral', category: 'gta', hashtags: ['#gta6', '#gaming', '#shorts'] },
  { videoId: '0U5ExnjCwe8', title: 'GTA 5 physics logic vs real life #gta5 #funny #shorts', channelTitle: 'LosSantosMemes', category: 'gta', hashtags: ['#gta5', '#gaming', '#shorts'] },
  { videoId: 'LaYxZTl6xyI', title: 'GTA stunt jump across the whole city #gtastunts', channelTitle: 'StuntMaster', category: 'gta', hashtags: ['#gta5', '#stunts', '#gaming'] },
  { videoId: '7bgKiLrQW5U', title: 'When police in GTA has 5 stars #gta5memes', channelTitle: 'GTAClips', category: 'gta', hashtags: ['#gta5', '#memes', '#shorts'] },
  { videoId: 'txa_ILklFfc', title: 'Most secret locations in GTA 5 #gtasecrets #shorts', channelTitle: 'GTADiscoveries', category: 'gta', hashtags: ['#gta5', '#secrets', '#gaming'] },

  // Comedy & Memes
  { videoId: 'wA8WNn7OoZs', title: 'POV: when mom leaves their kids home alone #funny #relatable #wwe', channelTitle: 'RelatableShorts', category: 'comedy', hashtags: ['#funny', '#relatable', '#memes'] },
  { videoId: 'z-jwSj1z23Y', title: 'Bro might be pregnant 😭🙏🥀 #memes #funny', channelTitle: 'MemeSupreme', category: 'comedy', hashtags: ['#funny', '#memes', '#comedy'] },
  { videoId: 'SR3VIWTO5Ro', title: 'POV: How teacher feels after saying this on PTM #funny #relatable', channelTitle: 'SchoolMemes', category: 'comedy', hashtags: ['#funny', '#relatable', '#school'] },
  { videoId: 'U7jlPyNkGmg', title: 'WHO WON??! #aurabattle #tungtungsahur #meme #aura', channelTitle: 'MemeUniverse', category: 'comedy', hashtags: ['#aurabattle', '#meme', '#viral'] },
  { videoId: 'WPkso_aTePw', title: 'Bro forgot where he parked his car 💀 #relatable #funny', channelTitle: 'LaughBox', category: 'comedy', hashtags: ['#funny', '#comedy', '#shorts'] },
  { videoId: 'izIJ3wWpuQk', title: 'Nobody expects this plot twist #plotwist #shorts', channelTitle: 'TwistClips', category: 'comedy', hashtags: ['#funny', '#memes', '#twist'] },

  // Tech, AI & Gadgets
  { videoId: 'lgAG0ZCu8J8', title: 'Humanoid Robot learns parkour in Unreal Engine #tech #ai #robotics', channelTitle: 'FutureTech', category: 'tech', hashtags: ['#tech', '#ai', '#robotics', '#future'] },
  { videoId: 'K9GpaJig1Vs', title: 'Transparent smartphone prototype revealed #gadgets #tech', channelTitle: 'TechInsiders', category: 'tech', hashtags: ['#tech', '#gadgets', '#smartphone'] },
  { videoId: 'YyG3rZGAxaU', title: 'Crazy setup transformation with Cyberpunk lights #pcsetup', channelTitle: 'SetupWars', category: 'tech', hashtags: ['#tech', '#pcsetup', '#cyberpunk'] },
  { videoId: '28tZDNIQXGM', title: 'AI created this whole video in 10 seconds #generativeai', channelTitle: 'AIExplorers', category: 'tech', hashtags: ['#ai', '#tech', '#future'] },
  { videoId: 'YwyD1iOtCjk', title: 'Mini high-tech tools you can carry everywhere #edc #gadgets', channelTitle: 'EverydayGadgets', category: 'tech', hashtags: ['#tech', '#gadgets', '#tools'] },

  // Anime & Badass Edits
  { videoId: '42qgi55nrqU', title: 'Gojo Satoru 4K 60FPS Domain Expansion Edit #jujutsukaisen', channelTitle: 'AnimeAesthetic', category: 'anime', hashtags: ['#anime', '#gojo', '#jjk', '#edit'] },
  { videoId: 'VNH2asl287g', title: 'Demon Slayer Sun Breathing animation in 4K #demonslayer', channelTitle: 'KimetsuClips', category: 'anime', hashtags: ['#demonslayer', '#anime', '#edit'] },
  { videoId: 'w361Dk5kESk', title: 'Attack on Titan Eren Yeager Transformation #aot #anime', channelTitle: 'TitanEdits', category: 'anime', hashtags: ['#aot', '#eren', '#anime'] },
  { videoId: '187Ngm56mx4', title: 'Solo Leveling Jinwoo Arise Scene #sololeveling #edit', channelTitle: 'AriseClips', category: 'anime', hashtags: ['#sololeveling', '#anime', '#edit'] },
  { videoId: '8mNgKZIP4S4', title: 'Epic Fan Animation Fight Scene #fananimation #anime', channelTitle: 'AnimStudios', category: 'anime', hashtags: ['#anime', '#animation', '#action'] },

  // Sports & Trick Shots
  { videoId: 'SqkTQPWUBuI', title: 'Cristiano Ronaldo impossible physics gravity defying jump #cr7', channelTitle: 'FootballIcons', category: 'sports', hashtags: ['#cr7', '#football', '#ronaldo', '#sports'] },
  { videoId: '5hCgJh-xzH4', title: 'Lionel Messi ankle breaker dribble vs 5 defenders #messi', channelTitle: 'MessiMagic', category: 'sports', hashtags: ['#messi', '#football', '#skills'] },
  { videoId: 'inb8F-xsn3E', title: 'Basketball half-court buzzer beater with 0.1s left #nba', channelTitle: 'HoopDreams', category: 'sports', hashtags: ['#basketball', '#nba', '#sports'] },
  { videoId: 'fNYBVEO1kEw', title: 'Skateboard 900 flip down a giant 20-stair set #skateboarding', channelTitle: 'SkateFlow', category: 'sports', hashtags: ['#skate', '#sports', '#extremesports'] },

  // Animals & Pets
  { videoId: 'zxviRWhcl-g', title: 'Golden Retriever reaction when meeting new kitten #cute #pets', channelTitle: 'PetMoments', category: 'animals', hashtags: ['#cute', '#pets', '#dogs', '#cats'] },
  { videoId: 'XZ3ZqXuWfEY', title: 'Cat realizes it has four paws in the mirror #funnycats', channelTitle: 'FelineFails', category: 'animals', hashtags: ['#cats', '#funny', '#animals'] },
  { videoId: '1fZGOS6GuRc', title: 'Smart parrot talks back and orders snacks #parrots #birds', channelTitle: 'TalkingParrot', category: 'animals', hashtags: ['#animals', '#pets', '#parrot'] },
  { videoId: 'l2ohhBI4z4E', title: 'Baby panda rolling down the hill repeatedly #pandas', channelTitle: 'WildlifeDaily', category: 'animals', hashtags: ['#animals', '#cute', '#panda'] },

  // Music & Beats
  { videoId: 'G0b4KEYSwRw', title: 'Beatboxer creates full techno rave with just his mouth #beatbox', channelTitle: 'BeatboxChamps', category: 'music', hashtags: ['#music', '#beatbox', '#shorts'] },
  { videoId: 'E6gIJKkt0AI', title: 'Guitarist plays hotel california solo blindfolded #guitar', channelTitle: 'GuitarRiffs', category: 'music', hashtags: ['#guitar', '#music', '#solo'] },
  { videoId: 'YUmZSjMvnM0', title: 'Synthesizer cyberpunk beat live on modular rack #synth', channelTitle: 'SynthwaveLab', category: 'music', hashtags: ['#music', '#cyberpunk', '#synth'] },

  // Science & Mind-Blowing Facts
  { videoId: 'W2uxZBxZpWo', title: 'Hydraulic Press vs Indestructible Titanium Cube #satisfying', channelTitle: 'HydraulicLab', category: 'science', hashtags: ['#science', '#satisfying', '#shorts'] },
  { videoId: '3OkUBpIkkUs', title: 'What would happen if the Moon suddenly collided with Earth?', channelTitle: 'CosmosUnveiled', category: 'science', hashtags: ['#science', '#space', '#facts'] },
  { videoId: 'IfbInYur0r8', title: 'Liquid nitrogen dropped into swimming pool reaction #chemistry', channelTitle: 'CrazyScience', category: 'science', hashtags: ['#science', '#experiments', '#chemistry'] },
  { videoId: 'S0fknYGR4iI', title: 'Slow motion droplet hitting water at 100,000 FPS #slowmo', channelTitle: 'MacroUniverse', category: 'science', hashtags: ['#slowmo', '#satisfying', '#science'] }
];

/**
 * Searches online YouTube for real video IDs using public endpoint
 */
export async function searchYouTubeOnline(queryText: string, limitCount = 12): Promise<string[]> {
  try {
    const searchQuery = queryText.trim() + ' #shorts';
    const res = await fetch(`https://www.youtube.com/results?search_query=${encodeURIComponent(searchQuery)}&sp=EgIYAQ%253D%253D`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
      },
    });

    if (!res.ok) return [];

    const html = await res.text();
    const matches = Array.from(html.matchAll(/"videoId":"([a-zA-Z0-9_-]{11})"/g)).map((m) => m[1]);
    const uniqueIds = Array.from(new Set(matches)).slice(0, limitCount);
    return uniqueIds;
  } catch (err) {
    console.error('Online YouTube search error:', err);
    return [];
  }
}

/**
 * Universal search & browse YouTube Shorts:
 * - If query is a URL / video ID -> retrieves that exact video
 * - If query is text -> searches curated list + online YouTube results
 * - If category is provided -> filters by category
 */
export async function searchYouTubeShortsCatalog(options: {
  query?: string;
  category?: string;
  limit?: number;
}): Promise<YouTubeMetadataResult[]> {
  const { query: queryText = '', category = 'all', limit = 25 } = options;
  const cleanQ = queryText.trim();

  // 1. Check if user typed or pasted a specific YouTube link or raw ID
  const directId = parseYouTubeVideoId(cleanQ);
  if (directId) {
    try {
      const meta = await fetchYouTubeVideoMetadata(directId);
      return [meta];
    } catch {}
  }

  const results: YouTubeMetadataResult[] = [];
  const seenIds = new Set<string>();

  // 2. Filter from curated catalog
  let filteredCurated = [...CURATED_YOUTUBE_CATALOG];

  if (category && category !== 'all') {
    filteredCurated = filteredCurated.filter(
      (item) => item.category === category || item.hashtags.some((h) => h.includes(category))
    );
  }

  if (cleanQ) {
    const qLower = cleanQ.toLowerCase();
    filteredCurated = filteredCurated.filter(
      (item) =>
        item.title.toLowerCase().includes(qLower) ||
        item.channelTitle.toLowerCase().includes(qLower) ||
        item.category.toLowerCase().includes(qLower) ||
        item.hashtags.some((h) => h.toLowerCase().includes(qLower))
    );
  }

  // Convert curated items to metadata results
  for (const item of filteredCurated) {
    if (seenIds.has(item.videoId)) continue;
    seenIds.add(item.videoId);

    results.push({
      videoId: item.videoId,
      youtubeUrl: `https://www.youtube.com/watch?v=${item.videoId}`,
      embedUrl: `https://www.youtube-nocookie.com/embed/${item.videoId}`,
      title: item.title,
      channelTitle: item.channelTitle,
      thumbnailUrl: `https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`,
      duration: 60,
      isAttributionVerified: true,
      isEmbeddable: true,
      category: item.category,
    });
  }

  // 3. If query was provided and we have fewer results than desired, search online YouTube!
  if (cleanQ && results.length < limit) {
    const onlineIds = await searchYouTubeOnline(cleanQ, limit - results.length + 5);
    for (const vid of onlineIds) {
      if (seenIds.has(vid)) continue;
      seenIds.add(vid);

      try {
        const meta = await fetchYouTubeVideoMetadata(vid);
        results.push(meta);
      } catch {}

      if (results.length >= limit) break;
    }
  }

  return results.slice(0, limit);
}
