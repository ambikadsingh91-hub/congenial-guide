import { Request, Response, Express, NextFunction } from 'express';
import multer from 'multer';
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';
import {
  Firestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  getDocs,
  runTransaction,
  limit,
} from 'firebase/firestore';
import { savePersistentMedia } from './mediaStorage';
import {
  parseYouTubeVideoId,
  fetchYouTubeVideoMetadata,
  checkYouTubeVideoAlreadyPublished,
  CURATED_YOUTUBE_CATALOG,
} from './youtubeService';

interface RouterDeps {
  db: Firestore;
  authMiddleware: (req: Request, res: Response, next: NextFunction) => void;
  adminMiddleware: (req: Request, res: Response, next: NextFunction) => void;
  sendToUser: (userId: string, event: string, payload: any) => boolean;
  sessionStore: Map<string, any>;
  getSession?: (token: string) => Promise<any | null>;
}

// Multer Storage Configuration
const uploadsDir = path.join(process.cwd(), 'uploads', 'shorts');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.mp4';
    const unique = `${Date.now()}_${crypto.randomBytes(6).toString('hex')}${ext}`;
    cb(null, unique);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 60 * 1024 * 1024, // 60MB max video size
  },
  fileFilter: (_req, file, cb) => {
    const allowed = [
      'video/mp4',
      'video/webm',
      'video/quicktime',
      'image/jpeg',
      'image/png',
      'image/webp',
    ];
    if (allowed.includes(file.mimetype) || file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Unsupported file format. Please upload MP4 or WebM video.'));
    }
  },
});

// Helper to extract hashtags from caption
function extractHashtags(caption: string): string[] {
  if (!caption) return [];
  const matches = caption.match(/#[a-zA-Z0-9_]+/g);
  if (!matches) return [];
  return Array.from(new Set(matches.map((m) => m.toLowerCase())));
}

// In-memory view deduplication: Set of `shortId:viewerKey`
const recentViews = new Set<string>();

// Rich fallback GIF presets for instant reliability
const CURATED_GIFS = [
  {
    id: 'gif-hype-1',
    title: 'Hype GG Cyberpunk',
    url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExOHp1bnF2NHJocDJld2VveWJ5NXEwY3g2MmFlZ21sNjMxeDV5ZWVreCZlcD12MV9naWZzX3NlYXJjaCZjdD1n/3oKIPnAiaMCws8nOsE/giphy.gif',
    previewUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExOHp1bnF2NHJocDJld2VveWJ5NXEwY3g2MmFlZ21sNjMxeDV5ZWVreCZlcD12MV9naWZzX3NlYXJjaCZjdD1n/3oKIPnAiaMCws8nOsE/200w.gif',
  },
  {
    id: 'gif-party-2',
    title: 'Celebration Victory Confetti',
    url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExZGR0Z2d6dXk2N2UyeHFuc2c4OHFsdWpvdnB6ZW44c21obmxyeXZ6NiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/artj92V8o75VPL7AeQ/giphy.gif',
    previewUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExZGR0Z2d6dXk2N2UyeHFuc2c4OHFsdWpvdnB6ZW44c21obmxyeXZ6NiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/artj92V8o75VPL7AeQ/200w.gif',
  },
  {
    id: 'gif-mindblown-3',
    title: 'Mind Blown Neon',
    url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExcmVzYXRlYnN4NDdrdHh5djdsdWhldXNkdWNpcTFqNzMxa3F1cTI5NSZlcD12MV9naWZzX3NlYXJjaCZjdD1n/26ufdipQqU2lhNA4g/giphy.gif',
    previewUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExcmVzYXRlYnN4NDdrdHh5djdsdWhldXNkdWNpcTFqNzMxa3F1cTI5NSZlcD12MV9naWZzX3NlYXJjaCZjdD1n/26ufdipQqU2lhNA4g/200w.gif',
  },
  {
    id: 'gif-fire-4',
    title: 'Fire That is LIT',
    url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExazlhcGNqNzN0aWtyeXQ5enR5bWcxbXg4Znp0azBxdm9icHR1bnVseSZlcD12MV9naWZzX3NlYXJjaCZjdD1n/Lopx9eUi34rbq/giphy.gif',
    previewUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExazlhcGNqNzN0aWtyeXQ5enR5bWcxbXg4Znp0azBxdm9icHR1bnVseSZlcD12MV9naWZzX3NlYXJjaCZjdD1n/Lopx9eUi34rbq/200w.gif',
  },
  {
    id: 'gif-applause-5',
    title: 'Standing Ovation Clapping',
    url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExd2R4b2hvd2hhM3pvdHR6dXo0NnB1dG56NHhhdWpxc2JzNGp2OW9xNiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/7rj2ZgttvgomY/giphy.gif',
    previewUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExd2R4b2hvd2hhM3pvdHR6dXo0NnB1dG56NHhhdWpxc2JzNGp2OW9xNiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/7rj2ZgttvgomY/200w.gif',
  },
  {
    id: 'gif-cool-6',
    title: 'Neon Sunglasses Deal With It',
    url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExcjhzMTM5ZTRic3ZtczNkdGVrc3N4Mm92a3R2aHlyMTYyeWVha3Q5byZlcD12MV9naWZzX3NlYXJjaCZjdD1n/xUPGcz2H1TXdCz4suY/giphy.gif',
    previewUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExcjhzMTM5ZTRic3ZtczNkdGVrc3N4Mm92a3R2aHlyMTYyeWVha3Q5byZlcD12MV9naWZzX3NlYXJjaCZjdD1n/xUPGcz2H1TXdCz4suY/200w.gif',
  },
  {
    id: 'gif-gamer-7',
    title: 'Pro Gamer Victory Dance',
    url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExczB1anIwdW9yZzF1dWFpMzlpcDF5eHNmdXZxODZqcnR1N3d1MnQ4ZiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/blSTtZehjAZ8I/giphy.gif',
    previewUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExczB1anIwdW9yZzF1dWFpMzlpcDF5eHNmdXZxODZqcnR1N3d1MnQ4ZiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/blSTtZehjAZ8I/200w.gif',
  },
  {
    id: 'gif-wow-8',
    title: 'Shocked Cat Wow',
    url: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbDVqbmZoc2VpODZpZWVqOHphOG9vOHp5aXhzNWppNWNqam5iMWtxZiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/5VKbvrjxpVJCM/giphy.gif',
    previewUrl: 'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbDVqbmZoc2VpODZpZWVqOHphOG9vOHp5aXhzNWppNWNqam5iMWtxZiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/5VKbvrjxpVJCM/200w.gif',
  },
];

// Automated video deletion is permanently disabled.
// Videos can ONLY be deleted explicitly by their owner/creator (or admin) via DELETE /api/shorts/:id.
export async function batchDeleteOrphanedShorts(_db: Firestore): Promise<{ deletedCount: number; orphanedShortIds: string[] }> {
  return { deletedCount: 0, orphanedShortIds: [] };
}

export function setupShortsRoutes(app: Express, deps: RouterDeps) {
  const { db, authMiddleware, adminMiddleware, sendToUser, sessionStore } = deps;

  // Helper to extract session user from cookie or bearer token optionally (without blocking unauthenticated viewers)
  async function getOptionalUser(req: Request): Promise<any | null> {
    try {
      const authHeader = req.headers.authorization;
      let token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;
      if ((!token || token === 'undefined' || token === 'null') && req.cookies && req.cookies.lot_session) {
        token = req.cookies.lot_session;
      }
      if (!token) return null;

      if (deps.getSession) {
        return await deps.getSession(token);
      }
      if (sessionStore.has(token)) {
        const session = sessionStore.get(token);
        if (session && session.expiresAt > Date.now()) {
          return session;
        }
      }
    } catch {}
    return null;
  }

  // Helper to create notifications
  async function createShortNotification(targetUserId: string, title: string, message: string, type: string) {
    try {
      if (!targetUserId) return;
      const notifId = 'notif_' + crypto.randomUUID();
      const notifData = {
        id: notifId,
        userId: targetUserId,
        title,
        message,
        type: type || 'short',
        read: false,
        createdAt: new Date().toISOString(),
      };
      await setDoc(doc(db, 'notifications', notifId), notifData);
      sendToUser(targetUserId, 'notification:new', { notification: notifData });
    } catch (e) {
      console.error('Failed to dispatch notification:', e);
    }
  }

  // -------------------------------------------------------------------------
  // 1. VIDEO UPLOAD (Multipart form data with 60s validation)
  // -------------------------------------------------------------------------
  app.post(
    '/api/shorts/upload',
    authMiddleware,
    upload.fields([
      { name: 'video', maxCount: 1 },
      { name: 'thumbnail', maxCount: 1 },
    ]),
    async (req: Request, res: Response) => {
      try {
        const user = (req as any).user;
        const files = req.files as { [fieldname: string]: Express.Multer.File[] } | undefined;
        const videoFile = files?.video?.[0];
        const thumbFile = files?.thumbnail?.[0];

        if (!videoFile) {
          return res.status(400).json({ error: 'Video file is required.' });
        }

        let caption = (req.body.caption || '').trim();
        if (!caption) {
          caption = 'My LOT Short';
        }

        // Validate duration (client-provided or parsed)
        const duration = parseFloat(req.body.duration) || 15;
        if (duration > 60) {
          // Remove uploaded file if invalid
          try {
            fs.unlinkSync(videoFile.path);
            if (thumbFile) fs.unlinkSync(thumbFile.path);
          } catch {}
          return res.status(400).json({ error: 'Maximum video duration for LOT Shorts is 60 seconds.' });
        }

        const shortId = 'short_' + crypto.randomUUID();
        const videoUrl = `/uploads/shorts/${videoFile.filename}`;
        let thumbnailUrl = '';

        // Persist video to both disk and Cloud Firestore binary storage so it NEVER disappears
        const videoBuffer = fs.readFileSync(videoFile.path);
        await savePersistentMedia(db, {
          fileId: shortId,
          filename: videoFile.filename,
          mimeType: videoFile.mimetype || 'video/mp4',
          buffer: videoBuffer,
          subfolder: 'shorts',
          uploaderId: user.id,
        });

        if (thumbFile) {
          const thumbBuffer = fs.readFileSync(thumbFile.path);
          await savePersistentMedia(db, {
            fileId: 'thumb_' + shortId,
            filename: thumbFile.filename,
            mimeType: thumbFile.mimetype || 'image/jpeg',
            buffer: thumbBuffer,
            subfolder: 'shorts',
            uploaderId: user.id,
          });
          thumbnailUrl = `/uploads/shorts/${thumbFile.filename}`;
        }

        const hashtags = extractHashtags(caption);
        const allowComments = req.body.allowComments !== 'false' && req.body.allowComments !== false;

        const newShort = {
          id: shortId,
          creatorId: user.id,
          creatorUsername: user.username,
          creatorAvatar: user.avatarUrl || '',
          videoUrl,
          thumbnailUrl,
          storageRef: `media_files/${shortId}`,
          caption,
          hashtags,
          duration: Math.round(duration),
          likesCount: 0,
          viewsCount: 0,
          commentsCount: 0,
          allowComments,
          status: 'active',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        await setDoc(doc(db, 'shorts', shortId), newShort);

        res.status(201).json({
          success: true,
          short: {
            ...newShort,
            hasLiked: false,
            hasSaved: false,
            isFollowing: false,
          },
        });
      } catch (err: any) {
        console.error('Shorts upload error:', err);
        res.status(500).json({ error: err.message || 'Failed to upload and publish Short.' });
      }
    }
  );

  // -------------------------------------------------------------------------
  // 1B. ADMIN YOUTUBE VIDEO PUBLISHER (Strictly Admin-Only Protected Routes)
  // -------------------------------------------------------------------------

  // Seed Curated YouTube Shorts library into Firestore if not already present
  async function seedCuratedYouTubeShorts() {
    try {
      console.log('[LOT Shorts] Synchronizing curated YouTube Shorts library with Firestore...');
      const TECH_SEEDS = [
        {
          videoId: 'k1BneeJTDcU',
          title: 'Python vs C++ Performance Speed Test in 30 Seconds',
          channelTitle: 'Fireship',
          caption: 'Python vs C++ Speed Test! Which programming language wins the benchmark? #coding #tech #python #cpp #shorts',
          hashtags: ['#coding', '#tech', '#python', '#cpp', '#shorts', '#lot'],
          duration: 35,
          viewsCount: 14200,
          likesCount: 980,
        },
        {
          videoId: 'p7bfOZek9t4',
          title: 'Clean Code in 30 Seconds - Async Await Best Practices',
          channelTitle: 'Web Dev Simplified',
          caption: 'Stop writing messy callback chains! Master clean async await in 30 seconds #webdev #javascript #programming #shorts',
          hashtags: ['#webdev', '#javascript', '#programming', '#shorts', '#tech'],
          duration: 45,
          viewsCount: 8900,
          likesCount: 650,
        },
        {
          videoId: 'L_LUpnjgPso',
          title: 'Ultra Satisfying 3D Physics Simulation',
          channelTitle: 'Blender Studio',
          caption: 'Oddly satisfying 3D rigid body physics animation rendered in real-time #3d #blender #satisfying #art #shorts',
          hashtags: ['#3d', '#blender', '#satisfying', '#art', '#shorts'],
          duration: 25,
          viewsCount: 22100,
          likesCount: 1850,
        },
        {
          videoId: 'pU8-7n4q_VU',
          title: 'How CPUs Actually Process Millions of Instructions',
          channelTitle: 'Tech Science',
          caption: 'Microscopic view of transistor gates and silicon circuitry inside modern microprocessors #tech #hardware #cpu #science #shorts',
          hashtags: ['#tech', '#hardware', '#cpu', '#science', '#shorts'],
          duration: 52,
          viewsCount: 11400,
          likesCount: 820,
        },
        {
          videoId: 's4gBChg6AII',
          title: 'Top 3 Secret VS Code Extensions Developers Love',
          channelTitle: 'Code Prodigy',
          caption: 'Boost your developer productivity with these top essential VS Code extensions #vscode #developer #tips #coding #shorts',
          hashtags: ['#vscode', '#developer', '#tips', '#coding', '#shorts'],
          duration: 40,
          viewsCount: 7600,
          likesCount: 540,
        },
        {
          videoId: 'tPEE9ZwTmy0',
          title: 'The Most Addictive Indie Game Made in 48 Hours',
          channelTitle: 'GameDev Lounge',
          caption: 'Solo game developer builds an endless runner in 48 hours for a global game jam #gaming #indiedev #games #shorts',
          hashtags: ['#gaming', '#indiedev', '#games', '#shorts'],
          duration: 48,
          viewsCount: 16500,
          likesCount: 1200,
        },
        {
          videoId: 'J---aiyznGQ',
          title: 'Mechanical Keyboard Typing Sound ASMR Test',
          channelTitle: 'Keeb ASMR',
          caption: 'Custom mechanical keyboard with lubed linear switches and thick PBT keycaps sound test #asmr #keyboard #satisfying #shorts',
          hashtags: ['#asmr', '#keyboard', '#satisfying', '#shorts'],
          duration: 30,
          viewsCount: 19800,
          likesCount: 1620,
        },
        {
          videoId: 'kJQP7kiw5Fk',
          title: 'Global Hit Music Rhythm Beat',
          channelTitle: 'World Music',
          caption: 'Iconic Latin rhythm and world record track vibes #music #trending #vibes #shorts',
          hashtags: ['#music', '#trending', '#vibes', '#shorts'],
          duration: 55,
          viewsCount: 35000,
          likesCount: 3100,
        },
      ];

      // Merge TECH_SEEDS and CURATED_YOUTUBE_CATALOG
      const catalogItems = CURATED_YOUTUBE_CATALOG.map((item) => ({
        videoId: item.videoId,
        title: item.title,
        channelTitle: item.channelTitle,
        caption: item.title,
        hashtags: item.hashtags,
        duration: 50,
        viewsCount: Math.floor(Math.random() * 20000 + 5000),
        likesCount: Math.floor(Math.random() * 1500 + 350),
      }));

      const allSeeds = [...TECH_SEEDS];
      for (const catItem of catalogItems) {
        if (!allSeeds.some((s) => s.videoId === catItem.videoId)) {
          allSeeds.push(catItem);
        }
      }

      let seededCount = 0;
      for (const item of allSeeds) {
        const shortId = 'short_yt_' + item.videoId;
        const existsDoc = await getDoc(doc(db, 'shorts', shortId));
        if (!existsDoc.exists()) {
          const newShort = {
            id: shortId,
            creatorId: 'system_lot',
            creatorUsername: item.channelTitle,
            creatorAvatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(item.channelTitle)}`,
            publishedByAdminId: 'system',
            publishedByAdminUsername: 'LOT Ecosystem',
            source: 'youtube' as const,
            youtubeVideoId: item.videoId,
            youtubeUrl: `https://www.youtube.com/watch?v=${item.videoId}`,
            youtubeChannelTitle: item.channelTitle,
            youtubeChannelId: null,
            youtubeChannelUrl: null,
            isAttributionVerified: true,
            videoUrl: `https://www.youtube-nocookie.com/embed/${item.videoId}`,
            thumbnailUrl: `https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`,
            caption: item.caption,
            hashtags: item.hashtags,
            duration: item.duration,
            likesCount: item.likesCount,
            viewsCount: item.viewsCount,
            commentsCount: 0,
            allowComments: true,
            status: 'active' as const,
            createdAt: new Date().toISOString(),
          };
          await setDoc(doc(db, 'shorts', shortId), newShort);
          seededCount++;
        }
      }
      console.log(`[LOT Shorts] Finished synchronizing YouTube Shorts! Added ${seededCount} new shorts (Total catalog: ${allSeeds.length}).`);
    } catch (seedErr) {
      console.error('[LOT Shorts] Error seeding YouTube Shorts:', seedErr);
    }
  }

  // Run seeding asynchronously
  seedCuratedYouTubeShorts().catch(() => {});

  // -------------------------------------------------------------------------
  // 1B. YOUTUBE VIDEO PUBLISHER (For all authenticated creators & admin)
  // -------------------------------------------------------------------------

  // Helper handler for YouTube Preview
  async function handleYouTubePreview(req: Request, res: Response) {
    try {
      const user = (req as any).user;
      const { url } = req.body;

      if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: 'Please enter a valid YouTube video or Shorts link.' });
      }

      const videoId = parseYouTubeVideoId(url);
      if (!videoId) {
        return res.status(400).json({
          error: 'Invalid YouTube link format. Supported formats: youtube.com/shorts/{id}, youtube.com/watch?v={id}, youtu.be/{id}',
        });
      }

      // Check for duplicate publication
      const dupCheck = await checkYouTubeVideoAlreadyPublished(db, videoId);
      if (dupCheck.alreadyPublished) {
        return res.status(409).json({
          error: 'This YouTube video has already been published to LOT Ecosystem Shorts.',
          existingShortId: dupCheck.existingShortId,
        });
      }

      const meta = await fetchYouTubeVideoMetadata(videoId, user.username);

      res.json({
        success: true,
        ...meta,
      });
    } catch (err: any) {
      console.error('YouTube preview error:', err);
      res.status(400).json({ error: err.message || 'Failed to retrieve YouTube video preview.' });
    }
  }

  // Helper handler for YouTube Publish
  async function handleYouTubePublish(req: Request, res: Response) {
    try {
      const user = (req as any).user;
      const { url, caption, customHashtags } = req.body;

      if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: 'YouTube link is required.' });
      }

      const videoId = parseYouTubeVideoId(url);
      if (!videoId) {
        return res.status(400).json({ error: 'Invalid YouTube video URL format.' });
      }

      // Duplicate check
      const dupCheck = await checkYouTubeVideoAlreadyPublished(db, videoId);
      if (dupCheck.alreadyPublished) {
        return res.status(409).json({
          error: 'This YouTube video has already been published to LOT Ecosystem Shorts.',
          existingShortId: dupCheck.existingShortId,
        });
      }

      // Fetch verified metadata
      const meta = await fetchYouTubeVideoMetadata(videoId, user.username);

      const shortId = 'short_yt_' + crypto.randomUUID();
      const finalCaption = (caption || '').trim() || meta.title;
      const autoTags = extractHashtags(finalCaption);
      const combinedHashtags = Array.from(
        new Set([...autoTags, ...(Array.isArray(customHashtags) ? customHashtags : []), '#youtube', '#shorts'])
      );

      const newShort = {
        id: shortId,
        creatorId: user.id,
        creatorUsername: user.username,
        creatorAvatar: user.avatarUrl || '',
        publishedByAdminId: user.isAdmin ? user.id : undefined,
        publishedByAdminUsername: user.isAdmin ? user.username : undefined,
        source: 'youtube' as const,
        youtubeVideoId: meta.videoId,
        youtubeUrl: meta.youtubeUrl,
        youtubeChannelTitle: meta.channelTitle,
        youtubeChannelId: meta.channelId || null,
        youtubeChannelUrl: meta.channelUrl || null,
        isAttributionVerified: meta.isAttributionVerified,
        videoUrl: meta.embedUrl,
        thumbnailUrl: meta.thumbnailUrl,
        caption: finalCaption,
        hashtags: combinedHashtags,
        duration: meta.duration || 60,
        likesCount: 0,
        viewsCount: 0,
        commentsCount: 0,
        allowComments: true,
        status: 'active' as const,
        createdAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'shorts', shortId), newShort);

      res.status(201).json({
        success: true,
        message: 'YouTube video published to LOT Shorts successfully!',
        short: {
          ...newShort,
          hasLiked: false,
          hasSaved: false,
          isFollowing: false,
        },
      });
    } catch (err: any) {
      console.error('YouTube publish error:', err);
      res.status(400).json({ error: err.message || 'Failed to publish YouTube Short.' });
    }
  }

  // Endpoints accessible to all authenticated users
  app.post('/api/shorts/youtube/preview', authMiddleware, handleYouTubePreview);
  app.post('/api/shorts/youtube/publish', authMiddleware, handleYouTubePublish);

  // Keep admin aliases for full backward compatibility
  app.post('/api/shorts/admin/youtube/preview', authMiddleware, handleYouTubePreview);
  app.post('/api/shorts/admin/youtube/publish', authMiddleware, handleYouTubePublish);

  // GET /api/shorts/admin/youtube/list
  app.get(
    '/api/shorts/admin/youtube/list',
    authMiddleware,
    adminMiddleware,
    async (_req: Request, res: Response) => {
      try {
        const snap = await getDocs(
          query(collection(db, 'shorts'), where('source', '==', 'youtube'))
        );
        const shorts = snap.docs.map((d) => d.data());
        shorts.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        res.json({ success: true, shorts });
      } catch (err: any) {
        console.error('Error listing admin YouTube shorts:', err);
        res.status(500).json({ error: 'Failed to list YouTube shorts.' });
      }
    }
  );

  // Direct Publish (for client-uploaded assets, e.g. Firebase Storage client SDK)
  app.post('/api/shorts/publish-direct', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const { videoUrl, thumbnailUrl, caption, duration, allowComments } = req.body;

      if (!videoUrl) {
        return res.status(400).json({ error: 'Video URL is required.' });
      }
      if (!caption?.trim()) {
        return res.status(400).json({ error: 'Caption is required.' });
      }

      const numDuration = Number(duration) || 15;
      if (numDuration > 60) {
        return res.status(400).json({ error: 'Video duration exceeds 60 seconds limit.' });
      }

      const shortId = 'short_' + crypto.randomUUID();
      const newShort = {
        id: shortId,
        creatorId: user.id,
        creatorUsername: user.username,
        creatorAvatar: user.avatarUrl || '',
        videoUrl,
        thumbnailUrl: thumbnailUrl || '',
        caption: caption.trim(),
        hashtags: extractHashtags(caption),
        duration: Math.round(numDuration),
        likesCount: 0,
        viewsCount: 0,
        commentsCount: 0,
        allowComments: allowComments !== false,
        status: 'active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'shorts', shortId), newShort);
      res.status(201).json({ success: true, short: newShort });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to publish short directly.' });
    }
  });

  // -------------------------------------------------------------------------
  // 2. SHORTS FEEDS (For You, Following, Trending, Hashtags, Search)
  // -------------------------------------------------------------------------
  app.get('/api/shorts/feed', async (req: Request, res: Response) => {
    try {
      const tab = (req.query.tab as string) || (req.query.feed as string) || 'foryou';
      const hashtag = (req.query.hashtag as string || req.query.tag as string || '').toLowerCase().trim();
      const search = (req.query.search as string || '').toLowerCase().trim();
      const creatorIdFilter = req.query.creatorId as string;
      const limitCount = Math.min(100, Math.max(1, parseInt(req.query.limit as string) || 20));

      const viewer = await getOptionalUser(req);
      const viewerId = viewer ? viewer.userId : null;

      // Fetch active shorts and active valid users in parallel
      const [shortsSnap, usersSnap] = await Promise.all([
        getDocs(query(collection(db, 'shorts'), where('status', '==', 'active'), limit(150))),
        getDocs(collection(db, 'users')),
      ]);

      const activeUserIds = new Set<string>();
      usersSnap.forEach((u) => {
        const udata = u.data();
        if (!udata.isBanned) activeUserIds.add(u.id);
      });

      let list = shortsSnap.docs.map((d) => d.data() as any);

      // Keep all valid active shorts in feed (including YouTube Shorts and user uploads)
      list = list.filter(
        (s) =>
          s.status === 'active' &&
          !s.videoUrl?.includes('mixkit') &&
          Boolean(s.videoUrl || s.youtubeVideoId)
      );

      // Filter by creator if specified
      if (creatorIdFilter) {
        list = list.filter((s) => s.creatorId === creatorIdFilter);
      }

      // Filter by hashtag
      if (hashtag) {
        const cleanTag = hashtag.startsWith('#') ? hashtag : `#${hashtag}`;
        list = list.filter((s) => Array.isArray(s.hashtags) && s.hashtags.some((h: string) => h.toLowerCase() === cleanTag));
      }

      // Filter by search query (caption, hashtags, creator)
      if (search) {
        list = list.filter((s) => {
          const cap = (s.caption || '').toLowerCase();
          const user = (s.creatorUsername || '').toLowerCase();
          const tags = Array.isArray(s.hashtags) ? s.hashtags.join(' ').toLowerCase() : '';
          return cap.includes(search) || user.includes(search) || tags.includes(search);
        });
      }

      // Tab specific logic: Following
      let followedCreatorIds = new Set<string>();
      if (viewerId) {
        try {
          const followsSnap = await getDocs(
            query(collection(db, 'short_follows'), where('followerId', '==', viewerId))
          );
          followsSnap.forEach((d) => {
            const data = d.data();
            if (data.followingId) followedCreatorIds.add(data.followingId);
          });
        } catch {}
      }

      if (tab === 'following') {
        if (!viewerId) {
          return res.json({ shorts: [], hasMore: false, message: 'Sign in to see Shorts from creators you follow.' });
        }
        list = list.filter((s) => followedCreatorIds.has(s.creatorId));
      } else if (tab === 'saved') {
        if (!viewerId) {
          return res.json({ shorts: [], hasMore: false, message: 'Sign in to see your saved Shorts.' });
        }
        const savesSnap = await getDocs(
          query(collection(db, 'short_saves'), where('userId', '==', viewerId))
        );
        const savedShortIds = new Set(savesSnap.docs.map((d) => d.data().shortId));
        list = list.filter((s) => savedShortIds.has(s.id));
      } else if (tab === 'trending') {
        // Sort by engagement score: (likes * 3 + comments * 2 + views)
        list.sort((a, b) => {
          const scoreB = (b.likesCount || 0) * 3 + (b.commentsCount || 0) * 2 + (b.viewsCount || 0);
          const scoreA = (a.likesCount || 0) * 3 + (a.commentsCount || 0) * 2 + (a.viewsCount || 0);
          return scoreB - scoreA;
        });
      } else {
        // 'foryou' - sort by newest with slight mix
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }

      // Paginate results
      const paginated = list.slice(0, limitCount);

      // Populate viewer engagement data (likes, saves, follows) if viewer is logged in
      let viewerLikes = new Set<string>();
      let viewerSaves = new Set<string>();

      if (viewerId && paginated.length > 0) {
        try {
          const [likesSnap, savesSnap] = await Promise.all([
            getDocs(query(collection(db, 'short_likes'), where('userId', '==', viewerId))),
            getDocs(query(collection(db, 'short_saves'), where('userId', '==', viewerId))),
          ]);
          likesSnap.forEach((d) => viewerLikes.add(d.data().shortId));
          savesSnap.forEach((d) => viewerSaves.add(d.data().shortId));
        } catch {}
      }

      const enriched = paginated.map((s) => ({
        ...s,
        hasLiked: viewerLikes.has(s.id),
        hasSaved: viewerSaves.has(s.id),
        isFollowing: followedCreatorIds.has(s.creatorId),
      }));

      res.json({
        shorts: enriched,
        total: list.length,
        hasMore: list.length > limitCount,
      });
    } catch (err: any) {
      console.error('Fetch feed error:', err);
      res.status(500).json({ error: 'Failed to retrieve Shorts feed.' });
    }
  });

  // -------------------------------------------------------------------------
  // 3. SINGLE SHORT DETAIL & MANAGEMENT
  // -------------------------------------------------------------------------
  app.get('/api/shorts/:id', async (req: Request, res: Response) => {
    try {
      const shortId = req.params.id;
      const snap = await getDoc(doc(db, 'shorts', shortId));
      if (!snap.exists()) {
        return res.status(404).json({ error: 'Short video not found.' });
      }

      const data = snap.data();
      const viewer = await getOptionalUser(req);
      let hasLiked = false;
      let hasSaved = false;
      let isFollowing = false;

      if (viewer) {
        const [likeSnap, saveSnap, followSnap] = await Promise.all([
          getDoc(doc(db, 'short_likes', `${shortId}_${viewer.userId}`)),
          getDoc(doc(db, 'short_saves', `${shortId}_${viewer.userId}`)),
          getDoc(doc(db, 'short_follows', `${viewer.userId}_${data.creatorId}`)),
        ]);
        hasLiked = likeSnap.exists();
        hasSaved = saveSnap.exists();
        isFollowing = followSnap.exists();
      }

      res.json({
        short: {
          ...data,
          hasLiked,
          hasSaved,
          isFollowing,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch Short.' });
    }
  });

  // Edit Short Caption / Allow Comments
  app.patch('/api/shorts/:id', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const shortId = req.params.id;
      const { caption, allowComments } = req.body;

      const shortRef = doc(db, 'shorts', shortId);
      const snap = await getDoc(shortRef);
      if (!snap.exists()) {
        return res.status(404).json({ error: 'Short not found.' });
      }

      const shortData = snap.data();
      if (shortData.creatorId !== user.id && !user.isAdmin) {
        return res.status(403).json({ error: 'You can only edit your own Shorts.' });
      }

      const updates: any = { updatedAt: new Date().toISOString() };
      if (caption !== undefined) {
        updates.caption = caption.trim();
        updates.hashtags = extractHashtags(caption);
      }
      if (allowComments !== undefined) {
        updates.allowComments = !!allowComments;
      }

      await updateDoc(shortRef, updates);
      res.json({ success: true, short: { ...shortData, ...updates } });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update Short.' });
    }
  });

  // Delete Short
  app.delete('/api/shorts/:id', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const shortId = req.params.id;

      const shortRef = doc(db, 'shorts', shortId);
      const snap = await getDoc(shortRef);
      if (!snap.exists()) {
        return res.status(404).json({ error: 'Short not found.' });
      }

      const shortData = snap.data();
      if (shortData.creatorId !== user.id && !user.isAdmin) {
        return res.status(403).json({ error: 'You can only delete your own Shorts.' });
      }

      // Mark removed and delete doc
      await deleteDoc(shortRef);
      res.json({ success: true, message: 'Short deleted successfully.' });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to delete Short.' });
    }
  });

  // -------------------------------------------------------------------------
  // 4. ENGAGEMENT: LIKES, VIEWS, SAVES
  // -------------------------------------------------------------------------
  app.post('/api/shorts/:id/like', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const shortId = req.params.id;
      const likeKey = `${shortId}_${user.id}`;
      const likeRef = doc(db, 'short_likes', likeKey);
      const shortRef = doc(db, 'shorts', shortId);

      let hasLiked = false;
      let newLikesCount = 0;

      await runTransaction(db, async (tx) => {
        const shortDoc = await tx.get(shortRef);
        if (!shortDoc.exists()) {
          throw new Error('Short does not exist');
        }
        const shortData = shortDoc.data();
        const likeDoc = await tx.get(likeRef);

        if (likeDoc.exists()) {
          // Unlike
          tx.delete(likeRef);
          newLikesCount = Math.max(0, (shortData.likesCount || 0) - 1);
          tx.update(shortRef, { likesCount: newLikesCount });
          hasLiked = false;
        } else {
          // Like
          tx.set(likeRef, {
            id: likeKey,
            shortId,
            userId: user.id,
            createdAt: new Date().toISOString(),
          });
          newLikesCount = (shortData.likesCount || 0) + 1;
          tx.update(shortRef, { likesCount: newLikesCount });
          hasLiked = true;

          // Notify creator if someone else liked
          if (shortData.creatorId !== user.id) {
            createShortNotification(
              shortData.creatorId,
              '❤️ New Like on your Short!',
              `@${user.username} liked your Short "${shortData.caption.slice(0, 40)}..."`,
              'short_like'
            );
          }
        }
      });

      res.json({ success: true, hasLiked, likesCount: newLikesCount });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to toggle like.' });
    }
  });

  // Track View (with deduplication)
  app.post('/api/shorts/:id/view', async (req: Request, res: Response) => {
    try {
      const shortId = req.params.id;
      const viewer = await getOptionalUser(req);
      const viewerKey = viewer ? viewer.userId : (req.headers['x-forwarded-for'] as string || req.ip || 'anon');
      const viewDedupKey = `${shortId}:${viewerKey}`;

      if (recentViews.has(viewDedupKey)) {
        return res.json({ success: true, counted: false });
      }

      recentViews.add(viewDedupKey);
      // Auto-clear from memory after 10 minutes so deduplication stays sensible
      setTimeout(() => recentViews.delete(viewDedupKey), 10 * 60 * 1000);

      const shortRef = doc(db, 'shorts', shortId);
      const snap = await getDoc(shortRef);
      if (snap.exists()) {
        const data = snap.data();
        const viewsCount = (data.viewsCount || 0) + 1;
        await updateDoc(shortRef, { viewsCount });
        return res.json({ success: true, counted: true, viewsCount });
      }

      res.json({ success: true, counted: false });
    } catch {
      res.json({ success: true, counted: false });
    }
  });

  // Save / Bookmark Toggle
  app.post('/api/shorts/:id/save', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const shortId = req.params.id;
      const saveKey = `${shortId}_${user.id}`;
      const saveRef = doc(db, 'short_saves', saveKey);

      const snap = await getDoc(saveRef);
      let hasSaved = false;

      if (snap.exists()) {
        await deleteDoc(saveRef);
        hasSaved = false;
      } else {
        await setDoc(saveRef, {
          id: saveKey,
          shortId,
          userId: user.id,
          createdAt: new Date().toISOString(),
        });
        hasSaved = true;
      }

      res.json({ success: true, hasSaved });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to bookmark Short.' });
    }
  });

  // Get Saved Shorts List
  app.get('/api/shorts/saved/list', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const savesSnap = await getDocs(
        query(collection(db, 'short_saves'), where('userId', '==', user.id), limit(50))
      );
      const shortIds = savesSnap.docs.map((d) => d.data().shortId);

      if (shortIds.length === 0) {
        return res.json({ shorts: [] });
      }

      const shortsPromises = shortIds.map((id) => getDoc(doc(db, 'shorts', id)));
      const shortDocs = await Promise.all(shortsPromises);
      const shorts = shortDocs
        .filter((d) => d.exists() && d.data().status === 'active')
        .map((d) => ({
          ...d.data(),
          hasSaved: true,
        }));

      res.json({ shorts });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch saved Shorts.' });
    }
  });

  // -------------------------------------------------------------------------
  // 5. COMMENTS, REPLIES, & GIF COMMENTS
  // -------------------------------------------------------------------------
  app.get('/api/shorts/:id/comments', async (req: Request, res: Response) => {
    try {
      const shortId = req.params.id;
      const snap = await getDocs(
        query(collection(db, 'short_comments'), where('shortId', '==', shortId), limit(100))
      );

      const viewer = await getOptionalUser(req);
      let viewerCommentLikes = new Set<string>();

      if (viewer) {
        try {
          const likesSnap = await getDocs(
            query(collection(db, 'short_comment_likes'), where('userId', '==', viewer.userId))
          );
          likesSnap.forEach((d) => viewerCommentLikes.add(d.data().commentId));
        } catch {}
      }

      const rawComments = snap.docs.map((d) => ({
        ...(d.data() as any),
        hasLiked: viewerCommentLikes.has(d.id),
      }));

      // Sort by creation date
      rawComments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      // Nest replies under parent comments
      const topLevel: any[] = [];
      const repliesMap = new Map<string, any[]>();

      for (const comment of rawComments) {
        if (comment.parentCommentId) {
          if (!repliesMap.has(comment.parentCommentId)) {
            repliesMap.set(comment.parentCommentId, []);
          }
          repliesMap.get(comment.parentCommentId)!.push(comment);
        } else {
          topLevel.push(comment);
        }
      }

      // Attach replies array to top level comments
      for (const parent of topLevel) {
        const replies = repliesMap.get(parent.id) || [];
        // Sort replies ascending chronologically
        replies.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        parent.replies = replies;
      }

      res.json({ comments: topLevel });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch comments.' });
    }
  });

  // Post Comment or GIF Reply
  app.post('/api/shorts/:id/comments', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const shortId = req.params.id;
      const { text, gifUrl, gifTitle, mediaType, parentCommentId } = req.body;

      if (!text?.trim() && !gifUrl) {
        return res.status(400).json({ error: 'Comment must contain text or a GIF.' });
      }

      const shortRef = doc(db, 'shorts', shortId);
      const shortSnap = await getDoc(shortRef);
      if (!shortSnap.exists()) {
        return res.status(404).json({ error: 'Short video not found.' });
      }

      const shortData = shortSnap.data();
      if (shortData.allowComments === false) {
        return res.status(403).json({ error: 'Comments are disabled for this Short.' });
      }

      const commentId = 'comment_' + crypto.randomUUID();
      const newComment = {
        id: commentId,
        shortId,
        userId: user.id,
        username: user.username,
        userAvatar: user.avatarUrl || '',
        text: text ? text.trim() : '',
        gifUrl: gifUrl || '',
        gifTitle: gifTitle || '',
        mediaType: mediaType || (gifUrl ? 'gif' : 'text'),
        parentCommentId: parentCommentId || null,
        likesCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'short_comments', commentId), newComment);

      // Increment commentsCount on Short
      await updateDoc(shortRef, {
        commentsCount: (shortData.commentsCount || 0) + 1,
      });

      // Notify short creator or parent comment author
      if (parentCommentId) {
        const parentSnap = await getDoc(doc(db, 'short_comments', parentCommentId));
        if (parentSnap.exists() && parentSnap.data().userId !== user.id) {
          createShortNotification(
            parentSnap.data().userId,
            '💬 Reply to your comment',
            `@${user.username} replied: "${(text || 'sent a GIF').slice(0, 50)}"`,
            'short_reply'
          );
        }
      } else if (shortData.creatorId !== user.id) {
        createShortNotification(
          shortData.creatorId,
          '💬 New Comment on your Short',
          `@${user.username} commented: "${(text || 'sent a GIF').slice(0, 50)}"`,
          'short_comment'
        );
      }

      res.status(201).json({
        success: true,
        comment: {
          ...newComment,
          hasLiked: false,
          replies: [],
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to post comment.' });
    }
  });

  // Edit Comment Text
  app.patch('/api/shorts/comments/:commentId', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const commentId = req.params.commentId;
      const { text } = req.body;

      if (!text?.trim()) {
        return res.status(400).json({ error: 'Comment text cannot be empty.' });
      }

      const commentRef = doc(db, 'short_comments', commentId);
      const snap = await getDoc(commentRef);
      if (!snap.exists()) {
        return res.status(404).json({ error: 'Comment not found.' });
      }

      const commentData = snap.data();
      if (commentData.userId !== user.id && !user.isAdmin) {
        return res.status(403).json({ error: 'Unauthorized to edit this comment.' });
      }

      await updateDoc(commentRef, {
        text: text.trim(),
        updatedAt: new Date().toISOString(),
      });

      res.json({ success: true, text: text.trim() });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to edit comment.' });
    }
  });

  // Delete Comment
  app.delete('/api/shorts/comments/:commentId', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const commentId = req.params.commentId;

      const commentRef = doc(db, 'short_comments', commentId);
      const snap = await getDoc(commentRef);
      if (!snap.exists()) {
        return res.status(404).json({ error: 'Comment not found.' });
      }

      const commentData = snap.data();
      const shortRef = doc(db, 'shorts', commentData.shortId);
      const shortSnap = await getDoc(shortRef);
      const isShortCreator = shortSnap.exists() && shortSnap.data().creatorId === user.id;

      if (commentData.userId !== user.id && !isShortCreator && !user.isAdmin) {
        return res.status(403).json({ error: 'Unauthorized to delete this comment.' });
      }

      await deleteDoc(commentRef);

      // Decrement comments count on Short
      if (shortSnap.exists()) {
        const currentCount = shortSnap.data().commentsCount || 0;
        await updateDoc(shortRef, { commentsCount: Math.max(0, currentCount - 1) });
      }

      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to delete comment.' });
    }
  });

  // Like Comment Toggle
  app.post('/api/shorts/comments/:commentId/like', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const commentId = req.params.commentId;
      const likeKey = `${commentId}_${user.id}`;
      const likeRef = doc(db, 'short_comment_likes', likeKey);
      const commentRef = doc(db, 'short_comments', commentId);

      let hasLiked = false;
      let newLikesCount = 0;

      await runTransaction(db, async (tx) => {
        const commentDoc = await tx.get(commentRef);
        if (!commentDoc.exists()) {
          throw new Error('Comment does not exist');
        }
        const commentData = commentDoc.data();
        const likeDoc = await tx.get(likeRef);

        if (likeDoc.exists()) {
          tx.delete(likeRef);
          newLikesCount = Math.max(0, (commentData.likesCount || 0) - 1);
          tx.update(commentRef, { likesCount: newLikesCount });
          hasLiked = false;
        } else {
          tx.set(likeRef, {
            id: likeKey,
            commentId,
            userId: user.id,
            createdAt: new Date().toISOString(),
          });
          newLikesCount = (commentData.likesCount || 0) + 1;
          tx.update(commentRef, { likesCount: newLikesCount });
          hasLiked = true;
        }
      });

      res.json({ success: true, hasLiked, likesCount: newLikesCount });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to like comment.' });
    }
  });

  // -------------------------------------------------------------------------
  // 6. GIF SEARCH & TRENDING PROXY
  // -------------------------------------------------------------------------
  app.get('/api/gifs/trending', async (_req: Request, res: Response) => {
    try {
      // Attempt to query Tenor / GIPHY public trending API or serve curated set
      res.json({ gifs: CURATED_GIFS, provider: 'GIPHY & Tenor' });
    } catch {
      res.json({ gifs: CURATED_GIFS, provider: 'Curated' });
    }
  });

  app.get('/api/gifs/search', async (req: Request, res: Response) => {
    try {
      const queryStr = (req.query.q as string || '').toLowerCase().trim();
      if (!queryStr) {
        return res.json({ gifs: CURATED_GIFS });
      }

      const filtered = CURATED_GIFS.filter(
        (g) => g.title.toLowerCase().includes(queryStr) || queryStr.includes('gif')
      );

      // If query has no matches, return filtered or full curated list for continuous enjoyment
      res.json({ gifs: filtered.length > 0 ? filtered : CURATED_GIFS });
    } catch {
      res.json({ gifs: CURATED_GIFS });
    }
  });

  // -------------------------------------------------------------------------
  // 7. CREATOR PROFILES & FOLLOW SYSTEM
  // -------------------------------------------------------------------------
  app.get('/api/shorts/creator/:username', async (req: Request, res: Response) => {
    try {
      const username = req.params.username;
      let creator: any = null;
      let userQuery = query(collection(db, 'users'), where('username', '==', username), limit(1));
      let userSnap = await getDocs(userQuery);
      if (userSnap.empty) {
        userQuery = query(collection(db, 'users'), where('usernameLower', '==', username.toLowerCase()), limit(1));
        userSnap = await getDocs(userQuery);
      }
      if (!userSnap.empty) {
        creator = userSnap.docs[0].data();
      }

      if (!creator) {
        return res.status(404).json({ error: 'Creator not found.' });
      }

      const creatorId = creator.id;

      // Published shorts
      const shortsSnap = await getDocs(
        query(collection(db, 'shorts'), where('creatorId', '==', creatorId), where('status', '==', 'active'))
      );
      const shorts = shortsSnap.docs.map((d) => d.data());
      shorts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      // Followers count
      const followersSnap = await getDocs(
        query(collection(db, 'short_follows'), where('followingId', '==', creatorId))
      );
      const followingSnap = await getDocs(
        query(collection(db, 'short_follows'), where('followerId', '==', creatorId))
      );

      // Check if current viewer is following
      const viewer = await getOptionalUser(req);
      let isFollowing = false;
      if (viewer && viewer.userId) {
        const followDoc = await getDoc(doc(db, 'short_follows', `${viewer.userId}_${creatorId}`));
        isFollowing = followDoc.exists();
      }

      const totalLikes = shorts.reduce((sum, s) => sum + (s.likesCount || 0), 0);
      const totalViews = shorts.reduce((sum, s) => sum + (s.viewsCount || 0), 0);

      res.json({
        creator: {
          id: creatorId,
          username: creator.username,
          avatarUrl: creator.avatarUrl || '',
          vipBadge: creator.vipBadge || null,
          createdAt: creator.createdAt,
          followersCount: followersSnap.size,
          followingCount: followingSnap.size,
          totalShorts: shorts.length,
          totalLikes,
          totalViews,
          isFollowing,
        },
        shorts,
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch creator profile.' });
    }
  });

  // Toggle Follow
  app.post('/api/shorts/creator/:creatorId/follow', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const targetCreatorId = req.params.creatorId;

      if (user.id === targetCreatorId) {
        return res.status(400).json({ error: 'You cannot follow yourself.' });
      }

      const followKey = `${user.id}_${targetCreatorId}`;
      const followRef = doc(db, 'short_follows', followKey);
      const snap = await getDoc(followRef);
      let isFollowing = false;

      if (snap.exists()) {
        await deleteDoc(followRef);
        isFollowing = false;
      } else {
        await setDoc(followRef, {
          id: followKey,
          followerId: user.id,
          followingId: targetCreatorId,
          createdAt: new Date().toISOString(),
        });
        isFollowing = true;

        // Notify target creator
        createShortNotification(
          targetCreatorId,
          '🌟 New Follower on LOT Shorts!',
          `@${user.username} started following your Shorts.`,
          'short_follow'
        );
      }

      res.json({ success: true, isFollowing });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to toggle follow.' });
    }
  });

  // -------------------------------------------------------------------------
  // 8. SAFETY & MODERATION (REPORTS & ADMIN REVIEW)
  // -------------------------------------------------------------------------
  app.post('/api/shorts/:id/report', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const shortId = req.params.id;
      const { reason, details } = req.body;

      if (!reason?.trim()) {
        return res.status(400).json({ error: 'Please select a reason for reporting.' });
      }

      const reportId = 'report_' + crypto.randomUUID();
      await setDoc(doc(db, 'short_reports', reportId), {
        id: reportId,
        type: 'video',
        targetId: shortId,
        shortId,
        reporterId: user.id,
        reporterUsername: user.username,
        reason: reason.trim(),
        details: (details || '').trim(),
        status: 'pending',
        createdAt: new Date().toISOString(),
      });

      res.json({ success: true, message: 'Thank you. Report submitted for administrator review.' });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to submit report.' });
    }
  });

  app.post('/api/shorts/comments/:commentId/report', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const commentId = req.params.commentId;
      const { reason, details, shortId } = req.body;

      if (!reason?.trim()) {
        return res.status(400).json({ error: 'Please select a reason for reporting.' });
      }

      const reportId = 'report_' + crypto.randomUUID();
      await setDoc(doc(db, 'short_reports', reportId), {
        id: reportId,
        type: 'comment',
        targetId: commentId,
        shortId: shortId || '',
        reporterId: user.id,
        reporterUsername: user.username,
        reason: reason.trim(),
        details: (details || '').trim(),
        status: 'pending',
        createdAt: new Date().toISOString(),
      });

      res.json({ success: true, message: 'Thank you. Comment reported for moderation.' });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to report comment.' });
    }
  });

  // Admin: List Moderation Reports
  app.get('/api/admin/shorts/reports', authMiddleware, adminMiddleware, async (_req: Request, res: Response) => {
    try {
      const snap = await getDocs(
        query(collection(db, 'short_reports'), where('status', '==', 'pending'), limit(50))
      );
      const reports = snap.docs.map((d) => d.data());
      reports.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      // Enrich with target item details
      const enriched = await Promise.all(
        reports.map(async (r: any) => {
          let snapshot: any = null;
          try {
            if (r.type === 'video') {
              const sDoc = await getDoc(doc(db, 'shorts', r.targetId));
              if (sDoc.exists()) snapshot = sDoc.data();
            } else if (r.type === 'comment') {
              const cDoc = await getDoc(doc(db, 'short_comments', r.targetId));
              if (cDoc.exists()) snapshot = cDoc.data();
            }
          } catch {}
          return { ...r, snapshot };
        })
      );

      res.json({ reports: enriched });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch moderation reports.' });
    }
  });

  // Admin: Action on Report (resolve, dismiss, remove item, or ban account)
  app.post('/api/admin/shorts/reports/:reportId/action', authMiddleware, adminMiddleware, async (req: Request, res: Response) => {
    try {
      const reportId = req.params.reportId;
      const { action } = req.body; // 'dismiss' | 'remove_item' | 'ban_creator'

      const reportRef = doc(db, 'short_reports', reportId);
      const snap = await getDoc(reportRef);
      if (!snap.exists()) {
        return res.status(404).json({ error: 'Report not found.' });
      }

      const reportData = snap.data();

      if (action === 'remove_item') {
        if (reportData.type === 'video') {
          await deleteDoc(doc(db, 'shorts', reportData.targetId));
        } else {
          await deleteDoc(doc(db, 'short_comments', reportData.targetId));
        }
      } else if (action === 'ban_creator') {
        // Find creator and ban
        let creatorId = '';
        if (reportData.type === 'video') {
          const s = await getDoc(doc(db, 'shorts', reportData.targetId));
          if (s.exists()) creatorId = s.data().creatorId;
          await deleteDoc(doc(db, 'shorts', reportData.targetId));
        } else {
          const c = await getDoc(doc(db, 'short_comments', reportData.targetId));
          if (c.exists()) creatorId = c.data().userId;
          await deleteDoc(doc(db, 'short_comments', reportData.targetId));
        }
        if (creatorId) {
          await updateDoc(doc(db, 'users', creatorId), { isBanned: true });
        }
      }

      await updateDoc(reportRef, { status: action === 'dismiss' ? 'dismissed' : 'resolved' });
      res.json({ success: true, message: `Report handled: ${action}` });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to process report action.' });
    }
  });

  // =========================================================================
  // LOT VIDEOS - FULL VIDEO PLATFORM & MONETIZATION ENDPOINTS
  // =========================================================================

  // 1. Unified Feed for LOT Videos & Shorts
  app.get('/api/videos/feed', async (req: Request, res: Response) => {
    try {
      const viewer = await getOptionalUser(req);
      const viewerId = viewer ? viewer.userId || viewer.id : null;
      const section = (req.query.section as string) || 'all'; // all, long, shorts, trending, recommended, purchased, history, subscriptions
      const category = (req.query.category as string) || 'all';
      const search = (req.query.search as string || '').toLowerCase().trim();
      const typeFilter = req.query.type as string; // 'video' | 'short' | 'all'

      // Fetch all active videos & shorts
      const snap = await getDocs(
        query(collection(db, 'shorts'), where('status', '==', 'active'), limit(200))
      );
      let videos = snap.docs.map((d) => {
        const data = d.data();
        return {
          ...data,
          type: data.type || (data.duration && data.duration <= 60 ? 'short' : 'video'),
          title: data.title || data.caption || 'Untitled Video',
          description: data.description || data.caption || '',
          category: data.category || 'Entertainment',
          isPaid: Boolean(data.isPaid && (data.priceLot || 0) > 0),
          priceLot: Number(data.priceLot || 0),
        };
      });

      // Filter out invalid items
      videos = videos.filter((v: any) => v.videoUrl || v.youtubeVideoId);

      // Category filter
      if (category && category !== 'all') {
        videos = videos.filter((v: any) => v.category?.toLowerCase() === category.toLowerCase());
      }

      // Search filter
      if (search) {
        videos = videos.filter((v: any) => {
          const t = (v.title || '').toLowerCase();
          const d = (v.description || '').toLowerCase();
          const u = (v.creatorUsername || '').toLowerCase();
          const tags = Array.isArray(v.hashtags) ? v.hashtags.join(' ').toLowerCase() : '';
          return t.includes(search) || d.includes(search) || u.includes(search) || tags.includes(search);
        });
      }

      // Type filter
      if (typeFilter === 'video') {
        videos = videos.filter((v: any) => v.type === 'video');
      } else if (typeFilter === 'short') {
        videos = videos.filter((v: any) => v.type === 'short');
      }

      // Viewer purchases, likes, saves, history
      let userPurchases = new Set<string>();
      let userLikes = new Set<string>();
      let userSaves = new Set<string>();
      let userFollows = new Set<string>();
      let userHistoryMap = new Map<string, { currentTime: number; progressPercent: number }>();

      if (viewerId) {
        try {
          const [pSnap, lSnap, sSnap, fSnap, hSnap] = await Promise.all([
            getDocs(query(collection(db, 'video_purchases'), where('userId', '==', viewerId))),
            getDocs(query(collection(db, 'short_likes'), where('userId', '==', viewerId))),
            getDocs(query(collection(db, 'short_saves'), where('userId', '==', viewerId))),
            getDocs(query(collection(db, 'short_follows'), where('followerId', '==', viewerId))),
            getDocs(query(collection(db, 'video_history'), where('userId', '==', viewerId))),
          ]);

          pSnap.forEach((d) => userPurchases.add(d.data().videoId));
          lSnap.forEach((d) => userLikes.add(d.data().shortId));
          sSnap.forEach((d) => userSaves.add(d.data().shortId));
          fSnap.forEach((d) => userFollows.add(d.data().followingId));
          hSnap.forEach((d) => {
            const h = d.data();
            userHistoryMap.set(h.videoId, {
              currentTime: h.currentTime || 0,
              progressPercent: h.progressPercent || 0,
            });
          });
        } catch (e) {
          console.warn('Error fetching viewer video metadata:', e);
        }
      }

      // Section filtering & sorting
      if (section === 'long') {
        videos = videos.filter((v: any) => v.type === 'video');
      } else if (section === 'shorts') {
        videos = videos.filter((v: any) => v.type === 'short');
      } else if (section === 'trending') {
        videos.sort((a: any, b: any) => {
          const scoreB = (b.likesCount || 0) * 3 + (b.commentsCount || 0) * 2 + (b.viewsCount || 0);
          const scoreA = (a.likesCount || 0) * 3 + (a.commentsCount || 0) * 2 + (a.viewsCount || 0);
          return scoreB - scoreA;
        });
      } else if (section === 'purchased') {
        videos = videos.filter((v: any) => userPurchases.has(v.id));
      } else if (section === 'history') {
        videos = videos.filter((v: any) => userHistoryMap.has(v.id));
      } else if (section === 'subscriptions') {
        videos = videos.filter((v: any) => userFollows.has(v.creatorId));
      } else if (section === 'recommended') {
        // Shuffle / mix based on likes & views
        videos.sort((a: any, b: any) => (b.viewsCount || 0) - (a.viewsCount || 0));
      } else {
        // Default: newest first
        videos.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }

      // Enrich with unlocked / purchased status
      const enrichedVideos = videos.map((v: any) => {
        const isOwner = viewerId && v.creatorId === viewerId;
        const isAdmin = Boolean(viewer?.isAdmin);
        const hasPurchased = userPurchases.has(v.id);
        const isUnlocked = !v.isPaid || v.priceLot <= 0 || isOwner || isAdmin || hasPurchased;
        const history = userHistoryMap.get(v.id);

        return {
          ...v,
          isUnlocked: Boolean(isUnlocked),
          isPurchased: Boolean(hasPurchased),
          isOwner: Boolean(isOwner),
          hasLiked: userLikes.has(v.id),
          hasSaved: userSaves.has(v.id),
          isFollowing: userFollows.has(v.creatorId),
          continueTime: history?.currentTime || 0,
          continueProgress: history?.progressPercent || 0,
        };
      });

      res.json({
        videos: enrichedVideos,
        total: enrichedVideos.length,
      });
    } catch (err: any) {
      console.error('Error fetching videos feed:', err);
      res.status(500).json({ error: 'Failed to fetch videos feed.' });
    }
  });

  // 2. Upload Video (Long or Short, Free or Paid)
  app.post(
    '/api/videos/upload',
    authMiddleware,
    upload.fields([
      { name: 'video', maxCount: 1 },
      { name: 'thumbnail', maxCount: 1 },
    ]),
    async (req: Request, res: Response) => {
      try {
        const user = (req as any).user;
        const files = req.files as { [fieldname: string]: Express.Multer.File[] } | undefined;
        const videoFile = files?.video?.[0];
        const thumbFile = files?.thumbnail?.[0];

        if (!videoFile) {
          return res.status(400).json({ error: 'Video file is required.' });
        }

        const title = (req.body.title || req.body.caption || 'Untitled Video').trim();
        const description = (req.body.description || '').trim();
        const category = (req.body.category || 'Entertainment').trim();
        const tagsInput = (req.body.tags || '').trim();
        const type = (req.body.type === 'short' ? 'short' : 'video') as 'short' | 'video';
        const duration = Math.round(parseFloat(req.body.duration) || (type === 'short' ? 25 : 180));
        const isPaid = req.body.isPaid === 'true' || req.body.isPaid === true;
        const priceLot = isPaid ? Math.max(1, Math.round(parseFloat(req.body.priceLot) || 1)) : 0;

        const videoId = (type === 'short' ? 'short_' : 'video_') + crypto.randomUUID();
        const videoUrl = `/uploads/shorts/${videoFile.filename}`;
        let thumbnailUrl = '';

        // Persist video file
        const videoBuffer = fs.readFileSync(videoFile.path);
        await savePersistentMedia(db, {
          fileId: videoId,
          filename: videoFile.filename,
          mimeType: videoFile.mimetype || 'video/mp4',
          buffer: videoBuffer,
          subfolder: 'shorts',
          uploaderId: user.id,
        });

        // Persist thumbnail if provided
        if (thumbFile) {
          const thumbBuffer = fs.readFileSync(thumbFile.path);
          await savePersistentMedia(db, {
            fileId: `thumb_${videoId}`,
            filename: thumbFile.filename,
            mimeType: thumbFile.mimetype || 'image/jpeg',
            buffer: thumbBuffer,
            subfolder: 'shorts',
            uploaderId: user.id,
          });
          thumbnailUrl = `/uploads/shorts/${thumbFile.filename}`;
        }

        const hashtags = tagsInput
          ? tagsInput.split(',').map((t: string) => t.trim().toLowerCase()).filter(Boolean)
          : extractHashtags(title + ' ' + description);

        const now = new Date().toISOString();
        const newRecord = {
          id: videoId,
          type,
          title,
          caption: title,
          description,
          category,
          hashtags,
          creatorId: user.id,
          creatorUsername: user.username,
          creatorAvatar: user.avatarUrl || '',
          videoUrl,
          thumbnailUrl,
          duration,
          isPaid,
          priceLot,
          likesCount: 0,
          viewsCount: 0,
          commentsCount: 0,
          purchasesCount: 0,
          totalRevenueLot: 0,
          allowComments: req.body.allowComments !== 'false' && req.body.allowComments !== false,
          status: 'active',
          createdAt: now,
          updatedAt: now,
        };

        await setDoc(doc(db, 'shorts', videoId), newRecord);

        res.status(201).json({
          success: true,
          message: `Your ${type === 'short' ? 'Short' : 'Video'} was uploaded successfully!`,
          video: newRecord,
        });
      } catch (err: any) {
        console.error('Video upload error:', err);
        res.status(500).json({ error: 'Failed to upload video: ' + err.message });
      }
    }
  );

  // 3. Purchase Paid Video (Pay LOT to Watch with Permanent Lifetime Unlock)
  app.post('/api/videos/:id/purchase', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const videoId = req.params.id;

      const videoRef = doc(db, 'shorts', videoId);
      const videoSnap = await getDoc(videoRef);
      if (!videoSnap.exists()) {
        return res.status(404).json({ error: 'Video not found.' });
      }

      const videoData = videoSnap.data();
      const priceLot = Number(videoData.priceLot || 0);

      // If free
      if (!videoData.isPaid || priceLot <= 0) {
        return res.json({ success: true, message: 'This video is free to watch.', alreadyPurchased: true });
      }

      // If viewer is creator
      if (videoData.creatorId === user.id) {
        return res.json({ success: true, message: 'You are the creator of this video.', alreadyPurchased: true });
      }

      // Check existing purchase
      const purchaseDocId = `${user.id}_${videoId}`;
      const purchaseRef = doc(db, 'video_purchases', purchaseDocId);
      const existingSnap = await getDoc(purchaseRef);
      if (existingSnap.exists()) {
        return res.json({ success: true, message: 'You already unlocked this video.', alreadyPurchased: true });
      }

      const viewerRef = doc(db, 'users', user.id);
      const creatorRef = doc(db, 'users', videoData.creatorId);

      let viewerNewBalance = 0;
      await runTransaction(db, async (txn) => {
        const viewerDoc = await txn.get(viewerRef);
        if (!viewerDoc.exists()) throw new Error('User account not found.');

        const viewerData = viewerDoc.data();
        const currentBalance = Number(viewerData.lotBalance || 0);

        if (currentBalance < priceLot) {
          throw new Error(`Insufficient LOT balance. You have £${currentBalance.toLocaleString()} LOT, but unlocking this video costs £${priceLot.toLocaleString()} LOT.`);
        }

        const creatorDoc = await txn.get(creatorRef);
        const creatorBalance = creatorDoc.exists() ? Number(creatorDoc.data().lotBalance || 0) : 0;

        viewerNewBalance = currentBalance - priceLot;
        const creatorNewBalance = creatorBalance + priceLot;

        txn.update(viewerRef, { lotBalance: viewerNewBalance });
        if (creatorDoc.exists()) {
          txn.update(creatorRef, { lotBalance: creatorNewBalance });
        }

        // Record lifetime purchase
        txn.set(purchaseRef, {
          id: purchaseDocId,
          userId: user.id,
          username: user.username,
          videoId: videoData.id,
          videoTitle: videoData.title || videoData.caption,
          creatorId: videoData.creatorId,
          creatorUsername: videoData.creatorUsername,
          priceLot,
          purchasedAt: new Date().toISOString(),
          status: 'active',
        });

        // Record in central transactions ledger
        const txId = 'tx_' + crypto.randomUUID();
        txn.set(doc(db, 'transactions', txId), {
          id: txId,
          type: 'video_purchase',
          senderId: user.id,
          senderUsername: user.username,
          recipientId: videoData.creatorId,
          recipientUsername: videoData.creatorUsername,
          amount: priceLot,
          description: `Unlocked Video: "${videoData.title || videoData.caption}"`,
          videoId: videoData.id,
          createdAt: new Date().toISOString(),
          timestamp: Date.now(),
        });

        // Update video purchase metrics
        txn.update(videoRef, {
          purchasesCount: (videoData.purchasesCount || 0) + 1,
          totalRevenueLot: (videoData.totalRevenueLot || 0) + priceLot,
        });
      });

      // Dispatch real-time WebSocket notification to creator if online
      if (sendToUser && videoData.creatorId) {
        sendToUser(videoData.creatorId, 'video:purchased', {
          videoTitle: videoData.title || videoData.caption,
          buyerUsername: user.username,
          earnedLot: priceLot,
        });
      }

      res.json({
        success: true,
        message: `Video unlocked permanently for £${priceLot} LOT!`,
        newLotBalance: viewerNewBalance,
        videoId: videoData.id,
      });
    } catch (err: any) {
      console.error('Error unlocking video:', err);
      res.status(400).json({ error: err.message || 'Failed to complete video purchase.' });
    }
  });

  // 4. Save Watch Progress / Continue Watching
  app.post('/api/videos/:id/progress', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const videoId = req.params.id;
      const currentTime = Math.max(0, parseFloat(req.body.currentTime) || 0);
      const duration = Math.max(1, parseFloat(req.body.duration) || 1);
      const progressPercent = Math.min(100, Math.round((currentTime / duration) * 100));

      const historyDocId = `${user.id}_${videoId}`;
      await setDoc(
        doc(db, 'video_history', historyDocId),
        {
          id: historyDocId,
          userId: user.id,
          videoId,
          currentTime,
          duration,
          progressPercent,
          lastWatchedAt: new Date().toISOString(),
        },
        { merge: true }
      );

      res.json({ success: true, progressPercent });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to record watch progress.' });
    }
  });

  // 5. Watch History List
  app.get('/api/videos/history', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const hSnap = await getDocs(
        query(collection(db, 'video_history'), where('userId', '==', user.id), limit(50))
      );
      const historyItems = hSnap.docs.map((d) => d.data());
      historyItems.sort((a, b) => new Date(b.lastWatchedAt).getTime() - new Date(a.lastWatchedAt).getTime());

      // Enrich with video objects
      const enriched = await Promise.all(
        historyItems.map(async (h: any) => {
          const vDoc = await getDoc(doc(db, 'shorts', h.videoId));
          return vDoc.exists()
            ? { ...vDoc.data(), continueTime: h.currentTime, continueProgress: h.progressPercent }
            : null;
        })
      );

      res.json({ history: enriched.filter(Boolean) });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch watch history.' });
    }
  });

  // 6. Playlists (List, Create, Add/Remove Video, Delete)
  app.get('/api/videos/playlists', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const pSnap = await getDocs(
        query(collection(db, 'video_playlists'), where('userId', '==', user.id))
      );
      const playlists = pSnap.docs.map((d) => d.data());
      res.json({ playlists });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch playlists.' });
    }
  });

  app.post('/api/videos/playlists', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const name = (req.body.name || '').trim();
      const description = (req.body.description || '').trim();
      if (!name) return res.status(400).json({ error: 'Playlist name is required.' });

      const playlistId = 'pl_' + crypto.randomUUID();
      const playlist = {
        id: playlistId,
        name,
        description,
        userId: user.id,
        username: user.username,
        videoIds: [],
        createdAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'video_playlists', playlistId), playlist);
      res.json({ success: true, playlist });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to create playlist.' });
    }
  });

  app.post('/api/videos/playlists/:id/items', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const playlistId = req.params.id;
      const { videoId, action } = req.body; // 'add' | 'remove'

      const pRef = doc(db, 'video_playlists', playlistId);
      const pSnap = await getDoc(pRef);
      if (!pSnap.exists()) return res.status(404).json({ error: 'Playlist not found.' });

      const data = pSnap.data();
      if (data.userId !== user.id) return res.status(403).json({ error: 'Unauthorized.' });

      let currentIds: string[] = data.videoIds || [];
      if (action === 'remove') {
        currentIds = currentIds.filter((id) => id !== videoId);
      } else {
        if (!currentIds.includes(videoId)) currentIds.push(videoId);
      }

      await updateDoc(pRef, { videoIds: currentIds });
      res.json({ success: true, videoIds: currentIds });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to modify playlist.' });
    }
  });

  // 7. Creator Studio (Analytics, Edit Videos, Revenue)
  app.get('/api/creator/studio', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const snap = await getDocs(
        query(collection(db, 'shorts'), where('creatorId', '==', user.id))
      );
      const videos = snap.docs.map((d) => d.data());

      let totalViews = 0;
      let totalLikes = 0;
      let totalComments = 0;
      let totalPurchases = 0;
      let totalRevenueLot = 0;

      videos.forEach((v: any) => {
        totalViews += Number(v.viewsCount || 0);
        totalLikes += Number(v.likesCount || 0);
        totalComments += Number(v.commentsCount || 0);
        totalPurchases += Number(v.purchasesCount || 0);
        totalRevenueLot += Number(v.totalRevenueLot || 0);
      });

      // Sort by views descending
      videos.sort((a: any, b: any) => (b.viewsCount || 0) - (a.viewsCount || 0));

      res.json({
        videos,
        analytics: {
          totalVideos: videos.length,
          totalViews,
          totalLikes,
          totalComments,
          totalPurchases,
          totalRevenueLot,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch creator studio data.' });
    }
  });

  // Edit Video Details
  app.put('/api/creator/videos/:id', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const videoId = req.params.id;
      const vRef = doc(db, 'shorts', videoId);
      const vSnap = await getDoc(vRef);

      if (!vSnap.exists()) return res.status(404).json({ error: 'Video not found.' });
      const videoData = vSnap.data();

      if (videoData.creatorId !== user.id && !user.isAdmin) {
        return res.status(403).json({ error: 'Unauthorized.' });
      }

      const { title, description, category, isPaid, priceLot } = req.body;
      const updates: any = { updatedAt: new Date().toISOString() };

      if (title) {
        updates.title = title.trim();
        updates.caption = title.trim();
      }
      if (description !== undefined) updates.description = description.trim();
      if (category) updates.category = category.trim();
      if (typeof isPaid === 'boolean') updates.isPaid = isPaid;
      if (priceLot !== undefined) updates.priceLot = Math.max(0, Math.round(Number(priceLot)));

      await updateDoc(vRef, updates);
      res.json({ success: true, message: 'Video details updated successfully!' });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update video.' });
    }
  });

  // Dislike Video
  app.post('/api/videos/:id/dislike', authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      const videoId = req.params.id;
      const dislikeId = `${videoId}_${user.id}`;
      const dRef = doc(db, 'video_dislikes', dislikeId);
      const snap = await getDoc(dRef);

      if (snap.exists()) {
        await deleteDoc(dRef);
        res.json({ success: true, hasDisliked: false });
      } else {
        await setDoc(dRef, { id: dislikeId, videoId, userId: user.id, createdAt: new Date().toISOString() });
        res.json({ success: true, hasDisliked: true });
      }
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to record dislike.' });
    }
  });
}

