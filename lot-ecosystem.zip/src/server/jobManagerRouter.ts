import { Request, Response, Express } from 'express';
import {
  Firestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import {
  Employee,
  SalaryPayment,
  AttendanceRecord,
  LeaveRequest,
  JobAuditLog,
  OrganizationProfile,
  EmploymentType,
  SalaryFrequency,
} from '../types/jobManager';

interface RouterOptions {
  db: Firestore;
  authMiddleware: any;
  sendToUser?: (userId: string, event: string, payload: any) => boolean;
}

export function setupJobManagerRoutes(app: Express, { db, authMiddleware, sendToUser }: RouterOptions) {
  // Helper to remove any undefined fields before writing to Firestore
  function cleanFirestoreData(data: any): any {
    if (data === undefined) return null;
    if (data === null || typeof data !== 'object') return data;
    if (Array.isArray(data)) {
      return data.map((item) => (item === undefined ? null : cleanFirestoreData(item)));
    }
    const result: Record<string, any> = {};
    for (const [key, val] of Object.entries(data)) {
      if (val !== undefined) {
        result[key] = cleanFirestoreData(val);
      }
    }
    return result;
  }

  // Helper to log audit actions
  async function logAudit(
    orgId: string,
    action: JobAuditLog['action'],
    description: string,
    performedBy: string,
    performedByUsername: string,
    targetEmployeeId?: string,
    targetEmployeeName?: string
  ) {
    try {
      const auditId = 'audit_' + crypto.randomUUID();
      const auditLog: JobAuditLog = {
        id: auditId,
        orgId,
        action,
        description,
        performedBy,
        performedByUsername,
        targetEmployeeId,
        targetEmployeeName,
        timestamp: new Date().toISOString(),
      };
      await setDoc(doc(db, 'job_audit_logs', auditId), cleanFirestoreData(auditLog));
    } catch (err) {
      console.warn('[Job Manager] Failed to write audit log:', err);
    }
  }

  // Helper to get or create organization for user
  async function getOrCreateOrg(userId: string, username: string): Promise<OrganizationProfile> {
    const orgsRef = collection(db, 'job_organizations');
    const q = query(orgsRef, where('ownerId', '==', userId));
    const snap = await getDocs(q);

    if (!snap.empty) {
      return snap.docs[0].data() as OrganizationProfile;
    }

    // Auto-create default organization for the user
    const newOrgId = 'org_' + userId;
    const defaultOrg: OrganizationProfile = {
      id: newOrgId,
      name: `${username}'s Enterprise & Job Manager`,
      type: 'Business',
      departmentList: ['Executive', 'Operations', 'Finance', 'Engineering', 'Sales & Marketing', 'General Staff'],
      ownerId: userId,
      ownerUsername: username,
      defaultCurrency: 'LOT',
      createdAt: new Date().toISOString(),
    };

    await setDoc(doc(db, 'job_organizations', newOrgId), cleanFirestoreData(defaultOrg));
    return defaultOrg;
  }

  // ----------------------------------------------------
  // 1. Organization Profile
  // ----------------------------------------------------
  app.get('/api/jobs/organization', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;

      // 1. Check all employments for current user across the entire ecosystem
      const empSnap = await getDocs(collection(db, 'job_employees'));
      const myEmployments: Employee[] = [];
      empSnap.forEach((d) => {
        const emp = d.data() as Employee;
        if (
          emp.userId === current.id ||
          (emp.username && emp.username.toLowerCase() === current.username.toLowerCase())
        ) {
          myEmployments.push(emp);
        }
      });

      // 2. Check if user owns an organization
      const orgsSnap = await getDocs(query(collection(db, 'job_organizations'), where('ownerId', '==', current.id)));
      let ownedOrg: OrganizationProfile | null = null;
      if (!orgsSnap.empty) {
        ownedOrg = orgsSnap.docs[0].data() as OrganizationProfile;
      }

      // Count employees in owned organization
      let ownedOrgEmployeesCount = 0;
      if (ownedOrg) {
        empSnap.forEach((d) => {
          if (d.data().orgId === ownedOrg!.id) ownedOrgEmployeesCount++;
        });
      }

      // Determine active organization to display
      let primaryOrg: OrganizationProfile;
      if (ownedOrg && (ownedOrgEmployeesCount > 0 || myEmployments.length === 0)) {
        primaryOrg = ownedOrg;
      } else if (myEmployments.length > 0) {
        // Fetch employer's organization profile
        const employerOrgSnap = await getDoc(doc(db, 'job_organizations', myEmployments[0].orgId));
        if (employerOrgSnap.exists()) {
          primaryOrg = employerOrgSnap.data() as OrganizationProfile;
        } else {
          primaryOrg = ownedOrg || (await getOrCreateOrg(current.id, current.username));
        }
      } else {
        primaryOrg = ownedOrg || (await getOrCreateOrg(current.id, current.username));
      }

      const isManager = Boolean(
        current.isAdmin ||
        (ownedOrg && (ownedOrgEmployeesCount > 0 || myEmployments.length === 0))
      );

      res.json({
        success: true,
        organization: primaryOrg,
        ownedOrganization: ownedOrg,
        isManager,
        isEmployee: myEmployments.length > 0,
        myEmployments,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to fetch organization' });
    }
  });

  app.post('/api/jobs/organization', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const { name, type, departmentList, defaultCurrency } = req.body;

      const org = await getOrCreateOrg(current.id, current.username);
      if (org.ownerId !== current.id && !current.isAdmin) {
        return res.status(403).json({ error: 'Only authorized managers can update organization profile' });
      }

      const updated = {
        ...org,
        name: (name || org.name).trim().slice(0, 100),
        type: type || org.type,
        departmentList: Array.isArray(departmentList) && departmentList.length > 0 ? departmentList : org.departmentList,
        defaultCurrency: defaultCurrency || org.defaultCurrency,
      };

      await setDoc(doc(db, 'job_organizations', org.id), updated);
      await logAudit(org.id, 'employee_updated', `Updated organization profile: ${updated.name}`, current.id, current.username);

      res.json({ success: true, organization: updated });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to update organization' });
    }
  });

  // ----------------------------------------------------
  // 2. Search LOT Ecosystem Users
  // ----------------------------------------------------
  app.get('/api/jobs/users/search', authMiddleware, async (req: Request, res: Response) => {
    try {
      const q = (req.query.q as string || '').toLowerCase().trim().replace(/^@/, '');
      const usersSnap = await getDocs(collection(db, 'users'));
      const employeesSnap = await getDocs(collection(db, 'job_employees'));

      // Map existing employee userIds and usernames
      const employedUserIds = new Set<string>();
      const employedUsernames = new Set<string>();
      employeesSnap.forEach((d) => {
        const emp = d.data() as Employee;
        if (emp.userId) employedUserIds.add(emp.userId);
        if (emp.username) employedUsernames.add(emp.username.toLowerCase());
      });

      const matched: any[] = [];
      usersSnap.forEach((docSnap) => {
        const u = docSnap.data();
        const username = (u.username || '').toLowerCase();
        const fullName = (u.fullName || '').toLowerCase();
        if (!q || username.includes(q) || fullName.includes(q)) {
          matched.push({
            id: u.id,
            username: u.username,
            fullName: u.fullName || u.username,
            avatarUrl: u.avatarUrl || '',
            lotBalance: u.lotBalance || 0,
            vipBadge: u.vipBadge || null,
            isEmployed: employedUserIds.has(u.id) || employedUsernames.has(username),
          });
        }
      });

      res.json({ success: true, users: matched.slice(0, 30) });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to search users' });
    }
  });

  // Dedicated endpoint to resolve a specific user by username or userId
  app.get('/api/jobs/users/resolve', authMiddleware, async (req: Request, res: Response) => {
    try {
      const usernameQuery = ((req.query.username as string) || '').toLowerCase().trim().replace(/^@/, '');
      const userIdQuery = (req.query.userId as string) || '';

      if (!usernameQuery && !userIdQuery) {
        return res.status(400).json({ error: 'Please provide a username or userId to resolve' });
      }

      const usersSnap = await getDocs(collection(db, 'users'));
      let foundUser: any = null;

      for (const docSnap of usersSnap.docs) {
        const u = docSnap.data();
        const uname = (u.username || '').toLowerCase();
        const unameLower = (u.usernameLower || '').toLowerCase();
        if ((userIdQuery && u.id === userIdQuery) || (usernameQuery && (uname === usernameQuery || unameLower === usernameQuery))) {
          foundUser = {
            id: u.id,
            username: u.username,
            fullName: u.fullName || u.username,
            avatarUrl: u.avatarUrl || '',
            lotBalance: u.lotBalance || 0,
            vipBadge: u.vipBadge || null,
          };
          break;
        }
      }

      if (!foundUser) {
        return res.status(404).json({ error: 'User not found in LOT Ecosystem' });
      }

      res.json({ success: true, user: foundUser });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to resolve user' });
    }
  });

  // ----------------------------------------------------
  // 3. Employee Management (List, Add, Update)
  // ----------------------------------------------------
  app.get('/api/jobs/employees', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const org = await getOrCreateOrg(current.id, current.username);

      const empRef = collection(db, 'job_employees');
      const snap = await getDocs(empRef);

      const allEmployees: Employee[] = [];
      const myEmployments: Employee[] = [];

      snap.forEach((d) => {
        const emp = d.data() as Employee;
        // Check if current user is this employee
        if (
          emp.userId === current.id ||
          (emp.username && emp.username.toLowerCase() === current.username.toLowerCase())
        ) {
          myEmployments.push(emp);
        }
        // Check if this employee belongs to user's owned org
        if (emp.orgId === org.id) {
          allEmployees.push(emp);
        }
      });

      // True manager privilege: owns the organization, is an admin, or has registered employees
      const isManager = Boolean(org.ownerId === current.id || current.isAdmin || allEmployees.length > 0);
      const returnedEmployees = isManager ? allEmployees : myEmployments;

      res.json({
        success: true,
        employees: returnedEmployees,
        myEmployments,
        isManager,
        isEmployee: myEmployments.length > 0,
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to list employees' });
    }
  });

  app.post('/api/jobs/employees', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const org = await getOrCreateOrg(current.id, current.username);

      if (org.ownerId !== current.id && !current.isAdmin) {
        return res.status(403).json({ error: 'Unauthorized: Only managers can add employees.' });
      }

      const {
        userId,
        username,
        avatarUrl,
        fullName,
        email,
        phone,
        employeeIdNumber,
        department,
        jobTitle,
        employmentType,
        customEmploymentType,
        joiningDate,
        salaryFrequency,
        baseSalary,
        currency,
        hourlyRate,
        dailyRate,
        totalLeaveAllowance,
        notes,
        autoPayEnabled,
      } = req.body;

      if ((!fullName || !fullName.trim()) && (!username || !username.trim())) {
        return res.status(400).json({ error: 'Employee name or LOT username is required.' });
      }
      if (!employeeIdNumber || !employeeIdNumber.trim()) {
        return res.status(400).json({ error: 'Employee ID Number is required.' });
      }

      // Check duplicate employee ID within organization
      const dupCheckQ = query(
        collection(db, 'job_employees'),
        where('orgId', '==', org.id),
        where('employeeIdNumber', '==', employeeIdNumber.trim().toUpperCase())
      );
      const dupCheckSnap = await getDocs(dupCheckQ);
      if (!dupCheckSnap.empty) {
        return res.status(400).json({ error: `An employee with ID '${employeeIdNumber.trim().toUpperCase()}' already exists in your organization.` });
      }

      // Automatically search and resolve user from LOT Ecosystem `users` collection
      let resolvedUserId = userId || null;
      let resolvedUsername = username ? username.trim().replace(/^@/, '') : null;
      let resolvedAvatarUrl = avatarUrl || null;
      let resolvedFullName = (fullName || '').trim();

      const candidateLookup = (resolvedUsername || resolvedFullName.replace(/^@/, '')).toLowerCase().trim();

      if (!resolvedUserId && candidateLookup) {
        const usersSnap = await getDocs(collection(db, 'users'));
        for (const uDoc of usersSnap.docs) {
          const uData = uDoc.data();
          const uname = (uData.username || '').toLowerCase();
          const unameLower = (uData.usernameLower || '').toLowerCase();
          if (uname === candidateLookup || unameLower === candidateLookup) {
            resolvedUserId = uDoc.id;
            resolvedUsername = uData.username;
            resolvedAvatarUrl = uData.avatarUrl || resolvedAvatarUrl || null;
            if (!resolvedFullName || resolvedFullName.toLowerCase() === candidateLookup) {
              resolvedFullName = uData.fullName || uData.username;
            }
            break;
          }
        }
      } else if (resolvedUserId) {
        // If userId was provided, ensure username & avatarUrl match
        try {
          const uDoc = await getDoc(doc(db, 'users', resolvedUserId));
          if (uDoc.exists()) {
            const uData = uDoc.data();
            resolvedUsername = uData.username || resolvedUsername;
            resolvedAvatarUrl = uData.avatarUrl || resolvedAvatarUrl;
            if (!resolvedFullName) resolvedFullName = uData.fullName || uData.username;
          }
        } catch {}
      }

      // If linked to LOT user, check duplicate in this org
      if (resolvedUserId) {
        const userDupQ = query(
          collection(db, 'job_employees'),
          where('orgId', '==', org.id),
          where('userId', '==', resolvedUserId)
        );
        const userDupSnap = await getDocs(userDupQ);
        if (!userDupSnap.empty) {
          return res.status(400).json({ error: `@${resolvedUsername} is already an employee in your organization.` });
        }
      }

      const empId = 'emp_' + crypto.randomUUID();
      const now = new Date().toISOString();
      const frequency: SalaryFrequency = salaryFrequency || 'Monthly';

      // Compute initial next expected salary date
      let intervalMs = 30 * 24 * 60 * 60 * 1000; // Monthly
      if (frequency === 'Hourly') intervalMs = 60 * 60 * 1000;
      else if (frequency === 'Daily') intervalMs = 24 * 60 * 60 * 1000;
      else if (frequency === 'Weekly') intervalMs = 7 * 24 * 60 * 60 * 1000;
      else if (frequency === 'Monthly') intervalMs = 30 * 24 * 60 * 60 * 1000;

      const nextExpectedSalaryDate = new Date(Date.now() + intervalMs).toISOString();

      const newEmployee: Employee = {
        id: empId,
        orgId: org.id,
        organizationName: org.name,
        userId: resolvedUserId,
        username: resolvedUsername,
        avatarUrl: resolvedAvatarUrl,
        fullName: resolvedFullName || resolvedUsername || 'Employee',
        email: (email || '').trim(),
        phone: (phone || '').trim(),
        employeeIdNumber: employeeIdNumber.trim().toUpperCase(),
        department: department || 'General Staff',
        jobTitle: jobTitle || 'Staff Member',
        employmentType: employmentType || 'Private Company Employee',
        customEmploymentType: customEmploymentType || '',
        status: 'active',
        joiningDate: joiningDate || now.split('T')[0],
        exitDate: null,
        salaryFrequency: frequency,
        baseSalary: Number(baseSalary) >= 0 ? Number(baseSalary) : 0,
        currency: currency || org.defaultCurrency || 'LOT',
        hourlyRate: Number(hourlyRate) > 0 ? Number(hourlyRate) : undefined,
        dailyRate: Number(dailyRate) > 0 ? Number(dailyRate) : undefined,
        totalLeaveAllowance: Number(totalLeaveAllowance) >= 0 ? Number(totalLeaveAllowance) : 18,
        leaveUsed: 0,
        lastPaidDate: null,
        nextExpectedSalaryDate,
        autoPayEnabled: autoPayEnabled !== false,
        performanceRecords: [],
        promotionHistory: [],
        documents: [],
        managerId: current.id,
        managerUsername: current.username,
        notes: (notes || '').trim(),
        createdAt: now,
        updatedAt: now,
      };

      await setDoc(doc(db, 'job_employees', empId), cleanFirestoreData(newEmployee));
      await logAudit(
        org.id,
        'employee_created',
        `Added employee ${newEmployee.fullName} (${newEmployee.employeeIdNumber}) as ${newEmployee.jobTitle} with ${newEmployee.salaryFrequency} pay schedule`,
        current.id,
        current.username,
        empId,
        newEmployee.fullName
      );

      // Send in-app notification to linked LOT user
      if (resolvedUserId) {
        const notifId = 'notif_' + crypto.randomUUID();
        setDoc(doc(db, 'notifications', notifId), {
          id: notifId,
          userId: resolvedUserId,
          title: 'Employment Record Created',
          message: `You were enrolled as ${newEmployee.jobTitle} at ${org.name} with ${newEmployee.salaryFrequency} salary of ${newEmployee.baseSalary.toLocaleString()} ${newEmployee.currency}.`,
          type: 'job',
          read: false,
          createdAt: now,
        }).catch(() => {});

        if (sendToUser) {
          sendToUser(resolvedUserId, 'job:enrolled', {
            employee: newEmployee,
            organization: org,
          });
        }
      }

      res.json({ success: true, employee: newEmployee });
    } catch (err: any) {
      console.error('[Job Manager] Add employee error:', err);
      res.status(500).json({ error: err.message || 'Failed to add employee' });
    }
  });

  app.put('/api/jobs/employees/:id', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const { id } = req.params;
      const empRef = doc(db, 'job_employees', id);
      const snap = await getDoc(empRef);

      if (!snap.exists()) {
        return res.status(404).json({ error: 'Employee not found' });
      }

      const emp = snap.data() as Employee;
      const org = await getOrCreateOrg(current.id, current.username);

      if (emp.orgId !== org.id || (org.ownerId !== current.id && !current.isAdmin)) {
        return res.status(403).json({ error: 'Unauthorized to update this employee' });
      }

      const updates = req.body;
      const now = new Date().toISOString();

      // Track salary change in audit history if revised
      if (updates.baseSalary !== undefined && updates.baseSalary !== emp.baseSalary) {
        const oldSal = emp.baseSalary;
        const newSal = Number(updates.baseSalary) || 0;
        await logAudit(
          org.id,
          'salary_changed',
          `Salary for ${emp.fullName} changed from ${oldSal} to ${newSal} ${emp.currency}`,
          current.id,
          current.username,
          emp.id,
          emp.fullName
        );
      }

      // Track status changes
      if (updates.status && updates.status !== emp.status) {
        await logAudit(
          org.id,
          'status_changed',
          `Employment status for ${emp.fullName} changed from ${emp.status} to ${updates.status}`,
          current.id,
          current.username,
          emp.id,
          emp.fullName
        );
      }

      const updatedEmployee: Employee = {
        ...emp,
        ...updates,
        updatedAt: now,
      };

      await updateDoc(empRef, cleanFirestoreData(updatedEmployee));
      res.json({ success: true, employee: updatedEmployee });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to update employee' });
    }
  });

  // ----------------------------------------------------
  // 4. Performance & Promotions
  // ----------------------------------------------------
  app.post('/api/jobs/employees/:id/performance', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const { id } = req.params;
      const { rating, reviewTitle, notes } = req.body;

      const empRef = doc(db, 'job_employees', id);
      const snap = await getDoc(empRef);
      if (!snap.exists()) return res.status(404).json({ error: 'Employee not found' });

      const emp = snap.data() as Employee;
      const newReview = {
        id: 'perf_' + crypto.randomUUID(),
        date: new Date().toISOString().split('T')[0],
        rating: Math.min(5, Math.max(1, Number(rating) || 5)),
        reviewTitle: (reviewTitle || 'Performance Review').trim(),
        notes: (notes || '').trim(),
        reviewedBy: `@${current.username}`,
      };

      const updatedRecords = [...(emp.performanceRecords || []), newReview];
      await updateDoc(empRef, cleanFirestoreData({ performanceRecords: updatedRecords, updatedAt: new Date().toISOString() }));

      res.json({ success: true, record: newReview });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to add performance review' });
    }
  });

  app.post('/api/jobs/employees/:id/promotion', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const { id } = req.params;
      const { newTitle, newSalary, notes } = req.body;

      const empRef = doc(db, 'job_employees', id);
      const snap = await getDoc(empRef);
      if (!snap.exists()) return res.status(404).json({ error: 'Employee not found' });

      const emp = snap.data() as Employee;
      const promotion = {
        id: 'promo_' + crypto.randomUUID(),
        date: new Date().toISOString().split('T')[0],
        previousTitle: emp.jobTitle,
        newTitle: (newTitle || emp.jobTitle).trim(),
        previousSalary: emp.baseSalary,
        newSalary: Number(newSalary) >= 0 ? Number(newSalary) : emp.baseSalary,
        notes: (notes || '').trim(),
        authorizedBy: `@${current.username}`,
      };

      const history = [...(emp.promotionHistory || []), promotion];
      await updateDoc(empRef, cleanFirestoreData({
        jobTitle: promotion.newTitle,
        baseSalary: promotion.newSalary,
        promotionHistory: history,
        updatedAt: new Date().toISOString(),
      }));

      await logAudit(
        emp.orgId,
        'salary_changed',
        `Promotion & Salary Revision for ${emp.fullName}: Promoted to ${promotion.newTitle} with salary ${promotion.newSalary} ${emp.currency}`,
        current.id,
        current.username,
        emp.id,
        emp.fullName
      );

      res.json({ success: true, promotion });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to record promotion' });
    }
  });

  // ----------------------------------------------------
  // 5. Contracts & Documents
  // ----------------------------------------------------
  app.post('/api/jobs/employees/:id/documents', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const { id } = req.params;
      const { title, type, fileUrl, fileName, fileSize } = req.body;

      if (!fileUrl) return res.status(400).json({ error: 'fileUrl is required' });

      const empRef = doc(db, 'job_employees', id);
      const snap = await getDoc(empRef);
      if (!snap.exists()) return res.status(404).json({ error: 'Employee not found' });

      const emp = snap.data() as Employee;
      const docItem = {
        id: 'doc_' + crypto.randomUUID(),
        title: (title || 'Employee Document').trim(),
        type: type || 'contract',
        fileUrl,
        fileName: fileName || 'document.pdf',
        fileSize: Number(fileSize) || 0,
        uploadedAt: new Date().toISOString(),
        uploadedBy: `@${current.username}`,
      };

      const updatedDocs = [...(emp.documents || []), docItem];
      await updateDoc(empRef, cleanFirestoreData({ documents: updatedDocs, updatedAt: new Date().toISOString() }));
      await logAudit(
        emp.orgId,
        'document_uploaded',
        `Uploaded document '${docItem.title}' for ${emp.fullName}`,
        current.id,
        current.username,
        emp.id,
        emp.fullName
      );

      res.json({ success: true, document: docItem });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to attach document' });
    }
  });

  // ----------------------------------------------------
  // 6. Salary Calculation & Payment Management
  // ----------------------------------------------------
  app.post('/api/jobs/payments/calculate', authMiddleware, async (req: Request, res: Response) => {
    try {
      const { employeeId, salaryPeriod, hoursWorked, daysWorked, adjustments } = req.body;
      const empSnap = await getDoc(doc(db, 'job_employees', employeeId));
      if (!empSnap.exists()) return res.status(404).json({ error: 'Employee not found' });

      const emp = empSnap.data() as Employee;
      let calculatedBase = emp.baseSalary;

      if (emp.salaryFrequency === 'Hourly' && Number(hoursWorked) > 0) {
        calculatedBase = Number(hoursWorked) * (emp.hourlyRate || emp.baseSalary);
      } else if (emp.salaryFrequency === 'Daily' && Number(daysWorked) > 0) {
        calculatedBase = Number(daysWorked) * (emp.dailyRate || emp.baseSalary);
      }

      let bonusTotal = 0;
      let deductionTotal = 0;

      if (Array.isArray(adjustments)) {
        adjustments.forEach((adj: any) => {
          const amt = Number(adj.amount) || 0;
          if (['bonus', 'commission', 'overtime', 'reward'].includes(adj.type)) {
            bonusTotal += Math.abs(amt);
          } else {
            deductionTotal += Math.abs(amt);
          }
        });
      }

      const netPayable = Math.max(0, calculatedBase + bonusTotal - deductionTotal);

      res.json({
        success: true,
        baseAmount: calculatedBase,
        totalBonus: bonusTotal,
        totalDeductions: deductionTotal,
        netPayableAmount: netPayable,
        currency: emp.currency,
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Calculation failed' });
    }
  });

  app.get('/api/jobs/payments', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const org = await getOrCreateOrg(current.id, current.username);
      const employeeId = req.query.employeeId as string;

      // Find all employee records for current user
      const empSnap = await getDocs(collection(db, 'job_employees'));
      const myEmpIds = new Set<string>();
      empSnap.forEach((d) => {
        const emp = d.data() as Employee;
        if (
          emp.userId === current.id ||
          (emp.username && emp.username.toLowerCase() === current.username.toLowerCase())
        ) {
          myEmpIds.add(emp.id);
        }
      });

      const paymentsRef = collection(db, 'job_payments');
      const snap = await getDocs(paymentsRef);

      const list: SalaryPayment[] = [];
      const seen = new Set<string>();

      snap.forEach((d) => {
        const p = d.data() as SalaryPayment;
        if (seen.has(p.id)) return;

        const isManager = p.orgId === org.id || current.isAdmin;
        const isMyPayment = myEmpIds.has(p.employeeId);

        if (isManager || isMyPayment) {
          if (!employeeId || p.employeeId === employeeId) {
            list.push(p);
            seen.add(p.id);
          }
        }
      });

      // Sort descending by creation date
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      res.json({ success: true, payments: list });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch payments' });
    }
  });

  app.post('/api/jobs/payments', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const org = await getOrCreateOrg(current.id, current.username);

      const {
        employeeId,
        salaryPeriod,
        baseAmount,
        hoursWorked,
        daysWorked,
        adjustments,
        totalBonus,
        totalDeductions,
        netPayableAmount,
        paidAmount,
        paymentStatus,
        paymentMethod,
        transactionReference,
        notes,
        nextExpectedSalaryDate,
      } = req.body;

      const empSnap = await getDoc(doc(db, 'job_employees', employeeId));
      if (!empSnap.exists()) return res.status(404).json({ error: 'Employee not found' });
      const emp = empSnap.data() as Employee;

      // Ensure user is authorized to pay this employee
      if (emp.orgId !== org.id && !current.isAdmin) {
        const targetOrgSnap = await getDoc(doc(db, 'job_organizations', emp.orgId));
        if (!targetOrgSnap.exists() || targetOrgSnap.data().ownerId !== current.id) {
          return res.status(403).json({ error: 'Unauthorized: Only managers of this organization can process salary payments.' });
        }
      }

      const paymentId = 'pay_' + crypto.randomUUID();
      const now = new Date().toISOString();

      const payment: SalaryPayment = {
        id: paymentId,
        employeeId: emp.id,
        employeeName: emp.fullName,
        employeeIdNumber: emp.employeeIdNumber,
        department: emp.department,
        jobTitle: emp.jobTitle,
        orgId: emp.orgId || org.id,
        organizationName: emp.organizationName || org.name,
        salaryPeriod: (salaryPeriod || 'Current Period').trim(),
        salaryFrequency: emp.salaryFrequency,
        baseAmount: Number(baseAmount) || emp.baseSalary,
        totalHoursWorked: Number(hoursWorked) || undefined,
        totalDaysWorked: Number(daysWorked) || undefined,
        adjustments: Array.isArray(adjustments) ? adjustments : [],
        totalBonus: Number(totalBonus) || 0,
        totalDeductions: Number(totalDeductions) || 0,
        netPayableAmount: Number(netPayableAmount) || 0,
        paidAmount: Number(paidAmount) || 0,
        paymentStatus: paymentStatus || 'paid',
        paymentDate: paymentStatus === 'paid' ? now.split('T')[0] : null,
        nextExpectedSalaryDate: nextExpectedSalaryDate || '',
        paymentMethod: paymentMethod || 'LOT Ecosystem Transfer',
        transactionReference: transactionReference || `TX-SAL-${Date.now().toString(36).toUpperCase()}`,
        currency: emp.currency || 'LOT',
        notes: (notes || '').trim(),
        recordedBy: current.id,
        recordedByUsername: current.username,
        slipGenerated: true,
        createdAt: now,
        updatedAt: now,
      };

      await setDoc(doc(db, 'job_payments', paymentId), cleanFirestoreData(payment));
      await logAudit(
        emp.orgId || org.id,
        'payment_recorded',
        `Recorded salary payment for ${emp.fullName}: ${payment.netPayableAmount} ${payment.currency} for period '${payment.salaryPeriod}' (${payment.paymentStatus})`,
        current.id,
        current.username,
        emp.id,
        emp.fullName
      );

      // Real LOT Currency Crediting when paid in LOT to a linked LOT user
      const amountToCredit = Number(paidAmount) || Number(netPayableAmount) || 0;
      if (payment.paymentStatus === 'paid' && amountToCredit > 0 && emp.userId) {
        try {
          const userDocRef = doc(db, 'users', emp.userId);
          const userDocSnap = await getDoc(userDocRef);
          if (userDocSnap.exists()) {
            const currentBal = Number(userDocSnap.data()?.lotBalance) || 0;
            const newBal = currentBal + amountToCredit;
            await updateDoc(userDocRef, { lotBalance: newBal });

            // Send real-time balance update if connected
            if (sendToUser) {
              sendToUser(emp.userId, 'wallet:balance_update', { lotBalance: newBal });
              sendToUser(emp.userId, 'balance:update', { lotBalance: newBal });
            }

            // Record transaction in transactions collection
            const txId = 'tx_sal_' + crypto.randomUUID();
            await setDoc(doc(db, 'transactions', txId), {
              id: txId,
              senderId: current.id,
              senderUsername: org.name,
              recipientId: emp.userId,
              recipientUsername: emp.username || emp.fullName,
              amount: amountToCredit,
              type: 'salary',
              description: `Salary for ${payment.salaryPeriod} (${emp.jobTitle})`,
              timestamp: now,
              createdAt: now,
            }).catch(() => {});
          }
        } catch (credErr) {
          console.warn('[Job Manager] Wallet credit warning:', credErr);
        }
      }

      // In-app notification to linked employee
      if (emp.userId) {
        const notifId = 'notif_' + crypto.randomUUID();
        setDoc(doc(db, 'notifications', notifId), {
          id: notifId,
          userId: emp.userId,
          title: `Salary ${payment.paymentStatus === 'paid' ? 'Paid' : 'Processed'}`,
          message: `Your salary for ${payment.salaryPeriod} (${payment.netPayableAmount} ${payment.currency}) has been recorded.`,
          type: 'job',
          read: false,
          createdAt: now,
        }).catch(() => {});
      }

      res.json({ success: true, payment });
    } catch (err: any) {
      console.error('[Job Manager] Record payment error:', err);
      res.status(500).json({ error: err.message || 'Failed to record salary payment' });
    }
  });

  // Correct a payment record
  app.put('/api/jobs/payments/:id', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const { id } = req.params;
      const { correctionReason, adminAuditNote, notes: reqNotes, paidAmount, paymentStatus, paymentMethod, transactionReference } = req.body;

      const effectiveReason = (correctionReason || adminAuditNote || reqNotes || 'Status updated').trim();
      if (!effectiveReason) {
        return res.status(400).json({ error: 'Correction reason or audit note is required' });
      }

      const payRef = doc(db, 'job_payments', id);
      const snap = await getDoc(payRef);
      if (!snap.exists()) return res.status(404).json({ error: 'Payment not found' });

      const pay = snap.data() as SalaryPayment;
      const now = new Date().toISOString();

      const updated = {
        ...pay,
        paidAmount: Number(paidAmount) >= 0 ? Number(paidAmount) : pay.paidAmount,
        paymentStatus: paymentStatus || pay.paymentStatus,
        paymentMethod: paymentMethod || pay.paymentMethod,
        transactionReference: transactionReference || pay.transactionReference,
        notes: `${pay.notes ? pay.notes + ' | ' : ''}Correction by @${current.username}: ${effectiveReason}`,
        updatedAt: now,
      };

      await updateDoc(payRef, cleanFirestoreData(updated));
      await logAudit(
        pay.orgId,
        'payment_corrected',
        `Payment ${id} corrected for ${pay.employeeName}. Reason: ${effectiveReason}`,
        current.id,
        current.username,
        pay.employeeId,
        pay.employeeName
      );

      res.json({ success: true, payment: updated });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to correct payment' });
    }
  });

  // ----------------------------------------------------
  // 7. Attendance Tracking
  // ----------------------------------------------------
  app.get('/api/jobs/attendance', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const org = await getOrCreateOrg(current.id, current.username);
      const employeeId = req.query.employeeId as string;
      const month = req.query.month as string; // YYYY-MM

      // Find user's employee IDs
      const empSnap = await getDocs(collection(db, 'job_employees'));
      const myEmpIds = new Set<string>();
      empSnap.forEach((d) => {
        const emp = d.data() as Employee;
        if (
          emp.userId === current.id ||
          (emp.username && emp.username.toLowerCase() === current.username.toLowerCase())
        ) {
          myEmpIds.add(emp.id);
        }
      });

      const attRef = collection(db, 'job_attendance');
      const snap = await getDocs(attRef);

      const records: AttendanceRecord[] = [];
      snap.forEach((d) => {
        const rec = d.data() as AttendanceRecord;
        const isManager = rec.orgId === org.id || current.isAdmin;
        const isMyAttendance = myEmpIds.has(rec.employeeId);

        if (isManager || isMyAttendance) {
          if (!employeeId || rec.employeeId === employeeId) {
            if (!month || rec.date.startsWith(month)) {
              records.push(rec);
            }
          }
        }
      });

      records.sort((a, b) => b.date.localeCompare(a.date));
      res.json({ success: true, attendance: records, records: records });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch attendance' });
    }
  });

  app.post('/api/jobs/attendance', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const org = await getOrCreateOrg(current.id, current.username);

      const { employeeId, date, status, checkInTime, checkOutTime, hoursWorked, overtimeHours, notes } = req.body;
      if (!employeeId || !date) {
        return res.status(400).json({ error: 'Employee and date are required' });
      }

      const empSnap = await getDoc(doc(db, 'job_employees', employeeId));
      if (!empSnap.exists()) return res.status(404).json({ error: 'Employee not found' });
      const emp = empSnap.data() as Employee;

      // Unique record ID per employee per date
      const recordId = `att_${employeeId}_${date.replace(/-/g, '')}`;
      const rec: AttendanceRecord = {
        id: recordId,
        employeeId: emp.id,
        employeeName: emp.fullName,
        orgId: emp.orgId || org.id,
        date,
        status: status || 'present',
        checkInTime: checkInTime || '09:00',
        checkOutTime: checkOutTime || '17:00',
        hoursWorked: Number(hoursWorked) >= 0 ? Number(hoursWorked) : status === 'present' ? 8 : 0,
        overtimeHours: Number(overtimeHours) >= 0 ? Number(overtimeHours) : 0,
        notes: (notes || '').trim(),
        markedBy: `@${current.username}`,
        createdAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'job_attendance', recordId), cleanFirestoreData(rec));
      res.json({ success: true, record: rec });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to record attendance' });
    }
  });

  // ----------------------------------------------------
  // 8. Leave Requests
  // ----------------------------------------------------
  app.get('/api/jobs/leaves', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const org = await getOrCreateOrg(current.id, current.username);

      // Find user's employee IDs
      const empSnap = await getDocs(collection(db, 'job_employees'));
      const myEmpIds = new Set<string>();
      empSnap.forEach((d) => {
        const emp = d.data() as Employee;
        if (
          emp.userId === current.id ||
          (emp.username && emp.username.toLowerCase() === current.username.toLowerCase())
        ) {
          myEmpIds.add(emp.id);
        }
      });

      const leavesRef = collection(db, 'job_leaves');
      const snap = await getDocs(leavesRef);

      const list: LeaveRequest[] = [];
      const seen = new Set<string>();

      snap.forEach((d) => {
        const lr = d.data() as LeaveRequest;
        if (seen.has(lr.id)) return;

        const isManager = lr.orgId === org.id || current.isAdmin;
        const isMyLeave = myEmpIds.has(lr.employeeId) || lr.userId === current.id;

        if (isManager || isMyLeave) {
          list.push(lr);
          seen.add(lr.id);
        }
      });

      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      res.json({ success: true, leaves: list });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch leave requests' });
    }
  });

  app.post('/api/jobs/leaves', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const { employeeId, leaveType, startDate, endDate, daysCount, reason } = req.body;

      const empSnap = await getDoc(doc(db, 'job_employees', employeeId));
      if (!empSnap.exists()) return res.status(404).json({ error: 'Employee not found' });
      const emp = empSnap.data() as Employee;

      // Allow if user is the employee themselves OR manager of employee's org OR admin
      const isSelf = emp.userId === current.id || (emp.username && emp.username.toLowerCase() === current.username.toLowerCase());
      const org = await getOrCreateOrg(current.id, current.username);
      const isOrgManager = emp.orgId === org.id || current.isAdmin;

      if (!isSelf && !isOrgManager) {
        return res.status(403).json({ error: 'Unauthorized: You can only submit leave requests for yourself or your organization employees.' });
      }

      const leaveId = 'leave_' + crypto.randomUUID();
      const newLeave: LeaveRequest = {
        id: leaveId,
        employeeId: emp.id,
        employeeName: emp.fullName,
        employeeIdNumber: emp.employeeIdNumber,
        userId: emp.userId || current.id,
        orgId: emp.orgId,
        leaveType: leaveType || 'Casual Leave',
        startDate,
        endDate,
        daysCount: Number(daysCount) || 1,
        reason: (reason || '').trim(),
        status: 'pending',
        createdAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'job_leaves', leaveId), cleanFirestoreData(newLeave));

      // Notify org owner if submitted by employee
      const orgDoc = await getDoc(doc(db, 'job_organizations', emp.orgId));
      if (orgDoc.exists() && orgDoc.data().ownerId !== current.id) {
        const notifId = 'notif_' + crypto.randomUUID();
        setDoc(doc(db, 'notifications', notifId), {
          id: notifId,
          userId: orgDoc.data().ownerId,
          title: 'New Leave Request Submitted',
          message: `${emp.fullName} (@${current.username}) submitted a leave request for ${newLeave.daysCount} day(s).`,
          type: 'job',
          read: false,
          createdAt: new Date().toISOString(),
        }).catch(() => {});
      }

      res.json({ success: true, leave: newLeave });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to submit leave request' });
    }
  });

  // Support both /api/jobs/leaves/:id and /api/jobs/leaves/:id/review
  const handleLeaveReview = async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const { id } = req.params;
      const { status, reviewNotes, rejectionReason } = req.body; // status: 'approved' | 'rejected'

      const leaveRef = doc(db, 'job_leaves', id);
      const snap = await getDoc(leaveRef);
      if (!snap.exists()) return res.status(404).json({ error: 'Leave request not found' });

      const leave = snap.data() as LeaveRequest;
      const now = new Date().toISOString();
      const note = (reviewNotes || rejectionReason || '').trim();

      await updateDoc(leaveRef, cleanFirestoreData({
        status,
        reviewNotes: note,
        reviewedBy: `@${current.username}`,
        reviewedAt: now,
      }));

      // If approved, update employee leave balance
      if (status === 'approved') {
        const empRef = doc(db, 'job_employees', leave.employeeId);
        const empSnap = await getDoc(empRef);
        if (empSnap.exists()) {
          const emp = empSnap.data() as Employee;
          await updateDoc(empRef, cleanFirestoreData({
            leaveUsed: (emp.leaveUsed || 0) + leave.daysCount,
            updatedAt: now,
          }));
        }
      }

      await logAudit(
        leave.orgId,
        'leave_reviewed',
        `${status === 'approved' ? 'Approved' : 'Rejected'} ${leave.daysCount} days ${leave.leaveType} for ${leave.employeeName}`,
        current.id,
        current.username,
        leave.employeeId,
        leave.employeeName
      );

      // In-app notification to employee
      if (leave.userId) {
        const notifId = 'notif_' + crypto.randomUUID();
        setDoc(doc(db, 'notifications', notifId), {
          id: notifId,
          userId: leave.userId,
          title: `Leave Request ${status === 'approved' ? 'Approved' : 'Rejected'}`,
          message: `Your request for ${leave.daysCount} days (${leave.startDate} to ${leave.endDate}) was ${status}.`,
          type: 'job',
          read: false,
          createdAt: now,
        }).catch(() => {});
      }

      res.json({ success: true, status });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to review leave request' });
    }
  };

  app.put('/api/jobs/leaves/:id', authMiddleware, handleLeaveReview);
  app.put('/api/jobs/leaves/:id/review', authMiddleware, handleLeaveReview);

  // ----------------------------------------------------
  // 9. Dashboard Analytics & Reports
  // ----------------------------------------------------
  app.get('/api/jobs/reports', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const org = await getOrCreateOrg(current.id, current.username);

      const [empSnap, paySnap] = await Promise.all([
        getDocs(collection(db, 'job_employees')),
        getDocs(collection(db, 'job_payments')),
      ]);

      const orgEmployees: Employee[] = [];
      empSnap.forEach((d) => {
        const e = d.data() as Employee;
        if (e.orgId === org.id) orgEmployees.push(e);
      });

      const orgPayments: SalaryPayment[] = [];
      paySnap.forEach((d) => {
        const p = d.data() as SalaryPayment;
        if (p.orgId === org.id) orgPayments.push(p);
      });

      const totalEmployees = orgEmployees.length;
      const activeEmployees = orgEmployees.filter((e) => e.status === 'active').length;

      // Expected monthly salary expense
      const totalExpectedSalary = orgEmployees.reduce((sum, e) => {
        let monthlyEquiv = e.baseSalary;
        if (e.salaryFrequency === 'Weekly') monthlyEquiv = e.baseSalary * 4.33;
        if (e.salaryFrequency === 'Daily') monthlyEquiv = e.baseSalary * 22;
        if (e.salaryFrequency === 'Hourly') monthlyEquiv = (e.hourlyRate || e.baseSalary) * 160;
        return sum + monthlyEquiv;
      }, 0);

      const totalPaid = orgPayments
        .filter((p) => p.paymentStatus === 'paid')
        .reduce((sum, p) => sum + (p.paidAmount || p.netPayableAmount), 0);

      const totalPending = orgPayments
        .filter((p) => p.paymentStatus === 'pending' || p.paymentStatus === 'partially_paid')
        .reduce((sum, p) => sum + (p.netPayableAmount - (p.paidAmount || 0)), 0);

      const totalOverdue = orgPayments
        .filter((p) => p.paymentStatus === 'overdue')
        .reduce((sum, p) => sum + (p.netPayableAmount - (p.paidAmount || 0)), 0);

      // Breakdown by department
      const departmentBreakdown: Record<string, { count: number; salary: number }> = {};
      orgEmployees.forEach((e) => {
        const d = e.department || 'Unassigned';
        if (!departmentBreakdown[d]) departmentBreakdown[d] = { count: 0, salary: 0 };
        departmentBreakdown[d].count += 1;
        departmentBreakdown[d].salary += e.baseSalary;
      });

      // Breakdown by employment type
      const employmentTypeBreakdown: Record<string, number> = {};
      orgEmployees.forEach((e) => {
        const t = e.employmentType || 'Private Company Employee';
        employmentTypeBreakdown[t] = (employmentTypeBreakdown[t] || 0) + 1;
      });

      res.json({
        success: true,
        metrics: {
          totalEmployees,
          activeEmployees,
          totalExpectedSalary,
          totalPaid,
          totalPending,
          totalOverdue,
          currency: org.defaultCurrency,
          departmentBreakdown,
          employmentTypeBreakdown,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to generate reports' });
    }
  });

  // ----------------------------------------------------
  // 10. Audit Logs
  // ----------------------------------------------------
  app.get('/api/jobs/audit-logs', authMiddleware, async (req: Request, res: Response) => {
    try {
      const current = (req as any).user;
      const org = await getOrCreateOrg(current.id, current.username);

      const snap = await getDocs(collection(db, 'job_audit_logs'));
      const logs: JobAuditLog[] = [];
      snap.forEach((d) => {
        const log = d.data() as JobAuditLog;
        if (log.orgId === org.id) logs.push(log);
      });

      logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      res.json({ success: true, logs: logs.slice(0, 100) });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to fetch audit logs' });
    }
  });

  // ----------------------------------------------------
  // 11. Automated Recurring Payroll Engine
  // ----------------------------------------------------
  async function executeAutoPayroll() {
    try {
      const employeesSnap = await getDocs(collection(db, 'job_employees'));
      const now = Date.now();
      const nowIso = new Date().toISOString();
      let processedCount = 0;
      let totalDisbursed = 0;
      const disbursements: any[] = [];

      for (const empDoc of employeesSnap.docs) {
        const emp = empDoc.data() as Employee;
        if (emp.status !== 'active') continue;
        if (emp.autoPayEnabled === false) continue;

        // Determine pay schedule interval
        let intervalMs = 30 * 24 * 60 * 60 * 1000; // Monthly (30 days)
        if (emp.salaryFrequency === 'Hourly') intervalMs = 60 * 60 * 1000; // 1 hour
        else if (emp.salaryFrequency === 'Daily') intervalMs = 24 * 60 * 60 * 1000; // 24 hours
        else if (emp.salaryFrequency === 'Weekly') intervalMs = 7 * 24 * 60 * 60 * 1000; // 7 days
        else if (emp.salaryFrequency === 'Monthly') intervalMs = 30 * 24 * 60 * 60 * 1000; // 30 days

        let isDue = false;
        if (emp.nextExpectedSalaryDate) {
          isDue = new Date(emp.nextExpectedSalaryDate).getTime() <= now;
        } else if (emp.lastPaidDate) {
          isDue = now - new Date(emp.lastPaidDate).getTime() >= intervalMs;
        } else {
          // If never paid, check if interval has elapsed since enrollment or joining
          const baseline = new Date(emp.createdAt || emp.joiningDate || nowIso).getTime();
          isDue = now - baseline >= intervalMs;
        }

        if (!isDue) continue;

        // Calculate pay amount based on frequency and rates
        let payAmount = Number(emp.baseSalary) || 0;
        if (emp.salaryFrequency === 'Hourly' && (Number(emp.hourlyRate) || 0) > 0) {
          payAmount = Number(emp.hourlyRate);
        } else if (emp.salaryFrequency === 'Daily' && (Number(emp.dailyRate) || 0) > 0) {
          payAmount = Number(emp.dailyRate);
        }

        if (payAmount <= 0) continue;

        const nextExpectedDate = new Date(now + intervalMs).toISOString();
        const paymentId = 'pay_auto_' + crypto.randomUUID();
        const periodStr = `Auto-Pay [${emp.salaryFrequency}] ${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;

        const payment: SalaryPayment = {
          id: paymentId,
          employeeId: emp.id,
          employeeName: emp.fullName,
          employeeIdNumber: emp.employeeIdNumber,
          department: emp.department,
          jobTitle: emp.jobTitle,
          orgId: emp.orgId,
          organizationName: emp.organizationName,
          salaryPeriod: periodStr,
          salaryFrequency: emp.salaryFrequency,
          baseAmount: payAmount,
          adjustments: [],
          totalBonus: 0,
          totalDeductions: 0,
          netPayableAmount: payAmount,
          paidAmount: payAmount,
          paymentStatus: 'paid',
          paymentDate: nowIso.split('T')[0],
          nextExpectedSalaryDate: nextExpectedDate,
          paymentMethod: 'LOT Ecosystem Transfer',
          transactionReference: `AUTO-SAL-${Date.now().toString(36).toUpperCase()}`,
          currency: emp.currency || 'LOT',
          notes: `Automated scheduled recurring salary disbursement according to ${emp.salaryFrequency} payroll frequency.`,
          recordedBy: 'system_autopay',
          recordedByUsername: 'LOT Automated Recurring Payroll Engine',
          slipGenerated: true,
          createdAt: nowIso,
          updatedAt: nowIso,
        };

        await setDoc(doc(db, 'job_payments', paymentId), cleanFirestoreData(payment));

        // Update employee lastPaidDate and nextExpectedSalaryDate
        await updateDoc(doc(db, 'job_employees', emp.id), cleanFirestoreData({
          lastPaidDate: nowIso,
          nextExpectedSalaryDate: nextExpectedDate,
          updatedAt: nowIso,
        }));

        // If linked to LOT user, credit real LOT balance and write ledger transaction
        if (emp.userId) {
          try {
            const userRef = doc(db, 'users', emp.userId);
            const userSnap = await getDoc(userRef);
            if (userSnap.exists()) {
              const currentBal = Number(userSnap.data().lotBalance) || 0;
              const newBal = currentBal + payAmount;
              await updateDoc(userRef, { lotBalance: newBal });

              if (sendToUser) {
                sendToUser(emp.userId, 'wallet:balance_update', { lotBalance: newBal });
                sendToUser(emp.userId, 'balance:update', { lotBalance: newBal });
                sendToUser(emp.userId, 'job:salary_paid', { payment, newBalance: newBal });
              }

              // Ledger transaction
              const txId = 'tx_sal_' + crypto.randomUUID();
              await setDoc(doc(db, 'transactions', txId), {
                id: txId,
                senderId: emp.orgId,
                senderUsername: emp.organizationName,
                recipientId: emp.userId,
                recipientUsername: emp.username || emp.fullName,
                amount: payAmount,
                type: 'salary',
                description: `Automated ${emp.salaryFrequency} salary for ${emp.jobTitle}`,
                timestamp: nowIso,
                createdAt: nowIso,
              }).catch(() => {});
            }
          } catch (credErr) {
            console.warn('[Auto-Payroll] Error crediting wallet:', credErr);
          }

          // In-app notification
          const notifId = 'notif_' + crypto.randomUUID();
          setDoc(doc(db, 'notifications', notifId), {
            id: notifId,
            userId: emp.userId,
            title: `Salary Automatically Paid (+${payAmount.toLocaleString()} ${emp.currency || 'LOT'})`,
            message: `Your ${emp.salaryFrequency} salary of ${payAmount.toLocaleString()} ${emp.currency || 'LOT'} has been automatically paid and deposited into your LOT wallet by ${emp.organizationName}.`,
            type: 'job',
            read: false,
            createdAt: nowIso,
          }).catch(() => {});
        }

        await logAudit(
          emp.orgId,
          'payment_recorded',
          `Automated recurring salary paid to ${emp.fullName}: ${payAmount} ${emp.currency || 'LOT'} for ${emp.salaryFrequency} schedule`,
          'system_autopay',
          'LOT Automated Payroll Engine',
          emp.id,
          emp.fullName
        );

        processedCount++;
        totalDisbursed += payAmount;
        disbursements.push({
          employeeId: emp.id,
          employeeName: emp.fullName,
          amount: payAmount,
          currency: emp.currency || 'LOT',
          salaryFrequency: emp.salaryFrequency,
          nextExpectedSalaryDate: nextExpectedDate,
        });
      }

      if (processedCount > 0) {
        console.log(`[Auto-Payroll] Successfully executed recurring payroll for ${processedCount} employee(s), total: ${totalDisbursed} LOT.`);
      }

      return { success: true, processedCount, totalDisbursed, disbursements };
    } catch (err: any) {
      console.error('[Auto-Payroll] Execution error:', err);
      return { success: false, error: err.message || 'Auto-payroll execution error' };
    }
  }

  // Route to trigger or test auto-payroll on demand
  app.post('/api/jobs/payroll/run-auto', authMiddleware, async (req: Request, res: Response) => {
    try {
      const result = await executeAutoPayroll();
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to run auto-payroll' });
    }
  });

  // Background recurring scheduler: runs every 60 seconds (with initial run after 3s)
  setTimeout(() => {
    executeAutoPayroll().catch(() => {});
  }, 3000);

  setInterval(() => {
    executeAutoPayroll().catch(() => {});
  }, 60000);
}

