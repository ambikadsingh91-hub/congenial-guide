import fs from 'fs';
import path from 'path';

const CACHE_DIR = path.join(process.cwd(), 'data');
if (!fs.existsSync(CACHE_DIR)) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

export function readCacheFile<T>(filename: string, defaultValue: T): T {
  try {
    const filePath = path.join(CACHE_DIR, filename);
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(content) as T;
    }
  } catch (err) {
    console.warn(`Failed reading cache ${filename}:`, err);
  }
  return defaultValue;
}

export function writeCacheFile<T>(filename: string, data: T): void {
  try {
    const filePath = path.join(CACHE_DIR, filename);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.warn(`Failed writing cache ${filename}:`, err);
  }
}

/**
 * Executes a Firestore operation with an automatic timeout guard.
 * If the operation throws an error (e.g. Quota limit exceeded) or times out,
 * it returns the fallback value instead of hanging or crashing requests.
 */
export async function withFirestoreTimeout<T>(
  promiseOrFn: Promise<T> | (() => Promise<T>),
  fallback: T,
  timeoutMs = 1500
): Promise<T> {
  try {
    const p = typeof promiseOrFn === 'function' ? promiseOrFn() : promiseOrFn;
    return await Promise.race([
      p,
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('FIRESTORE_TIMEOUT')), timeoutMs)
      ),
    ]);
  } catch (err: any) {
    const msg = err?.message || String(err);
    if (msg.includes('Quota') || msg.includes('quota') || msg.includes('TIMEOUT')) {
      console.warn(`[Firestore Offline/Quota Fallback]: ${msg}`);
    } else {
      console.warn(`[Firestore Guard Error]: ${msg}`);
    }
    return fallback;
  }
}
