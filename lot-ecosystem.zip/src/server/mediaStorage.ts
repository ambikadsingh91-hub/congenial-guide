import { Firestore, doc, setDoc, getDoc, Bytes } from 'firebase/firestore';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { Request, Response } from 'express';

const CHUNK_SIZE = 600 * 1024; // 600KB chunks (safely within Firestore 1MB doc limit)

export interface PersistentMediaMeta {
  fileId: string;
  filename: string;
  mimeType: string;
  totalSize: number;
  totalChunks: number;
  uploaderId?: string;
  createdAt: string;
}

// Ensure base upload directories exist
const baseUploadDir = path.join(process.cwd(), 'uploads');
const shortsUploadDir = path.join(baseUploadDir, 'shorts');
const mediaUploadDir = path.join(baseUploadDir, 'media');
const appsUploadDir = path.join(baseUploadDir, 'apps');
const videosUploadDir = path.join(baseUploadDir, 'videos');

[baseUploadDir, shortsUploadDir, mediaUploadDir, appsUploadDir, videosUploadDir].forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

/**
 * Persistently stores a media buffer to both local disk (for high-speed streaming)
 * and Cloud Firestore binary chunks (so media NEVER disappears on container restart).
 */
export async function savePersistentMedia(
  db: Firestore,
  options: {
    fileId?: string;
    filename: string;
    mimeType: string;
    buffer: Buffer;
    subfolder?: 'shorts' | 'media' | 'apps' | 'videos';
    uploaderId?: string;
  }
): Promise<{ fileId: string; filename: string; url: string; size: number }> {
  const fileId = options.fileId || 'media_' + crypto.randomUUID();
  const subfolder = options.subfolder || 'media';
  const targetDir = path.join(baseUploadDir, subfolder);
  const filePath = path.join(targetDir, options.filename);

  // 1. Write to local disk cache
  fs.writeFileSync(filePath, options.buffer);

  // 2. Break buffer into chunks and persist in Cloud Firestore
  const totalSize = options.buffer.length;
  const totalChunks = Math.ceil(totalSize / CHUNK_SIZE);
  const now = new Date().toISOString();

  const metaDoc: PersistentMediaMeta = {
    fileId,
    filename: options.filename,
    mimeType: options.mimeType,
    totalSize,
    totalChunks,
    uploaderId: options.uploaderId,
    createdAt: now,
  };

  // Save metadata
  await setDoc(doc(db, 'media_files', fileId), metaDoc);

  // Map filename to fileId for instant lookup by filename
  const cleanDocName = options.filename.replace(/[/\\?%*:|"<>]/g, '_');
  await setDoc(doc(db, 'media_files_by_name', cleanDocName), {
    fileId,
    filename: options.filename,
    mimeType: options.mimeType,
    totalSize,
    createdAt: now,
  });

  // Save binary chunks (using native Firestore Bytes type, not base64)
  const chunkPromises: Promise<any>[] = [];
  for (let i = 0; i < totalChunks; i++) {
    const start = i * CHUNK_SIZE;
    const end = Math.min(start + CHUNK_SIZE, totalSize);
    const chunkBuffer = options.buffer.subarray(start, end);
    const chunkId = `${fileId}_chunk_${i}`;

    chunkPromises.push(
      setDoc(doc(db, 'media_chunks', chunkId), {
        fileId,
        chunkIndex: i,
        data: Bytes.fromUint8Array(chunkBuffer),
        size: chunkBuffer.length,
        createdAt: now,
      })
    );
  }

  await Promise.all(chunkPromises);

  const url = subfolder === 'shorts' ? `/uploads/shorts/${options.filename}` : `/api/media/${fileId}/${options.filename}`;
  return { fileId, filename: options.filename, url, size: totalSize };
}

/**
 * Rehydrates a media file from Firestore chunks to local disk cache if container restarted.
 */
export async function rehydrateMediaFromFirestore(
  db: Firestore,
  fileIdOrFilename: string,
  targetFilePath: string
): Promise<{ buffer: Buffer; mimeType: string } | null> {
  try {
    let fileDocSnap = await getDoc(doc(db, 'media_files', fileIdOrFilename));

    // If not found by fileId, query by filename mapping
    if (!fileDocSnap.exists()) {
      const cleanDocName = path.basename(fileIdOrFilename).replace(/[/\\?%*:|"<>]/g, '_');
      const nameSnap = await getDoc(doc(db, 'media_files_by_name', cleanDocName));
      if (nameSnap.exists()) {
        const mappedFileId = nameSnap.data().fileId;
        fileDocSnap = await getDoc(doc(db, 'media_files', mappedFileId));
      }
    }

    if (!fileDocSnap.exists()) {
      // Check if fileId is in filename prefix (e.g. media_123_...)
      const cleanName = path.basename(fileIdOrFilename);
      const parts = cleanName.split('_');
      if (parts.length > 1) {
        const checkSnap = await getDoc(doc(db, 'media_files', parts[0]));
        if (checkSnap.exists()) fileDocSnap = checkSnap;
      }
    }

    if (!fileDocSnap.exists()) {
      return null;
    }

    const meta = fileDocSnap.data() as PersistentMediaMeta;
    const chunkBuffers: Buffer[] = [];

    // Fetch all chunks
    for (let i = 0; i < meta.totalChunks; i++) {
      const chunkId = `${meta.fileId}_chunk_${i}`;
      const chunkSnap = await getDoc(doc(db, 'media_chunks', chunkId));
      if (!chunkSnap.exists()) {
        console.error(`Missing chunk ${i} for file ${meta.fileId}`);
        return null;
      }
      const chunkData = chunkSnap.data();
      const uint8 = (chunkData.data as any).toUint8Array();
      chunkBuffers.push(Buffer.from(uint8));
    }

    const fullBuffer = Buffer.concat(chunkBuffers);

    // Save back to local disk cache
    const parentDir = path.dirname(targetFilePath);
    if (!fs.existsSync(parentDir)) {
      fs.mkdirSync(parentDir, { recursive: true });
    }
    fs.writeFileSync(targetFilePath, fullBuffer);

    return { buffer: fullBuffer, mimeType: meta.mimeType };
  } catch (err) {
    console.error('Error rehydrating media from Firestore:', err);
    return null;
  }
}

/**
 * Streams media with HTTP 206 Partial Content support for videos and rich media.
 */
export function streamMediaFile(
  req: Request,
  res: Response,
  filePath: string,
  mimeType: string
) {
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('Media not found');
  }

  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Content-Type', mimeType);

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;

    if (start >= fileSize || end >= fileSize) {
      res.status(416).setHeader('Content-Range', `bytes */${fileSize}`);
      return res.end();
    }

    const chunksize = end - start + 1;
    const file = fs.createReadStream(filePath, { start, end });

    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Content-Length': chunksize,
      'Content-Type': mimeType,
    });

    file.pipe(res);
  } else {
    res.writeHead(200, {
      'Content-Length': fileSize,
      'Content-Type': mimeType,
    });
    fs.createReadStream(filePath).pipe(res);
  }
}
