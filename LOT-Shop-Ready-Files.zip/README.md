# LOT Shop

GitHub Pages-ready frontend prototype.

## Files
- `index.html`
- `style.css`
- `script.js`

## Demo admin
Username: `Virat`
Password: `9825727203`

This admin credential is only a local demo convenience. It is NOT secure production authentication because GitHub Pages is public and all JavaScript is visible to visitors.

## Important for production
Connect the service layer in `script.js` to your real LOT API. The API/server must be the source of truth for accounts, passwords, balances, listing ownership, stock, purchases, seller payouts, and transactions. Never put a secret/service-role key or plaintext production password in this repository.

## GitHub Pages
Put these files directly in the repository root and enable:
Settings → Pages → Deploy from branch → `main` → `/ (root)`.
