/* LOT Shop client demo.
   Replace the API functions in the SERVICE LAYER when the real LOT API is provided.
   The Virat admin account below is intentionally only a local development demo.
   NEVER use a frontend password as production admin authentication. */

const ADMIN_USER="Virat";
const ADMIN_PASSWORD="9825727203";

const state={user:null,items:[],selected:null,buying:false};

function load(){
  state.items=JSON.parse(localStorage.getItem("lot_items")||"[]");
  state.user=JSON.parse(sessionStorage.getItem("lot_user")||"null");
  if(state.user){showApp();render()}else showAuth("login");
}
function saveItems(){localStorage.setItem("lot_items",JSON.stringify(state.items))}
function showAuth(mode){
  document.getElementById("loginForm").classList.toggle("hidden",mode!=="login");
  document.getElementById("signupForm").classList.toggle("hidden",mode!=="signup");
  document.getElementById("loginTab").classList.toggle("active",mode==="login");
  document.getElementById("signupTab").classList.toggle("active",mode==="signup");
}
function login(e){
  e.preventDefault();
  const u=document.getElementById("loginUser").value.trim(),p=document.getElementById("loginPass").value;
  if(u===ADMIN_USER&&p===ADMIN_PASSWORD){
    state.user={username:ADMIN_USER,balance:100000,isAdmin:true,listings:0,purchases:0,sales:0};
    sessionStorage.setItem("lot_user",JSON.stringify(state.user)); showApp(); render(); toast("Admin login successful"); return;
  }
  const users=JSON.parse(localStorage.getItem("lot_users")||"[]");
  const found=users.find(x=>(x.username.toLowerCase()===u.toLowerCase()||x.email.toLowerCase()===u.toLowerCase())&&x.password===p);
  if(!found){document.getElementById("loginMsg").textContent="Invalid username/email or password.";return}
  state.user={username:found.username,balance:found.balance||0,isAdmin:false,listings:0,purchases:0,sales:0};
  sessionStorage.setItem("lot_user",JSON.stringify(state.user));showApp();render();toast("Welcome back, "+state.user.username);
}
function signup(e){
  e.preventDefault();
  const u=document.getElementById("signupUser").value.trim(),em=document.getElementById("signupEmail").value.trim(),p=document.getElementById("signupPass").value,c=document.getElementById("signupConfirm").value;
  const msg=document.getElementById("signupMsg");
  if(p.length<8){msg.textContent="Password must be at least 8 characters.";return}
  if(p!==c){msg.textContent="Passwords do not match.";return}
  const users=JSON.parse(localStorage.getItem("lot_users")||"[]");
  if(users.some(x=>x.username.toLowerCase()===u.toLowerCase()||x.email.toLowerCase()===em.toLowerCase())){msg.textContent="Username or email already exists.";return}
  users.push({username:u,email:em,password:p,balance:0});localStorage.setItem("lot_users",JSON.stringify(users));
  state.user={username:u,balance:0,isAdmin:false,listings:0,purchases:0,sales:0};sessionStorage.setItem("lot_user",JSON.stringify(state.user));showApp();render();toast("Account created");
}
function showApp(){document.getElementById("authScreen").classList.add("hidden");document.getElementById("app").classList.remove("hidden")}
function logout(){state.user=null;sessionStorage.removeItem("lot_user");document.getElementById("app").classList.add("hidden");document.getElementById("authScreen").classList.remove("hidden");showAuth("login")}
function render(){
  if(!state.user)return;
  document.getElementById("navUser").textContent=state.user.username+(state.user.isAdmin?" (Admin)":"");
  document.getElementById("balance").textContent=fmt(state.user.balance);
  const q=(document.getElementById("search").value||"").toLowerCase(),cat=document.getElementById("category").value;
  const list=state.items.filter(i=>i.active!==false&&(cat==="all"||i.category===cat)&&(`${i.name} ${i.seller}`.toLowerCase().includes(q)));
  document.getElementById("items").innerHTML=list.length?list.map(card).join(""):`<p class="muted">No items found. Be the first to list something!</p>`;
  const mine=state.items.filter(i=>i.seller===state.user.username);
  document.getElementById("stats").innerHTML=[["Balance",fmt(state.user.balance)+" LOT"],["Listings",mine.length],["Purchases",state.user.purchases||0],["Sales",state.user.sales||0]].map(x=>`<div class="stat"><small class="muted">${x[0]}</small><b>${x[1]}</b></div>`).join("");
  document.getElementById("myListings").innerHTML=mine.length?mine.map(i=>`<div class="listing-row"><div><b>${esc(i.name)}</b><br><small class="muted">${fmt(i.price)} LOT · Stock ${i.stock}</small></div><span>${i.active===false?"Disabled":"Active"}</span>${state.user.isAdmin||i.seller===state.user.username?`<button class="secondary-btn" onclick="toggleListing(${i.id})">${i.active===false?"Enable":"Disable"}</button><button class="danger" onclick="removeItem(${i.id})">Remove</button>`:""}</div>`).join(""):`<p class="muted">You have no listings.</p>`;
}
function card(i){return `<article class="item-card"><img class="item-image" src="${esc(i.image)}" alt=""><div class="item-content"><h3>${esc(i.name)}</h3><p class="seller">Seller: ${esc(i.seller)}</p><p class="seller">${esc(i.description||"")}</p><div class="item-bottom"><div><div class="price">${fmt(i.price)} LOT</div><div class="stock">Stock: ${i.stock}</div></div></div><button class="buy-btn" onclick="openPurchase(${i.id})" ${i.stock<1?"disabled":""}>${i.stock<1?"Out of Stock":"Buy Now"}</button></div></article>`}
function createListing(){
  const name=document.getElementById("itemName").value.trim(),price=Number(document.getElementById("itemPrice").value),stock=Number(document.getElementById("itemStock").value),cat=document.getElementById("itemCategory").value,desc=document.getElementById("itemDescription").value.trim(),file=document.getElementById("itemImage").files[0];
  if(!name||price<=0||stock<=0||!file){toast("Enter all listing details and choose an image.");return}
  if(file.size>5*1024*1024){toast("Image must be 5MB or smaller.");return}
  const reader=new FileReader();reader.onload=()=>{state.items.push({id:Date.now(),name,price,stock,category:cat,description:desc,seller:state.user.username,image:reader.result,active:true});saveItems();render();toast("Listing published");document.getElementById("itemName").value="";document.getElementById("itemPrice").value="";document.getElementById("itemStock").value="";document.getElementById("itemDescription").value="";document.getElementById("itemImage").value=""};reader.readAsDataURL(file)
}
function openPurchase(id){
  if(!state.user){return}
  state.selected=state.items.find(i=>i.id===id);if(!state.selected)return;
  document.getElementById("pName").textContent="Purchase "+state.selected.name+"?";
  document.getElementById("pPrice").textContent=fmt(state.selected.price);
  document.getElementById("pStock").textContent=state.selected.stock;
  document.getElementById("pBalance").textContent=fmt(state.user.balance);
  document.getElementById("pRemaining").textContent=fmt(state.user.balance-state.selected.price);
  document.getElementById("purchaseModal").classList.add("active");
}
function closePurchase(){document.getElementById("purchaseModal").classList.remove("active");state.selected=null}
function buy(){
  if(state.buying||!state.selected)return;state.buying=true;
  const i=state.items.find(x=>x.id===state.selected.id);
  if(!i||i.stock<=0){toast("Out of stock.");state.buying=false;closePurchase();return}
  if(i.seller===state.user.username){toast("You cannot buy your own item.");state.buying=false;return}
  if(state.user.balance<i.price){toast("Insufficient LOT balance.");state.buying=false;return}
  state.user.balance-=i.price;i.stock--;state.user.purchases=(state.user.purchases||0)+1;
  if(!i.sales)i.sales=0;i.sales++;
  if(!i.sellerBalance)i.sellerBalance=0;i.sellerBalance+=i.price;
  sessionStorage.setItem("lot_user",JSON.stringify(state.user));saveItems();closePurchase();render();toast("Purchase successful");state.buying=false;
}
function toggleListing(id){const i=state.items.find(x=>x.id===id);if(i&&(state.user.isAdmin||i.seller===state.user.username)){i.active=i.active===false;saveItems();render();toast(i.active?"Listing enabled":"Listing disabled")}}
function removeItem(id){const i=state.items.find(x=>x.id===id);if(!i)return;if(!(state.user.isAdmin||i.seller===state.user.username)){toast("You cannot remove this listing.");return}state.items=state.items.filter(x=>x.id!==id);saveItems();render();toast("Listing removed")}
function fmt(n){return Number(n||0).toLocaleString("en-US")}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function toast(m){const t=document.getElementById("toast");t.textContent=m;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2500)}
load();

/*
PRODUCTION API SERVICE LAYER TO ADD LATER:
loginUser(), getCurrentUser(), getLotBalance(), getListings(),
createListing(), updateListing(), deleteListing(), purchaseItem(), getTransactions().
For production, authentication, balances, prices, stock, admin permissions,
uploads and purchases MUST be checked by the server/real API. This local demo
does not provide secure real-money/LOT accounting.
*/
